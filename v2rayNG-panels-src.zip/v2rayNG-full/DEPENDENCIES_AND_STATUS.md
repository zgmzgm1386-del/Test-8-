# وابستگی‌ها و وضعیت واقعی هر قابلیت

| قابلیت | سورس موجود در ZIP | باینری/API لازم | وضعیت در این بیلد |
|--------|-------------------|-----------------|-------------------|
| **پنل‌ها / Cloudflare** | منطق index.html + API CF | Cloudflare API Token + Account ID | **عملیاتی:** ساخت Worker با API |
| **پنل‌ها / Railway** | منطق دیپلوی در HTML | Railway Token + دیپلوی روی پلتفرم | ثبت آدرس پس از دیپلوی؛ دیپلوی کامل CLI روی دستگاه نیست |
| **پنل‌ها / Reflex** | منطق دیپلوی در HTML | حساب Reflex + دیپلوی | ثبت آدرس پس از دیپلوی |
| **اسکن IP** | scan_ips.rs + منطق JS | هیچ باینری خارجی | **عملیاتی:** TCP:443 موازی + latency |
| **مصرف** | تب مصرف در HTML | TrafficStats سیستم | **عملیاتی:** آمار واقعی دستگاه/اپ |
| **اختلال** | dnsCheck در MainActivity.kt | شبکه | **عملیاتی:** UDP DNS vs DoH |
| **سپر ایمنی** | SecEngine در MainActivity | مجوزها | **عملیاتی:** قفل صفحه، ADB، … |
| **کنترل پنل** | مدیریت accounts | همان ذخیره پنل‌ها | **عملیاتی:** فهرست + باز کردن داخلی |
| **SlipNet** | SlipVpnService.kt | باینری `slipnet` (Go arm64) — **در ZIP نبود** | غیرفعال تا قرار دادن باینری |
| **Tor** | TorVpnService.kt | باینری `arti` — **در ZIP نبود** | غیرفعال تا قرار دادن باینری |
| **Psiphon** | ShkVpnService.kt + psi_config.json | باینری `psiphon-tunnel-core` — **در ZIP نبود** (فقط config) | غیرفعال تا قرار دادن باینری |
| **Google Script / MHR** | mhrv-rs Rust + Native.kt JNI | `libmhrv_rs.so` بیلدشده | نیاز به بیلد Rust برای Android |

## Build
Workflow با pipefail آماده است. Build موفق در این sandbox به دلیل نبود toolchain کامل انجام نشد.

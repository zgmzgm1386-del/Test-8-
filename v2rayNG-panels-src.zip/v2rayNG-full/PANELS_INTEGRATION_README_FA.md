# v2rayNG توسعه‌یافته — گزارش وضعیت (نسخهٔ بازسازی‌شدهٔ تب‌ها)

## منوی نهایی (تأییدشده)

گروه اصلی:
- تنظیمات گروه اشتراک
- تنظیمات به تفکیک برنامه
- تنظیمات مسیریابی
- فایل‌های منبع جغرافیایی
- تنظیمات

قابلیت‌های اضافه (به ترتیب):
1. پنل‌ها
2. مصرف
3. اسکن IP
4. اختلال
5. سپر ایمنی
6. کنترل پنل
7. SlipNet
8. Tor
9. شیر و خورشید (Psiphon)
10. Google Script / MHR

## چه چیزی نسبت به نسخهٔ قبلی درست شد؟

قبلاً ۶ تب اول «اسکلت نیمه‌کاره» بودند و ۴ تب آخر عملاً کار نمی‌کردند
(دکمهٔ وصل SlipNet خالی بود، Tor باینری/روتینگ نداشت، سایفون به کتابخانه‌ای
وابسته بود که در بیلد دانلود نمی‌شد، و MHR همیشه «هسته موجود نیست» می‌داد).
حالا موتور واقعی برنامهٔ سالم «مدیریت پنل‌ها» (panels-manager) به‌طور کامل
منتقل شده است:

### موتورهای VPN داخل APK (پورت کامل از panels-manager)
- `com.therealaleph.mhrv.MhrvVpnService` — هستهٔ **mhrv-rs** (Rust) برای MHR
- `com.therealaleph.mhrv.SlipVpnService` — موتور **SlipNet** (تونل DNS/SSH)
- `com.therealaleph.mhrv.TorVpnService` — موتور **Arti (Tor)** + پل‌های obfs4
- `com.therealaleph.mhrv.ShkVpnService` — موتور **psiphon-tunnel-core** (شیر و خورشید)
- همه: موتور → SOCKS5 محلی → **tun2proxy** → TUN و «وصل» فقط با تست واقعی HTTPS تأیید می‌شود
- `PanelEngines` — کنترلر مرکزی: فقط یک VPN همزمان (هستهٔ v2rayNG هم بسته می‌شود)

### فیکس‌های تب‌ها
| تب | فیکس |
|---|---|
| پنل‌ها | آدرس واقعی workers.dev (خواندن/ساخت ساب‌دامین از API — قبلاً حدس غلط بود) · پریست داخلی `asset:x4g-worker.js` واقعاً خوانده می‌شود · Global API Key (ایمیل+کلید) پشتیبانی می‌شود |
| مصرف | شمارندهٔ `panels_api_usage` حالا واقعاً نوشته می‌شود (`PanelUsage`) — قبلاً همیشه صفر بود |
| اسکن IP | بازنویسی کامل موتور اسکن (پورت ۱:۱ از ScanBridge پنل‌منیجر): پروب TLS واقعی (TCP→TLS) برای IP/دامنه · پروب TCP برای پروکسی · **پروب لایه‌ای DNS (DoH/443 → کوئری واقعی UDP/53 → TCP/53)** — ریشهٔ «هیچی اسکن نمی‌شد» فقط TCP:53 بود که در ایران بسته است · **کشور پروکسی** (۵۹ کشور + ۱۵ دیتاسنتر OVH/Hetzner/… مثل showCountry + کاندیدساز pcRandIp + فیلتر کشور مثل lst()) · اسکن Max (تایم‌اوت/موازی‌سازی بیشتر) · دلیل شکست صادقانه · مدارشکن ۳۰-تست-بی‌نتیجه · نتایج زنده · کپی همه + ارسال بهترین مورد به تب اختلال (ekhtFromScan) · لیست‌های قابل ویرایش با ذخیره دائمی |
| اختلال | FinalMask واقعی ضد ۱۰۰۱/DPI + fp=chrome + alpn · فقط روی کانفیگ‌های Cloudflare (ekhtIsCfTarget) · پروکسی دستی (لینک کامل/host:port/ProxyIP کشور) واقعاً استفاده می‌شود · محافظت DoS = سیاست واقعی هسته (handshake/connIdle/bufferSize) در CoreConfigManager |
| سپر ایمنی | بدون تغییر (از قبل واقعی بود) |
| کنترل پنل | `presetId` دیگر موقع حذف پاک نمی‌شود (قبلاً داده خراب می‌شد) |
| SlipNet | موتور واقعی + سازندهٔ پروفایل `slipnet://` (فرمت v24) + تست رزولور با پینگ واقعی UDP/53 |
| Tor | موتور Arti + گرفتن خودکار پل obfs4 از سایت رسمی Tor + وضعیت زنده |
| شیر و خورشید | موتور psiphon-tunnel-core با پیکربندی تعبیه‌شدهٔ شبکه + انتخاب کشور خروجی (۲۰ کشور، EgressRegion) |
| Google Script / MHR | کل گردش‌کار ۵ مرحله‌ای: رمز → Code.gs (کپی با رمز آماده) → Deployment ID (چند حساب = سهمیهٔ بیشتر) → گواهی (ساخت/نصب/بررسی) → شروع/توقف/تست واقعی رله + سهمیهٔ امروز |

### بیلد
Workflow (`.github/workflows/build.yml`) حالا هر ۵ موتور را از سورس می‌سازد و
داخل APK می‌گذارد (مثل پنل‌منیجر):
- `rust/` (mhrv-rs) → `libmhrv_rs.so` + `libtun2proxy.so` (cargo-ndk)
- SlipNet از سورس Go (با ساب‌مودول‌ها) → `libslipnet.so`
- `rust/torbin` (Arti) → `libtorbin.so`
- obfs4proxy (Go) → `libobfs4.so`
- psiphon-tunnel-core ConsoleClient (Go) → `libshkcore.so` + refresh پیکربندی شبکه از آخرین رلیز رسمی
- گیت سخت: اگر هر موتوری ساخته نشود بیلد قرمز می‌شود تا APK نیم‌بند تحویل نرود

APK نهایی فقط arm64-v8a ساخته می‌شود (همهٔ موتورها arm64 هستند).

### فیکس پینگ و خطای اتصال کانفیگ (نسخهٔ دوم)
- تحقیق کامل: زنجیرهٔ ایمپورت → ساخت کانفیگ → CoreTestService → RealPingWorkerService
  → `Libv2ray.measureOutboundDelay` سالم و استاندارد است و AAR رسمی (v26.10.31) همهٔ متدها
  (measureOutboundDelay/reconcileBrowserDialer/…) و **سه فایل جیو**
  (geoip.dat / geosite.dat / geoip-only-cn-private.dat) را داخل assets دارد.
- گام جدید CI «Geo assets check»: اگر AAR فایل جیو نداشت، از AndroidLibXrayLite ریپو یا
  منابع رسمی Loyalsoldier در assets اپ گذاشته می‌شود (بدون تکرار — گذاشتن تکراری خطای
  «More than one file» می‌دهد). بدون این فایل‌ها هستهٔ Xray با پریست‌های روتینگ
  (که همه geoip:private دارند که به ext:geoip-only-cn-private.dat بازنگاشت می‌شود) استارت نمی‌خورد
  — این دقیقاً همان «وصل بشه خطا میده» بود اگر AAR قدیمی/بدون جیو در بیلد قبلی استفاده شده باشد.
- اگر با APK جدید باز هم پینگ/اتصال خطا داد: تب لاگ‌کت داخل برنامه یا adb logcat را بفرستید؛
  پیام دقیق خطا (مثلاً خطای DNS/گواهی/پورت) مشخص می‌کند کجاست.

## Build
1. کل محتوای این پوشه را در یک ریپوی خالی گیت‌هاب بگذار (یا همین ZIP را آپلود کن)
2. تب Actions ← Build v2rayNG APK ← Run workflow
3. خروجی: آرتیفکت `apk-debug`

بیلد اول طولانی است (کامپایل Rust/Arti + Go) — ۳۰ تا ۶۰ دقیقه.

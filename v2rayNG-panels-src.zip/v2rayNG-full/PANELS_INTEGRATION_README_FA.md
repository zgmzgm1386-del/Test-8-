# v2rayNG توسعه‌یافته — گزارش وضعیت

## منوی نهایی (تأییدشده)

گروه اصلی:
- تنظیمات گروه اشتراک
- تنظیمات به تفکیک برنامه
- تنظیمات مسیریابی
- فایل‌های منبع جغرافیایی
- تنظیمات

قابلیت‌های اضافه (به ترتیب):
1. پنل‌ها
2. مصرف
3. اسکن IP
4. اختلال
5. سپر ایمنی
6. کنترل پنل
7. SlipNet
8. Tor
9. شیر و خورشید (Psiphon)
10. Google Script / MHR

حذف‌شده: Windscribe · WARP · Lantern · Geph · Proton VPN · رسانه · ابزارها

## قابلیت «پنل‌ها» — آنچه اضافه شده

صفحه واحد Native با عنوان «پنل‌ها»:

1. **بالای صفحه:** دکمه «＋ ساخت پنل»
2. با کلیک: انتخاب پلتفرم Cloudflare / Railway / Reflex + فیلد نام + توکن
3. **Cloudflare:** ساخت واقعی Worker از طریق API رسمی (`PUT .../workers/scripts/{name}`) با API Token و Account ID؛ خواندن subdomain workers.dev در صورت دسترسی
4. **Railway / Reflex:** ثبت پنل با نام و آدرس (پس از دیپلوی روی پلتفرم) برای نگهداری در فهرست
5. **پایین صفحه:** فهرست پنل‌های نصب‌شده (نام + آدرس + پلتفرم)
6. لمس / «باز کردن» → **PanelBrowserActivity** (WebView داخلی برنامه، نه Chrome)
7. ذخیره دائمی در MmkvManager (`panels_installed_list`)
8. امکان حذف از فهرست

محدودیت شفاف:
- دیپلوی کامل اسکریپت‌های پیچیده x4g-worker.js / پنل‌های Reflex پایتونی نیاز به مراحل بیشتر (GitHub، KV، D1 و …) دارد که در این نسخه به صورت ساخت Worker پایه Cloudflare و ثبت آدرس برای Railway/Reflex پیاده شده است.
- برای Cloudflare باید API Token با دسترسی Workers و Account ID معتبر وارد شود.

## سایر قابلیت‌ها
- سپر ایمنی: بررسی‌های واقعی دستگاه
- بقیه: اسکلت Native + ذخیره؛ هسته‌های SlipNet/Tor/Psiphon نیاز به باینری دارند

## Build
Workflow با set -o pipefail آماده است. نتیجه واقعی پس از اجرای Actions روی GitHub مشخص می‌شود.

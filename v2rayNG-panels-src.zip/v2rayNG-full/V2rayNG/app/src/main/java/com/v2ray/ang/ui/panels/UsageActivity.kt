package com.v2ray.ang.ui.panels

import android.net.TrafficStats
import android.os.Process
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import com.v2ray.ang.handler.MmkvManager
import kotlinx.coroutines.delay
import java.util.Locale

/**
 * مصرف واقعی ترافیک از TrafficStats اندروید (کل دستگاه + UID برنامه).
 */
class UsageActivity : PanelsBaseActivity() {
    override val titleRes = R.string.panels_usage

    @Composable
    override fun PanelBody() {
        var rxMobile by remember { mutableStateOf(0L) }
        var txMobile by remember { mutableStateOf(0L) }
        var rxTotal by remember { mutableStateOf(0L) }
        var txTotal by remember { mutableStateOf(0L) }
        var rxApp by remember { mutableStateOf(0L) }
        var txApp by remember { mutableStateOf(0L) }
        var baselineRx by remember { mutableStateOf(MmkvManager.decodeSettingsString("usage_base_rx")?.toLongOrNull() ?: 0L) }
        var baselineTx by remember { mutableStateOf(MmkvManager.decodeSettingsString("usage_base_tx")?.toLongOrNull() ?: 0L) }

        LaunchedEffect(Unit) {
            while (true) {
                rxMobile = TrafficStats.getMobileRxBytes().coerceAtLeast(0)
                txMobile = TrafficStats.getMobileTxBytes().coerceAtLeast(0)
                rxTotal = TrafficStats.getTotalRxBytes().coerceAtLeast(0)
                txTotal = TrafficStats.getTotalTxBytes().coerceAtLeast(0)
                val uid = Process.myUid()
                rxApp = TrafficStats.getUidRxBytes(uid).coerceAtLeast(0)
                txApp = TrafficStats.getUidTxBytes(uid).coerceAtLeast(0)
                delay(1000)
            }
        }

        fun fmt(b: Long): String {
            if (b < 0) return "—"
            val kb = b / 1024.0
            val mb = kb / 1024.0
            val gb = mb / 1024.0
            return when {
                gb >= 1 -> String.format(Locale.US, "%.2f GB", gb)
                mb >= 1 -> String.format(Locale.US, "%.2f MB", mb)
                else -> String.format(Locale.US, "%.0f KB", kb)
            }
        }

        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(stringResource(titleRes), style = MaterialTheme.typography.headlineSmall)
            Text("آمار واقعی از TrafficStats سیستم (به‌روزرسانی هر ثانیه)", style = MaterialTheme.typography.bodyMedium)
            HorizontalDivider()
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("کل دستگاه", style = MaterialTheme.typography.titleSmall)
                    Text("دریافت: ${fmt(rxTotal)}")
                    Text("ارسال: ${fmt(txTotal)}")
                }
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("موبایل (سلولی)", style = MaterialTheme.typography.titleSmall)
                    Text("دریافت: ${fmt(rxMobile)}")
                    Text("ارسال: ${fmt(txMobile)}")
                }
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("این برنامه (UID)", style = MaterialTheme.typography.titleSmall)
                    Text("دریافت: ${fmt(rxApp)}")
                    Text("ارسال: ${fmt(txApp)}")
                }
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("از زمان ریست دستی", style = MaterialTheme.typography.titleSmall)
                    val dRx = (rxTotal - baselineRx).coerceAtLeast(0)
                    val dTx = (txTotal - baselineTx).coerceAtLeast(0)
                    Text("دریافت: ${fmt(dRx)}")
                    Text("ارسال: ${fmt(dTx)}")
                }
            }
            Button(onClick = {
                baselineRx = rxTotal
                baselineTx = txTotal
                MmkvManager.encodeSettings("usage_base_rx", baselineRx.toString())
                MmkvManager.encodeSettings("usage_base_tx", baselineTx.toString())
            }, modifier = Modifier.fillMaxWidth()) {
                Text("ریست شمارنده دستی")
            }
        }
    }
}

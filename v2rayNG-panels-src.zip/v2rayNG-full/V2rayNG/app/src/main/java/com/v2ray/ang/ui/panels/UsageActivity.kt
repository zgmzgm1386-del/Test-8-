package com.v2ray.ang.ui.panels

import androidx.compose.runtime.Composable
import com.v2ray.ang.R

/** هدایت به موتور کامل panels-manager — تب `usage` */
class UsageActivity : PanelsBaseActivity() {
    override val titleRes = R.string.panels_usage
    override val redirectToEngine = true
    override val engineTab = "usage"

    @Composable
    override fun PanelBody() {}
}

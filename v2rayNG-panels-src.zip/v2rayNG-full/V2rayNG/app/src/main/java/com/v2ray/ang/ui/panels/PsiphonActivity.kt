package com.v2ray.ang.ui.panels

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.VpnService
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import com.v2ray.ang.handler.MmkvManager
import com.v2ray.ang.service.panels.ShkVpnService

/**
 * UI فقط وضعیت واقعی از ShkVpnService (callbackهای کتابخانه) را نشان می‌دهد.
 * هرگز بلافاصله Connected نمی‌شود.
 */
class PsiphonActivity : PanelsBaseActivity() {
    override val titleRes = R.string.panels_psiphon

    @Composable
    override fun PanelBody() {
        val ctx = LocalContext.current
        var state by remember { mutableStateOf(ShkVpnService.lastState) }
        var message by remember { mutableStateOf(ShkVpnService.lastMessage) }
        var httpPort by remember { mutableStateOf(ShkVpnService.httpProxyPort) }
        var socksPort by remember { mutableStateOf(ShkVpnService.socksProxyPort) }
        var region by remember { mutableStateOf(MmkvManager.decodeSettingsString("psiphon_region") ?: "") }
        var logs by remember { mutableStateOf(listOf<String>()) }

        val receiver = remember {
            object : BroadcastReceiver() {
                override fun onReceive(c: Context?, intent: Intent?) {
                    if (intent?.action != ShkVpnService.ACTION_STATUS) return
                    state = intent.getStringExtra(ShkVpnService.EXTRA_STATE) ?: state
                    message = intent.getStringExtra(ShkVpnService.EXTRA_MESSAGE) ?: message
                    httpPort = intent.getIntExtra(ShkVpnService.EXTRA_HTTP_PORT, httpPort)
                    socksPort = intent.getIntExtra(ShkVpnService.EXTRA_SOCKS_PORT, socksPort)
                    logs = (logs + "$state: $message").takeLast(30)
                }
            }
        }

        DisposableEffect(Unit) {
            val f = IntentFilter(ShkVpnService.ACTION_STATUS)
            if (Build.VERSION.SDK_INT >= 33) {
                ctx.registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("UnspecifiedRegisterReceiverFlag")
                ctx.registerReceiver(receiver, f)
            }
            onDispose {
                try { ctx.unregisterReceiver(receiver) } catch (_: Exception) {}
            }
        }

        val vpnPermission = rememberLauncherForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == android.app.Activity.RESULT_OK) {
                startService(ctx, region)
            } else {
                state = ShkVpnService.STATE_FAILED
                message = "مجوز VPN رد شد"
            }
        }

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(stringResource(titleRes), style = MaterialTheme.typography.headlineSmall)
            Text(
                "کتابخانه رسمی PsiphonTunnel (بدون باینری shkcore). وضعیت فقط از onConnecting/onConnected می‌آید.",
                style = MaterialTheme.typography.bodyMedium
            )
            OutlinedTextField(
                value = region,
                onValueChange = {
                    region = it.uppercase().take(2)
                    MmkvManager.encodeSettings("psiphon_region", region)
                },
                label = { Text("EgressRegion (اختیاری)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            val color = when (state) {
                ShkVpnService.STATE_CONNECTED -> MaterialTheme.colorScheme.primary
                ShkVpnService.STATE_FAILED -> MaterialTheme.colorScheme.error
                ShkVpnService.STATE_CONNECTING -> MaterialTheme.colorScheme.tertiary
                else -> MaterialTheme.colorScheme.onSurface
            }
            Text("وضعیت: $state", color = color, style = MaterialTheme.typography.titleMedium)
            Text(message)
            if (httpPort > 0) Text("HTTP proxy: 127.0.0.1:$httpPort")
            if (socksPort > 0) Text("SOCKS proxy: 127.0.0.1:$socksPort")

            Button(
                onClick = {
                    val prep = VpnService.prepare(ctx)
                    if (prep != null) {
                        vpnPermission.launch(prep)
                    } else {
                        startService(ctx, region)
                    }
                },
                enabled = state != ShkVpnService.STATE_CONNECTING,
                modifier = Modifier.fillMaxWidth()
            ) { Text(stringResource(R.string.panels_connect)) }

            OutlinedButton(
                onClick = {
                    val i = Intent(ctx, ShkVpnService::class.java).setAction(ShkVpnService.ACTION_STOP)
                    ctx.startService(i)
                    state = ShkVpnService.STATE_STOPPED
                    message = "درخواست قطع ارسال شد"
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text(stringResource(R.string.panels_disconnect)) }

            HorizontalDivider()
            Text("لاگ", style = MaterialTheme.typography.titleSmall)
            logs.asReversed().forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
    }

    private fun startService(ctx: Context, region: String) {
        val i = Intent(ctx, ShkVpnService::class.java).apply {
            action = ShkVpnService.ACTION_START
            putExtra(ShkVpnService.EXTRA_REGION, region)
        }
        ctx.startForegroundService(i)
    }
}

package com.v2ray.ang.service.panels

import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.util.Log
import com.v2ray.ang.handler.MmkvManager
import java.util.concurrent.atomic.AtomicReference

/**
 * Central controller ensuring only one VPN tunnel is active at a time.
 * Coordinates between v2rayNG core service and extended Panels services.
 * Rules:
 * - Only one VPN active.
 * - Starting a Panels service stops the previous one (and v2ray if needed).
 * - Proper resource cleanup and status updates.
 */
object VpnServiceController {
    private const val TAG = "VpnServiceController"
    private val activeService = AtomicReference<Class<*>?>(null)

    enum class ServiceType {
        NONE, V2RAY, SLIPNET, TOR, PSIPHON, MHR, WARP, WINDSCRIBE, PROTON, GEPH, LANTERN
    }

    @Volatile
    var currentType: ServiceType = ServiceType.NONE
        private set

    fun requestStart(context: Context, type: ServiceType, serviceClass: Class<*>, extras: Intent.() -> Unit = {}) {
        Log.i(TAG, "requestStart $type (was ${currentType})")
        stopAll(context)
        val prepare = VpnService.prepare(context)
        if (prepare != null) {
            // Caller must handle permission; we just prepare intent
            Log.w(TAG, "VPN permission required")
        }
        val intent = Intent(context, serviceClass).apply {
            action = "START"
            extras()
        }
        try {
            context.startForegroundService(intent)
            activeService.set(serviceClass)
            currentType = type
            MmkvManager.encodeSettings("panels_active_vpn", type.name)
        } catch (t: Throwable) {
            Log.e(TAG, "start failed: ${t.message}")
            currentType = ServiceType.NONE
        }
    }

    fun stopAll(context: Context) {
        val cls = activeService.getAndSet(null)
        if (cls != null) {
            try {
                context.startService(Intent(context, cls).setAction("STOP"))
            } catch (_: Throwable) {}
        }
        // Also stop main v2ray if running (via existing LauncherManager if available)
        try {
            val launcher = Class.forName("com.v2ray.ang.core.LauncherManager")
            val stop = launcher.getMethod("stopService", Context::class.java)
            stop.invoke(null, context)
        } catch (_: Throwable) {}
        currentType = ServiceType.NONE
        MmkvManager.encodeSettings("panels_active_vpn", ServiceType.NONE.name)
        Log.i(TAG, "stopAll done")
    }

    fun isAnyRunning(): Boolean = currentType != ServiceType.NONE
}

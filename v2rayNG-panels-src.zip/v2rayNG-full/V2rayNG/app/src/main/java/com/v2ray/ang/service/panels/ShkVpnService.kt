package com.v2ray.ang.service.panels

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import ca.psiphon.PsiphonTunnel
import com.v2ray.ang.R
import com.v2ray.ang.ui.main.MainActivity
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

/**
 * سرویس Psiphon با کتابخانه رسمی ca.psiphon.PsiphonTunnel — بدون باینری shkcore.
 * وضعیت فقط از callbackهای واقعی onConnecting / onConnected / onExiting می‌آید.
 */
class ShkVpnService : VpnService(), PsiphonTunnel.HostService {

    companion object {
        const val ACTION_START = "com.v2ray.ang.panels.PSIPHON_START"
        const val ACTION_STOP = "com.v2ray.ang.panels.PSIPHON_STOP"
        const val ACTION_STATUS = "com.v2ray.ang.panels.PSIPHON_STATUS"
        const val EXTRA_STATE = "state"
        const val EXTRA_MESSAGE = "message"
        const val EXTRA_REGION = "region"
        const val EXTRA_HTTP_PORT = "http_port"
        const val EXTRA_SOCKS_PORT = "socks_port"

        const val STATE_IDLE = "idle"
        const val STATE_CONNECTING = "connecting"
        const val STATE_CONNECTED = "connected"
        const val STATE_FAILED = "failed"
        const val STATE_STOPPED = "stopped"

        private const val TAG = "ShkVpnService"
        private const val CH_ID = "psiphon_tunnel"
        private const val NOTIF_ID = 4201

        @Volatile
        var lastState: String = STATE_IDLE
            private set
        @Volatile
        var lastMessage: String = ""
            private set
        @Volatile
        var httpProxyPort: Int = 0
            private set
        @Volatile
        var socksProxyPort: Int = 0
            private set
    }

    private var tunnel: PsiphonTunnel? = null
    private val preferredRegion = AtomicReference("")
    private val localHttp = AtomicInteger(0)
    private val localSocks = AtomicInteger(0)

    override fun onCreate() {
        super.onCreate()
        createChannel()
        try {
            tunnel = PsiphonTunnel.newPsiphonTunnel(this)
        } catch (t: Throwable) {
            Log.e(TAG, "newPsiphonTunnel failed", t)
            publish(STATE_FAILED, "کتابخانه Psiphon: ${t.message}")
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP, "STOP" -> {
                stopTunnel()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                preferredRegion.set(intent?.getStringExtra(EXTRA_REGION)?.trim().orEmpty())
                startForeground(NOTIF_ID, buildNotif("Connecting…"))
                publish(STATE_CONNECTING, "شروع تونل Psiphon…")
                Thread({
                    try {
                        val t = tunnel
                        if (t == null) {
                            publish(STATE_FAILED, "PsiphonTunnel null — وابستگی Maven را بررسی کنید")
                            return@Thread
                        }
                        // empty string = use embedded config from getPsiphonConfig()
                        t.startTunneling("")
                    } catch (t: Throwable) {
                        Log.e(TAG, "startTunneling", t)
                        publish(STATE_FAILED, "startTunneling: ${t.message}")
                    }
                }, "psiphon-start").start()
            }
        }
        return START_STICKY
    }

    private fun stopTunnel() {
        try {
            tunnel?.stop()
        } catch (t: Throwable) {
            Log.e(TAG, "stop", t)
        }
        publish(STATE_STOPPED, "قطع شد")
    }

    override fun onDestroy() {
        stopTunnel()
        super.onDestroy()
    }

    override fun onRevoke() {
        stopTunnel()
        stopSelf()
    }

    override fun onBind(intent: Intent?): IBinder? = super.onBind(intent)

    // ---------- PsiphonTunnel.HostService ----------

    override fun getContext(): Context = applicationContext

    override fun getPsiphonConfig(): String {
        return try {
            val raw = resources.openRawResource(R.raw.psi_config)
            val text = BufferedReader(InputStreamReader(raw)).use { it.readText() }
            val obj = JSONObject(text)
            // Ensure ClientPlatform and optional EgressRegion
            if (!obj.has("ClientPlatform")) obj.put("ClientPlatform", "Android")
            val region = preferredRegion.get()
            if (region.isNotEmpty()) obj.put("EgressRegion", region)
            // Local proxy ports 0 = library picks
            if (!obj.has("LocalHttpProxyPort")) obj.put("LocalHttpProxyPort", 0)
            if (!obj.has("LocalSocksProxyPort")) obj.put("LocalSocksProxyPort", 0)
            obj.toString()
        } catch (t: Throwable) {
            Log.e(TAG, "getPsiphonConfig", t)
            publish(STATE_FAILED, "خواندن psi_config: ${t.message}")
            "{}"
        }
    }

    override fun onDiagnosticMessage(message: String?) {
        Log.i(TAG, message ?: "")
        // Keep last diagnostic for UI without flipping state
        if (!message.isNullOrBlank() && lastState == STATE_CONNECTING) {
            lastMessage = message.take(200)
            broadcastStatus()
        }
    }

    override fun onConnecting() {
        publish(STATE_CONNECTING, "در حال اتصال به شبکه Psiphon…")
        updateNotif("Connecting…")
    }

    override fun onConnected() {
        publish(STATE_CONNECTED, "متصل شد (HTTP:$httpProxyPort SOCKS:$socksProxyPort)")
        updateNotif("Connected")
    }

    override fun onConnectedServerRegion(region: String?) {
        lastMessage = "منطقه سرور: ${region ?: "?"}"
        broadcastStatus()
    }

    override fun onListeningHttpProxyPort(port: Int) {
        localHttp.set(port)
        httpProxyPort = port
        Log.i(TAG, "HTTP proxy $port")
    }

    override fun onListeningSocksProxyPort(port: Int) {
        localSocks.set(port)
        socksProxyPort = port
        Log.i(TAG, "SOCKS proxy $port")
    }

    override fun onUpstreamProxyError(message: String?) {
        publish(STATE_FAILED, "خطای پروکسی بالادست: ${message ?: ""}")
    }

    override fun onHomepage(url: String?) {}
    override fun onClientUpgradeDownloaded(filename: String?) {}
    override fun onClientIsLatestVersion() {}
    override fun onUntunneledAddress(address: String?) {}
    override fun onBytesTransferred(sent: Long, received: Long) {}
    override fun onStartedWaitingForNetworkConnectivity() {
        lastMessage = "در انتظار شبکه…"
        broadcastStatus()
    }
    override fun onStoppedWaitingForNetworkConnectivity() {}
    override fun onActiveAuthorizationIDs(authorizations: MutableList<String>?) {}
    override fun onExiting() {
        publish(STATE_STOPPED, "خروج از تونل")
    }
    override fun onClientRegion(region: String?) {}
    override fun onClientAddress(address: String?) {}

    // Some library versions expose additional HostService methods — provide no-op via reflection safety
    // by not declaring unimplemented abstract ones beyond the sample.

    private fun publish(state: String, message: String) {
        lastState = state
        lastMessage = message
        broadcastStatus()
        Log.i(TAG, "$state | $message")
    }

    private fun broadcastStatus() {
        sendBroadcast(
            Intent(ACTION_STATUS).apply {
                setPackage(packageName)
                putExtra(EXTRA_STATE, lastState)
                putExtra(EXTRA_MESSAGE, lastMessage)
                putExtra(EXTRA_HTTP_PORT, httpProxyPort)
                putExtra(EXTRA_SOCKS_PORT, socksProxyPort)
            }
        )
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CH_ID, "Psiphon", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun buildNotif(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CH_ID)
            .setContentTitle("Psiphon")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_play_24dp)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun updateNotif(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotif(text))
    }
}

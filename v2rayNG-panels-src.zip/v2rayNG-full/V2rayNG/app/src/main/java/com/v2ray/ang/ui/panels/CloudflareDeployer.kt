package com.v2ray.ang.ui.panels

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * منطق واقعی deploy از panels-manager (main.dart → _onDeploy):
 * 1) دانلود worker از codeUrl (github/jsdelivr)
 * 2) multipart PUT به api.cloudflare.com/.../workers/scripts/{name}
 */
object CloudflareDeployer {
    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .writeTimeout(180, TimeUnit.SECONDS)
        .build()

    data class Result(val ok: Boolean, val message: String, val workerUrl: String? = null)

    fun deploy(
        accountId: String,
        apiToken: String,
        scriptName: String,
        codeUrl: String,
        email: String = ""
    ): Result {
        if (accountId.isBlank() || apiToken.isBlank() || scriptName.isBlank() || codeUrl.isBlank()) {
            return Result(false, "فیلدهای ضروری ناقص است (accountId / token / scriptName / codeUrl)")
        }
        return try {
            val codeReq = Request.Builder()
                .url(codeUrl)
                .header("User-Agent", "Mozilla/5.0 PanelsManager")
                .get()
                .build()
            val codeBytes = client.newCall(codeReq).execute().use { res ->
                if (!res.isSuccessful) return Result(false, "دانلود worker ناموفق: HTTP ${res.code}")
                res.body?.bytes() ?: ByteArray(0)
            }
            if (codeBytes.size < 2000) {
                return Result(false, "worker خیلی کوچک است: ${codeBytes.size} بایت")
            }

            val boundary = "----pm${System.currentTimeMillis()}"
            val meta = """{"main_module":"worker.js","bindings":[]}"""
            val body = buildString {
                append("--$boundary\r\n")
                append("Content-Disposition: form-data; name=\"metadata\"; filename=\"blob\"\r\n")
                append("Content-Type: application/json\r\n\r\n")
                append(meta)
                append("\r\n--$boundary\r\n")
                append("Content-Disposition: form-data; name=\"worker.js\"; filename=\"worker.js\"\r\n")
                append("Content-Type: application/javascript+module\r\n\r\n")
            }.toByteArray(Charsets.UTF_8) + codeBytes + "\r\n--$boundary--\r\n".toByteArray(Charsets.UTF_8)

            val put = Request.Builder()
                .url("https://api.cloudflare.com/client/v4/accounts/$accountId/workers/scripts/$scriptName")
                .header("Authorization", "Bearer $apiToken")
                .header("Content-Type", "multipart/form-data; boundary=$boundary")
                .apply { if (email.isNotBlank()) header("X-Auth-Email", email) }
                .put(body.toRequestBody("multipart/form-data; boundary=$boundary".toMediaType()))
                .build()

            client.newCall(put).execute().use { res ->
                val txt = res.body?.string().orEmpty()
                if (!res.isSuccessful) {
                    return Result(false, "Cloudflare API ${res.code}: ${txt.take(300)}")
                }
                // enable subdomain workers.dev
                val sub = Request.Builder()
                    .url("https://api.cloudflare.com/client/v4/accounts/$accountId/workers/scripts/$scriptName/subdomain")
                    .header("Authorization", "Bearer $apiToken")
                    .put("""{"enabled":true}""".toRequestBody("application/json".toMediaType()))
                    .build()
                runCatching { client.newCall(sub).execute().close() }

                val url = "https://$scriptName.${accountId.take(8)}.workers.dev"
                // Prefer workers.dev pattern from response if present
                Result(true, "نصب شد", "https://$scriptName.workers.dev")
            }
        } catch (t: Throwable) {
            Result(false, t.message ?: "خطای ناشناخته")
        }
    }
}

package com.v2ray.ang.ui.panels

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

/**
 * اسکن IP واقعی: اتصال TCP موازی به پورت 443، اندازه‌گیری latency.
 * رنج‌های Cloudflare رایج + لیست قابل ویرایش.
 */
class IpScanActivity : PanelsBaseActivity() {
    override val titleRes = R.string.panels_ip_scan

    data class ScanResult(val ip: String, val ok: Boolean, val latencyMs: Long, val error: String = "")

    // Sample of Cloudflare edge IPs (public knowledge / common ranges used in similar tools)
    private val defaultTargets = listOf(
        "1.1.1.1", "1.0.0.1", "104.16.132.229", "104.17.176.12", "104.18.26.90",
        "104.21.12.34", "172.64.80.1", "172.67.74.224", "188.114.96.0", "188.114.97.0",
        "162.159.36.1", "162.159.46.1", "104.16.248.249", "104.16.249.249",
        "8.8.8.8", "8.8.4.4", "9.9.9.9", "208.67.222.222"
    )

    @Composable
    override fun PanelBody() {
        val scope = rememberCoroutineScope()
        var targets by remember { mutableStateOf(defaultTargets.joinToString("\n")) }
        var results by remember { mutableStateOf<List<ScanResult>>(emptyList()) }
        var scanning by remember { mutableStateOf(false) }
        var progress by remember { mutableStateOf("") }

        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Text(stringResource(titleRes), style = MaterialTheme.typography.headlineSmall)
            Text("اسکن TCP واقعی روی پورت 443 — اندازه‌گیری تأخیر موازی", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = targets,
                onValueChange = { targets = it },
                label = { Text("لیست IP (هر خط یک IP)") },
                modifier = Modifier.fillMaxWidth().height(120.dp)
            )
            Button(
                onClick = {
                    val list = targets.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }
                    if (list.isEmpty()) return@Button
                    scanning = true
                    results = emptyList()
                    progress = "0 / ${list.size}"
                    scope.launch {
                        val out = withContext(Dispatchers.IO) {
                            scanParallel(list) { done, total ->
                                // progress update on main via state is approximate
                            }
                        }
                        results = out.sortedBy { if (it.ok) it.latencyMs else Long.MAX_VALUE }
                        scanning = false
                        progress = "تمام — موفق: ${out.count { it.ok }} / ${out.size}"
                    }
                },
                enabled = !scanning,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (scanning) "در حال اسکن…" else "شروع اسکن") }
            if (progress.isNotEmpty()) Text(progress)
            Spacer(Modifier.height(8.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxSize()) {
                items(results) { r ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(r.ip)
                            Text(
                                if (r.ok) "${r.latencyMs} ms" else r.error.ifEmpty { "fail" },
                                color = if (r.ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }
    }

    private suspend fun scanParallel(ips: List<String>, onProgress: (Int, Int) -> Unit): List<ScanResult> = coroutineScope {
        val concurrency = 12
        val results = mutableListOf<ScanResult>()
        ips.chunked(concurrency).forEachIndexed { _, chunk ->
            val part = chunk.map { ip ->
                async(Dispatchers.IO) { scanOne(ip) }
            }.awaitAll()
            results.addAll(part)
            onProgress(results.size, ips.size)
        }
        results
    }

    private fun scanOne(ip: String): ScanResult {
        val start = System.nanoTime()
        return try {
            Socket().use { s ->
                s.soTimeout = 3000
                s.connect(InetSocketAddress(ip, 443), 3000)
                val ms = (System.nanoTime() - start) / 1_000_000
                ScanResult(ip, true, ms)
            }
        } catch (t: Throwable) {
            ScanResult(ip, false, -1, t.javaClass.simpleName)
        }
    }
}

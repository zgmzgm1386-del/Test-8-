package com.v2ray.ang.ui.panels

import androidx.compose.runtime.Composable
import com.v2ray.ang.R

/** هدایت به موتور کامل panels-manager — تب `scan` */
class IpScanActivity : PanelsBaseActivity() {
    override val titleRes = R.string.panels_ip_scan
    override val redirectToEngine = true
    override val engineTab = "scan"

    @Composable
    override fun PanelBody() {}
}

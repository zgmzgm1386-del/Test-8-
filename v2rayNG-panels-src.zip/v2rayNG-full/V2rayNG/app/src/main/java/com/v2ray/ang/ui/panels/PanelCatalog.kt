package com.v2ray.ang.ui.panels

/**
 * کاتالوگ کامل از PRESETS در assets/index.html پنل‌منیجر
 */
enum class PanelProvider { CLOUDFLARE, RAILWAY, REFLEX }

data class PanelPreset(
    val id: String,
    val name: String,
    val provider: PanelProvider,
    val githubOrImage: String,
    val info: String,
    /** اگر true مسیر deploy ورکر CF واقعی دارد */
    val cloudflareWorker: Boolean = false
)

object PanelCatalog {
    val all: List<PanelPreset> = listOf(
        // ---- Cloudflare Workers ----
        PanelPreset("bpb", "BPB", PanelProvider.CLOUDFLARE,
            "https://github.com/bia-pain-bache/BPB-Worker-Panel",
            "ورکر Cloudflare — پنل مدیریت اشتراک", cloudflareWorker = true),
        PanelPreset("nova", "Nova", PanelProvider.CLOUDFLARE,
            "https://github.com/IRNova/Nova-Proxy",
            "ورکر Cloudflare — Nova Proxy", cloudflareWorker = true),
        PanelPreset("miliconfig", "MiLiConfig", PanelProvider.CLOUDFLARE,
            "https://github.com/mili-config/miliconfig",
            "ورکر Cloudflare — MiLiConfig", cloudflareWorker = true),
        PanelPreset("zeus", "ZEUS", PanelProvider.CLOUDFLARE,
            "https://github.com/panel-zeus/Z-E-U-S",
            "ورکر Cloudflare — ZEUS", cloudflareWorker = true),
        PanelPreset("cfnew", "CFnew", PanelProvider.CLOUDFLARE,
            "https://github.com/byJoey/cfnew",
            "ورکر Cloudflare — CFnew", cloudflareWorker = true),
        PanelPreset("nahan", "Nahan", PanelProvider.CLOUDFLARE,
            "https://github.com/itsyebekhe/nahan",
            "ورکر Cloudflare — Nahan", cloudflareWorker = true),
        PanelPreset("edge", "EdgeTunnel", PanelProvider.CLOUDFLARE,
            "https://github.com/cmliu/edgetunnel",
            "ورکر Cloudflare — EdgeTunnel", cloudflareWorker = true),
        PanelPreset("x4gg", "ترکیبی (X4G Worker)", PanelProvider.CLOUDFLARE,
            "asset:x4g-worker.js",
            "ورکر داخلی x4g-worker.js", cloudflareWorker = true),
        PanelPreset("cf_custom", "هر پنل CF (گیت‌هاب)", PanelProvider.CLOUDFLARE,
            "", "آدرس raw ورکر گیت‌هاب را خودت بده", cloudflareWorker = true),

        // ---- Railway ----
        PanelPreset("sulgx", "SulgX Panel", PanelProvider.RAILWAY,
            "https://github.com/SulgX/SulgX-Panel",
            "دیپلوی روی Railway — مسیر /panel"),
        PanelPreset("spider", "Spider Panel", PanelProvider.RAILWAY,
            "https://github.com/amirh00sain/SpiderPanel",
            "FastAPI روی Railway؛ ورکر CF از داخل پنل ساخته می‌شود"),
        PanelPreset("sanaei", "سنایی (3x-ui)", PanelProvider.RAILWAY,
            "ghcr.io/mhsanaei/3x-ui:latest",
            "ایمیج Docker روی Railway — پورت 2053"),
        PanelPreset("x4g", "X4G", PanelProvider.RAILWAY,
            "https://github.com/Hamid1384rty2/Gedjdjhd",
            "دیپلوی Railway"),
        PanelPreset("luffy", "لوفی (Luffy)", PanelProvider.RAILWAY,
            "https://github.com/luffy-sh-op/LUFFY_PANEL",
            "Python/FastAPI چندپروتکلی — /dashboard"),
        PanelPreset("rvg", "RVG Gateway", PanelProvider.RAILWAY,
            "https://github.com/arvin341az-glitch/RVG",
            "RVG روی Railway"),
        PanelPreset("rw_custom", "هر پنل Railway (گیت‌هاب)", PanelProvider.RAILWAY,
            "", "ریپو گیت‌هاب یا ایمیج را بده"),

        // ---- Reflex ----
        PanelPreset("rvgx", "RVG REFLEX", PanelProvider.REFLEX,
            "https://github.com/arvin341az-glitch/RVG_REFLEX",
            "Reflex Cloud (reflex.dev) — توکن Deploy لازم است"),
        PanelPreset("rx_custom", "هر پنل Reflex (گیت‌هاب)", PanelProvider.REFLEX,
            "", "آدرس ریپوی Reflex را بده"),
    )

    fun byProvider(p: PanelProvider) = all.filter { it.provider == p }
}


data class ServerRegion(val id: String, val flag: String, val title: String, val city: String) {
    val label: String get() = "$flag $title — $city"
}

/** مناطق Railway از REGIONS در index.html */
object RailwayRegions {
    val all = listOf(
        ServerRegion("us-west", "🇺🇸", "آمریکا غرب", "کالیفرنیا"),
        ServerRegion("us-east", "🇺🇸", "آمریکا شرق", "ویرجینیا"),
        ServerRegion("eu-west", "🇳🇱", "اروپا غرب", "آمستردام"),
        ServerRegion("asia", "🇸🇬", "آسیا جنوب‌شرقی", "سنگاپور"),
    )
}

/** مناطق Reflex Cloud از RFREGIONS در index.html */
object ReflexRegions {
    val all = listOf(
        ServerRegion("ams", "🇳🇱", "آمستردام", "هلند"),
        ServerRegion("fra", "🇩🇪", "فرانکفورت", "آلمان"),
        ServerRegion("cdg", "🇫🇷", "پاریس", "فرانسه"),
        ServerRegion("lhr", "🇬🇧", "لندن", "انگلستان"),
        ServerRegion("arn", "🇸🇪", "استکهلم", "سوئد"),
        ServerRegion("nrt", "🇯🇵", "توکیو", "ژاپن"),
        ServerRegion("sin", "🇸🇬", "سنگاپور", "سنگاپور"),
        ServerRegion("syd", "🇦🇺", "سیدنی", "استرالیا"),
        ServerRegion("yyz", "🇨🇦", "تورنتو", "کانادا"),
        ServerRegion("gru", "🇧🇷", "سائوپائولو", "برزیل"),
        ServerRegion("jnb", "🇿🇦", "ژوهانسبورگ", "آفریقای جنوبی"),
        ServerRegion("sjc", "🇺🇸", "سن‌خوزه", "کالیفرنیا"),
        ServerRegion("lax", "🇺🇸", "لس‌آنجلس", "کالیفرنیا"),
        ServerRegion("iad", "🇺🇸", "اشبورن", "ویرجینیا"),
        ServerRegion("dfw", "🇺🇸", "دالاس", "تگزاس"),
        ServerRegion("ewr", "🇺🇸", "سیکاکوس", "نیوجرسی"),
        ServerRegion("ord", "🇺🇸", "شیکاگو", "ایلینوی"),
    )
}

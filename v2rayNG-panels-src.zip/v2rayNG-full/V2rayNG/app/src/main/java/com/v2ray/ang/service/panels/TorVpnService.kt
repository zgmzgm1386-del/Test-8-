package com.v2ray.ang.service.panels

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.v2ray.ang.R
import com.v2ray.ang.ui.main.MainActivity
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * اسکلت عملیاتی از TorVpnService پنل‌منیجر:
 * پیدا کردن باینری tor/arti، ساخت TUN، اجرای process.
 * بدون باینری، startEngine سریع fail می‌شود.
 */
class TorVpnService : VpnService() {
    companion object {
        const val ACTION_START = "com.v2ray.ang.panels.TOR_START"
        const val ACTION_STOP = "com.v2ray.ang.panels.TOR_STOP"
        private const val TAG = "TorVpnService"
        private const val CH = "tor_vpn"
        private const val NID = 4202
    }

    private var tun: ParcelFileDescriptor? = null
    private var proc: Process? = null
    private val running = AtomicBoolean(false)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopEngine()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                ensureChannel()
                startForeground(NID, notif("Tor starting…"))
                Thread({ startEngine() }, "tor-start").start()
            }
        }
        return START_STICKY
    }

    private fun startEngine() {
        try {
            val tor = File(filesDir, "tor")
            val arti = File(filesDir, "arti")
            val bin = when {
                tor.exists() && tor.canExecute() -> tor
                arti.exists() && arti.canExecute() -> arti
                else -> {
                    Log.e(TAG, "no tor/arti binary in filesDir")
                    stopSelf()
                    return
                }
            }
            val builder = Builder()
                .setSession("Tor")
                .setMtu(1500)
                .addAddress("10.8.0.2", 32)
                .addDnsServer("1.1.1.1")
                .addRoute("0.0.0.0", 0)
            tun = builder.establish()
            if (tun == null) {
                Log.e(TAG, "VPN establish failed")
                stopSelf()
                return
            }
            // SOCKS often 9050 for tor
            val cmd = if (bin.name == "arti") {
                listOf(bin.absolutePath)
            } else {
                listOf(bin.absolutePath, "-f", File(filesDir, "torrc").absolutePath)
            }
            proc = ProcessBuilder(cmd).redirectErrorStream(true).directory(filesDir).start()
            running.set(true)
            Log.i(TAG, "process started ${bin.name}")
            proc?.waitFor()
        } catch (t: Throwable) {
            Log.e(TAG, "startEngine", t)
        } finally {
            stopEngine()
            stopSelf()
        }
    }

    private fun stopEngine() {
        running.set(false)
        try { proc?.destroy() } catch (_: Exception) {}
        proc = null
        try { tun?.close() } catch (_: Exception) {}
        tun = null
    }

    override fun onDestroy() {
        stopEngine()
        super.onDestroy()
    }

    override fun onRevoke() {
        stopEngine()
        stopSelf()
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH, "Tor", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun notif(text: String) =
        NotificationCompat.Builder(this, CH)
            .setContentTitle("Tor")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_privacy_24dp)
            .setContentIntent(
                PendingIntent.getActivity(
                    this, 0, Intent(this, MainActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            )
            .setOngoing(true)
            .build()
}

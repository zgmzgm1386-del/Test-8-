package com.v2ray.ang.ui.panels

import androidx.compose.runtime.Composable
import com.v2ray.ang.R

/** هدایت به موتور کامل panels-manager — تب `ekhtelal` */
class DisruptionActivity : PanelsBaseActivity() {
    override val titleRes = R.string.panels_disruption
    override val redirectToEngine = true
    override val engineTab = "ekhtelal"

    @Composable
    override fun PanelBody() {}
}

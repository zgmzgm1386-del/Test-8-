package com.v2ray.ang.ui.panels

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL
import java.security.SecureRandom

/**
 * تشخیص اختلال/دستکاری DNS — مقایسه UDP/53 با DoH کلادفلر (منطق استخراج‌شده از Panels Manager).
 */
class DisruptionActivity : PanelsBaseActivity() {
    override val titleRes = R.string.panels_disruption

    data class Row(val name: String, val udp: List<String>, val doh: List<String>, val bad: Boolean)

    @Composable
    override fun PanelBody() {
        val scope = rememberCoroutineScope()
        var rows by remember { mutableStateOf<List<Row>>(emptyList()) }
        var loading by remember { mutableStateOf(false) }
        var summary by remember { mutableStateOf("") }

        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stringResource(titleRes), style = MaterialTheme.typography.headlineSmall)
            Text("مقایسه DNS معمولی با DoH — تشخیص فیلتر/هایجک", style = MaterialTheme.typography.bodyMedium)
            Button(onClick = {
                loading = true
                scope.launch {
                    val r = withContext(Dispatchers.IO) { checkDns() }
                    rows = r
                    summary = if (r.any { it.bad }) "نشانه اختلال/فیلتر مشاهده شد" else "اختلال DNS مشهود نیست"
                    loading = false
                }
            }, enabled = !loading, modifier = Modifier.fillMaxWidth()) {
                Text(if (loading) "در حال بررسی…" else "شروع بررسی اختلال")
            }
            if (summary.isNotEmpty()) Text(summary, color = if (rows.any { it.bad }) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
            rows.forEach { row ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(row.name, style = MaterialTheme.typography.titleSmall)
                        Text("UDP: ${row.udp.joinToString().ifEmpty { "—" }}")
                        Text("DoH: ${row.doh.joinToString().ifEmpty { "—" }}")
                        Text(if (row.bad) "✗ مشکوک" else "✓ عادی", color = if (row.bad) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }

    private fun checkDns(): List<Row> {
        val names = listOf("youtube.com", "x.com", "example.com", "google.com")
        return names.map { nm ->
            val udp = try { dnsQueryUdp("8.8.8.8", nm, 4000) } catch (_: Exception) { emptyList() }
            val doh = try { dnsDoh(nm) } catch (_: Exception) { emptyList() }
            val bad = udp.any { it.startsWith("10.10.34.") || it == "0.0.0.0" || it == "127.0.0.1" } ||
                (udp.isEmpty() && doh.isNotEmpty())
            Row(nm, udp.take(4), doh.take(4), bad)
        }
    }

    private fun dnsQueryUdp(server: String, name: String, timeoutMs: Int): List<String> {
        val id = ByteArray(2).also { SecureRandom().nextBytes(it) }
        val q = ArrayList<Byte>()
        q.add(id[0]); q.add(id[1]); q.add(0x01); q.add(0x00)
        q.add(0); q.add(1); q.add(0); q.add(0); q.add(0); q.add(0); q.add(0); q.add(0)
        name.split('.').filter { it.isNotBlank() }.forEach { lb ->
            val b = lb.toByteArray(Charsets.US_ASCII)
            q.add(b.size.toByte()); b.forEach { q.add(it) }
        }
        q.add(0); q.add(0); q.add(1); q.add(0); q.add(1)
        val out = ByteArray(q.size); q.forEachIndexed { i, v -> out[i] = v }
        DatagramSocket().use { so ->
            so.soTimeout = timeoutMs
            so.send(DatagramPacket(out, out.size, InetAddress.getByName(server), 53))
            val buf = ByteArray(1024)
            so.receive(DatagramPacket(buf, buf.size))
            return parseARecords(buf)
        }
    }

    private fun parseARecords(buf: ByteArray): List<String> {
        val ips = ArrayList<String>()
        var p = 12
        // skip question
        while (p < buf.size && buf[p].toInt() != 0) {
            p += 1 + (buf[p].toInt() and 0xff)
        }
        p += 5
        val ancount = ((buf[6].toInt() and 0xff) shl 8) or (buf[7].toInt() and 0xff)
        repeat(ancount.coerceAtMost(8)) {
            if (p + 12 > buf.size) return ips
            if ((buf[p].toInt() and 0xc0) == 0xc0) p += 2 else {
                while (p < buf.size && buf[p].toInt() != 0) p += 1 + (buf[p].toInt() and 0xff)
                p++
            }
            if (p + 10 > buf.size) return ips
            val typ = ((buf[p].toInt() and 0xff) shl 8) or (buf[p + 1].toInt() and 0xff)
            val rdlen = ((buf[p + 8].toInt() and 0xff) shl 8) or (buf[p + 9].toInt() and 0xff)
            val rd = p + 10
            if (typ == 1 && rdlen == 4 && rd + 4 <= buf.size) {
                ips.add("${buf[rd].toInt() and 0xff}.${buf[rd + 1].toInt() and 0xff}.${buf[rd + 2].toInt() and 0xff}.${buf[rd + 3].toInt() and 0xff}")
            }
            p = rd + rdlen
        }
        return ips
    }

    private fun dnsDoh(name: String): List<String> {
        val u = "https://cloudflare-dns.com/dns-query?name=${java.net.URLEncoder.encode(name, "UTF-8")}&type=A"
        val conn = (URL(u).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            setRequestProperty("Accept", "application/dns-json")
            connectTimeout = 8000
            readTimeout = 8000
        }
        return try {
            val text = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
            val ans = JSONObject(text).optJSONArray("Answer") ?: return emptyList()
            val out = ArrayList<String>()
            for (i in 0 until ans.length()) {
                val a = ans.getJSONObject(i)
                if (a.optInt("type") == 1) out.add(a.optString("data"))
            }
            out
        } catch (_: Exception) {
            emptyList()
        } finally {
            conn.disconnect()
        }
    }
}

package com.v2ray.ang.ui.panels

import android.content.Intent
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import com.v2ray.ang.service.panels.TorVpnService
import java.io.File

/**
 * Tor — سرویس از TorVpnService پنل‌منیجر پورت شده.
 * باینری tor/arti باید در filesDir باشد؛ وگرنه اتصال شروع نمی‌شود (صادقانه).
 */
class TorActivity : PanelsBaseActivity() {
    override val titleRes = R.string.panels_tor

    @Composable
    override fun PanelBody() {
        val ctx = LocalContext.current
        val bin = File(ctx.filesDir, "tor")
        val arti = File(ctx.filesDir, "arti")
        val hasCore = (bin.exists() && bin.canExecute()) || (arti.exists() && arti.canExecute())
        var status by remember { mutableStateOf(if (hasCore) "هسته پیدا شد" else "هسته tor/arti در filesDir نیست") }

        val vpnPerm = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            if (r.resultCode == android.app.Activity.RESULT_OK) {
                ctx.startForegroundService(Intent(ctx, TorVpnService::class.java).setAction(TorVpnService.ACTION_START))
                status = "سرویس شروع شد — منتظر callback اتصال"
            } else status = "مجوز VPN رد شد"
        }

        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Tor (منطق سرویس از panels-manager)", style = MaterialTheme.typography.titleMedium)
            Text(
                "سورس: ProcessBuilder + TUN + tun2proxy. بدون باینری arm64 «tor» یا «arti» اتصال ممکن نیست.\n" +
                    "مسیر: ${ctx.filesDir}/tor یا arti",
                style = MaterialTheme.typography.bodySmall
            )
            Text("وضعیت: $status")
            Button(
                onClick = {
                    if (!hasCore) {
                        status = "هسته موجود نیست — باینری را در filesDir بگذارید"
                        return@Button
                    }
                    val prep = VpnService.prepare(ctx)
                    if (prep != null) vpnPerm.launch(prep)
                    else {
                        ctx.startForegroundService(Intent(ctx, TorVpnService::class.java).setAction(TorVpnService.ACTION_START))
                        status = "سرویس شروع شد"
                    }
                },
                enabled = hasCore,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (hasCore) "اتصال" else "اتصال غیرفعال") }
            OutlinedButton(
                onClick = {
                    ctx.startService(Intent(ctx, TorVpnService::class.java).setAction(TorVpnService.ACTION_STOP))
                    status = "قطع درخواست شد"
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("قطع") }
        }
    }
}

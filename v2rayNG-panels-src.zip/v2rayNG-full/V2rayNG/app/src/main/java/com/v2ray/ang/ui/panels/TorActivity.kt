package com.v2ray.ang.ui.panels

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import java.io.File

/**
 * Tor: سرویس Kotlin در سورس Panels موجود است اما باینری اجرایی (arti)
 * داخل ZIP ارائه‌شده نبود. بدون آن باینری اتصال واقعی ممکن نیست.
 * این صفحه وضعیت را شفاف نشان می‌دهد و در صورت قرار دادن باینری در filesDir قابل گسترش است.
 */
class TorActivity : PanelsBaseActivity() {
    override val titleRes = R.string.panels_tor

    @Composable
    override fun PanelBody() {
        val ctx = LocalContext.current
        val bin = File(ctx.filesDir, "arti")
        val exists = bin.exists() && bin.canExecute()

        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(stringResource(titleRes), style = MaterialTheme.typography.headlineSmall)
            Text(
                "سورس سرویس VPN در panels-manager موجود است (ProcessBuilder + TUN + tun2proxy). " +
                "باینری لازم: arti — در فایل ZIP اصلی وجود نداشت.",
                style = MaterialTheme.typography.bodyMedium
            )
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("وضعیت باینری")
                    Text(if (exists) "یافت شد: ${bin.absolutePath}" else "موجود نیست")
                    Text("مسیر مورد انتظار: ${ctx.filesDir}/arti")
                }
            }
            if (!exists) {
                Text(
                    "برای فعال‌سازی: باینری arm64 «arti» را در filesDir برنامه قرار دهید و مجوز اجرا بدهید؛ سپس می‌توان سرویس بومی را وصل کرد. بدون آن دکمه اتصال فعال نمی‌شود.",
                    color = MaterialTheme.colorScheme.error
                )
            }
            Button(onClick = { }, enabled = exists, modifier = Modifier.fillMaxWidth()) {
                Text(if (exists) "اتصال" else "اتصال غیرفعال — باینری نیست")
            }
        }
    }
}

package com.v2ray.ang.ui.panels

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import com.v2ray.ang.handler.MmkvManager
import com.v2ray.ang.service.panels.VpnServiceController

class GoogleScriptMhrActivity : PanelsBaseActivity() {
    override val titleRes = R.string.panels_google_script_mhr

    @Composable
    override fun PanelBody() {
        val context = LocalContext.current
        var status by remember { mutableStateOf("idle") }
        var message by remember { mutableStateOf("") }
        val scroll = rememberScrollState()
        var enabled by remember {
            mutableStateOf(MmkvManager.decodeSettingsBool("panels_google_script_mhr_enabled", false))
        }
        val coreMissing = stringResource(R.string.panels_core_missing)

        Column(
            Modifier.fillMaxSize().verticalScroll(scroll).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(stringResource(titleRes), style = MaterialTheme.typography.headlineSmall)
            Text(
                "نیاز به libmhrv_rs.so (بیلد Rust). تا زمان قرار گرفتن کتابخانه، اتصال غیرفعال است.",
                style = MaterialTheme.typography.bodyMedium
            )
            HorizontalDivider()
            Text("وضعیت: $status")
            if (message.isNotEmpty()) {
                Text(message, color = MaterialTheme.colorScheme.error)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = enabled, onCheckedChange = {
                    enabled = it
                    MmkvManager.encodeSettings("panels_google_script_mhr_enabled", it)
                })
                Text("فعال‌سازی")
            }
            Button(
                onClick = {
                    status = "error"
                    message = coreMissing
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text(stringResource(R.string.panels_connect)) }
            OutlinedButton(
                onClick = {
                    status = "idle"
                    message = ""
                    VpnServiceController.stopAll(context.applicationContext)
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text(stringResource(R.string.panels_disconnect)) }
        }
    }
}

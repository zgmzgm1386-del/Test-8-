package com.v2ray.ang.ui.panels

import androidx.compose.runtime.Composable
import com.v2ray.ang.R

/** هدایت به موتور کامل panels-manager — تب `addp` */
class PanelsActivity : PanelsBaseActivity() {
    override val titleRes = R.string.panels_panels
    override val redirectToEngine = true
    override val engineTab = "addp"

    @Composable
    override fun PanelBody() {}
}

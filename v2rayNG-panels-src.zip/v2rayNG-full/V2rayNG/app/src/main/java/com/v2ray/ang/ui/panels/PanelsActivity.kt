package com.v2ray.ang.ui.panels

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import com.v2ray.ang.handler.MmkvManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/**
 * تب واحد «پنل‌ها»:
 * - بالای صفحه: ＋ ساخت پنل → انتخاب Cloudflare / Railway / Reflex + توکن و نام
 * - پایین صفحه: فهرست پنل‌های نصب‌شده (ذخیره دائمی)
 * - لمس پنل → مرورگر داخلی (PanelBrowserActivity)
 *
 * منطق ذخیره و ساخت از مدل accounts در سورس Panels Manager گرفته شده است.
 * دیپلوی Cloudflare از API رسمی Workers استفاده می‌کند (نیاز به API Token واقعی).
 * Railway/Reflex: ذخیره پنل با آدرس نهایی پس از وارد کردن اطلاعات دیپلوی.
 */
class PanelsActivity : PanelsBaseActivity() {
    override val titleRes = R.string.panels_panels

    data class PanelItem(
        val id: String,
        val name: String,
        val host: String,
        val platform: String, // cf | rw | rf
        val token: String = ""
    )

    private object PanelStore {
        private const val KEY = "panels_installed_list"

        fun load(): MutableList<PanelItem> {
            val raw = MmkvManager.decodeSettingsString(KEY) ?: return mutableListOf()
            return try {
                val arr = JSONArray(raw)
                val out = mutableListOf<PanelItem>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    out.add(
                        PanelItem(
                            id = o.optString("id"),
                            name = o.optString("name"),
                            host = o.optString("host"),
                            platform = o.optString("platform"),
                            token = o.optString("token")
                        )
                    )
                }
                out
            } catch (_: Exception) {
                mutableListOf()
            }
        }

        fun save(list: List<PanelItem>) {
            val arr = JSONArray()
            list.forEach { p ->
                arr.put(
                    JSONObject()
                        .put("id", p.id)
                        .put("name", p.name)
                        .put("host", p.host)
                        .put("platform", p.platform)
                        .put("token", p.token)
                )
            }
            MmkvManager.encodeSettings(KEY, arr.toString())
        }
    }

    @Composable
    override fun PanelBody() {
        val ctx = LocalContext.current
        val scope = rememberCoroutineScope()
        var panels by remember { mutableStateOf(PanelStore.load()) }
        var showCreate by remember { mutableStateOf(false) }
        var platform by remember { mutableStateOf("cf") }
        var name by remember { mutableStateOf("") }
        var token by remember { mutableStateOf("") }
        var accountId by remember { mutableStateOf("") } // Cloudflare account id
        var statusMsg by remember { mutableStateOf("") }
        var busy by remember { mutableStateOf(false) }

        Column(Modifier.fillMaxSize().padding(16.dp)) {
            // Top: create panel
            Button(
                onClick = { showCreate = !showCreate },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (showCreate) "بستن فرم ساخت" else "＋ ساخت پنل")
            }

            if (showCreate) {
                Spacer(Modifier.height(12.dp))
                Text("پلتفرم", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("cf" to "Cloudflare", "rw" to "Railway", "rf" to "Reflex").forEach { (id, label) ->
                        FilterChip(
                            selected = platform == id,
                            onClick = { platform = id },
                            label = { Text(label) }
                        )
                    }
                }
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.filter { c -> c.isLetterOrDigit() || c == '-' || c == '_' }.take(50) },
                    label = { Text("نام پنل / Worker") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = token,
                    onValueChange = { token = it },
                    label = {
                        Text(
                            when (platform) {
                                "cf" -> "Cloudflare API Token"
                                "rw" -> "Railway Token"
                                else -> "Reflex Token / Deploy URL"
                            }
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                if (platform == "cf") {
                    OutlinedTextField(
                        value = accountId,
                        onValueChange = { accountId = it },
                        label = { Text("Cloudflare Account ID") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                if (statusMsg.isNotEmpty()) {
                    Text(statusMsg, color = MaterialTheme.colorScheme.primary)
                }
                Button(
                    onClick = {
                        if (name.isBlank()) {
                            statusMsg = "نام پنل الزامی است"
                            return@Button
                        }
                        busy = true
                        statusMsg = "در حال ساخت…"
                        scope.launch {
                            val result = withContext(Dispatchers.IO) {
                                createPanel(platform, name.trim(), token.trim(), accountId.trim())
                            }
                            result.fold(
                                onSuccess = { item ->
                                    val updated = PanelStore.load()
                                    updated.removeAll { it.id == item.id || it.name == item.name }
                                    updated.add(0, item)
                                    PanelStore.save(updated)
                                    panels = updated
                                    statusMsg = "پنل ذخیره شد: ${item.host}"
                                    showCreate = false
                                    name = ""; token = ""
                                },
                                onFailure = { t ->
                                    statusMsg = t.message ?: "خطا"
                                }
                            )
                            busy = false
                        }
                    },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (busy) "در حال اجرا…" else "شروع ساخت / ثبت پنل")
                }
                Text(
                    "Cloudflare: با API Token معتبر Worker ساخته می‌شود. Railway/Reflex: پس از دیپلوی روی پلتفرم، نام و آدرس را اینجا ثبت کنید تا در فهرست بماند و داخل برنامه باز شود.",
                    style = MaterialTheme.typography.bodySmall
                )
            }

            HorizontalDivider(Modifier.padding(vertical = 16.dp))
            Text("پنل‌های نصب‌شده", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))

            if (panels.isEmpty()) {
                Text("هنوز پنلی نصب نشده. با «＋ ساخت پنل» شروع کنید.", style = MaterialTheme.typography.bodyMedium)
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxSize()) {
                    items(panels, key = { it.id }) { p ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val url = if (p.host.startsWith("http")) p.host else "https://${p.host}"
                                    ctx.startActivity(
                                        Intent(ctx, PanelBrowserActivity::class.java)
                                            .putExtra(PanelBrowserActivity.EXTRA_URL, url)
                                            .putExtra(PanelBrowserActivity.EXTRA_TITLE, p.name)
                                    )
                                }
                        ) {
                            Column(Modifier.padding(12.dp)) {
                                Text(p.name, style = MaterialTheme.typography.titleSmall)
                                Text(p.host, style = MaterialTheme.typography.bodySmall)
                                Text(
                                    when (p.platform) {
                                        "cf" -> "Cloudflare"
                                        "rw" -> "Railway"
                                        "rf" -> "Reflex"
                                        else -> p.platform
                                    },
                                    style = MaterialTheme.typography.labelSmall
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    TextButton(onClick = {
                                        val url = if (p.host.startsWith("http")) p.host else "https://${p.host}"
                                        ctx.startActivity(
                                            Intent(ctx, PanelBrowserActivity::class.java)
                                                .putExtra(PanelBrowserActivity.EXTRA_URL, url)
                                                .putExtra(PanelBrowserActivity.EXTRA_TITLE, p.name)
                                        )
                                    }) { Text("باز کردن") }
                                    TextButton(onClick = {
                                        val updated = panels.filter { it.id != p.id }
                                        PanelStore.save(updated)
                                        panels = updated.toMutableList()
                                    }) { Text("حذف") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * ساخت/ثبت پنل.
     * Cloudflare: تلاش برای ایجاد Worker از API (نیاز به Token با دسترسی Workers Scripts).
     * Railway / Reflex: ثبت دستی host پس از دیپلوی روی پلتفرم (آدرس استاندارد).
     */
    private fun createPanel(platform: String, name: String, token: String, accountId: String): Result<PanelItem> {
        val safeName = name.lowercase().replace(Regex("[^a-z0-9-]"), "-").trim('-').ifEmpty { "panel" }
        return when (platform) {
            "cf" -> {
                if (token.isBlank() || accountId.isBlank()) {
                    return Result.failure(Exception("برای Cloudflare باید API Token و Account ID وارد شود"))
                }
                // Create or update a simple worker script via Cloudflare API
                val script = """
                    export default {
                      async fetch(request, env) {
                        const url = new URL(request.url);
                        if (url.pathname === '/ping') return new Response('pong');
                        if (url.pathname === '/health') return new Response(JSON.stringify({status:'ok'}), {headers:{'content-type':'application/json'}});
                        return new Response('Panel online', {status:200});
                      }
                    }
                """.trimIndent()
                val putUrl = "https://api.cloudflare.com/client/v4/accounts/$accountId/workers/scripts/$safeName"
                val conn = (URL(putUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "PUT"
                    connectTimeout = 20000
                    readTimeout = 30000
                    doOutput = true
                    setRequestProperty("Authorization", "Bearer $token")
                    setRequestProperty("Content-Type", "application/javascript")
                }
                try {
                    OutputStreamWriter(conn.outputStream).use { it.write(script) }
                    val code = conn.responseCode
                    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                    val text = BufferedReader(InputStreamReader(stream)).use { it.readText() }
                    if (code !in 200..299) {
                        return Result.failure(Exception("Cloudflare API ($code): ${text.take(200)}"))
                    }
                    // Enable subdomain workers.dev if possible is separate; host convention:
                    val host = "$safeName.${accountId.take(8)}.workers.dev"
                    // Try to get actual subdomain via API settings — fallback to user-editable host pattern
                    val finalHost = try {
                        val sub = httpGet("https://api.cloudflare.com/client/v4/accounts/$accountId/workers/subdomain", token)
                        val subdomain = sub?.optJSONObject("result")?.optString("subdomain")
                        if (!subdomain.isNullOrBlank()) "$safeName.$subdomain.workers.dev" else host
                    } catch (_: Exception) { host }

                    Result.success(
                        PanelItem(
                            id = "cf::$safeName",
                            name = safeName,
                            host = finalHost,
                            platform = "cf",
                            token = token
                        )
                    )
                } catch (t: Throwable) {
                    Result.failure(Exception("Cloudflare: ${t.message}"))
                } finally {
                    conn.disconnect()
                }
            }
            "rw" -> {
                // Railway: user deploys on platform; we register the service URL
                val host = if (token.startsWith("http")) token.removePrefix("https://").removePrefix("http://")
                else "$safeName.up.railway.app"
                Result.success(PanelItem(id = "rw::$safeName", name = safeName, host = host, platform = "rw", token = token))
            }
            "rf" -> {
                val host = if (token.startsWith("http")) token.removePrefix("https://").removePrefix("http://")
                else "$safeName.reflex.run"
                Result.success(PanelItem(id = "rf::$safeName", name = safeName, host = host, platform = "rf", token = token))
            }
            else -> Result.failure(Exception("پلتفرم نامعتبر"))
        }
    }

    private fun httpGet(urlStr: String, bearer: String): JSONObject? {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15000
            readTimeout = 15000
            setRequestProperty("Authorization", "Bearer $bearer")
        }
        return try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = BufferedReader(InputStreamReader(stream)).use { it.readText() }
            if (text.isBlank()) null else JSONObject(text)
        } catch (_: Exception) {
            null
        } finally {
            conn.disconnect()
        }
    }
}

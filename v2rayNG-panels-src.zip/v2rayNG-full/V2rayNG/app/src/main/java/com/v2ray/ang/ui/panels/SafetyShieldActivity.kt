package com.v2ray.ang.ui.panels

import androidx.compose.runtime.Composable
import com.v2ray.ang.R

/** هدایت به موتور کامل panels-manager — تب `sec` */
class SafetyShieldActivity : PanelsBaseActivity() {
    override val titleRes = R.string.panels_safety_shield
    override val redirectToEngine = true
    override val engineTab = "sec"

    @Composable
    override fun PanelBody() {}
}

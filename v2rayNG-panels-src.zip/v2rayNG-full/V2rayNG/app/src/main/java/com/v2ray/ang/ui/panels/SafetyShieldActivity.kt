package com.v2ray.ang.ui.panels

import android.app.KeyguardManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * سپر ایمنی — منطق واقعی استخراج‌شده از MainActivity.kt پنل‌ها
 * (بررسی قفل صفحه، USB Debugging، برنامه‌های نصب‌شده، ... )
 */
class SafetyShieldActivity : PanelsBaseActivity() {
    override val titleRes = R.string.panels_safety_shield

    data class CheckResult(val name: String, val ok: Boolean, val detail: String)

    @Composable
    override fun PanelBody() {
        val ctx = LocalContext.current
        var results by remember { mutableStateOf<List<CheckResult>>(emptyList()) }
        var loading by remember { mutableStateOf(false) }
        val scroll = rememberScrollState()

        Column(Modifier.fillMaxSize().verticalScroll(scroll).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stringResource(titleRes), style = MaterialTheme.typography.headlineSmall)
            Text("بررسی‌های امنیتی واقعی از سورس Panels Manager", style = MaterialTheme.typography.bodyMedium)
            Button(onClick = {
                loading = true
                // run checks on IO
            }, enabled = !loading, modifier = Modifier.fillMaxWidth()) {
                Text(if (loading) "در حال بررسی…" else "اجرای بررسی‌ها")
            }
            // Simple synchronous checks for demo of real logic
            LaunchedEffect(loading) {
                if (!loading) return@LaunchedEffect
                val list = mutableListOf<CheckResult>()
                withContext(Dispatchers.Default) {
                    // 1. Screen lock
                    val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
                    val locked = km.isDeviceSecure
                    list.add(CheckResult("قفل صفحه", locked, if (locked) "فعال" else "غیرفعال — خطرناک"))
                    // 2. USB debugging
                    val adb = try {
                        Settings.Global.getInt(ctx.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1
                    } catch (_: Exception) { false }
                    list.add(CheckResult("USB Debugging", !adb, if (adb) "روشن است" else "خاموش"))
                    // 3. Developer options
                    val dev = try {
                        Settings.Global.getInt(ctx.contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
                    } catch (_: Exception) { false }
                    list.add(CheckResult("Developer Options", !dev, if (dev) "روشن" else "خاموش"))
                    // 4. App count
                    val pm = ctx.packageManager
                    val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
                    val userApps = apps.count { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
                    list.add(CheckResult("برنامه‌های کاربر", true, "$userApps برنامه"))
                    // 5. Android version
                    list.add(CheckResult("نسخه Android", Build.VERSION.SDK_INT >= 26, "API ${Build.VERSION.SDK_INT}"))
                }
                results = list
                loading = false
            }
            results.forEach { r ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(r.name)
                        Text(if (r.ok) "✓ ${r.detail}" else "✗ ${r.detail}", color = if (r.ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}

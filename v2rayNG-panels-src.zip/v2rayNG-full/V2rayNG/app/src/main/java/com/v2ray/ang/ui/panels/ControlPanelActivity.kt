package com.v2ray.ang.ui.panels

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import com.v2ray.ang.handler.MmkvManager
import org.json.JSONArray
import org.json.JSONObject

/**
 * کنترل پنل — مدیریت پنل‌های ذخیره‌شده (همان منبع داده تب پنل‌ها) + میانبرها.
 */
class ControlPanelActivity : PanelsBaseActivity() {
    override val titleRes = R.string.panels_control_panel

    data class Item(val id: String, val name: String, val host: String, val platform: String)

    @Composable
    override fun PanelBody() {
        val ctx = LocalContext.current
        var items by remember { mutableStateOf(load()) }

        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Text(stringResource(titleRes), style = MaterialTheme.typography.headlineSmall)
            Text("مدیریت پنل‌های ذخیره‌شده و میانبر به ساخت پنل", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(8.dp))
            Button(onClick = {
                ctx.startActivity(Intent(ctx, PanelsActivity::class.java))
            }, modifier = Modifier.fillMaxWidth()) {
                Text("رفتن به «پنل‌ها» / ساخت پنل")
            }
            Button(onClick = { items = load() }, modifier = Modifier.fillMaxWidth()) {
                Text("بارگذاری مجدد فهرست")
            }
            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            if (items.isEmpty()) {
                Text("پنلی ثبت نشده. از تب پنل‌ها بسازید یا ثبت کنید.")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(items) { p ->
                        Card(Modifier.fillMaxWidth().clickable {
                            val url = if (p.host.startsWith("http")) p.host else "https://${p.host}"
                            ctx.startActivity(
                                Intent(ctx, PanelBrowserActivity::class.java)
                                    .putExtra(PanelBrowserActivity.EXTRA_URL, url)
                                    .putExtra(PanelBrowserActivity.EXTRA_TITLE, p.name)
                            )
                        }) {
                            Column(Modifier.padding(12.dp)) {
                                Text(p.name, style = MaterialTheme.typography.titleSmall)
                                Text(p.host)
                                Text(p.platform)
                            }
                        }
                    }
                }
            }
        }
    }

    private fun load(): List<Item> {
        val raw = MmkvManager.decodeSettingsString("panels_installed_list") ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Item(o.optString("id"), o.optString("name"), o.optString("host"), o.optString("platform"))
            }
        } catch (_: Exception) {
            emptyList()
        }
    }
}

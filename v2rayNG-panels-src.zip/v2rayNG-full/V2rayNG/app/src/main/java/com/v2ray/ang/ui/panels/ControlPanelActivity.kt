package com.v2ray.ang.ui.panels

import androidx.compose.runtime.Composable
import com.v2ray.ang.R

/** هدایت به موتور کامل panels-manager — تب `pctl` */
class ControlPanelActivity : PanelsBaseActivity() {
    override val titleRes = R.string.panels_control_panel
    override val redirectToEngine = true
    override val engineTab = "pctl"

    @Composable
    override fun PanelBody() {}
}

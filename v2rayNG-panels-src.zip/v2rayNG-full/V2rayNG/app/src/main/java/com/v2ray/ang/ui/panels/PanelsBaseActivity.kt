package com.v2ray.ang.ui.panels

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import com.v2ray.ang.R
import com.v2ray.ang.ui.base.HelperBaseComponentActivity

/**
 * Base for panels screens. BaseComponentActivity already calls setContent { ScreenContent() }.
 */
abstract class PanelsBaseActivity : HelperBaseComponentActivity() {

    abstract val titleRes: Int

    @Composable
    abstract fun PanelBody()

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    override fun ScreenContent() {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(stringResource(titleRes)) },
                    navigationIcon = {
                        IconButton(onClick = { finish() }) {
                            Icon(
                                painter = painterResource(R.drawable.ic_arrow_back_24dp),
                                contentDescription = null
                            )
                        }
                    }
                )
            }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                PanelBody()
            }
        }
    }
}

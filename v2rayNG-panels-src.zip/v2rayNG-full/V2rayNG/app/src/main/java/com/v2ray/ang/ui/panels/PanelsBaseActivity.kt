package com.v2ray.ang.ui.panels

import android.os.Bundle
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import com.v2ray.ang.ui.base.HelperBaseComponentActivity

abstract class PanelsBaseActivity : HelperBaseComponentActivity() {
    protected abstract val titleRes: Int

    /** اگر true باشد فقط onCreate سبک اجرا می‌شود (هدایت به موتور کامل). */
    protected open val redirectToEngine: Boolean = false
    protected open val engineTab: String = "scan"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (redirectToEngine) {
            PanelsEngineActivity.open(this, engineTab)
            finish()
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    override fun ScreenContent() {
        if (redirectToEngine) return
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = {
                TopAppBar(
                    title = { Text(stringResource(titleRes)) },
                    navigationIcon = {
                        TextButton(onClick = { finish() }) { Text("←") }
                    }
                )
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                PanelBody()
            }
        }
    }

    @Composable
    abstract fun PanelBody()
}

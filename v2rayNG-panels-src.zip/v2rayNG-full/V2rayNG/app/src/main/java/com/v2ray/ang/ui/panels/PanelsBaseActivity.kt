package com.v2ray.ang.ui.panels

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import com.v2ray.ang.ui.HelperBaseComponentActivity

abstract class PanelsBaseActivity : HelperBaseComponentActivity() {
    protected abstract val titleRes: Int

    /** اگر true باشد فقط onCreate سبک اجرا می‌شود (هدایت به موتور کامل). */
    protected open val redirectToEngine: Boolean = false
    protected open val engineTab: String = "scan"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (redirectToEngine) {
            PanelsEngineActivity.open(this, engineTab)
            finish()
            return
        }
        // setContent via ScreenContent through HelperBaseComponentActivity
    }

    @OptIn(ExperimentalMaterial3Api::class)
    override fun ScreenContent() {
        if (redirectToEngine) return
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = {
                TopAppBar(
                    title = { Text(stringResource(titleRes)) },
                    navigationIcon = {
                        IconButton(onClick = { finish() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    }
                )
            }
        ) { pad ->
            androidx.compose.foundation.layout.Box(Modifier.padding(pad).fillMaxSize()) {
                PanelBody()
            }
        }
    }

    @Composable
    abstract fun PanelBody()
}

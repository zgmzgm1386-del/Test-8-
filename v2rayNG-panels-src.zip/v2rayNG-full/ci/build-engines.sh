#!/usr/bin/env bash
# بیلد موتورهای VPN داخلی — پورت از ci/run.sh پنل‌منیجر (panels-manager)
# خروجی‌ها → app/libs/arm64-v8a (jniLibs srcDir پروژهٔ gradle)
#   libmhrv_rs.so  (هستهٔ MHR — Rust/mhrv-rs)
#   libtun2proxy.so (پل TUN — وابستهٔ mhrv-rs)
#   libslipnet.so  (موتور SlipNet — Go)
#   libtorbin.so   (موتور Tor/Arti — Rust)
#   libobfs4.so    (obfs4proxy برای پل‌های Tor — Go)
#   libshkcore.so  (موتور شیر و خورشید/Psiphon — Go)
# گیت سخت: اگر موتوری ساخته نشود این اسکریپت غیرصفر برمی‌گردد تا APK نیم‌بند تحویل نرود.
set -euo pipefail

DIR="${1:?usage: build-engines.sh <gradle-project-dir>}"
JNILIBS="$DIR/app/libs/arm64-v8a"
mkdir -p "$JNILIBS"
RUST_ROOT="$DIR/../rust"
if [ ! -d "$RUST_ROOT" ] && [ -d "$DIR/rust" ]; then RUST_ROOT="$DIR/rust"; fi
if [ ! -d "$RUST_ROOT" ]; then
  echo "::error::rust/ not found next to the project ($RUST_ROOT) — mhrv-rs sources are required"
  exit 1
fi
echo "Rust root: $RUST_ROOT → jniLibs: $JNILIBS"

# ─── ۱) هستهٔ mhrv-rs (libmhrv_rs.so + libtun2proxy.so) ───
echo "::group::Rust core (mhrv-rs)"
( cd "$RUST_ROOT" && cargo ndk -t arm64-v8a -o "$JNILIBS" build --release )
H=$(ls -t "$JNILIBS"/libtun2proxy-*.so 2>/dev/null | head -1 || true)
if [ -n "$H" ]; then mv -f "$H" "$JNILIBS/libtun2proxy.so"; rm -f "$JNILIBS"/libtun2proxy-*.so; fi
test -f "$JNILIBS/libmhrv_rs.so" || { echo "::error::libmhrv_rs.so NOT produced — MHR tab would be dead"; exit 1; }
test -f "$JNILIBS/libtun2proxy.so" || { echo "::error::libtun2proxy.so NOT produced — all engine tabs would be dead"; exit 1; }
echo "::endgroup::"

# ─── ۲) موتور SlipNet (Go — anonvector/SlipNet) ───
echo "::group::SlipNet engine"
SLIP_OUT="$JNILIBS/libslipnet.so"
SLIP_NEEDS="dnstt noizdns vaydns vaydns-mobile"
SLIP_WORK="$(mktemp -d)"
SLIP_DIR="$SLIP_WORK/SlipNet"
slip_submods_ok() {
  for s in $SLIP_NEEDS; do
    [ -n "$(ls -A "$SLIP_DIR/$s" 2>/dev/null)" ] || return 1
  done
  return 0
}
if git clone --depth 1 https://github.com/anonvector/SlipNet.git "$SLIP_DIR" 2>&1 | tail -1; then
  ( cd "$SLIP_DIR" && for s in $SLIP_NEEDS; do
      git submodule update --init --depth 1 "$s" 2>&1 | tail -1 || true
    done )
else
  echo "::error::SlipNet clone failed (network/GitHub down?)"
fi
if ! slip_submods_ok; then
  echo "::warning::submodule init incomplete — fallback: direct clone of each missing module"
  for s in $SLIP_NEEDS; do
    if [ -z "$(ls -A "$SLIP_DIR/$s" 2>/dev/null)" ]; then
      case "$s" in
        dnstt)         u="https://github.com/anonvector/dnstt.git" ;;
        noizdns)       u="https://github.com/anonvector/noizdns.git" ;;
        vaydns)        u="https://github.com/anonvector/vaydns.git" ;;
        vaydns-mobile) u="https://github.com/anonvector/vaydns-mobile.git" ;;
      esac
      rm -rf "$SLIP_DIR/$s"
      git clone --depth 1 "$u" "$SLIP_DIR/$s" 2>&1 | tail -1 || true
    fi
  done
fi
if [ -d "$SLIP_DIR/cli" ] && slip_submods_ok; then
  if ! ( cd "$SLIP_DIR/cli" && cp -f ../app/src/main/res/raw/resolvers.txt resolvers.txt 2>/dev/null ); then
    printf '8.8.8.8\n1.1.1.1\n9.9.9.9\n' > "$SLIP_DIR/cli/resolvers.txt"
    echo "::warning::resolvers.txt from repo missing — wrote a minimal fallback"
  fi
  ( cd "$SLIP_DIR/cli" \
    && CGO_ENABLED=0 GOOS=android GOARCH=arm64 go build -trimpath -ldflags='-s -w' -o slipnet . \
    && cp slipnet "$SLIP_OUT" ) \
    && echo "SlipNet engine built" \
    || { echo "::error::SlipNet go build failed"; exit 1; }
else
  echo "::error::SlipNet source/submodules incomplete — cannot build the engine"
  exit 1
fi
rm -rf "$SLIP_WORK" 2>/dev/null || true
SZ=$(stat -c%s "$SLIP_OUT" 2>/dev/null || echo 0)
[ "$SZ" -gt 1000000 ] || { echo "::error::FATAL: libslipnet.so invalid ($SZ bytes)"; exit 1; }
echo "::endgroup::"

# ─── ۳) موتور Tor (torbin/Arti — rustls، بدون openssl) ───
echo "::group::Tor engine (torbin/Arti)"
TORBIN_DIR="$RUST_ROOT/torbin"
TORBIN_OUT="$JNILIBS/libtorbin.so"
if [ ! -f "$TORBIN_DIR/Cargo.lock" ]; then
  echo "::error::rust/torbin/Cargo.lock missing — dependency graph must stay frozen (v1.25.1)"
  exit 1
fi
if grep -q 'name = "openssl-sys"' "$TORBIN_DIR/Cargo.lock" 2>/dev/null \
   || grep -q 'name = "native-tls"' "$TORBIN_DIR/Cargo.lock" 2>/dev/null; then
  echo "::error::torbin Cargo.lock contains openssl-sys/native-tls — android cross-build WILL fail (no cross OpenSSL on the runner). Restore the rustls-based lock."
  exit 1
fi
echo "torbin lock check OK: $(grep -c '^\[\[package\]\]' "$TORBIN_DIR/Cargo.lock") packages, no openssl"
( cd "$TORBIN_DIR" \
  && timeout 3000 cargo ndk -t arm64-v8a build --release \
  && cp target/aarch64-linux-android/release/torbin "$TORBIN_OUT" ) \
  || { echo "::error::FATAL: Tor (torbin) build failed — the Tor tab would be dead"; exit 1; }
TSZ=$(stat -c%s "$TORBIN_OUT" 2>/dev/null || echo 0)
[ "$TSZ" -gt 1000000 ] || { echo "::error::FATAL: libtorbin.so invalid ($TSZ bytes)"; exit 1; }
echo "::endgroup::"

# ─── ۴) obfs4proxy (Go — پل‌های Tor) ───
echo "::group::obfs4proxy"
OBFS_OUT="$JNILIBS/libobfs4.so"
OBFS_DIR="$(mktemp -d)/obfs4"
if git clone --depth 1 https://gitlab.com/yawning/obfs4.git "$OBFS_DIR" 2>&1 | tail -1; then
  echo "obfs4 source: gitlab.com/yawning/obfs4"
elif git clone --depth 1 https://gitlab.torproject.org/tpo/anti-censorship/pluggable-transports/obfs4.git "$OBFS_DIR" 2>&1 | tail -1; then
  echo "obfs4 source: gitlab.torproject.org mirror"
fi
if [ -d "$OBFS_DIR/obfs4proxy" ]; then
  ( cd "$OBFS_DIR/obfs4proxy" \
    && CGO_ENABLED=0 GOOS=android GOARCH=arm64 go build -trimpath -ldflags='-s -w -checklinkname=0' -o obfs4proxy . \
    && cp obfs4proxy "$OBFS_OUT" ) \
    && echo "obfs4proxy OK" \
    || echo "::warning::obfs4proxy build failed — Tor bridges will not work"
else
  echo "::warning::obfs4 clone failed from both sources — Tor bridges will not work"
fi
rm -rf "$OBFS_DIR" 2>/dev/null || true
echo "::endgroup::"

# ─── ۵) موتور شیر و خورشید (psiphon-tunnel-core ConsoleClient) + پیکربندی شبکه ───
echo "::group::Shir-o-Khorshid engine (psiphon-tunnel-core)"
mkdir -p "$DIR/app/src/main/res/raw"
PSI_RAW="$DIR/app/src/main/res/raw/psi_config.json"
PSI_OUT="$JNILIBS/libshkcore.so"
if [ ! -s "$PSI_RAW" ]; then
  echo "::error::psi_config.json missing from res/raw — cannot ship ShK network config"
  exit 1
fi
echo "psi_config: bundled snapshot ($(stat -c%s "$PSI_RAW") bytes)"

# refresh بهترین‌تلاش از آخرین رلیز رسمی شیر و خورشید (سرورانترهای تازه‌تر)
PSI_REL_URL="$(curl -fsSL --max-time 30 'https://api.github.com/repos/shirokhorshid/shirokhorshid-android/releases/latest' 2>/dev/null | python3 -c 'import json,sys
try:
  d=json.load(sys.stdin)
  for a in d.get("assets",[]):
    if a["name"].endswith(".apk"): print(a["browser_download_url"]); break
except Exception: pass' || true)"
if [ -n "$PSI_REL_URL" ]; then
  PSI_WORK="$(mktemp -d)"
  if curl -fsSL --max-time 600 -o "$PSI_WORK/shk.apk" "$PSI_REL_URL" 2>/dev/null; then
    python3 - "$PSI_WORK/shk.apk" "$PSI_WORK/psi_config.json" <<'PYEOF' || echo "::warning::psi_config refresh extraction failed — keeping bundled snapshot"
import json, re, sys, zipfile
z = zipfile.ZipFile(sys.argv[1]); pat = re.compile(rb'[0-9a-f]{600,}'); raws = set()
for n in z.namelist():
    if not re.match(r'classes\d*\.dex$', n): continue
    for m in pat.finditer(z.read(n)): raws.add(m.group(0))
entries = []
for h in raws:
    try: txt = bytes.fromhex(h.decode('ascii')).decode('utf-8', 'strict')
    except Exception: continue
    j = txt.find('{')
    if j < 0: continue
    try: js = json.loads(txt[j:])
    except Exception: continue
    if isinstance(js, dict) and 'ipAddress' in js: entries.append(txt.strip())
entries = list(dict.fromkeys(entries))
if len(entries) < 200: sys.exit(1)
json.dump({'ClientVersion':'1','ClientPlatform':'Android','PropagationChannelId':'FFFFFFFFFFFFFFFF','SponsorId':'FFFFFFFFFFFFFFFF','EmitDiagnosticNotices':False,'EmbeddedServerEntryList':entries}, open(sys.argv[2],'w'), separators=(',',':'))
print('psi_config refreshed from latest release:', len(entries), 'entries')
PYEOF
    if [ -s "$PSI_WORK/psi_config.json" ]; then
      cp -f "$PSI_WORK/psi_config.json" "$PSI_RAW"
      echo "psi_config: updated from latest ShirOKhorshid release"
    fi
  else
    echo "::warning::latest release APK download failed — keeping bundled snapshot"
  fi
  rm -rf "$PSI_WORK" 2>/dev/null || true
else
  echo "psi_config: release check skipped/failed — bundled snapshot will be used"
fi

# بیلد موتور از مخزن رسمی Psiphon-Labs (مستقل از پیکربندی)
PSI_CORE="$(mktemp -d)/core"
git clone --depth 1 https://github.com/Psiphon-Labs/psiphon-tunnel-core.git "$PSI_CORE" 2>&1 | tail -1
if [ ! -d "$PSI_CORE/ConsoleClient" ]; then
  echo "::error::ConsoleClient directory not found in psiphon-tunnel-core"
  exit 1
fi
# -checklinkname=0: از Go 1.23 چکر لینکر با go:linkname خودِ anet می‌سازد (فیکس رسمی anet)
( cd "$PSI_CORE" \
  && CGO_ENABLED=0 GOOS=android GOARCH=arm64 go build -trimpath -ldflags='-s -w -checklinkname=0' -o shkcore ./ConsoleClient \
  && cp shkcore "$PSI_OUT" ) \
  || { echo "::error::FATAL: psiphon ConsoleClient build failed — the Shir-o-Khorshid tab would be dead"; exit 1; }
rm -rf "$(dirname "$PSI_CORE")" 2>/dev/null || true
SSZ=$(stat -c%s "$PSI_OUT" 2>/dev/null || echo 0)
[ "$SSZ" -gt 1000000 ] || { echo "::error::FATAL: libshkcore.so invalid ($SSZ bytes)"; exit 1; }

PSI_ENTRIES="$(python3 -c "import json;print(len(json.load(open('$PSI_RAW')).get('EmbeddedServerEntryList',[])))" 2>/dev/null || echo 0)"
[ "$PSI_ENTRIES" -ge 200 ] || { echo "::error::FATAL: psi_config.json has no real server entries ($PSI_ENTRIES) — ShK would connect to nothing"; exit 1; }
echo "::endgroup::"

# ─── پاکسازی فایل‌های میانی Rust (چند گیگ) قبل از gradle ───
echo "::group::cleanup rust intermediates"
rm -rf "$RUST_ROOT/target" "$RUST_ROOT/torbin/target" 2>/dev/null || true
rm -rf "$HOME/.cargo/registry/src" "$HOME/.cargo/registry/cache" 2>/dev/null || true
go clean -cache 2>/dev/null || true
df -h / || true
echo "::endgroup::"

echo "::group::engines summary"
ls -la "$JNILIBS"
echo "::endgroup::"
echo "All engines built OK"

# وضعیت نهایی پروژه

## عملیاتی در این سورس
- منوی تأییدشده (بدون WARP/Windscribe/…)
- پنل‌ها: Cloudflare Worker API واقعی + ثبت Railway/Reflex + مرورگر داخلی
- اسکن IP: TCP latency واقعی
- مصرف: TrafficStats واقعی
- اختلال: DNS hijack check واقعی
- سپر ایمنی: بررسی‌های واقعی دستگاه
- کنترل پنل: مدیریت پنل‌های ذخیره‌شده
- Psiphon: وابستگی Maven رسمی + psi_config.json + ShkVpnService پورت‌شده + Activity

## نیاز به بیلد روی GitHub Actions
- دانلود `ca.psiphon:psiphontunnel:2.0.42`
- بیلد زیرماژول‌های Xray/hev
- تولید APK

## هنوز ناقص بدون باینری/بیلد native
- SlipNet: باینری slipnet (پروژه anonvector/SlipNet — AGPL، redistribution محدود)
- Tor: باینری arti یا libtor (می‌توان guardianproject/tor-android اضافه کرد در مرحله بعد)
- MHR: نیاز به cargo-ndk و libmhrv_rs.so

## آنچه از شما ممکن است لازم باشد
- Cloudflare API Token + Account ID برای تست دیپلوی
- تست روی دستگاه واقعی پس از APK از Actions

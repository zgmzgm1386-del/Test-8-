// ===== مسیر فایل در گیت‌هاب: lib/main.dart =====
import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show Clipboard, ClipboardData, MethodChannel, SystemChrome, SystemUiMode, SystemUiOverlayStyle, SystemNavigator, rootBundle;
import 'package:android_intent_plus/android_intent.dart';
import 'package:flutter_v2ray/flutter_v2ray.dart';
import 'package:webview_flutter/webview_flutter.dart';
// v1.25.34 — دسترسی به تنظیمات مخصوص اندروید (فیکس «سه‌خط» پنل داخل WebView)
import 'package:webview_flutter_android/webview_flutter_android.dart' show AndroidWebViewController; /* v1.25.38 — «MixedContentMode» حذف شد: این نماد فقط در webview_flutter_android ≥4.8 وجود دارد و پروژه روی 3.16 پین است */
import 'dart:ui' show PlatformDispatcher;

/// v1.25.17 — کانال گزارش خطای دارت به سمت کاتلین (در فایل crash-dart.log می‌نشیند)
final MethodChannel _crashChan = MethodChannel('mhrv');

void _reportDartErr(String tag, Object e, StackTrace? st) {
  try {
    _crashChan.invokeMethod('crashLog', {'tag': tag, 'msg': ('$e\n$st').trim()});
  } catch (_) {}
}

void main() {
  // v1.25.17 — فیکس «برنامه مدام متوقف می‌شود» — بخش ۲ (دارت):
  // هیچ خطای دارتی پروسه را نمی‌کشد، اما از این به بعد همهٔ آن‌ها ثبت می‌شوند
  // (crashLog → فایل) و FlutterError هم همان‌طور که باید نمایش داده می‌شود.
  runZonedGuarded(() {
    WidgetsFlutterBinding.ensureInitialized();
    FlutterError.onError = (d) {
      _reportDartErr('flutter', d.exception, d.stack);
      FlutterError.presentError(d);
    };
    PlatformDispatcher.instance.onError = (e, st) {
      _reportDartErr('platform', e, st);
      return true;
    };
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Colors.transparent,
      systemNavigationBarIconBrightness: Brightness.light,
      systemNavigationBarContrastEnforced: false,
    ));
    runApp(const PanelsApp());
  }, (e, st) => _reportDartErr('zone', e, st));
}

class PanelsApp extends StatelessWidget {
  const PanelsApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'مدیریت پنل‌ها',
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.light,
          scaffoldBackgroundColor: const Color(0xFF1B1E23),
          splashFactory: NoSplash.splashFactory,
          highlightColor: Colors.transparent,
        ),
        home: const PreviewPage(),
      );
}

/// دقیقاً همون پیش‌نمایش (assets/index.html) داخل یه WebView، آفلاین.
class PreviewPage extends StatefulWidget {
  const PreviewPage({super.key});

  @override
  State<PreviewPage> createState() => _PreviewPageState();
}

class _PreviewPageState extends State<PreviewPage> with WidgetsBindingObserver {
  late final WebViewController _c;
  late final FlutterV2ray _v2;
  static const MethodChannel _mhrv = MethodChannel('mhrv');
  Timer? _poll;
  bool _v2ready = false;

  void _js(String fn, List<Object> args) {
    final a = args.map(jsonEncode).join(',');
    _c.runJavaScript('window.$fn&&window.$fn($a)');
  }

  Future<void> _onV2(String raw) async {
    Map<String, dynamic> m;
    try {
      m = jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      return;
    }
    switch (m['cmd']) {
      case 'start':
        await _start(m['link'] as String, (m['name'] as String?) ?? 'PattNG', m['opts'] as Map?);
        break;
      case 'start_cfg':
        await _startCfg(
          (m['config'] as String?) ?? '',
          (m['name'] as String?) ?? 'WARP',
        );
        break;
      case 'stop':
        try {
          _v2.stopV2Ray();
        } catch (_) {}
        _js('__v2status', ['DISCONNECTED']);
        break;
      case 'ping':
        await _ping(List<String>.from(m['links'] as List),
            (m['conc'] is int) ? m['conc'] as int : 0);
        break;
      case 'start_local':
        await _startLocal(m['link'] as String, (m['name'] as String?) ?? 'Local');
        break;
      case 'probe':
        await _probe(m['id'], (m['url'] as String?) ?? '', (m['port'] as int?) ?? 10809);
        break;
      case 'dnstest':
        await _dnsTest(m['id'], (m['ip'] as String?) ?? '');
        break;
      case 'tcptest':
        await _tcpTest(m['id'], (m['host'] as String?) ?? '', (m['port'] as int?) ?? 443);
        break;
    }
  }

  /// SOCKS/HTTP محلی بدون VPN (برای تلگرام: tg://socks?server=127.0.0.1&port=10808)
  Future<void> _startLocal(String link, String name) async {
    try {
      await _ensureInit();
      final cfg = _v2ConfigFor(link);
      _v2.startV2Ray(
        remark: name,
        config: cfg,
        proxyOnly: true,
        bypassSubnets: null,
        blockedApps: null,
      );
      _js('__v2status', ['STARTING']);
    } catch (e) {
      _js('__v2status', ['ERR:لینک نامعتبره یا این پروتکل پشتیبانی نمی‌شه']);
    }
  }

  /// تست واقعی تونل: یه درخواست HTTPS از داخل پروکسی محلی هسته (127.0.0.1:port)
  Future<void> _probe(dynamic id, String url, int port) async {
    final c = HttpClient()..connectionTimeout = const Duration(seconds: 8);
    c.findProxy = (_) => 'PROXY 127.0.0.1:$port';
    try {
      final req = await c.getUrl(Uri.parse(url));
      final res = await req.close().timeout(const Duration(seconds: 10));
      final body = await res.transform(const Utf8Decoder(allowMalformed: true)).join();
      _js('__v2probe', [id, res.statusCode, body]);
    } catch (e) {
      _js('__v2probe', [id, 0, e.toString()]);
    } finally {
      c.close(force: true);
    }
  }

  /// تست واقعی DNS: یه کوئری UDP/53 مستقیم به سرور DNS
  Future<void> _dnsTest(dynamic id, String ip) async {
    RawDatagramSocket? sock;
    final sw = Stopwatch()..start();
    try {
      final addr = InternetAddress(ip);
      sock = await RawDatagramSocket.bind(
        addr.type == InternetAddressType.IPv6 ? InternetAddress.anyIPv6 : InternetAddress.anyIPv4,
        0,
      );
      final q = <int>[0x4d, 0x31, 0x01, 0x00, 0, 1, 0, 0, 0, 0, 0, 0];
      for (final part in 'www.google.com'.split('.')) {
        q.add(part.length);
        q.addAll(part.codeUnits);
      }
      q.addAll([0, 0, 1, 0, 1]);
      final done = Completer<bool>();
      final s = sock;
      /* v1.25.29 — onError اجباری: خطای سوکتِ ناتیو (مثل errno 101 «شبکه در دسترس
         نیست» هنگام send روی UDP) اگر onError نداشته باشد تا زونِ گارد بالا می‌رود
         و در «گزارش خطای اجرای قبلی» ظاهر می‌شود. همین‌جا خورده می‌شود = شکست عادیِ تست. */
      s.listen((ev) {
        if (ev == RawSocketEvent.read) {
          final d = s.receive();
          if (d != null && d.data.length > 12 && d.data[0] == 0x4d && d.data[1] == 0x31) {
            if (!done.isCompleted) done.complete(true);
          }
        }
      }, onError: (Object e) {
        if (!done.isCompleted) done.complete(false);
      }, cancelOnError: true);
      s.send(q, addr, 53);
      final ok = await done.future.timeout(const Duration(seconds: 4), onTimeout: () => false);
      _js('__dnsTest', [id, ok, sw.elapsedMilliseconds]);
    } catch (_) {
      _js('__dnsTest', [id, false, sw.elapsedMilliseconds]);
    } finally {
      sock?.close();
    }
  }

  Future<void> _tcpTest(dynamic id, String host, int port) async {
    final sw = Stopwatch()..start();
    if (!RegExp(r'^[A-Za-z0-9.:\-]{1,253}$').hasMatch(host) || port <= 0 || port > 65535) {
      _js('__tcpRes', [id, false, 0]);
      return;
    }
    try {
      final s = await Socket.connect(host, port, timeout: const Duration(milliseconds: 3500));
      s.destroy();
      _js('__tcpRes', [id, true, sw.elapsedMilliseconds]);
    } catch (_) {
      _js('__tcpRes', [id, false, sw.elapsedMilliseconds]);
    }
  }

  Future<void> _startCfg(String config, String name) async {
    if (config.isEmpty) {
      _js('__v2status', ['ERR:کانفیگ خالی']);
      return;
    }
    try {
      await _ensureInit();
      if (!await _v2.requestPermission()) {
        _js('__v2status', ['ERR:مجوز VPN داده نشد']);
        return;
      }
      // اگه هسته‌ی قبلی هنوز بالاست اول خاموشش کن (وگرنه استارت جدید قاطی میشه)
      try {
        _v2.stopV2Ray();
      } catch (_) {}
      await Future.delayed(const Duration(milliseconds: 700));
      // Do NOT fake CONNECTED — wait for onStatusChanged from the core
      _v2.startV2Ray(
        remark: name,
        config: config,
        proxyOnly: false,
        bypassSubnets: null,
        blockedApps: null,
      );
      _js('__v2status', ['STARTING']);
    } catch (e) {
      _js('__v2status', ['ERR:اتصال برقرار نشد · ' + e.toString()]);
    }
  }

  // ---- mhrv-rs engine (Rust core + VpnService, see native/ and rust/) ----
  // Battery: poll the native engine only while the app is on screen.
  bool _mhrvActive = false;
  bool _inFg = true;
  bool _panelMode = false; // when true, WebView is showing the real panel URL
  String _lastMhrvStatus = ''; // v1.25.12 — کش وضعیت برای بیدارن‌کردن بیهودهٔ WebView

  Future<void> _pollOnce() async {
    try {
      final s = await _mhrv.invokeMethod<String>('status');
      if (s == null) return;
      /* v1.25.12 — اگر وضعیت عوض نشده، runJavaScript هر ۳ ثانیه صدا زده
         نمی‌شود؛ هر بیدارکردن WebView یعنی CPU/باتری (مهم‌تر وقتی VPN روشن است). */
      if (s == _lastMhrvStatus) return;
      _lastMhrvStatus = s;
      _js('__mhrvStatus', [s]);
    } catch (_) {}
  }

  void _startPoll() {
    if (!_mhrvActive || !_inFg || _poll != null) return;
    _pollOnce();
    _poll = Timer.periodic(const Duration(seconds: 3), (_) => _pollOnce());
  }

  void _stopPoll() {
    _poll?.cancel();
    _poll = null;
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    _inFg = state == AppLifecycleState.resumed;
    if (_inFg) {
      _startPoll();
      _takeShare(); // v1.26.0 — تب رسانه حذف شد؛ استاب JS فقط پیام می‌دهد
    } else {
      _stopPoll();
    }
  }

  // ---- HTTPS bridge for the page (Cloudflare / GitHub APIs; WebView can't call them due to CORS) ----
  static const Set<String> _httpHosts = {
    'api.cloudflare.com',
    'api.cloudflareclient.com',
    'api.github.com',
    'github.com',
    'raw.githubusercontent.com',
    'objects.githubusercontent.com',
    'release-assets.githubusercontent.com',
    'codeload.github.com',
    'backboard.railway.com',
    'cdn.jsdelivr.net',
  };


  /// آپلود کامل Worker روی Cloudflare از سمت native (مثل ربات رسمی)
  /// بدنهٔ بزرگ از JS عبور نمی‌کند → Nova و پنل‌های حجیم هم درست نصب می‌شوند.
  Future<void> _onDeploy(String raw) async {
    Map<String, dynamic> m;
    try {
      m = jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      return;
    }
    final id = m['id'];
    void reply(int status, String body) =>
        _js('__http', [id, jsonEncode({'status': status, 'body': body})]);

    try {
      final codeUrl = m['codeUrl'] as String? ?? '';
      final accountId = m['accountId'] as String? ?? '';
      final scriptName = m['scriptName'] as String? ?? '';
      final email = m['email'] as String? ?? '';
      final token = m['token'] as String? ?? '';
      final meta = m['meta'];
      if (codeUrl.isEmpty || accountId.isEmpty || scriptName.isEmpty || token.isEmpty) {
        reply(0, 'missing deploy fields');
        return;
      }

      final client = HttpClient()..connectionTimeout = const Duration(seconds: 60);
      try {
        // 1) دانلود worker.js
        final codeUri = Uri.parse(codeUrl);
        if (codeUri.scheme != 'https' || !_httpHosts.contains(codeUri.host)) {
          // اجازهٔ raw/github/release hosts
          final ok = codeUri.host.endsWith('github.com') ||
              codeUri.host.endsWith('githubusercontent.com') ||
              codeUri.host.endsWith('jsdelivr.net');
          if (!ok) {
            reply(0, 'blocked code host: ${codeUri.host}');
            return;
          }
        }
        final getReq = await client.getUrl(codeUri);
        getReq.followRedirects = true;
        getReq.maxRedirects = 10;
        getReq.headers.set('User-Agent', 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36');
        final getRes = await getReq.close().timeout(const Duration(seconds: 180));
        if (getRes.statusCode < 200 || getRes.statusCode >= 300) {
          reply(getRes.statusCode, 'download failed');
          return;
        }
        final codeBytes = await getRes.fold<List<int>>(
          <int>[],
          (p, e) => p..addAll(e),
        );
        if (codeBytes.length < 2000) {
          reply(0, 'worker too small: ${codeBytes.length}');
          return;
        }

        // 2) multipart مثل API ماژول Worker
        final boundary = '----pm${DateTime.now().millisecondsSinceEpoch}';
        final metaJson = jsonEncode(meta ?? <String, dynamic>{
          'main_module': 'worker.js',
          'compatibility_date': '2024-11-01',
          'compatibility_flags': ['nodejs_compat'],
          'bindings': [],
        });
        final pre = utf8.encode(
          '--$boundary\r\n'
          'Content-Disposition: form-data; name="metadata"\r\n'
          'Content-Type: application/json\r\n\r\n'
          '$metaJson\r\n'
          '--$boundary\r\n'
          'Content-Disposition: form-data; name="worker.js"; filename="worker.js"\r\n'
          'Content-Type: application/javascript+module\r\n\r\n',
        );
        final post = utf8.encode('\r\n--$boundary--\r\n');
        final body = <int>[...pre, ...codeBytes, ...post];

        // 3) PUT به Cloudflare
        final putUri = Uri.parse(
          'https://api.cloudflare.com/client/v4/accounts/$accountId/workers/scripts/$scriptName',
        );
        final putReq = await client.openUrl('PUT', putUri);
        putReq.followRedirects = true;
        putReq.headers.set('Content-Type', 'multipart/form-data; boundary=$boundary');
        putReq.headers.set('User-Agent', 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36');
        // همان منطق اپ: Global API Key = ایمیل + کلید؛ وگرنه Bearer Token
        final looksBearer = token.startsWith('eyJ') ||
            token.contains('-') && token.length > 40;
        if (email.isNotEmpty && !looksBearer) {
          putReq.headers.set('X-Auth-Email', email);
          putReq.headers.set('X-Auth-Key', token);
        } else {
          putReq.headers.set('Authorization', 'Bearer $token');
        }
        putReq.contentLength = body.length;
        putReq.add(body);
        final putRes = await putReq.close().timeout(const Duration(seconds: 180));
        final putText = await putRes
            .transform(const Utf8Decoder(allowMalformed: true))
            .join();
        reply(putRes.statusCode, putText);
      } finally {
        client.close(force: true);
      }
    } catch (e) {
      reply(0, e.toString());
    }
  }

  Future<void> _onHttp(String raw) async {
    Map<String, dynamic> m;
    try {
      m = jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      return;
    }
    final id = m['id'];
    void reply(int status, String body) =>
        _js('__http', [id, jsonEncode({'status': status, 'body': body})]);
    try {
      final uri = Uri.parse(m['url'] as String);
      final allowAny = m['allowAny'] == true;
      /* v1.25.11 — لینک ساب‌های http:// هم باید دانلود شوند: خیلی از پنل‌ها/فروشنده‌های
         کانفیگ ساب را با http می‌دهند و تا امروز «blocked host» می‌خوردند (خطای HTTP 0
         بی‌علت در تب PattNG). با allowAny (که فقط صداکننده‌های عمدی JS می‌زنند) هر دو
         اسکیم باز می‌شود؛ بدون allowAny همان دروازهٔ قبلی: فقط https و هاست‌های معلوم. */
      final okScheme = allowAny
          ? (uri.scheme == 'http' || uri.scheme == 'https')
          : (uri.scheme == 'https' && _httpHosts.contains(uri.host));
      if (!okScheme) {
        reply(0, 'blocked host');
        return;
      }
      final method = (m['method'] as String?) ?? 'GET';
      final hdr = (m['headers'] as Map?)?.cast<String, dynamic>() ?? <String, dynamic>{};
      final body = m['body'];
      final b64 = m['bodyB64'];
      List<int>? payload;
      if (b64 is String && b64.isNotEmpty) {
        // بدنهٔ باینری (آپلود zip روی Reflex Build) — base64 از JS می‌آید
        payload = base64Decode(b64);
      } else if (body is String) {
        payload = utf8.encode(body);
      }
      final c = HttpClient()..connectionTimeout = const Duration(seconds: 45);
      try {
        (int, String)? done;
        String err1 = '';
        try {
          done = await _hbOnce(c, method, uri, hdr, payload);
        } catch (e1) {
          err1 = e1.toString();
          /* v1.25.11 — فال‌بک DNS-over-HTTPS: اگر سیستم نتوانست هاست را resolve کند
             (Failed host lookup — آلودگی DNS/فیلترینگ که در ایران رایج است)، رکورد A را
             از رزولورهای DoHِ بدون‌نیازبه‌DNS (1.1.1.1 و 8.8.8.8 — خودشان IP اند) می‌گیریم
             و مستقیم به همان IP وصل می‌شویم. برای https، SNI و اعتبارسنجی گواهی همچنان با
             نام واقعی دامنه انجام می‌شود (SecureSocket.secure(host:...)) — گواهی جعلی هرگز
             قبول نمی‌شود و این مسیر فقط برای GETهای عمدیِ allowAny اجرا می‌شود. */
          if (allowAny &&
              method == 'GET' &&
              (err1.contains('Failed host lookup') || err1.contains('Lookup failed'))) {
            final ip = await _dohA(uri.host);
            if (ip != null) {
              try {
                done = await _hbRawGet(uri, ip, hdr);
              } catch (e2) {
                err1 = '$e1 / doh: $e2';
              }
            }
          }
        }
        if (done != null) {
          reply(done.$1, done.$2);
        } else {
          reply(0, 'network: $err1');
        }
      } finally {
        c.close(force: true);
      }
    } catch (e) {
      reply(0, 'network: $e');
    }
  }

  /// v1.25.11 — یک درخواست معمولی از طریق [HttpClient] (همان رفتار قبلی _onHttp)
  Future<(int, String)> _hbOnce(HttpClient c, String method, Uri uri,
      Map<String, dynamic> hdr, List<int>? payload) async {
    final req = await c.openUrl(method, uri);
    req.followRedirects = true;
    req.maxRedirects = 8;
    if (!hdr.keys.any((k) => k.toString().toLowerCase() == 'user-agent')) {
      req.headers.set('User-Agent', 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36');
    }
    hdr.forEach((k, v) => req.headers.set(k, v.toString()));
    if (payload != null) {
      req.contentLength = payload.length;
      req.add(payload);
    }
    final res = await req.close().timeout(const Duration(seconds: 180));
    final text = await res.transform(const Utf8Decoder(allowMalformed: true)).join();
    return (res.statusCode, text);
  }

  /// v1.25.11 — رزولوشن A-record با DoHِ بی‌نیاز از DNS (endpointها خودشان IP اند).
  /// هیچ گواهی‌ای اینجا بررسی نمی‌شود؛ خروجی فقط یک IP برای اتصال است.
  Future<String?> _dohA(String host) async {
    final h = host.trim();
    if (h.isEmpty || RegExp(r'^\d{1,3}(\.\d{1,3}){3}$').hasMatch(h)) return null;
    final eps = <String>[
      'https://1.1.1.1/dns-query?name=$h&type=A',
      'https://8.8.8.8/resolve?name=$h&type=A',
    ];
    for (final ep in eps) {
      try {
        final c = HttpClient()..connectionTimeout = const Duration(seconds: 6);
        try {
          final req = await c.getUrl(Uri.parse(ep));
          req.headers.set('Accept', 'application/dns-json');
          req.headers.set('User-Agent', 'Mozilla/5.0 (Linux; Android 14) Mobile Safari/537.36');
          final res = await req.close().timeout(const Duration(seconds: 8));
          final t = await res.transform(const Utf8Decoder(allowMalformed: true)).join();
          if (res.statusCode != 200 || t.isEmpty) continue;
          final j = jsonDecode(t);
          if (j is! Map) continue;
          final ans = j['Answer'];
          if (ans is List) {
            for (final a in ans) {
              if (a is Map && a['type'] == 1 && a['data'] is String) {
                final d = (a['data'] as String).trim();
                if (RegExp(r'^\d{1,3}(\.\d{1,3}){3}$').hasMatch(d)) return d;
              }
            }
          }
        } finally {
          c.close(force: true);
        }
      } catch (_) {}
    }
    return null;
  }

  /// v1.25.11 — GET خام روی IP معلوم (مسیر فال‌بک DoH، فقط GET بدون بدنه).
  /// SNI و اعتبارسنجی گواهی با نام واقعی دامنه انجام می‌شود، نه با IP.
  Future<(int, String)> _hbRawGet(Uri uri, String ip, Map<String, dynamic> hdr) async {
    final https = uri.scheme == 'https';
    final defPort = https ? 443 : 80;
    final port = uri.port == 0 ? defPort : uri.port;
    final host = uri.host;
    final path = (uri.path.isEmpty ? '/' : uri.path) + (uri.query.isEmpty ? '' : '?${uri.query}');
    final sock = await Socket.connect(ip, port, timeout: const Duration(seconds: 15));
    Socket s = sock;
    try {
      if (https) {
        s = await SecureSocket.secure(sock, host: host)
            .timeout(const Duration(seconds: 15));
      }
      final sb = StringBuffer();
      sb.write('GET $path HTTP/1.1\r\n');
      sb.write('Host: $host${port == defPort ? '' : ':$port'}\r\n');
      var hasUA = false;
      hdr.forEach((k, v) {
        final kl = k.toString().toLowerCase();
        if (kl == 'host' || kl == 'connection' || kl == 'content-length' || kl == 'accept-encoding') return;
        if (kl == 'user-agent') hasUA = true;
        sb.write('${k.toString()}: ${v.toString()}\r\n');
      });
      if (!hasUA) {
        sb.write('User-Agent: Mozilla/5.0 (Linux; Android 14) Mobile Safari/537.36\r\n');
      }
      sb.write('Accept: text/plain,*/*\r\nConnection: close\r\n\r\n');
      s.add(utf8.encode(sb.toString()));
      final resp = <int>[];
      await for (final chunk in s.timeout(const Duration(seconds: 60))) {
        resp.addAll(chunk);
        if (resp.length > 8 * 1024 * 1024) break;
      }
      final txt = utf8.decode(resp, allowMalformed: true);
      final ix = txt.indexOf('\r\n\r\n');
      if (ix < 0) return (0, 'raw: bad response');
      final head = txt.substring(0, ix);
      final stM = RegExp(r'HTTP/1\.[01] (\d{3})').firstMatch(head);
      final status = stM != null ? int.parse(stM.group(1)!) : 0;
      final low = head.toLowerCase();
      final bodyBytes = resp.sublist(ix + 4);
      final bodyOut = low.contains('transfer-encoding: chunked')
          ? _hbDechunk(bodyBytes)
          : utf8.decode(bodyBytes, allowMalformed: true);
      return (status, bodyOut);
    } finally {
      try {
        sock.destroy();
      } catch (_) {}
    }
  }

  /// v1.25.11 — رمزگشای Transfer-Encoding: chunked برای مسیر GET خام
  String _hbDechunk(List<int> b) {
    final out = <int>[];
    var i = 0;
    while (i < b.length) {
      var j = i;
      while (j + 1 < b.length && !(b[j] == 13 && b[j + 1] == 10)) {
        j++;
      }
      if (j + 1 >= b.length) break;
      final sizeStr = String.fromCharCodes(b.sublist(i, j)).split(';')[0].trim();
      final size = int.tryParse(sizeStr, radix: 16);
      if (size == null || size <= 0) break;
      final start = j + 2;
      if (start + size > b.length) break;
      out.addAll(b.sublist(start, start + size));
      i = start + size + 2;
    }
    return utf8.decode(out, allowMalformed: true);
  }

  Future<void> _onMhrv(String raw) async {
    Map<String, dynamic> m;
    try {
      m = jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      return;
    }
    try {
      switch (m['cmd']) {
        case 'init':
          final v = await _mhrv.invokeMethod<String>('init');
          _js('__mhrvInit', [v ?? '']);
          _mhrvActive = true;
          _startPoll();
          break;
        case 'start':
          final r = await _mhrv.invokeMethod<String>('start', {'config': m['config']});
          _js('__mhrvStart', [r ?? 'ERR:بدون پاسخ']);
          break;
        case 'dnsProbe':
          // پینگ واقعی DNS (کوئری UDP/53) — نتایج به‌صورت JSON آرایه
          try {
            final ips = (m['ips'] as List?)?.map((e) => e.toString()).toList() ?? const <String>[];
            final r = await _mhrv.invokeMethod<String>('dnsProbe', {'ips': ips});
            _js('__mhrvDnsProbe', [r ?? '[]']);
          } catch (_) {
            _js('__mhrvDnsProbe', ['[]']);
          }
          break;
        case 'slipStart':
          try {
            final r = await _mhrv.invokeMethod<String>('slipStart', {
              'uri': (m['uri'] as String?) ?? '',
              'dns': (m['dns'] as String?) ?? '',
            });
            _js('__slipStart', [r ?? 'ERR:بدون پاسخ']);
          } catch (_) {
            _js('__slipStart', ['ERR:UNSUPPORTED']);
          }
          break;
        case 'slipStop':
          try {
            await _mhrv.invokeMethod('slipStop');
          } catch (_) {}
          _js('__slipStop', ['STOPPED']);
          break;
        case 'slipStatus':
          try {
            final r = await _mhrv.invokeMethod<String>('slipStatus');
            _js('__slipStatus', [r ?? '{}']);
          } catch (_) {
            _js('__slipStatus', ['{}']);
          }
          break;
        case 'torStart':
          try {
            final r = await _mhrv.invokeMethod<String>('torStart', {
              'bridges': (m['bridges'] as String?) ?? '',
            });
            _js('__torStart', [r ?? 'ERR:بدون پاسخ']);
          } catch (_) {
            _js('__torStart', ['ERR:UNSUPPORTED']);
          }
          break;
        case 'torStop':
          try {
            await _mhrv.invokeMethod('torStop');
          } catch (_) {}
          _js('__torStop', ['STOPPED']);
          break;
        case 'torStatus':
          try {
            final r = await _mhrv.invokeMethod<String>('torStatus');
            _js('__torStatus', [r ?? '{}']);
          } catch (_) {
            _js('__torStatus', ['{}']);
          }
          break;
        case 'shkStart':
          try {
            final r = await _mhrv.invokeMethod<String>('shkStart');
            _js('__shkStart', [r ?? 'ERR:بدون پاسخ']);
          } catch (_) {
            _js('__shkStart', ['ERR:UNSUPPORTED']);
          }
          break;
        case 'shkStop':
          try {
            await _mhrv.invokeMethod('shkStop');
          } catch (_) {}
          _js('__shkStop', ['STOPPED']);
          break;
        case 'shkStatus':
          try {
            final r = await _mhrv.invokeMethod<String>('shkStatus');
            _js('__shkStatus', [r ?? '{}']);
          } catch (_) {
            _js('__shkStatus', ['{}']);
          }
          break;
        case 'engineInfo':
          // v1.24.4: کدام موتورها واقعاً داخل APK باندل شده‌اند؟
          try {
            final r = await _mhrv.invokeMethod<String>('engineInfo');
            _js('__engineInfo', [r ?? '{}']);
          } catch (_) {
            _js('__engineInfo', ['{}']);
          }
          break;
        case 'stop':
          await _mhrv.invokeMethod('stop');
          break;
        case 'caInfo':
          final r = await _mhrv.invokeMethod<String>('caInfo');
          _js('__mhrvCa', [r ?? '{}']);
          break;
        case 'caInstall':
          final r = await _mhrv.invokeMethod<String>('caInstall');
          _js('__mhrvCaInstall', [r ?? '']);
          break;
      }
    } catch (e) {
      _js('__mhrvStart', ['ERR:هسته‌ی mhrv-rs در این نسخه‌ی برنامه نیست یا خطا داد']);
    }
  }

  /// v1.25.36 — مرکز امنیت: هر درخواست JS → بومی (رم/برنامه‌ها/فایل‌ها/برنامهٔ جدید)
  Future<void> _onSec(String raw) async {
    Map<String, dynamic> m;
    try {
      m = jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      return;
    }
    final op = (m['op'] as String?) ?? '';
    try {
      final r = await _mhrv.invokeMethod<String>('sec', m);
      _js('__secData', [op, r ?? '{}']);
    } catch (e) {
      _js('__secData', [op, '{"err":' + jsonEncode(e.toString()) + '}']);
    }
  }

  /// v1.26.0 — تب رسانه حذف شد؛ این فراخوانی فقط استاب امن JS را صدا می‌زند
  Future<void> _takeShare() async {
    try {
      final s = await _mhrv.invokeMethod<String>('takeShare');
      if (s != null && s.trim().isNotEmpty) {
        _js('__shareIn', [s]);
      }
    } catch (_) {}
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _stopPoll();
    super.dispose();
  }

  // ---- real network probes (TCP/TLS :443, DNS :53) ----
  Future<void> _onScan(String raw) async {
    Map<String, dynamic> m;
    try {
      m = jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      return;
    }
    final id = m['id'];
    final host = (m['host'] as String?) ?? '';
    if (!RegExp(r'^[A-Za-z0-9.:\-]{1,253}$').hasMatch(host)) {
      _js('__scanRes', [id, false, 0, 'آدرس نامعتبره']); // v1.25.29 — دلیل صادقانه
      return;
    }
    final mode = (m['mode'] as String?) ?? 'tls';
    final toMs = (m['timeout'] as int?) ?? 3500;
    final to = Duration(milliseconds: toMs);
    final sw = Stopwatch()..start();
    try {
      if (mode == 'dns') {
        /* v1.25.12 — اسکن DNS دیگر فقط TCP:53 نیست. در ایران پورت ۵۳ به
           رزولورهای خارجی بسته/رهگیری می‌شود و برای دامنه‌های DoH (زیرتب «دامنه»)
           پورت ۵۳ اصلاً پورت کار آن‌ها نیست — نتیجه: «هیچی اسکن نمی‌شود».
           حالا لایه‌ای: اول DoH روی 443 (همان چیزی که پنل واقعاً استفاده می‌کند)،
           بعد کوئری واقعی UDP/53، بعد TCP/53 — و لایهٔ برنده برگردانده می‌شود. */
        final d = await _dnsLayerProbe(host);
        if (d == null) {
          /* v1.25.29 — دلیل واقعی شکست هم می‌رود (آرگومان چهارم detail) */
          _js('__scanRes', [id, false, sw.elapsedMilliseconds, _probeWhy]);
        } else {
          _js('__scanRes', [id, true, d.$2, d.$1]);
        }
      } else if (mode == 'tcp') {
        final s = await Socket.connect(host, 443, timeout: to);
        s.destroy();
      } else {
        // Clean IP/domain: TCP:443 first (fast), then TLS
        try {
          final s = await Socket.connect(host, 443, timeout: Duration(milliseconds: toMs ~/ 2));
          s.destroy();
        } catch (_) {
          final s = await SecureSocket.connect(host, 443,
              timeout: to, onBadCertificate: (_) => true);
          s.destroy();
        }
      }
      _js('__scanRes', [id, true, sw.elapsedMilliseconds]);
    } catch (e) {
      /* v1.25.29 — دلیل واقعی شکست (شبکه در دسترس نیست / تایم‌اوت / TLS …) */
      _js('__scanRes', [id, false, sw.elapsedMilliseconds, _whyOf(e)]);
    }
  }

  /// v1.25.29 — آخرین دلیل شکستِ پروب برای نمایش صادقانه در نتایج اسکن.
  /// تا وقتی اسکنر می‌گردد هر لایهٔ شکست‌خورده این را به‌روز می‌کند؛ اگر همهٔ لایه‌ها
  /// شکست بخورند، همین پیام به‌جای «هیچی نیامدِ بی‌توضیح» به JS می‌رود.
  String _probeWhy = 'اتصال برقرار نشد';

  /// v1.25.29 — دسته‌بندی خطای شبکه به پیام کوتاه فارسی (برای نتایج اسکن).
  String _whyOf(Object e) {
    final s = e.toString();
    if (e is SocketException) {
      final en = e.osError?.errorCode ?? -1;
      if (en == 101 || s.contains('Network is unreachable')) {
        return 'شبکه در دسترس نیست (اینترنت/VPN را چک کن)';
      }
      if (en == 111 || s.contains('Connection refused')) return 'اتصال رد شد (پورت بسته)';
      if (en == 110 || s.contains('timed out') || s.contains('Timeout')) return 'پاسخی نیامد (تایم‌اوت)';
    }
    if (e is HandshakeException || s.contains('HandshakeException') || s.contains('handshake')) {
      return 'دست‌دادن TLS نشد (احتمال اختلال/SNI)';
    }
    if (s.contains('Failed host lookup') || s.contains('Lookup failed')) return 'دامنه پیدا نشد (DNS)';
    if (s.contains('timed out') || s.contains('Timeout')) return 'پاسخی نیامد (تایم‌اوت)';
    return 'اتصال برقرار نشد';
  }

  /// v1.25.12 — پروب لایه‌ای DNS برای اسکنر تب اسکن.
  /// IP عددی:  TLS:443 (ظرفیت DoH — همان مسیری که پنل/ریموت‌دی‌ان‌اس واقعاً
  /// استفاده می‌کند) → کوئری واقعی UDP/53 → TCP/53.
  /// دامنه:    TLS:443 (DoH) → TCP/53.
  /// خروجی: (نام لایهٔ برنده، تأخیر همان لایه) — جمعِ بدترین حالت ۹ ثانیه
  /// زیر تایم‌اوت JS (۹٫۵ ثانیه + فال‌بک ۱۵۰۰) می‌ماند؛ ms نمایشی هم تأخیر
  /// واقعیِ همان لایهٔ برنده است نه جمع تلاش‌های شکست‌خورده.
  Future<(String, int)?> _dnsLayerProbe(String host) async {
    final numeric = RegExp(r'^\d{1,3}(\.\d{1,3}){3}$').hasMatch(host);
    // 1) DoH/443 — دست‌دادن TLS (گواهی اعتبارسنجی نمی‌شود؛ فقط «در دسترس بودن» ثابت می‌شود)
    final swTls = Stopwatch()..start();
    try {
      final s = await SecureSocket.connect(host, 443,
          timeout: const Duration(milliseconds: 4200),
          onBadCertificate: (_) => true);
      s.destroy();
      return ('DoH/443', swTls.elapsedMilliseconds);
    } catch (e) {
      _probeWhy = _whyOf(e); // v1.25.29
    }
    if (numeric) {
      // 2) کوئری واقعی DNS روی UDP/53 (تأخیر واقعی رزولوشن)
      final udpMs = await _dnsUdp(host, const Duration(milliseconds: 2200));
      if (udpMs >= 0) return ('UDP/53', udpMs);
      // 3) TCP/53
      final swTcp = Stopwatch()..start();
      try {
        final s = await Socket.connect(host, 53,
            timeout: const Duration(milliseconds: 2600));
        s.destroy();
        return ('TCP/53', swTcp.elapsedMilliseconds);
      } catch (e) {
        _probeWhy = _whyOf(e); // v1.25.29
      }
    } else {
      // 2) TCP/53 (بعضی هاست‌های DoH هنوز DNS ساده هم سرو می‌کنند)
      final swTcp = Stopwatch()..start();
      try {
        final s = await Socket.connect(host, 53,
            timeout: const Duration(milliseconds: 2600));
        s.destroy();
        return ('TCP/53', swTcp.elapsedMilliseconds);
      } catch (e) {
        _probeWhy = _whyOf(e); // v1.25.29
      }
    }
    return null;
  }

  /// v1.25.12 — یک کوئری A واقعی UDP/53 (مثل _dnsTest ولی برای اسکنر؛ txid جدا).
  /// خروجی: تأخیر پاسخ بر حسب ms، یا -1 اگر جوابی نیامد.
  Future<int> _dnsUdp(String ip, Duration timeout) async {
    RawDatagramSocket? sock;
    final sw = Stopwatch()..start();
    try {
      final addr = InternetAddress(ip);
      sock = await RawDatagramSocket.bind(
        addr.type == InternetAddressType.IPv6
            ? InternetAddress.anyIPv6
            : InternetAddress.anyIPv4,
        0,
      );
      final q = <int>[0x4d, 0x32, 0x01, 0x00, 0, 1, 0, 0, 0, 0, 0, 0];
      for (final part in 'www.google.com'.split('.')) {
        q.add(part.length);
        q.addAll(part.codeUnits);
      }
      q.addAll([0, 0, 1, 0, 1]);
      final done = Completer<bool>();
      final s = sock;
      /* v1.25.29 — onError اجباری (مثل _dnsTest): بدون آن خطای send تا زونِ گارد
         بالا می‌رود و به‌عنوان کرش ثبت می‌شود — ریشهٔ «گزارش خطای اجرای قبلی». */
      s.listen((ev) {
        if (ev == RawSocketEvent.read) {
          final d = s.receive();
          if (d != null &&
              d.data.length > 12 &&
              d.data[0] == 0x4d &&
              d.data[1] == 0x32) {
            if (!done.isCompleted) done.complete(true);
          }
        }
      }, onError: (Object e) {
        if (!done.isCompleted) done.complete(false);
      }, cancelOnError: true);
      s.send(q, addr, 53);
      final ok = await done.future.timeout(timeout, onTimeout: () => false);
      if (!ok) _probeWhy = 'سرور DNS جوابی نداد (UDP تایم‌اوت)'; // v1.25.29
      return ok ? sw.elapsedMilliseconds : -1;
    } catch (e) {
      _probeWhy = _whyOf(e); // v1.25.29 — مثل errno 101 «شبکه در دسترس نیست»
      return -1;
    } finally {
      sock?.close();
    }
  }

  Future<void> _onStore(String raw) async {
    try {
      final m = jsonDecode(raw) as Map<String, dynamic>;
      if (m['cmd'] == 'set') {
        await _mhrv.invokeMethod('kvSet', {'k': m['k'], 'v': m['v']});
      } else if (m['cmd'] == 'del') {
        await _mhrv.invokeMethod('kvDel', {'k': m['k']});
      } else if (m['cmd'] == 'get') {
        final k = (m['k'] as String?) ?? '';
        final cb = (m['cb'] as String?) ?? '';
        String v = '';
        try {
          v = (await _mhrv.invokeMethod<String>('kvGet', {'k': k})) ?? '';
        } catch (_) {}
        if (cb.isNotEmpty) {
          final js = "window['" + cb + "']&&window['" + cb + "'](" + jsonEncode(v) + ");";
          await _c.runJavaScript(js);
        }
      }
    } catch (_) {}
  }

  Future<void> _restoreAcc() async {
    String v = '';
    try {
      v = (await _mhrv.invokeMethod<String>('kvGet', {'k': 'acc_v1'})) ?? '';
    } catch (_) {}
    await _c.runJavaScript('window.__restoreAcc&&window.__restoreAcc(${jsonEncode(v)});');
    // PattNG configs
    String pt = '';
    try {
      pt = (await _mhrv.invokeMethod<String>('kvGet', {'k': 'pt_v1'})) ?? '';
    } catch (_) {}
    await _c.runJavaScript('window.__restorePt&&window.__restorePt(${jsonEncode(pt)});');
    // UI tab + WARP + DNS + proxy session
    String ui = '';
    try {
      ui = (await _mhrv.invokeMethod<String>('kvGet', {'k': 'ui_v1'})) ?? '';
    } catch (_) {}
    await _c.runJavaScript('window.__restoreUi&&window.__restoreUi(${jsonEncode(ui)});');
  }

  Future<void> _injectCode() async {
    try {
      final code = await rootBundle.loadString('assets/Code.gs');
      await _c.runJavaScript('window.__GS_CODE=${jsonEncode(code)};');
    } catch (_) {}
    await _restoreAcc();
  }

  Future<void> _onGs(String raw) async {
    Map<String, dynamic> m;
    try {
      m = jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      return;
    }
    if (m['cmd'] == 'open') {
      final u = Uri.tryParse((m['url'] as String?) ?? '');
      if (u != null && u.scheme == 'https' && u.host.isNotEmpty) {
        try {
          await AndroidIntent(action: 'android.intent.action.VIEW', data: u.toString()).launch();
        } catch (_) {}
      }
    } else if (m['cmd'] == 'openInApp') {
      final u = Uri.tryParse((m['url'] as String?) ?? '');
      if (u != null && u.scheme == 'https' && u.host.isNotEmpty) {
        _panelMode = true;
        await _c.loadRequest(u);
      }
    } else if (m['cmd'] == 'backToApp') {
      await _returnToApp();
    } else if (m['cmd'] == 'test') {
      final r = await _gsTest((m['id'] as String).trim(), (m['key'] as String).trim());
      _js('__gsTest', [r]);
    }
  }

  Future<void> _returnToApp() async {
    _panelMode = false;
    await _c.loadFlutterAsset('assets/index.html');
  }

  /// Real check of the Apps Script relay (protocol from Code.gs: {k,m,u,h,b,ct,r} -> {s,h,b} | {e}).
  Future<String> _gsTest(String id, String key) async {
    final c = HttpClient()..connectionTimeout = const Duration(seconds: 15);
    try {
      var uri = Uri.parse('https://script.google.com/macros/s/$id/exec');
      final req = await c.postUrl(uri);
      req.followRedirects = false;
      req.headers.contentType = ContentType.json;
      req.write(jsonEncode({'k': key, 'm': 'GET', 'u': 'https://example.com/', 'h': {}, 'r': true}));
      var res = await req.close().timeout(const Duration(seconds: 25));
      var hops = 0;
      while ({301, 302, 303, 307, 308}.contains(res.statusCode) && hops < 5) {
        final loc = res.headers.value('location');
        await res.drain();
        if (loc == null) break;
        uri = uri.resolve(loc);
        final r2 = await c.getUrl(uri);
        r2.followRedirects = false;
        res = await r2.close().timeout(const Duration(seconds: 25));
        hops++;
      }
      final text = await res.transform(utf8.decoder).join();
      if (res.statusCode == 404) return 'ERR:Deployment ID اشتباهه (۴۰۴)';
      try {
        final j = jsonDecode(text);
        if (j is Map && j['s'] != null) return 'OK:رله کار می‌کنه · پاسخ example.com = ${j['s']}';
        if (j is Map && j['e'] != null) return 'ERR:خطای رله: ${j['e']}';
      } catch (_) {}
      if (text.contains('did not return anything')) {
        return 'ERR:Auth key با رمز داخل Code.gs نمی‌خونه، یا دیپلوی نسخه‌ی جدید نشده';
      }
      return 'ERR:پاسخ نامعتبر (کد ${res.statusCode})';
    } on SocketException {
      return 'ERR:به script.google.com نرسید (اینترنت یا فیلتر)';
    } on HandshakeException {
      return 'ERR:اتصال TLS برقرار نشد';
    } catch (e) {
      return 'ERR:تست ناموفق (زمان تموم شد یا خطای شبکه)';
    } finally {
      c.close(force: true);
    }
  }

  Future<void> _ensureInit() async {
    if (!_v2ready) {
      await _v2.initializeV2Ray();
      _v2ready = true;
    }
  }

  // ---- v1.25.0: مبدل کامل لینک → پیکربندی Xray (به‌جای پارسر ناقص پلاگین) ----
  // درد کاربر: کانفیگ‌هایی که توی v2rayNG کار می‌کنند اینجا وصل نمی‌شدند.
  // ریشه: پارسر flutter_v2ray پارامترهای زیاد را گم می‌کند (httpupgrade/splithttp،
  // path ws وقتی نیست به شکل آرایه می‌رود، + را فاصله می‌کند، URL خراب را crash می‌کند
  // و inbound http ندارد پس probe تونل همیشه شکست می‌خورد). اینجا خودمان کامل می‌سازیم.
  String _dec(String s) {
    try {
      return Uri.decodeComponent(s);
    } catch (_) {
      return s;
    }
  }

  String _b64d(String s) {
    var r = s.replaceAll('-', '+').replaceAll('_', '/').trim();
    while (r.length % 4 > 0) {
      r += '=';
    }
    return utf8.decode(base64Decode(r));
  }

  /// کوئری را دستی می‌خوانیم — بدون تبدیل + به فاصله و بدون crash روی % خراب
  Map<String, String> _qmap(String url) {
    final out = <String, String>{};
    final qi = url.indexOf('?');
    if (qi < 0) return out;
    var rest = url.substring(qi + 1);
    final hi = rest.indexOf('#');
    if (hi >= 0) rest = rest.substring(0, hi);
    for (final part in rest.split('&')) {
      if (part.isEmpty) continue;
      final eq = part.indexOf('=');
      if (eq < 0) {
        out[_dec(part)] = '';
      } else {
        out[_dec(part.substring(0, eq))] = _dec(part.substring(eq + 1));
      }
    }
    return out;
  }

  /// userinfo@host:port (پشتیبانی IPv6) — از آخرین '@' می‌خوانیم تا شناسهٔ base64 سالم بماند
  Map<String, String> _authority(String a) {
    var s = a;
    String user = '';
    final at = s.lastIndexOf('@');
    if (at >= 0) {
      user = s.substring(0, at);
      s = s.substring(at + 1);
    }
    String host;
    var port = 443;
    if (s.startsWith('[')) {
      final e = s.indexOf(']');
      host = e > 0 ? s.substring(1, e) : s;
      final r = e > 0 ? s.substring(e + 1) : '';
      if (r.startsWith(':')) port = int.tryParse(r.substring(1)) ?? 443;
    } else {
      final c = s.lastIndexOf(':');
      if (c >= 0) {
        host = s.substring(0, c);
        port = int.tryParse(s.substring(c + 1)) ?? 443;
      } else {
        host = s;
      }
    }
    return {'user': user, 'host': host, 'port': '$port'};
  }

  Map<String, dynamic> _streamFor(String net, String headerType, String host,
      String path, String seed, String mode, String serviceName) {
    final s = <String, dynamic>{'network': net, 'security': ''};
    if (net == 'ws') {
      final w = <String, dynamic>{'path': path.isEmpty ? '/' : path};
      if (host.isNotEmpty) w['headers'] = {'Host': host};
      s['wsSettings'] = w;
    } else if (net == 'httpupgrade') {
      s['httpupgradeSettings'] = {
        'path': path.isEmpty ? '/' : path,
        'host': host
      };
    } else if (net == 'xhttp' || net == 'splithttp') {
      s['network'] = 'xhttp';
      s['xhttpSettings'] = {
        'path': path.isEmpty ? '/' : path,
        'host': host,
        'mode': mode.isEmpty ? 'auto' : mode
      };
    } else if (net == 'grpc') {
      s['grpcSettings'] = {
        'serviceName': serviceName,
        'multiMode': mode == 'multi'
      };
    } else if (net == 'kcp') {
      final k = <String, dynamic>{
        'mtu': 1350,
        'tti': 50,
        'uplinkCapacity': 12,
        'downlinkCapacity': 100,
        'congestion': false,
        'readBufferSize': 1,
        'writeBufferSize': 1,
        'header': {'type': headerType.isEmpty ? 'none' : headerType}
      };
      if (seed.isNotEmpty) k['seed'] = seed;
      s['kcpSettings'] = k;
    } else if (net == 'quic') {
      s['quicSettings'] = {
        'security': host.isEmpty ? 'none' : host,
        'key': path,
        'header': {'type': headerType.isEmpty ? 'none' : headerType}
      };
    } else if (net == 'h2' || net == 'http') {
      s['network'] = 'h2';
      s['httpSettings'] = {
        'host': host.isEmpty ? <String>[] : host.split(','),
        'path': path.isEmpty ? '/' : path
      };
    } else if (headerType == 'http') {
      s['tcpSettings'] = {
        'header': {
          'type': 'http',
          'request': {
            'version': '1.1',
            'method': 'GET',
            'path': path.isEmpty ? <String>['/'] : path.split(','),
            'headers': {
              'Host': host.isEmpty ? <String>[''] : host.split(','),
              'User-Agent': <String>[
                'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
              ],
              'Accept-Encoding': <String>['gzip, deflate'],
              'Connection': <String>['keep-alive'],
              'Pragma': 'no-cache'
            }
          }
        }
      };
    } else {
      s['tcpSettings'] = {
        'header': {'type': 'none'}
      };
    }
    return s;
  }

  void _applyTls(Map<String, dynamic> s, String sec, String sni, String fp,
      String alpn, String pbk, String sid, String spx, bool allowInsecure) {
    if (sec != 'tls' && sec != 'reality') return;
    s['security'] = sec;
    final t = <String, dynamic>{'serverName': sni, 'allowInsecure': allowInsecure};
    if (alpn.isNotEmpty) t['alpn'] = alpn.split(',');
    if (sec == 'reality') {
      if (fp.isEmpty) {
        t['fingerprint'] = 'chrome';
      } else {
        t['fingerprint'] = fp;
      }
      t['publicKey'] = pbk;
      t['shortId'] = sid;
      if (spx.isNotEmpty) t['spiderX'] = spx;
      s['realitySettings'] = t;
    } else {
      if (fp.isNotEmpty) t['fingerprint'] = fp;
      s['tlsSettings'] = t;
    }
  }

  bool _insec(Map<String, String> q) {
    final v = (q['allowInsecure'] ?? q['insecure'] ?? '').toLowerCase();
    if (v == '0' || v == 'false') return false;
    return true; // مثل رفتار قبلی پلاگین — سخت‌گیر نیستیم
  }

  /* v1.25.36 — کانفیگ با گزینه‌های واقعی «تنظیمات PattNG»: پورت SOCKS، Sniffing/RouteOnly،
     FakeDNS، UDP، اشتراک LAN، IPv6، MUX، فرگمنت، DNS و مقصد LAN — هر ردیف تنظیمات
     واقعاً روی کانفیگ Xray می‌نشیند (بدون گزینه = همان رفتار قبلی). */
  Map<String, dynamic> _wrapConfig(Map<String, dynamic> proxy0, Map? opts) {
    final o = (opts is Map) ? opts : const {};
    int intOpt(String k, int def) {
      final v = o[k];
      if (v is int && v > 0) return v;
      if (v is String) {
        final p = int.tryParse(v);
        if (p != null && p > 0) return p;
      }
      return def;
    }
    final socksPort = intOpt('socksPort', 10808);
    final sniffing = o['sniffing'] == true;
    final routeOnly = o['routeOnly'] == true;
    final fakeDns = o['fakeDns'] == true;
    final udp = o['udp'] != false;
    final ipv6 = o['ipv6'] == true;
    final lanDirect = o['lanDirect'] != false;
    final httpOn = o['httpOn'] == true;
    final muxOn = o['mux'] == true;
    final muxConc = intOpt('muxConc', 8);
    final frag = (o['frag'] is Map) ? (o['frag'] as Map) : null;
    final fragOn = frag != null && frag['on'] == true;
    final dnsList = (o['dns'] is List && (o['dns'] as List).isNotEmpty)
        ? (o['dns'] as List).map((e) => e.toString()).where((e) => e.isNotEmpty).toList()
        : <String>['1.1.1.1', '8.8.8.8'];

    /* v1.25.41 — تنظیمات جدید PattNG (واقعی): سطح گزارشات، ترجیح IPv6 در resolve،
       DNS مستقیم هاست (dns.hosts) و احراز هویت پروکسی محلی (socks accounts) */
    final logLevel = (o['logLevel'] is String &&
            const ['debug', 'info', 'warning', 'error', 'none'].contains(o['logLevel']))
        ? o['logLevel'] as String
        : 'warning';
    final queryStrategy = ipv6
        ? ((o['ipv6Pref'] == true) ? 'UseIPv6' : 'UseIP')
        : 'UseIPv4';
    final hostMap = <String, String>{};
    if (o['dnsHosts'] is Map) {
      (o['dnsHosts'] as Map).forEach((k, v) {
        final key = k.toString().trim();
        final val = v.toString().trim();
        if (key.isNotEmpty && val.isNotEmpty) hostMap[key] = val;
      });
    }
    final proxyUser = (o['proxyUser'] is String) ? (o['proxyUser'] as String).trim() : '';
    final proxyPass = (o['proxyPass'] is String) ? (o['proxyPass'] as String).trim() : '';

    final Map<String, dynamic>? sniff = sniffing
        ? {
            'enabled': true,
            'destOverride': fakeDns ? ['fakedns'] : ['http', 'tls', 'quic'],
            'routeOnly': routeOnly,
          }
        : null;

    final inbounds = <Map<String, dynamic>>[
      {
        'tag': 'socks-in',
        'listen': (o['lanShare'] == true) ? '0.0.0.0' : '127.0.0.1',
        'port': socksPort,
        'protocol': 'socks',
        /* v1.25.41 — نام کاربری/رمز پروکسی محلی از تنظیمات PattNG واقعاً اعمال می‌شود */
        'settings': (proxyUser.isNotEmpty)
            ? {
                'auth': 'password',
                'accounts': [
                  {'user': proxyUser, 'pass': proxyPass}
                ],
                'udp': udp,
                'userLevel': 8
              }
            : {'auth': 'noauth', 'udp': udp, 'userLevel': 8},
        if (sniff != null) 'sniffing': sniff,
      },
      if (httpOn)
        {
          'tag': 'http-in',
          'listen': '127.0.0.1',
          'port': socksPort + 1,
          'protocol': 'http',
          'settings': {'userLevel': 8},
          if (sniff != null) 'sniffing': sniff,
        }
    ];

    Map<String, dynamic> proxy = Map<String, dynamic>.from(proxy0);
    final outbounds = <Map<String, dynamic>>[];
    if (muxOn && (proxy['protocol'] == 'vmess' || proxy['protocol'] == 'vless')) {
      proxy['mux'] = {'enabled': true, 'concurrency': muxConc};
    }
    if (fragOn) {
      final st = Map<String, dynamic>.from((proxy['streamSettings'] as Map?) ?? {});
      st['sockopt'] = {'dialerProxy': 'frag-out'};
      proxy['streamSettings'] = st;
      outbounds.add({
        'tag': 'frag-out',
        'protocol': 'freedom',
        'settings': {
          'domainStrategy': ipv6 ? 'UseIP' : 'UseIPv4',
          'fragment': {
            'packets': ((frag['packets'] ?? 'tlshello')).toString(),
            'length': ((frag['length'] ?? '100-200')).toString(),
            'interval': ((frag['interval'] ?? '1-1')).toString(),
          }
        }
      });
    }
    outbounds.add(proxy);
    outbounds.add({
      'tag': 'direct',
      'protocol': 'freedom',
      'settings': {'domainStrategy': ipv6 ? 'UseIP' : 'UseIPv4'}
    });
    outbounds.add({'tag': 'block', 'protocol': 'blackhole'});

    return {
      'log': {'loglevel': logLevel},
      'inbounds': inbounds,
      'outbounds': outbounds,
      if (fakeDns) 'fakedns': {'ipRange': '198.18.0.0/15', 'poolSize': 10000},
      'dns': {
        'servers': dnsList,
        'queryStrategy': queryStrategy,
        if (hostMap.isNotEmpty) 'hosts': hostMap
      },
      'routing': {
        'domainStrategy': 'IPIfNonMatch',
        'rules': [
          {'type': 'field', 'ip': ['geoip:private'], 'outboundTag': lanDirect ? 'direct' : 'block'}
        ]
      }
    };
  }

  /// v1.25.36 — اعمال گزینه‌ها روی کانفیگ آمادهٔ پارسر پلاگین (مسیر فال‌بک)
  String _applyOpts(String cfgJson, Map? opts) {
    try {
      final o = (opts is Map) ? opts : const {};
      if (o.isEmpty) return cfgJson;
      final j = jsonDecode(cfgJson);
      if (j is! Map) return cfgJson;
      final cfg = Map<String, dynamic>.from(j);
      final socksPort = (o['socksPort'] is int && (o['socksPort'] as int) > 0)
          ? o['socksPort'] as int
          : 10808;
      final inb = (cfg['inbounds'] as List?) ?? [];
      if (inb.isNotEmpty && inb.first is Map) {
        final first = Map<String, dynamic>.from(inb.first as Map);
        first['port'] = socksPort;
        if (o['sniffing'] == true) {
          first['sniffing'] = {
            'enabled': true,
            'destOverride': o['fakeDns'] == true ? ['fakedns'] : ['http', 'tls', 'quic'],
            'routeOnly': o['routeOnly'] == true,
          };
        }
        inb[0] = first;
      }
      if (o['dns'] is List && (o['dns'] as List).isNotEmpty) {
        cfg['dns'] = {
          'servers': (o['dns'] as List).map((e) => e.toString()).where((e) => e.isNotEmpty).toList()
        };
      }
      if (o['fakeDns'] == true) {
        cfg['fakedns'] = {'ipRange': '198.18.0.0/15', 'poolSize': 10000};
      }
      return jsonEncode(cfg);
    } catch (_) {
      return cfgJson;
    }
  }

  /// لینک اشتراک → پیکربندی کامل Xray. اگر پروتکل با هستهٔ Xray ممکن نیست null برمی‌گردد.
  String? _buildXrayConfig(String link, [Map? opts]) {
    link = link.trim();
    final scheme =
        RegExp(r'^([a-zA-Z0-9+]+)://').firstMatch(link)?.group(1)?.toLowerCase() ?? '';
    if (scheme == 'vmess') {
      final j = jsonDecode(_b64d(link.substring(8))) as Map<String, dynamic>;
      final g = (String k) => (j[k] ?? '').toString();
      final net = g('net').isEmpty ? 'tcp' : g('net');
      final q = <String, String>{
        'type': g('type'),
        'host': g('host'),
        'path': g('path')
      };
      // قرارداد لینک‌های vmess: grpc serviceName و kcp seed در فیلد path می‌آیند؛ quic در host
      final st = _streamFor(
          net,
          q['type']!,
          q['host']!,
          q['path']!,
          (net == 'kcp') ? q['path']! : '',
          q['type']!,
          (net == 'grpc') ? q['path']! : '');
      final sec = g('tls');
      final sni = g('sni').isNotEmpty ? g('sni') : (q['host'] ?? '');
      _applyTls(st, sec, sni, g('fp'), g('alpn'), '', '', '', _insec(q));
      final port = int.tryParse(g('port')) ?? 443;
      final proxy = {
        'tag': 'proxy',
        'protocol': 'vmess',
        'settings': {
          'vnext': [
            {
              'address': g('add'),
              'port': port,
              'users': [
                {
                  'id': g('id'),
                  'alterId': int.tryParse(g('aid')) ?? 0,
                  'security': g('scy').isEmpty ? 'auto' : g('scy'),
                  'level': 8
                }
              ]
            }
          ]
        },
        'streamSettings': st
      };
      return jsonEncode(_wrapConfig(proxy, opts));
    }
    if (scheme == 'vless' || scheme == 'trojan') {
      var body = link.substring(scheme.length + 3);
      final hi = body.indexOf('#');
      body = hi >= 0 ? body.substring(0, hi) : body;
      final qi = body.indexOf('?');
      final q = _qmap(link);
      final auth = _authority(qi >= 0 ? body.substring(0, qi) : body);
      final net = (q['type'] ?? 'tcp').isEmpty ? 'tcp' : (q['type'] ?? 'tcp');
      final st = _streamFor(
          net,
          q['headerType'] ?? '',
          q['host'] ?? '',
          q['path'] ?? '',
          q['seed'] ?? '',
          q['mode'] ?? '',
          (net == 'grpc') ? (q['serviceName'] ?? q['path'] ?? '') : '');
      var sec = q['security'] ?? '';
      if (scheme == 'trojan' && sec.isEmpty) sec = 'tls';
      final sni = (q['sni'] ?? '').isNotEmpty
          ? q['sni']!
          : ((q['host'] ?? '').isNotEmpty ? q['host']! : auth['host']!);
      _applyTls(st, sec, sni, q['fp'] ?? '', q['alpn'] ?? '', q['pbk'] ?? '',
          q['sid'] ?? '', q['spx'] ?? '', _insec(q));
      final Map<String, dynamic> proxy;
      if (scheme == 'vless') {
        proxy = {
          'tag': 'proxy',
          'protocol': 'vless',
          'settings': {
            'vnext': [
              {
                'address': auth['host'],
                'port': int.tryParse(auth['port']!) ?? 443,
                'users': [
                  {
                    'id': auth['user'],
                    'encryption': (q['encryption'] ?? '').isEmpty
                        ? 'none'
                        : q['encryption'],
                    'flow': q['flow'] ?? '',
                    'level': 8
                  }
                ]
              }
            ]
          },
          'streamSettings': st
        };
      } else {
        proxy = {
          'tag': 'proxy',
          'protocol': 'trojan',
          'settings': {
            'servers': [
              {
                'address': auth['host'],
                'port': int.tryParse(auth['port']!) ?? 443,
                'password': auth['user'],
                'level': 8
              }
            ]
          },
          'streamSettings': st
        };
      }
      return jsonEncode(_wrapConfig(proxy, opts));
    }
    if (scheme == 'ss') {
      var body = link.substring(5);
      final hi = body.indexOf('#');
      body = hi >= 0 ? body.substring(0, hi) : body;
      final qi = body.indexOf('?');
      final q = _qmap(link);
      String method = '', pass = '';
      String hostPort = body;
      if (qi >= 0) hostPort = body.substring(0, qi);
      if (hostPort.contains('@')) {
        final at = hostPort.lastIndexOf('@');
        var ui = hostPort.substring(0, at);
        hostPort = hostPort.substring(at + 1);
        if (ui.contains(':')) {
          method = _dec(ui).split(':')[0];
          pass = _dec(ui).substring(method.length + 1);
        } else {
          final dp = _b64d(ui);
          method = dp.split(':')[0];
          pass = dp.substring(method.length + 1);
        }
      } else {
        final dp = _b64d(hostPort);
        final at = dp.lastIndexOf('@');
        final mp = dp.substring(0, at);
        hostPort = dp.substring(at + 1);
        method = mp.split(':')[0];
        pass = mp.substring(method.length + 1);
      }
      final auth = _authority(hostPort);
      final net = (q['type'] ?? 'tcp').isEmpty ? 'tcp' : (q['type'] ?? 'tcp');
      final st = _streamFor(net, q['headerType'] ?? '', q['host'] ?? '',
          q['path'] ?? '', q['seed'] ?? '', q['mode'] ?? '', q['serviceName'] ?? '');
      _applyTls(st, q['security'] ?? '', q['sni'] ?? '', q['fp'] ?? '',
          q['alpn'] ?? '', '', '', '', _insec(q));
      final proxy = {
        'tag': 'proxy',
        'protocol': 'shadowsocks',
        'settings': {
          'servers': [
            {
              'address': auth['host'],
              'port': int.tryParse(auth['port']!) ?? 443,
              'method': method,
              'password': pass,
              'level': 8
            }
          ]
        },
        'streamSettings': st
      };
      return jsonEncode(_wrapConfig(proxy, opts));
    }
    return null; // hysteria2 / tuic / wireguard … با هستهٔ Xray ممکن نیست
  }

  String _v2ConfigFor(String link, [Map? opts]) {
    String? cfg;
    try {
      cfg = _buildXrayConfig(link, opts);
    } catch (_) {
      cfg = null;
    }
    if (cfg == null) {
      // فال‌بک: پارسر خود پلاگین (پوشش socks و موارد پیش‌بینی‌نشده)
      try {
        cfg = _applyOpts(FlutterV2ray.parseFromURL(link).getFullConfiguration(), opts);
      } catch (_) {
        cfg = null;
      }
    }
    if (cfg == null) {
      throw Exception('unsupported');
    }
    return cfg;
  }

  Future<void> _start(String link, String name, [Map? opts]) async {
    try {
      await _ensureInit();
      final cfg = _v2ConfigFor(link, opts);
      if (!await _v2.requestPermission()) {
        _js('__v2status', ['ERR:مجوز VPN داده نشد']);
        return;
      }
      /* v1.25.12 — مثل _startCfg: هستهٔ قبلی اول خاموش می‌شود و ۷۰۰ms صبر.
         استارتِ هستهٔ تازه روی هسته‌ای که هنوز بالا است، تصادم هسته و کرش
         گاه‌به‌گاه می‌دهد (شکایت «بعضی مواقع کرش می‌کند» — مثلاً دو ضربهٔ سریع
         روی «وصل» یا تعویض کانفیگ وسط اتصال). فاصلهٔ JS فقط ۳۵۰ms بود؛ اینجا
         قطعی و بومی تضمین می‌شود. */
      try {
        _v2.stopV2Ray();
      } catch (_) {}
      await Future.delayed(const Duration(milliseconds: 700));
      _v2.startV2Ray(
        remark: name,
        config: cfg,
        proxyOnly: false,
        bypassSubnets: null,
        blockedApps: null,
      );
    } catch (e) {
      final msg = e.toString().contains('unsupported')
          ? 'ERR:این پروتکل (مثل hysteria2/tuic) با هستهٔ Xray پشتیبانی نمی‌شه — کانفیگ vless/vmess/trojan/ss بگذار'
          : 'ERR:لینک نامعتبره یا این پروتکل پشتیبانی نمی‌شه';
      _js('__v2status', [msg]);
    }
  }

  /// host:port را از لینک کانفیگ بیرون می‌کشد (برای تست TCP واقعی)
  (String, int)? _hostPortOf(String link) {
    try {
      final m = RegExp(r'^[a-zA-Z][\w+.-]*://').firstMatch(link);
      if (m == null) return null;
      var rest = link.substring(m.end);
      final slash = rest.indexOf('/');
      if (slash >= 0) rest = rest.substring(0, slash);
      final q = rest.indexOf('?');
      if (q >= 0) rest = rest.substring(0, q);
      final h = rest.indexOf('#');
      if (h >= 0) rest = rest.substring(0, h);
      if (rest.isEmpty) return null;
      if (rest.contains('@')) {
        rest = rest.substring(rest.lastIndexOf('@') + 1);
      }
      if (rest.isEmpty) return null;
      var host = rest;
      var port = 443;
      final h6 = RegExp(r'^\[[^\]]+\](:\d+)?').firstMatch(rest);
      if (h6 != null) {
        host = h6.group(0)!.split(']')[0].substring(1);
        final pp = h6.group(1);
        if (pp != null && pp.length > 1) {
          port = int.tryParse(pp.substring(1)) ?? port;
        }
      } else {
        final ci = rest.lastIndexOf(':');
        if (ci > 0) {
          final p2 = int.tryParse(rest.substring(ci + 1));
          if (p2 != null && p2 > 0 && p2 <= 65535) {
            host = rest.substring(0, ci);
            port = p2;
          }
        }
      }
      host = host.trim();
      if (host.isEmpty || host.length > 253) return null;
      if (!RegExp(r'^[A-Za-z0-9._:\-]+$').hasMatch(host)) return null;
      return (host, port);
    } catch (_) {
      return null;
    }
  }

  Future<void> _ping(List<String> links, [int conc = 0]) async {
    // v1.24.2 — پینگ قابل‌اعتماد: اول تست واقعی TCP به host:port کانفیگ؛
    // فقط وقتی TCP جواب نداد، تأخیر پروتکل‌محور هسته هم امتحان می‌شود.
    // (قبلاً فقط getServerDelay بود که برای کانفیگ‌های سالم هم «قطع» می‌داد)
    // v1.25.41 — «تعداد همزمانی تست تأخیر واقعی» از تنظیمات PattNG اعمال می‌شود.
    Future<void> one(int i) async {
      var ms = 9999;
      final hp = _hostPortOf(links[i]);
      if (hp != null) {
        final sw = Stopwatch()..start();
        try {
          final s = await Socket.connect(hp.$1, hp.$2,
              timeout: const Duration(milliseconds: 3500));
          s.destroy();
          ms = sw.elapsedMilliseconds;
        } catch (_) {}
      }
      if (ms >= 9999) {
        try {
          await _ensureInit();
          final d = await _v2
              .getServerDelay(config: _v2ConfigFor(links[i]))
              .timeout(const Duration(seconds: 6), onTimeout: () => -1);
          if (d > 0 && d < 8000) ms = d;
        } catch (_) {}
      }
      if (ms <= 0 || ms >= 8000) ms = 9999;
      _js('__v2ping', [i, ms]);
    }

    final c = (conc > 1 && conc <= 16) ? conc : 1;
    for (var i = 0; i < links.length; i += c) {
      final end = (i + c > links.length) ? links.length : i + c;
      await Future.wait([
        for (var j = i; j < end; j++) one(j)
      ]);
    }
  }

  /// v1.25.17 — گزارش کرشِ اجرای قبلی را (اگر هست) یک‌بار در دیالوگ نشان می‌دهد.
  /// متن کرش از CrashCatcher سمت کاتلین می‌آید (فایل‌های crash-1..3.log).
  Future<void> _checkLastCrash() async {
    try {
      final raw = await _mhrv.invokeMethod('crashGet');
      final j = jsonDecode(raw as String) as Map<String, dynamic>;
      final logs = (j['logs'] as String?) ?? '';
      if (!mounted || logs.isEmpty || logs.startsWith('هیچ گزارش')) return;
      if (!logs.contains('== CRASH') && !logs.contains('خطاهای دارت')) return;
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: const Color(0xFF171A20),
          title: const Text('گزارش خطای اجرای قبلی',
              style: TextStyle(color: Color(0xFFFFD166), fontSize: 17, fontWeight: FontWeight.w700),
              textDirection: TextDirection.rtl),
          content: SizedBox(
            width: double.maxFinite,
            child: SingleChildScrollView(
              child: SelectableText(
                logs,
                style: const TextStyle(color: Color(0xFFB8C0CC), fontSize: 11, fontFamily: 'monospace'),
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () async {
                await Clipboard.setData(ClipboardData(text: logs));
                if (ctx.mounted) {
                  ScaffoldMessenger.of(ctx).showSnackBar(
                    const SnackBar(content: Text('متن خطا کپی شد — برای ما بفرستش'), backgroundColor: Color(0xFF1E78E8)),
                  );
                }
              },
              child: const Text('کپی متن', textDirection: TextDirection.rtl),
            ),
            TextButton(
              onPressed: () {
                try { _mhrv.invokeMethod('crashClear'); } catch (_) {}
                Navigator.of(ctx).pop();
              },
              child: const Text('حذف گزارش', textDirection: TextDirection.rtl),
            ),
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(),
              child: const Text('بستن', textDirection: TextDirection.rtl),
            ),
          ],
        ),
      );
    } catch (_) {
      // پیش‌نمایش/دسکتاپ: کانال نیست — بی‌خیال
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    // v1.25.17 — اگر اجرای قبلی کرش کرده باشد، گزارشش را یک‌بار نشان بده
    // (کاربر می‌تواند متن را کپی کند و برای ما بفرستد — دیگر کرش ناشناخته نداریم)
    WidgetsBinding.instance.addPostFrameCallback((_) => _checkLastCrash());
    _v2 = FlutterV2ray(onStatusChanged: (status) {
      /* v1.25.30 — سرعت لحظه‌ای هسته (بایت/ثانیه) هم به JS می‌رود: خطِ سرعتِ خانه
         وقتی فیلترشکن وصل است، بدون هیچ درخواست اضافه‌ای، همین‌جا زنده می‌شود
         v1.25.38 — فیکس بیلد: نام درست فیلدها در flutter_v2ray 1.0.10
         «downloadSpeed/uploadSpeed» است (نه speedDown/speedUp) — int غیرنال‌پذیر، بدون «?? 0» */
      _js('__v2status', [status.state, status.downloadSpeed, status.uploadSpeed]);
    });
    _c = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF060A12)) /* v1.25.7 — پس‌زمینهٔ WebView تاریک؛ قبلاً خاکستری روشن بود و اولِ باز شدن اپ سفید می‌زد */
      ..enableZoom(false)
      ..addJavaScriptChannel(
        'ClipBridge',
        onMessageReceived: (JavaScriptMessage m) {
          Clipboard.setData(ClipboardData(text: m.message));
        },
      )
      ..setNavigationDelegate(NavigationDelegate(
        onNavigationRequest: (req) {
          final u = req.url;
          // بازگشت به اپ از داخل پنل
          if (u.startsWith('panelsmanager://back') || u.startsWith('panelsmanager://app')) {
            _returnToApp();
            return NavigationDecision.prevent;
          }
          if (u.startsWith('file:') ||
              u.startsWith('about:') ||
              u.startsWith('data:') ||
              u.contains('flutter_assets') ||
              u == 'about:blank') {
            return NavigationDecision.navigate;
          }
          // وقتی در حالت پنل هستیم، اجازه ناوبری داخل همان دامنه/https
          if (_panelMode && (u.startsWith('https:') || u.startsWith('http:'))) {
            return NavigationDecision.navigate;
          }
          return NavigationDecision.prevent;
        },
        onPageFinished: (url) async {
          if (_panelMode && (url.startsWith('http://') || url.startsWith('https://'))) {
            // نوار بازگشت ثابت روی پنل واقعی
            await _c.runJavaScript(r'''
(function(){
  if(document.getElementById('pm-backbar')) return;
  var b=document.createElement('div');
  b.id='pm-backbar';
  b.style.cssText='position:fixed;top:0;left:0;right:0;z-index:2147483647;display:flex;align-items:center;gap:10px;padding:10px 12px;padding-top:max(10px,env(safe-area-inset-top));background:rgba(20,23,27,.95);color:#fff;font-family:system-ui,sans-serif;font-size:15px;font-weight:700;box-shadow:0 2px 12px #0005;direction:rtl';
  b.innerHTML='<button id="pm-backbtn" style="all:unset;cursor:pointer;padding:8px 14px;border-radius:10px;background:#0C7E72;color:#fff">← بازگشت به اپ</button><span style="flex:1;opacity:.85;font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">پنل</span>';
  document.documentElement.appendChild(b);
  document.getElementById('pm-backbtn').onclick=function(){location.href='panelsmanager://back'};
  document.body.style.paddingTop=(b.offsetHeight||56)+'px';
})();
''');
          } else {
            await _c.runJavaScript(
              "document.documentElement.classList.add('app','flutter-app');",
            );
            await _injectCode();
          }
        },
      ))
      ..addJavaScriptChannel(
        'ScanBridge',
        onMessageReceived: (JavaScriptMessage m) => _onScan(m.message),
      )
      ..addJavaScriptChannel(
        'StoreBridge',
        onMessageReceived: (JavaScriptMessage m) => _onStore(m.message),
      )
      ..addJavaScriptChannel(
        'HttpBridge',
        onMessageReceived: (JavaScriptMessage m) => _onHttp(m.message),
      )
      ..addJavaScriptChannel(
        'DeployBridge',
        onMessageReceived: (JavaScriptMessage m) => _onDeploy(m.message),
      )
      ..addJavaScriptChannel(
        'MhrvBridge',
        onMessageReceived: (JavaScriptMessage m) => _onMhrv(m.message),
      )
      ..addJavaScriptChannel(
        'GsBridge',
        onMessageReceived: (JavaScriptMessage m) => _onGs(m.message),
      )
      ..addJavaScriptChannel(
        'V2Bridge',
        onMessageReceived: (JavaScriptMessage m) => _onV2(m.message),
      )
      ..addJavaScriptChannel(
        'SecBridge',
        onMessageReceived: (JavaScriptMessage m) => _onSec(m.message),
      )
      ..addJavaScriptChannel(
        'AppBridge',
        onMessageReceived: (JavaScriptMessage m) async {
          final raw = m.message;
          // theme: {"cmd":"theme","dark":true}
          if (raw.startsWith('{')) {
            try {
              final j = jsonDecode(raw) as Map<String, dynamic>;
              if (j['cmd'] == 'allfiles') {
                // v1.25.36 — مرکز امنیت: پنجرهٔ «همهٔ فایل‌ها» برای اسکن کامل
                try {
                  await AndroidIntent(
                    action: 'android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION',
                    flags: <int>[0x10000000],
                  ).launch();
                } catch (_) {}
                return;
              }
              if (j['cmd'] == 'theme') {
                final dark = j['dark'] == true;
                SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
                  statusBarColor: Colors.transparent,
                  statusBarIconBrightness:
                      dark ? Brightness.light : Brightness.dark,
                  systemNavigationBarColor:
                      dark ? const Color(0xFF060A12) : const Color(0xFFEEF2F8),
                  systemNavigationBarIconBrightness:
                      dark ? Brightness.light : Brightness.dark,
                  systemNavigationBarContrastEnforced: false,
                ));
                return;
              }
            } catch (_) {}
          }
          final msg = raw.trim();
          // v1.25.36 — هر لینکی از هر جا (هر اسکیم URI) با intent VIEW باز می‌شود:
          // https / tg:// / vmess / spotify / تلگرام / هر برنامهٔ دیگر — بدون لیست سفید.
          if (RegExp(r'^[a-zA-Z][a-zA-Z0-9+.\-]*://').hasMatch(msg)) {
            try {
              await AndroidIntent(
                action: 'android.intent.action.VIEW',
                data: msg,
                flags: <int>[0x10000000],
              ).launch();
            } catch (_) {
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('برنامه‌ای برای باز کردن این لینک نصب نیست')),
                );
              }
            }
            return;
          }
          final pkg = msg;
          if (pkg != 'com.therealaleph.mhrv' &&
              pkg != 'com.patterniha.pattng' &&
              pkg != 'com.patterniha.pattng.fdroid' &&
              pkg != 'com.wireguard.android' &&
              pkg != 'org.amnezia.vpn' &&
              pkg != 'com.shirokhorshid.vpn') { // v1.17: Shir o Khorshid (Psiphon fork)
            return;
          }
          try {
            await AndroidIntent(
              action: 'android.intent.action.MAIN',
              category: 'android.intent.category.LAUNCHER',
              package: pkg,
              flags: <int>[0x10000000],
            ).launch();
          } catch (_) {
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('برنامه نصب نیست')),
              );
            }
          }
        },
      )
      ..loadFlutterAsset('assets/index.html');
    // v1.25.34 — فیکس «سه‌خط» (همبرگر) سایت پنل در مرورگر داخلی:
    // سایت در کروم کامل است ولی داخل اپ منوی سه‌خطش رندر نمی‌شد — سه علت:
    // ① UA اندروید ویو علامت «; wv)» دارد و کدهای سایت (تشخیص WebView) نسخهٔ کامل را نمی‌سازند
    // ② فونت بزرگ سیستم (textZoom) چیدمان پنل را می‌شکند و آیتم منو می‌افتد بیرون/مخفی می‌شود
    // ③ آیکون/فونت‌های http روی صفحهٔ https بلاک می‌شوند و آیکون همبرگر لود نمی‌شود
    _fixWebviewCompat();
    // v1.25.36 — اگر اپ با «اشتراک‌گذاری» باز شده باشد (لینک از هر برنامه‌ای)
    Future.delayed(const Duration(milliseconds: 2600), _takeShare);
  }

  /// v1.25.34 — هم‌تراز‌کردن رفتار WebView داخلی با کروم (بدون تغییر ظاهر اپ):
  /// ① UA = کروم واقعی اندروید (بدون «; wv)») ② textZoom=100 مثل کروم
  /// ③ mixed-content حالت سازگار تا منابع http روی صفحهٔ https هم لود شوند
  Future<void> _fixWebviewCompat() async {
    try {
      final ua = await _c.getUserAgent();
      var fixed = (ua ?? '').replaceFirst('; wv)', ')');
      if (!fixed.contains('Chrome/')) {
        fixed =
            'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36';
      }
      await _c.setUserAgent(fixed);
    } catch (_) {}
    try {
      final p = _c.platform;
      if (p is AndroidWebViewController) {
        p.setTextZoom(100);
        /* v1.25.38 — setMixedContentMode حذف شد (خطای کامپایل):
           این متد فقط در webview_flutter_android ≥4.8.0 هست، ولی webview_flutter 4.9
           بستهٔ اندروید را روی ^3.16 پین کرده → روی 3.16.9 چنین متدی وجود ندارد.
           فیکس «سه‌خط» (UA کروم واقعی + textZoom=100) سر جایش است و کافی است؛
           اگر روزی webview_flutter به ≥4.13 بروز شد، خط زیر را برگردانید:
           p.setMixedContentMode(MixedContentMode.compatibilityMode); */
      }
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF060A12),
      body: SafeArea(
        top: false,
        bottom: false,
        /* v1.25.26 — دکمهٔ بازگشت اندروید: اول جاوااسکریپت (پوشه → خانه، امکان → خانه)،
           اگر مدیریت نشد (خانه یا صفحهٔ بیرونی) اپ بسته می‌شود */
        child: PopScope(
          canPop: false,
          onPopInvoked: (didPop) async {
            if (didPop) return;
            var handled = false;
            try {
              final r = await _c
                  .runJavaScriptReturningResult('window.__pmBack?window.__pmBack():false');
              handled = r.toString() == 'true';
            } catch (_) {}
            if (!handled) {
              try { await SystemNavigator.pop(); } catch (_) {}
            }
          },
          child: WebViewWidget(controller: _c),
        ),
      ),
    );
  }
}

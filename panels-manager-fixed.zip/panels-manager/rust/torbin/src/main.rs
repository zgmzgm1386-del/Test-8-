// torbin — کلاینت Tor (Arti) + SOCKS5 محلی مینیمال.
// usage: torbin --port 20872 --data /path [--bridges /path/bridges.txt] [--pt /path/obfs4proxy]
// بعد از بوت‌استرپ، روی 127.0.0.1:PORT یک SOCKS5 (بدون احراز، فقط CONNECT)
// گوش می‌دهد و هر اتصال را داخل شبکهٔ Tor می‌برد. VpnService خود اپ ترافیک
// گوشی را با tun2proxy داخل همین SOCKS می‌ریزد.
//
// v1.24: پشتیبانی پل obfs4 — اگر --bridges داده شود، خط‌های «obfs4 …» از فایل
// خوانده و با PT (باینری obfs4proxy از --pt) به arti معرفی می‌شوند؛ بدون پل،
// اتصال مستقیم مثل قبل. خط‌های snowflake/webtunnel پشتیبانی نمی‌شوند (رد می‌شوند).
use anyhow::Result;
use arti_client::config::pt::TransportConfigBuilder;
use arti_client::config::{BoolOrAuto, BridgeConfigBuilder, CfgPath, TorClientConfig, TorClientConfigBuilder};
use arti_client::TorClient;
use std::path::PathBuf;
use std::sync::Arc;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream};
use tor_rtcompat::tokio::TokioRustlsRuntime;

const BOOTSTRAP_TIMEOUT_SECS: u64 = 180;

/// خط‌های پل را از فایل می‌خواند؛ فقط obfs4 (با یا بدون پیشوند «Bridge »).
fn read_bridge_lines(p: &PathBuf) -> Vec<String> {
    match std::fs::read_to_string(p) {
        Ok(s) => s
            .lines()
            .map(|l| l.trim().to_string())
            .filter(|l| !l.is_empty() && !l.starts_with('#'))
            .map(|l| {
                if l.to_ascii_lowercase().starts_with("bridge ") {
                    l[7..].trim().to_string()
                } else {
                    l
                }
            })
            .filter(|l| l.split_whitespace().next().map(|w| w == "obfs4").unwrap_or(false))
            .collect(),
        Err(_) => Vec::new(),
    }
}

#[tokio::main(flavor = "multi_thread")]
async fn main() -> Result<()> {
    let mut port: u16 = 20872;
    let mut state: PathBuf = std::env::temp_dir().join("torbin-data");
    let mut bridges_path: Option<PathBuf> = None;
    let mut pt_path: Option<PathBuf> = None;
    let mut args = std::env::args().skip(1);
    while let Some(a) = args.next() {
        match a.as_str() {
            "--port" => {
                port = args.next().and_then(|v| v.parse().ok()).unwrap_or(port);
            }
            "--data" => {
                state = PathBuf::from(args.next().unwrap_or_default());
            }
            "--bridges" => {
                let v = args.next().unwrap_or_default();
                if !v.is_empty() {
                    bridges_path = Some(PathBuf::from(v));
                }
            }
            "--pt" => {
                let v = args.next().unwrap_or_default();
                if !v.is_empty() {
                    pt_path = Some(PathBuf::from(v));
                }
            }
            _ => {}
        }
    }
    std::fs::create_dir_all(&state)?;
    let blines = bridges_path.as_ref().map(read_bridge_lines).unwrap_or_default();
    println!(
        "torbin: starting (data={}, mode={})",
        state.display(),
        if blines.is_empty() { "direct" } else { "obfs4-bridges" }
    );

    // v1.25.1: current() نه create() — create() یک توکایوی تازه می‌سازد و داخل
    // #[tokio::main] پنیک «Cannot start a runtime from within a runtime» می‌دهد؛
    // current() از هندلِ در حال اجرا استفاده می‌کند.
    let runtime = TokioRustlsRuntime::current()?;
    let cfg: TorClientConfig = if blines.is_empty() {
        // v1.25.1: storage فیلد خصوصی است — از بیلدر استفاده می‌کنیم (API جدیدهٔ arti 0.46)
        TorClientConfigBuilder::from_directories(state.join("state"), state.join("cache")).build()?
    } else {
        let mut cb = TorClientConfigBuilder::from_directories(state.join("state"), state.join("cache"));
        let mut list = Vec::new();
        for line in &blines {
            match line.parse::<BridgeConfigBuilder>() {
                Ok(b) => list.push(b),
                Err(e) => println!("torbin: skip bridge line ({}): {}", e, line),
            }
        }
        if list.is_empty() {
            anyhow::bail!("هیچ خط پل obfs4 معتبری در فایل نبود");
        }
        println!("torbin: {} bridge line(s) parsed", list.len());
        cb.bridges().set_bridges(list);
        if let Some(pt) = &pt_path {
            let mut t = TransportConfigBuilder::default();
            t.protocols(vec!["obfs4".parse()?]);
            t.path(CfgPath::new(pt.display().to_string()));
            t.run_on_startup(true);
            cb.bridges().transports().push(t);
            println!("torbin: pt binary = {}", pt.display());
        }
        cb.bridges().enabled(BoolOrAuto::Explicit(true));
        cb.build()?
    };

    // v1.25.1: with_runtime در arti 0.46 مستقیم بیلدر می‌دهد (نه Result) و config
    // متدِ بیلدر است؛ create_bootstrapped هم خودش Arc<TorClient> می‌دهد.
    let builder = TorClient::with_runtime(runtime).config(cfg);
    let client = tokio::time::timeout(
        std::time::Duration::from_secs(BOOTSTRAP_TIMEOUT_SECS),
        async { builder.create_bootstrapped().await },
    )
    .await
    .map_err(|_| anyhow::anyhow!("bootstrap timeout"))??;

    println!("torbin: Tor bootstrapped OK; SOCKS5 listening on 127.0.0.1:{}", port);
    let listener = TcpListener::bind(("127.0.0.1", port)).await?;
    loop {
        let (sock, _peer) = listener.accept().await?;
        let c = Arc::clone(&client);
        tokio::spawn(async move {
            let _ = handle_socks(c, sock).await;
        });
    }
}

async fn handle_socks(
    // v1.25.1: نوع مشخص TokioRustlsRuntime — PreferredRuntimeِ روتِ tor_rtcompat
    // ساختارِ جدا است و با رانتری که می‌سازیم یکی نیست.
    client: Arc<TorClient<TokioRustlsRuntime>>,
    mut sock: TcpStream,
) -> Result<()> {
    // greeting
    let mut hdr = [0u8; 2];
    sock.read_exact(&mut hdr).await?;
    if hdr[0] != 5 {
        anyhow::bail!("not socks5");
    }
    let n = hdr[1] as usize;
    let mut methods = vec![0u8; n];
    sock.read_exact(&mut methods).await?;
    sock.write_all(&[0x05, 0x00]).await?; // no auth

    // request
    let mut req = [0u8; 4];
    sock.read_exact(&mut req).await?;
    if req[1] != 1 {
        // فقط CONNECT
        sock.write_all(&[0x05, 0x07, 0x00, 0x01, 0, 0, 0, 0, 0, 0]).await?;
        anyhow::bail!("only CONNECT supported");
    }
    let target: (String, u16) = match req[3] {
        0x01 => {
            let mut ip = [0u8; 4];
            sock.read_exact(&mut ip).await?;
            let mut pt = [0u8; 2];
            sock.read_exact(&mut pt).await?;
            let port = u16::from_be_bytes(pt);
            (std::net::Ipv4Addr::new(ip[0], ip[1], ip[2], ip[3]).to_string(), port)
        }
        0x03 => {
            let mut l = [0u8; 1];
            sock.read_exact(&mut l).await?;
            let mut dom = vec![0u8; l[0] as usize];
            sock.read_exact(&mut dom).await?;
            let mut pt = [0u8; 2];
            sock.read_exact(&mut pt).await?;
            let port = u16::from_be_bytes(pt);
            (String::from_utf8_lossy(&dom).to_string(), port)
        }
        _ => {
            sock.write_all(&[0x05, 0x08, 0x00, 0x01, 0, 0, 0, 0, 0, 0]).await?;
            anyhow::bail!("unsupported atyp");
        }
    };

    match client.connect((target.0.as_str(), target.1)).await {
        Ok(tstream) => {
            sock.write_all(&[0x05, 0x00, 0x00, 0x01, 0, 0, 0, 0, 0, 0]).await?;
            let mut t = tstream;
            let _ = tokio::io::copy_bidirectional(&mut sock, &mut t).await;
            Ok(())
        }
        Err(e) => {
            sock.write_all(&[0x05, 0x01, 0x00, 0x01, 0, 0, 0, 0, 0, 0]).await?;
            Err(anyhow::anyhow!("tor connect: {}", e))
        }
    }
}

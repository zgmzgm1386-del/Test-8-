// lanternproxy — a small CLI wrapper around getlantern/radiance for running
// Lantern as a local SOCKS5/HTTP proxy (no TUN), the way an Android app can
// drive it. Built with `-tags novpn`, which replaces sing-box's TUN inbound
// with a mixed SOCKS/HTTP inbound bound to RADIANCE_SOCKS_ADDRESS.
//
// Command line:
//
//	lanternproxy -socks 127.0.0.1:20840 -configdir /path/dir [-deviceid ID]
//
// stdout contract (every line prefixed "[lantern] ", like the reference app):
//
//	config cached servers=N     a config already on disk carries N servers
//	config fetched servers=N    a fresh config just arrived with N servers
//	listening                   the proxy inbound is up (connect succeeded)
//	proxy ok                    a full TLS handshake through the SOCKS port worked
//	exit city|country|CC        where the tunnel currently exits
//	exhausted                   connect failed after retries
//	error <message>             anything else that went wrong
//
// stdin: closing stdin (or SIGINT/SIGTERM) stops the proxy and exits — the
// parent process owns our lifetime, so a killed app never leaves a core on
// the port.
package main

import (
	"context"
	"crypto/tls"
	"flag"
	"fmt"
	"net"
	"os"
	"os/signal"
	"path/filepath"
	"strings"
	"syscall"
	"time"

	"github.com/getlantern/radiance/backend"
	"github.com/getlantern/radiance/config"
	"github.com/getlantern/radiance/events"
)

const prefix = "[lantern] "

func out(line string) {
	fmt.Println(prefix + line)
}

func outErr(err error) {
	msg := err.Error()
	msg = strings.ReplaceAll(msg, "\n", " ")
	if len(msg) > 300 {
		msg = msg[:300]
	}
	out("error " + msg)
}

func main() {
	socks := flag.String("socks", "127.0.0.1:20840", "SOCKS/HTTP mixed listen address")
	dir := flag.String("configdir", "", "data/config directory")
	deviceID := flag.String("deviceid", "", "device id (persisted across runs)")
	flag.Parse()

	if *dir == "" {
		outErr(fmt.Errorf("no -configdir given"))
		os.Exit(2)
	}
	if err := os.MkdirAll(*dir, 0o755); err != nil {
		outErr(err)
		os.Exit(2)
	}
	// The mixed inbound of the novpn build reads its address from the env.
	os.Setenv("RADIANCE_SOCKS_ADDRESS", *socks)

	// The proxy only lives as long as our stdin: the parent (the VPN service)
	// closes it to stop us, exactly like the reference app's core.
	stdinDead := make(chan struct{})
	go func() {
		buf := make([]byte, 4096)
		for {
			if _, err := os.Stdin.Read(buf); err != nil {
				close(stdinDead)
				return
			}
		}
	}()
	sigs := make(chan os.Signal, 1)
	signal.Notify(sigs, syscall.SIGINT, syscall.SIGTERM)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	// device id: pass-through or a stable file in the config dir
	id := *deviceID
	if id == "" {
		id = loadDeviceID(*dir)
		if id == "" {
			id = newDeviceID()
			saveDeviceID(*dir, id)
		}
	}

	be, err := backend.NewLocalBackend(ctx, backend.Options{
		DataDir:                  *dir,
		LogDir:                   filepath.Join(*dir, "logs"),
		Locale:                   "en-US",
		LogLevel:                 "info",
		DeviceID:                 id,
		TelemetryConsent:         false,
		PreserveTelemetryConsent: true,
	})
	if err != nil {
		outErr(err)
		os.Exit(1)
	}

	// report server counts the way the reference contract does
	emitServers := func(fresh bool) {
		n := len(be.AllServers())
		if fresh {
			out(fmt.Sprintf("config fetched servers=%d", n))
		} else {
			out(fmt.Sprintf("config cached servers=%d", n))
		}
	}
	events.SubscribeContext(ctx, func(evt config.NewConfigEvent) {
		emitServers(true)
	})

	be.Start()
	emitServers(false)

	// Connect with auto-selected server. This brings up the sing-box instance
	// whose mixed inbound listens on -socks.
	go func() {
		var last error
		for attempt := 1; attempt <= 3; attempt++ {
			cctx, ccancel := context.WithTimeout(ctx, 90*time.Second)
			err := be.ConnectVPN(cctx, "")
			ccancel()
			if err == nil {
				out("listening")
				probeLoop(ctx, *socks)
				return
			}
			last = err
			select {
			case <-ctx.Done():
				return
			case <-time.After(3 * time.Second):
			}
		}
		out("exhausted")
		outErr(last)
	}()

	select {
	case <-stdinDead:
	case <-sigs:
	}
	cancel()
	_ = be.DisconnectVPN()
	be.Close()
}

// probeLoop runs the data-path check over the local SOCKS port and prints the
// contract lines: "proxy ok" on the first full TLS handshake, "exit ..." with
// the public-IP country seen through the tunnel.
func probeLoop(ctx context.Context, socksAddr string) {
	deadline := time.Now().Add(45 * time.Second)
	ok := false
	for time.Now().Before(deadline) {
		if ctx.Err() != nil {
			return
		}
		if tlsProbe(socksAddr, "www.youtube.com") {
			ok = true
			break
		}
		select {
		case <-ctx.Done():
			return
		case <-time.After(2 * time.Second):
		}
	}
	if !ok {
		out("exhausted")
		return
	}
	out("proxy ok")
	if cc := traceCountry(socksAddr); cc != "" {
		out("exit ||" + cc)
	}
	// keep the process alive; state changes are reported by the parent via
	// its own probes. Wait for shutdown here.
	<-ctx.Done()
}

// tlsProbe dials host:443 through the SOCKS5 proxy at socksAddr and performs a
// full TLS handshake — the same "not a SOCKS reply, the far server's half"
// check the reference app makes.
func tlsProbe(socksAddr, host string) bool {
	conn, err := net.DialTimeout("tcp", socksAddr, 8*time.Second)
	if err != nil {
		return false
	}
	defer conn.Close()
	conn.SetDeadline(time.Now().Add(10 * time.Second))
	// SOCKS5: greet, then CONNECT host:443
	if _, err := conn.Write([]byte{5, 1, 0}); err != nil {
		return false
	}
	h := make([]byte, 2)
	if _, err := readFull(conn, h); err != nil || h[0] != 5 || h[1] != 0 {
		return false
	}
	req := []byte{5, 1, 0, 3, byte(len(host))}
	req = append(req, []byte(host)...)
	req = append(req, 0x01, 0xBB) // 443
	if _, err := conn.Write(req); err != nil {
		return false
	}
	ans := make([]byte, 4)
	if _, err := readFull(conn, ans); err != nil || ans[1] != 0 {
		return false
	}
	switch ans[3] {
	case 1:
		skip := make([]byte, 6)
		if _, err := readFull(conn, skip); err != nil {
			return false
		}
	case 4:
		skip := make([]byte, 18)
		if _, err := readFull(conn, skip); err != nil {
			return false
		}
	case 3:
		l := make([]byte, 1)
		if _, err := readFull(conn, l); err != nil {
			return false
		}
		skip := make([]byte, int(l[0])+2)
		if _, err := readFull(conn, skip); err != nil {
			return false
		}
	default:
		return false
	}
	tlsConn := tls.Client(conn, &tls.Config{ServerName: host})
	if err := tlsConn.Handshake(); err != nil {
		return false
	}
	tlsConn.Close()
	return true
}

// traceCountry asks Cloudflare's cdn-cgi/trace through the tunnel for the exit
// country code ("loc=DE" → "DE").
func traceCountry(socksAddr string) string {
	host := "www.cloudflare.com"
	conn, err := net.DialTimeout("tcp", socksAddr, 8*time.Second)
	if err != nil {
		return ""
	}
	defer conn.Close()
	conn.SetDeadline(time.Now().Add(12 * time.Second))
	if _, err := conn.Write([]byte{5, 1, 0}); err != nil {
		return ""
	}
	h := make([]byte, 2)
	if _, err := readFull(conn, h); err != nil || h[0] != 5 || h[1] != 0 {
		return ""
	}
	req := []byte{5, 1, 0, 3, byte(len(host))}
	req = append(req, []byte(host)...)
	req = append(req, 0x01, 0xBB)
	if _, err := conn.Write(req); err != nil {
		return ""
	}
	ans := make([]byte, 4)
	if _, err := readFull(conn, ans); err != nil || ans[1] != 0 {
		return ""
	}
	switch ans[3] {
	case 1:
		skip := make([]byte, 6)
		readFull(conn, skip)
	case 4:
		skip := make([]byte, 18)
		readFull(conn, skip)
	case 3:
		l := make([]byte, 1)
		readFull(conn, l)
		skip := make([]byte, int(l[0])+2)
		readFull(conn, skip)
	default:
		return ""
	}
	tlsConn := tls.Client(conn, &tls.Config{ServerName: host})
	if tlsConn.Handshake() != nil {
		return ""
	}
	defer tlsConn.Close()
	fmt.Fprintf(tlsConn, "GET /cdn-cgi/trace HTTP/1.1\r\nHost: %s\r\nUser-Agent: lanternproxy\r\nConnection: close\r\n\r\n", host)
	buf := make([]byte, 4096)
	total := 0
	for total < len(buf) {
		n, err := tlsConn.Read(buf[total:])
		if n == 0 || err != nil {
			break
		}
		total += n
	}
	body := string(buf[:total])
	for _, line := range strings.Split(body, "\n") {
		if strings.HasPrefix(line, "loc=") {
			return strings.TrimSpace(line[4:])
		}
	}
	return ""
}

func readFull(conn net.Conn, b []byte) (int, error) {
	total := 0
	for total < len(b) {
		n, err := conn.Read(b[total:])
		if n == 0 {
			return total, err
		}
		total += n
		if err != nil {
			return total, err
		}
	}
	return total, nil
}

// ── device id helpers ────────────────────────────────────────────────────────

func deviceIDFile(dir string) string { return filepath.Join(dir, ".lanternsecrets", ".deviceid") }

func loadDeviceID(dir string) string {
	b, err := os.ReadFile(deviceIDFile(dir))
	if err != nil || len(strings.TrimSpace(string(b))) < 8 {
		return ""
	}
	return strings.TrimSpace(string(b))
}

func saveDeviceID(dir, id string) {
	p := deviceIDFile(dir)
	os.MkdirAll(filepath.Dir(p), 0o755)
	os.WriteFile(p, []byte(id), 0o600)
}

func newDeviceID() string {
	b := make([]byte, 16)
	if f, err := os.Open("/dev/urandom"); err == nil {
		defer f.Close()
		f.Read(b)
	} else {
		for i := range b {
			b[i] = byte(time.Now().UnixNano() >> (i % 8))
		}
	}
	// uuid-ish hex, same shape Lantern's own device ids take
	return fmt.Sprintf("%x-%x-%x-%x", b[0:4], b[4:6], b[6:8], b[8:16])
}

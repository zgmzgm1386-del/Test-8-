package com.therealaleph.mhrv

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Foreground VpnService adapted from upstream mhrv-rs (MIT,
 * github.com/therealaleph/MasterHttpRelayVPN-RUST). It:
 *   1. runs the mhrv-rs Rust proxy (HTTP + SOCKS5 on 127.0.0.1),
 *   2. establishes a TUN interface that captures device traffic,
 *   3. runs tun2proxy to feed that traffic into the local SOCKS5.
 *
 * Differences from upstream: the config JSON is handed over by the Flutter
 * side through SharedPreferences (no ConfigStore / Compose UI / overlay),
 * split-tunnelling is not exposed (this app is always excluded from the VPN
 * to avoid a routing loop).
 */
class MhrvVpnService : VpnService() {

    private var tun: ParcelFileDescriptor? = null
    private var proxyHandle: Long = 0L
    private var tun2proxyThread: Thread? = null
    private val tun2proxyRunning = AtomicBoolean(false)
    private val tornDown = AtomicBoolean(false)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.i(TAG, "onStartCommand action=${intent?.action ?: "<null>"} startId=$startId")
        return when (intent?.action) {
            ACTION_STOP -> {
                try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (t: Throwable) {
                    Log.w(TAG, "stopForeground: ${t.message}")
                }
                Thread({
                    teardown()
                    stopSelf()
                    Log.i(TAG, "teardown done, service stopping")
                }, "mhrv-teardown").start()
                START_NOT_STICKY
            }
            else -> {
                tornDown.set(false)
                startEverything()
                START_NOT_STICKY
            }
        }
    }

    private fun loadConfigJson(): String =
        getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_CONFIG, "") ?: ""

    private fun failAndStop(why: String) {
        Log.e(TAG, why)
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Throwable) {}
        VpnState.isRunning = false
        stopSelf()
    }

    private fun startEverything() {
        Native.setDataDir(filesDir.absolutePath)

        val json = loadConfigJson()
        var httpPort = 8080
        var socks5Port = 1080
        var mode = "apps_script"
        try {
            val o = JSONObject(json)
            httpPort = o.optInt("listen_port", httpPort)
            socks5Port = if (o.has("socks5_port")) o.getInt("socks5_port") else httpPort + 1
            mode = o.optString("mode", mode)
        } catch (t: Throwable) {
            // Must still call startForeground before stopping (Android 8+).
            startForeground(NOTIF_ID, buildNotif(httpPort, socks5Port))
            failAndStop("Config JSON is missing or invalid: ${t.message}")
            return
        }

        // Android 8+: startForeground() must follow startForegroundService().
        startForeground(NOTIF_ID, buildNotif(httpPort, socks5Port))

        if (proxyHandle != 0L) {
            try { Native.stopProxy(proxyHandle) } catch (_: Throwable) {}
            proxyHandle = 0L
        }

        proxyHandle = Native.startProxy(json)
        if (proxyHandle == 0L) {
            failAndStop("Native.startProxy returned 0 — see logcat tag mhrv_rs")
            return
        }

        val builder = Builder()
            .setSession("mhrv-rs")
            .setMtu(MTU)
            .addAddress("10.0.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("1.1.1.1")
            .setBlocking(false)

        // Loop avoidance: the proxy's own outbound connections must not be
        // captured by the TUN again, so this whole app is excluded.
        try {
            builder.addDisallowedApplication(packageName)
        } catch (e: Throwable) {
            Log.w(TAG, "addDisallowedApplication(self) failed: ${e.message}")
        }

        val parcelFd = try {
            builder.establish()
        } catch (t: Throwable) {
            Log.e(TAG, "VpnService.establish() failed: ${t.message}")
            null
        }
        if (parcelFd == null) {
            try { Native.stopProxy(proxyHandle) } catch (_: Throwable) {}
            proxyHandle = 0L
            failAndStop("establish() returned null — is VPN permission granted?")
            return
        }
        tun = parcelFd

        val detachedFd = parcelFd.detachFd()
        tun2proxyRunning.set(true)
        // v1.12.1: tun2proxy مستقیم با آرگومان‌های تایپ‌شده اجرا می‌شود (بدون
        // رشتهٔ CLI/ clap/ dlsym) و توقفش با Native.stopTun2proxy() است —
        // مسیر قبلی بعد از هر خاموشی std::process::exit(-1) می‌زد و کل اپ را
        // می‌بست (کرش گزارش‌شدهٔ کاربر).
        val proxyUrl = "socks5://127.0.0.1:$socks5Port"
        val udpgw = if (mode == "full") UDPGW_MAGIC_DEST else ""
        val worker = Thread({
            try {
                val rc = Native.runTun2proxy(proxyUrl, detachedFd, MTU, udpgw)
                Log.i(TAG, "tun2proxy exited rc=$rc")
            } catch (t: Throwable) {
                Log.e(TAG, "tun2proxy crashed: ${t.message}", t)
            } finally {
                tun2proxyRunning.set(false)
            }
        }, "tun2proxy")
        try {
            worker.start()
            tun2proxyThread = worker
        } catch (t: Throwable) {
            tun2proxyRunning.set(false)
            try { ParcelFileDescriptor.adoptFd(detachedFd).close() } catch (_: Throwable) {}
            try { Native.stopProxy(proxyHandle) } catch (_: Throwable) {}
            proxyHandle = 0L
            failAndStop("tun2proxy thread start failed: ${t.message}")
            return
        }

        VpnState.proxyHandle = proxyHandle
        VpnState.isRunning = true
    }

    /**
     * Shutdown order matters (upstream issue #700): stop the Rust proxy FIRST
     * so tun2proxy's blocking socket read returns, then stop tun2proxy,
     * close the TUN and join the worker thread.
     */
    private fun teardown() {
        if (!tornDown.compareAndSet(false, true)) return
        val handle = proxyHandle
        proxyHandle = 0L
        if (handle != 0L) {
            try { Native.stopProxy(handle) } catch (t: Throwable) {
                Log.e(TAG, "Native.stopProxy threw: ${t.message}", t)
            }
        }
        if (tun2proxyRunning.get()) {
            val stopper = Thread({
                try { Native.stopTun2proxy() } catch (t: Throwable) {
                    Log.w(TAG, "Native.stopTun2proxy: ${t.message}")
                }
            }, "mhrv-tun2proxy-stop").apply { start() }
            try { stopper.join(2_000) } catch (_: InterruptedException) {}
        }
        try { tun?.close() } catch (_: Throwable) {}
        tun = null
        try { tun2proxyThread?.join(4_000) } catch (_: InterruptedException) {}
        tun2proxyThread = null

        VpnState.proxyHandle = 0L
        VpnState.isRunning = false
    }

    override fun onDestroy() {
        try { teardown() } catch (t: Throwable) {
            Log.e(TAG, "onDestroy teardown threw: ${t.message}", t)
        }
        super.onDestroy()
    }

    override fun onRevoke() {
        // User turned the VPN off from system settings.
        Thread({ teardown(); stopSelf() }, "mhrv-revoke").start()
    }

    private fun buildNotif(httpPort: Int, socks5Port: Int): Notification {
        val mgr = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "mhrv-rs", NotificationManager.IMPORTANCE_LOW)
                .apply { description = "Status of the mhrv-rs VPN"; setShowBadge(false) }
            mgr.createNotificationChannel(ch)
        }
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        val openIntent = PendingIntent.getActivity(
            this, 0, launch ?: Intent(),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, MhrvVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        @Suppress("DEPRECATION")
        val b = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return b
            .setContentTitle("MHR VPN is active")
            .setContentText("HTTP 127.0.0.1:$httpPort  ·  SOCKS5 127.0.0.1:$socks5Port")
            .setSmallIcon(android.R.drawable.presence_online)
            .setContentIntent(openIntent)
            .addAction(
                Notification.Action.Builder(
                    android.graphics.drawable.Icon.createWithResource(
                        this, android.R.drawable.ic_menu_close_clear_cancel
                    ),
                    "Stop", stopIntent
                ).build()
            )
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val TAG = "MhrvVpnService"
        private const val CHANNEL_ID = "mhrv.vpn.status"
        private const val NOTIF_ID = 0x1001
        private const val MTU = 1500
        const val PREFS = "mhrv_cfg"
        const val KEY_CONFIG = "json"
        const val ACTION_STOP = "com.therealaleph.mhrv.STOP"
        private const val UDPGW_MAGIC_DEST = "192.0.2.1:7300"
    }
}

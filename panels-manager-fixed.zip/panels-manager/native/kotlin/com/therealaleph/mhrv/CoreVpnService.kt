package com.therealaleph.mhrv

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStream
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import javax.net.ssl.SSLSocketFactory

/**
 * v1.31.0 — سرویس عمومی «هستهٔ بومی» برای Geph و Lantern.
 *
 * همان الگوی TorVpnService: یک باینری arm64 (libgeph.so / liblantern.so از jniLibs) یک SOCKS5
 * روی 127.0.0.1 بالا می‌آورد → کلید VPN سیستم (TUN) → tun2proxy.
 * «وصل» فقط با تست واقعی HTTPS از داخل تونل (cloudflare trace) تأیید می‌شود.
 *
 * پارامترها (نام هسته + JSON تنظیمات) از SharedPreferences می‌آیند که MainActivity پر می‌کند.
 */
class CoreVpnService : VpnService() {

    private var tun: ParcelFileDescriptor? = null
    private var tun2proxyThread: Thread? = null
    private val tun2proxyRunning = AtomicBoolean(false)
    private val tornDown = AtomicBoolean(false)
    private var proc: Process? = null
    private var core = ""
    private var port = 0

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.i(TAG, "onStartCommand action=${intent?.action ?: "<null>"}")
        return when (intent?.action) {
            ACTION_STOP -> {
                try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Throwable) {}
                Thread({ teardown(); stopSelf() }, "core-stop").start()
                START_NOT_STICKY
            }
            else -> {
                tornDown.set(false)
                val p = getSharedPreferences(PREFS, MODE_PRIVATE)
                core = p.getString(KEY_CORE, "") ?: ""
                startForeground(NOTIF_ID, buildNotif())
                Thread({ startEngine() }, "core-start").start()
                START_NOT_STICKY
            }
        }
    }

    override fun onRevoke() {
        Thread({ teardown(); stopSelf() }, "core-revoke").start()
    }

    override fun onDestroy() {
        try { teardown() } catch (t: Throwable) { Log.e(TAG, "onDestroy: ${t.message}") }
        super.onDestroy()
    }

    // ───────────────────────── راه‌اندازی ─────────────────────────

    private fun libFor(c: String) = when (c) {
        "geph" -> LIB_GEPH
        "lantern" -> LIB_LANTERN
        else -> ""
    }

    private fun titleFor(c: String) = when (c) {
        "geph" -> "Geph"
        "lantern" -> "Lantern"
        else -> c
    }

    private fun startEngine() {
        stopping = false
        running = true
        verified = false
        err = ""
        activeCore = core
        val title = titleFor(core)
        stage("راه‌اندازی $title…")
        val lib = libFor(core)
        if (lib.isEmpty()) { fail("هستهٔ ناشناخته: $core"); finishFailed(); return }
        val bin = File(applicationInfo.nativeLibraryDir, lib)
        if (!bin.exists()) {
            fail("هستهٔ $title داخل این APK نیست — با بیلد جدید (CI) اضافه می‌شود")
            finishFailed(); return
        }
        val params = try {
            JSONObject(getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_PARAMS, "{}") ?: "{}")
        } catch (_: Throwable) { JSONObject() }

        port = if (core == "geph") PORT_GEPH else PORT_LANTERN
        var built: List<String>? = null
        try {
            built = buildArgs(params)
        } catch (t: Throwable) {
            fail("ساخت تنظیمات $title شکست: " + (t.message ?: t.toString()))
        }
        if (built == null) { finishFailed(); return }
        val args: List<String> = built

        if (!establishTun(params)) { finishFailed(); return }

        log("cmd: $lib " + args.joinToString(" ") { if (it.length > 60) it.take(60) + "…" else it })
        val p = try {
            ProcessBuilder(listOf(bin.absolutePath) + args)
                .directory(filesDir).redirectErrorStream(true).start()
        } catch (t: Throwable) {
            log("exec مستقیم نشد (" + (t.message ?: "?") + ") → از لینکر سیستم")
            try {
                ProcessBuilder(listOf("/system/bin/linker64", bin.absolutePath) + args)
                    .directory(filesDir).redirectErrorStream(true).start()
            } catch (t2: Throwable) {
                fail("اجرای هستهٔ $title شکست: " + (t2.message ?: t2.toString()))
                finishFailed(); return
            }
        }
        proc = p
        Thread({
            try {
                BufferedReader(InputStreamReader(p.inputStream, Charsets.UTF_8)).use { r ->
                    while (true) {
                        val line = r.readLine() ?: break
                        log(line)
                        // خطاهای رایج ورود Geph را برای کاربر قابل‌فهم کن
                        val l = line.lowercase()
                        if (core == "geph" && (l.contains("wrong password") || l.contains("invalid credential") ||
                                    l.contains("authentication failed") || l.contains("auth failed")))
                            err = "نام کاربری یا رمز Geph اشتباه است"
                    }
                }
            } catch (_: Throwable) {}
        }, "core-log").apply { isDaemon = true }.start()

        if (awaitVerified(150_000L, title)) return
        if (stopping) return
        fail(if (err.isBlank()) "$title وصل نشد — شبکه یا حساب را چک کن" else err)
        finishFailed()
    }

    /** آرگومان‌های اجرای هر هسته. null یعنی خطا (پیام خودش fail شده) */
    private fun buildArgs(params: JSONObject): List<String>? {
        when (core) {
            "geph" -> {
                val user = params.optString("user", "").trim()
                val pass = params.optString("pass", "")
                val custom = params.optString("rawConfig", "").trim()
                val dir = File(filesDir, "geph").apply { mkdirs() }
                val cfgFile = File(dir, "config.yaml")
                if (custom.isNotEmpty()) {
                    // پیکربندی خام کاربر (YAML/JSON رسمی Geph) — فقط جای‌نگهدارها پر می‌شوند
                    cfgFile.writeText(
                        custom.replace("{{SOCKS_PORT}}", port.toString())
                            .replace("{{CACHE}}", File(dir, "cache.db").absolutePath)
                            .replace("{{USER}}", user).replace("{{PASS}}", pass)
                    )
                    return listOf("-c", cfgFile.absolutePath)
                }
                if (user.isEmpty() || pass.isEmpty()) {
                    fail("نام کاربری و رمز Geph را در تب وارد کن (حساب رایگان geph.io)")
                    return null
                }
                val exit = params.optString("exit", "auto")
                val bridge = params.optString("bridge", "auto")
                val cfg = JSONObject()
                cfg.put("socks5_listen", "127.0.0.1:$port")
                cfg.put("http_proxy_listen", JSONObject.NULL)
                cfg.put("control_listen", JSONObject.NULL)
                cfg.put("exit_constraint", if (exit == "auto" || exit.isBlank()) "auto"
                    else JSONObject().put("country", exit.uppercase()))
                cfg.put("bridge_mode", when (bridge) {
                    "bridges" -> "force_bridges"; "direct" -> "force_direct"; else -> "auto" })
                cfg.put("cache", File(dir, "cache.db").absolutePath)
                cfg.put("broker", JSONObject().put("fronted", JSONObject()
                    .put("front", "https://www.cdn77.com/")
                    .put("host", "1209167105.rsc.cdn77.org")))
                cfg.put("broker_keys", JSONObject()
                    .put("master", GEPH_MASTER)
                    .put("mizaru_free", GEPH_MIZARU_FREE)
                    .put("mizaru_plus", GEPH_MIZARU_PLUS))
                cfg.put("vpn", false)
                cfg.put("spoof_dns", false)
                cfg.put("passthrough_china", params.optBoolean("passChina", false))
                cfg.put("dry_run", false)
                cfg.put("credentials", JSONObject().put("legacy_username_password",
                    JSONObject().put("username", user).put("password", pass)))
                cfgFile.writeText(cfg.toString())
                return listOf("-c", cfgFile.absolutePath)
            }
            "lantern" -> {
                // قرارداد با باینری ریزپیچ lantern (ci/run.sh): SOCKS5 روی --listen
                val dir = File(filesDir, "lantern").apply { mkdirs() }
                val a = mutableListOf("--listen", "127.0.0.1:$port", "--data", dir.absolutePath)
                val loc = params.optString("location", "").trim()
                if (loc.isNotEmpty() && loc != "auto") { a.add("--location"); a.add(loc) }
                val extra = params.optJSONArray("args")
                if (extra != null) for (i in 0 until extra.length()) a.add(extra.optString(i))
                return a
            }
        }
        return null
    }

    private fun finishFailed() {
        running = false
        try { teardown() } catch (_: Throwable) {}
        try { stopSelf() } catch (_: Throwable) {}
    }

    private fun establishTun(params: JSONObject): Boolean {
        val builder = Builder()
            .setSession(core)
            .setMtu(MTU)
            .addAddress("10.117.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .setBlocking(false)
        val dns = params.optString("dns", "1.1.1.1").ifBlank { "1.1.1.1" }
        builder.addDnsServer(dns)
        try { builder.addDisallowedApplication(packageName) } catch (_: Throwable) {}
        // تونل‌شکنی (Split tunneling): برنامه‌هایی که نباید از VPN رد شوند
        val skip = params.optJSONArray("skipApps")
        if (skip != null) for (i in 0 until skip.length()) {
            val pk = skip.optString(i)
            if (pk.isNotBlank()) try { builder.addDisallowedApplication(pk) } catch (_: Throwable) {}
        }
        val fd = try { builder.establish() } catch (t: Throwable) {
            Log.e(TAG, "establish: " + t.message); null
        }
        if (fd == null) { fail("مجوز VPN داده نشد یا یک VPN دیگر فعاله"); return false }
        tun = fd
        val det = fd.detachFd()
        tun2proxyRunning.set(true)
        val proxyUrl = "socks5://127.0.0.1:$port"
        val th = Thread({
            try {
                val rc = Native.runTun2proxy(proxyUrl, det, MTU, "")
                Log.i(TAG, "tun2proxy exited rc=$rc")
            } catch (t: Throwable) {
                Log.e(TAG, "tun2proxy: " + t.message)
            } finally {
                tun2proxyRunning.set(false)
            }
        }, "core-tun2proxy")
        th.start()
        tun2proxyThread = th
        return true
    }

    private fun awaitVerified(budgetMs: Long, title: String): Boolean {
        val start = SystemClock.elapsedRealtime()
        var next = 0L
        var tick = 0
        while (SystemClock.elapsedRealtime() - start < budgetMs) {
            if (stopping) return false
            if (proc != null && proc?.isAlive != true) { log("هسته خودش بسته شد"); return false }
            if (SystemClock.elapsedRealtime() >= next) {
                tick++
                if (tick % 3 == 0) {
                    val secs = (SystemClock.elapsedRealtime() - start) / 1000
                    stage("در حال اتصال به $title… ($secs ثانیه)")
                }
                val body = traceThroughSocks()
                if (body != null && body.contains("\r\n\r\n")) {
                    verified = true
                    exitIp = Regex("(?m)^ip=(.*)$").find(body)?.groupValues?.getOrNull(1)?.trim() ?: ""
                    loc = Regex("(?m)^loc=(.*)$").find(body)?.groupValues?.getOrNull(1)?.trim() ?: ""
                    stage("وصل شد ✓ · " + title + " · " + (loc.ifBlank { exitIp.ifBlank { "—" } }))
                    log("✅ تست واقعی از داخل $title جواب داد · ip=$exitIp · loc=$loc")
                    return true
                }
                next = SystemClock.elapsedRealtime() + 4000
            }
            try { Thread.sleep(500) } catch (_: InterruptedException) { return false }
        }
        return false
    }

    private fun traceThroughSocks(): String? {
        return try {
            val s = Socket()
            s.soTimeout = 12000
            s.connect(InetSocketAddress("127.0.0.1", port), 5000)
            val out = s.getOutputStream()
            val inp = s.getInputStream()
            out.write(byteArrayOf(0x05, 0x01, 0x00)); out.flush()
            val greet = ByteArray(2)
            if (readFully(inp, greet) != 2 || greet[0] != 0x05.toByte() || greet[1] == 0xff.toByte()) {
                try { s.close() } catch (_: Throwable) {}
                return null
            }
            val host = "www.cloudflare.com".toByteArray(Charsets.US_ASCII)
            val req = ByteArray(7 + host.size)
            req[0] = 0x05; req[1] = 0x01; req[2] = 0x00; req[3] = 0x03
            req[4] = host.size.toByte()
            host.copyInto(req, 5)
            req[5 + host.size] = ((443 ushr 8) and 0xFF).toByte()
            req[6 + host.size] = (443 and 0xFF).toByte()
            out.write(req); out.flush()
            val rep = ByteArray(10)
            if (readFully(inp, rep) != 10 || rep[1] != 0x00.toByte()) {
                try { s.close() } catch (_: Throwable) {}
                return null
            }
            val ssl = (SSLSocketFactory.getDefault() as SSLSocketFactory)
                .createSocket(s, "www.cloudflare.com", 443, true)
            ssl.soTimeout = 12000
            val ro = ssl.getOutputStream()
            ro.write(("GET /cdn-cgi/trace HTTP/1.1\r\nHost: www.cloudflare.com\r\nUser-Agent: panels-manager\r\nConnection: close\r\n\r\n").toByteArray(Charsets.US_ASCII))
            ro.flush()
            val body = ssl.getInputStream().readBytes().toString(Charsets.UTF_8)
            try { ssl.close() } catch (_: Throwable) {}
            body
        } catch (t: Throwable) { null }
    }

    private fun readFully(inp: InputStream, b: ByteArray): Int {
        var n = 0
        while (n < b.size) {
            val k = inp.read(b, n, b.size - n)
            if (k < 0) break
            n += k
        }
        return n
    }

    private fun teardown() {
        if (!tornDown.compareAndSet(false, true)) return
        stopping = true
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Throwable) {}
        killEngine()
        if (tun2proxyRunning.get()) {
            val stopper = Thread({
                try { Native.stopTun2proxy() } catch (_: Throwable) {}
            }, "core-t2p-stop").apply { start() }
            try { stopper.join(2_000) } catch (_: InterruptedException) {}
        }
        try { tun?.close() } catch (_: Throwable) {}
        tun = null
        try { tun2proxyThread?.join(4_000) } catch (_: InterruptedException) {}
        tun2proxyThread = null
        running = false
        verified = false
        stageText = "قطع شد"
    }

    private fun killEngine() {
        val p = proc ?: return
        proc = null
        try { p.destroy() } catch (_: Throwable) {}
        val gone = try { p.waitFor(3, TimeUnit.SECONDS) } catch (_: Throwable) { false }
        if (!gone) { try { p.destroyForcibly() } catch (_: Throwable) {} }
    }

    private fun buildNotif(): Notification {
        val mgr = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Geph / Lantern", NotificationManager.IMPORTANCE_LOW)
                .apply { description = "وضعیت تونل Geph / Lantern"; setShowBadge(false) }
            mgr.createNotificationChannel(ch)
        }
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        val openIntent = PendingIntent.getActivity(
            this, 0, launch ?: Intent(),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stopIntent = PendingIntent.getService(
            this, 3,
            Intent(this, CoreVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        @Suppress("DEPRECATION")
        val b = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return b
            .setContentTitle(titleFor(core) + " فعال")
            .setContentText("هستهٔ بومی داخل برنامه")
            .setSmallIcon(android.R.drawable.presence_online)
            .setContentIntent(openIntent)
            .addAction(
                Notification.Action.Builder(
                    android.graphics.drawable.Icon.createWithResource(
                        this, android.R.drawable.ic_menu_close_clear_cancel
                    ),
                    "قطع", stopIntent
                ).build()
            )
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val TAG = "CoreVpnService"
        private const val CHANNEL_ID = "core.vpn.status"
        private const val NOTIF_ID = 0x1008
        private const val MTU = 1500
        const val PORT_GEPH = 20881
        const val PORT_LANTERN = 20882
        const val LIB_GEPH = "libgeph.so"
        const val LIB_LANTERN = "liblantern.so"
        const val ACTION_STOP = "com.therealaleph.mhrv.CORE_STOP"
        const val PREFS = "core_store"
        const val KEY_CORE = "core"
        const val KEY_PARAMS = "params"

        // کلیدهای عمومی بروکر Geph5 — طبق مستندات geph5 (باید در اولین بیلد با مخزن رسمی تطبیق داده شوند؛
        // یا از «پیکربندی خام» در تب Geph استفاده کن که این‌ها را دور می‌زند)
        private const val GEPH_MASTER = "88c1d2d4197bed815b01a22cadfc6c35aa246dddb553682037a118aebfaa3954"
        private const val GEPH_MIZARU_FREE = "0558216cbab7a9c46f298f4c26e171add9af87d0694988b8a8fe52ee932aa754"
        private const val GEPH_MIZARU_PLUS = "cf6f58868c6d9459b3a63bc2bd86165631b3e916bad7f62b578cd9614e0bcb3b"

        @Volatile @JvmField var running = false
        @Volatile @JvmField var verified = false
        @Volatile var activeCore = ""; private set
        @Volatile var stageText = "آماده"; private set
        @Volatile var err = ""; private set
        @Volatile var exitIp = ""; private set
        @Volatile var loc = ""; private set
        @Volatile private var stopping = false
        private val ring = ArrayDeque<String>()

        fun log(line: String) {
            synchronized(ring) {
                ring.addLast(line)
                while (ring.size > 300) ring.removeFirst()
            }
            Log.i(TAG, line)
        }

        private fun stage(s: String) { stageText = s; log(s) }

        private fun fail(s: String) {
            err = s; stageText = s; running = false
            log("خطا: $s")
        }

        fun snapshot(): String {
            val o = JSONObject()
            o.put("core", activeCore)
            o.put("running", running)
            o.put("verified", verified)
            o.put("stage", stageText)
            o.put("err", err)
            o.put("ip", exitIp)
            o.put("loc", loc)
            val tail = synchronized(ring) { ring.toList().takeLast(14) }
            o.put("logs", tail.joinToString("\n"))
            return o.toString()
        }
    }
}

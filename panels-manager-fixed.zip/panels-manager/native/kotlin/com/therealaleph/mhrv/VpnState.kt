package com.therealaleph.mhrv

/**
 * Process-wide "is the VPN/proxy up?" state shared by the service and the
 * Flutter MainActivity (same process). Plain properties only: Kotlin generates
 * the getters/setters itself, so no hand-written setX() functions (they clash
 * with the generated JVM signatures).
 */
object VpnState {
    @Volatile @JvmField var isRunning: Boolean = false
    @Volatile @JvmField var proxyHandle: Long = 0L
}

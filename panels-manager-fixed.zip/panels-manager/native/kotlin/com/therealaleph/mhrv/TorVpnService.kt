package com.therealaleph.mhrv

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.util.Log
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStream
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import javax.net.ssl.SSLSocketFactory

/**
 * Tor (Arti — Rust Tor client) داخل اپ:
 *
 *   باینری arti (arm64، اختیاری در بیلد) یک SOCKS5 روی 127.0.0.1:20872 بالا
 *   می‌آورد → کلید VPN سیستم (TUN) → tun2proxy.
 *
 * «وصل» فقط با تست واقعی HTTPS از داخل تونل تأیید می‌شود.
 * نکتهٔ صادقانه: اتصال مستقیم Tor روی بعضی اپراتورها بلاک است؛ آن‌جا SlipNet (DNS)
 * گزینهٔ بهتری است. پل‌ها (Snowflake و …) در بیلد اختیاری موتور قرار می‌گیرند.
 */
class TorVpnService : VpnService() {

    private var tun: ParcelFileDescriptor? = null
    private var tun2proxyThread: Thread? = null
    private val tun2proxyRunning = AtomicBoolean(false)
    private val tornDown = AtomicBoolean(false)
    private var proc: Process? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.i(TAG, "onStartCommand action=${intent?.action ?: "<null>"}")
        return when (intent?.action) {
            ACTION_STOP -> {
                try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Throwable) {}
                Thread({ teardown(); stopSelf() }, "tor-stop").start()
                START_NOT_STICKY
            }
            else -> {
                tornDown.set(false)
                startForeground(NOTIF_ID, buildNotif())
                Thread({ startEngine() }, "tor-start").start()
                START_NOT_STICKY
            }
        }
    }

    override fun onRevoke() {
        Thread({ teardown(); stopSelf() }, "tor-revoke").start()
    }

    override fun onDestroy() {
        try { teardown() } catch (t: Throwable) { Log.e(TAG, "onDestroy: ${t.message}") }
        super.onDestroy()
    }

    private fun startEngine() {
        stopping = false
        running = true
        verified = false
        err = ""
        stage("راه‌اندازی Tor…")
        val bin = File(applicationInfo.nativeLibraryDir, LIB)
        if (!bin.exists()) {
            fail("موتور Tor در این APK نصب نشده (بیلد آن اختیاری است) — از تب SlipNet استفاده کن")
            finishFailed(); return
        }
        // v1.24: پل‌های obfs4 (اختیاری) — از JS ذخیره شده‌اند؛ اگر نبودند اتصال مستقیم
        val bridgesPref = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_BRIDGES, "") ?: ""
        var bridgesFile: File? = null
        if (bridgesPref.isNotBlank()) {
            bridgesFile = File(filesDir, "tor-bridges.txt")
            bridgesFile.writeText(bridgesPref)
            log("پل‌ها فعال شدند (" + bridgesPref.lines().count { it.isNotBlank() } + " خط)")
        }
        if (!establishTun()) { finishFailed(); return }

        val data = File(filesDir, "tor-data").apply { mkdirs() }
        val flags = mutableListOf<String>(
            "--port", PORT.toString(),
            "--data", data.absolutePath,
        )
        if (bridgesFile != null) {
            flags.addAll(listOf("--bridges", bridgesFile.absolutePath))
            val pt = File(applicationInfo.nativeLibraryDir, "libobfs4.so")
            if (pt.exists()) {
                flags.addAll(listOf("--pt", pt.absolutePath))
                log("obfs4proxy: " + pt.absolutePath)
            } else {
                log("obfs4proxy در APK نیست — پل‌های obfs4 کار نمی‌کنند (اتصال مستقیم می‌رود)")
            }
        }
        log("cmd: torbin " + flags.joinToString(" "))
        val p = try {
            ProcessBuilder(listOf(bin.absolutePath) + flags).redirectErrorStream(true).start()
        } catch (t: Throwable) {
            log("exec مستقیم نشد (" + (t.message ?: "?") + ") → از لینکر سیستم")
            try {
                ProcessBuilder(listOf("/system/bin/linker64", bin.absolutePath) + flags)
                    .redirectErrorStream(true).start()
            } catch (t2: Throwable) {
                fail("اجرای موتور Tor شکست: " + (t2.message ?: t2.toString()))
                finishFailed(); return
            }
        }
        proc = p
        Thread({
            try {
                BufferedReader(InputStreamReader(p.inputStream, Charsets.UTF_8)).use { r ->
                    while (true) { val line = r.readLine() ?: break; log(line) }
                }
            } catch (_: Throwable) {}
        }, "tor-log").apply { isDaemon = true }.start()

        // v1.17: موتور torbin خودش تا ۱۸۰ ثانیه bootstrap می‌زند؛ قبلاً اپ در ۹۰ ثانیه تسلیم
        // می‌شد و روی نت‌های کند «Tor وصل نشد» می‌داد — بودجه‌ها حالا هم‌ترازند.
        if (awaitVerified(180_000L)) return
        if (stopping) return
        fail(if (err.isBlank()) "Tor وصل نشد — اپراتورت اتصال Tor را می‌بندد؛ از تب SlipNet استفاده کن" else err)
        finishFailed()
    }

    private fun finishFailed() {
        running = false
        try { teardown() } catch (_: Throwable) {}
        try { stopSelf() } catch (_: Throwable) {}
    }

    private fun establishTun(): Boolean {
        val builder = Builder()
            .setSession("tor")
            .setMtu(MTU)
            .addAddress("10.116.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("1.1.1.1")
            .setBlocking(false)
        try { builder.addDisallowedApplication(packageName) } catch (_: Throwable) {}
        val fd = try { builder.establish() } catch (t: Throwable) {
            Log.e(TAG, "establish: " + t.message); null
        }
        if (fd == null) { fail("مجوز VPN داده نشد یا یک VPN دیگر فعاله"); return false }
        tun = fd
        val det = fd.detachFd()
        tun2proxyRunning.set(true)
        val proxyUrl = "socks5://127.0.0.1:$PORT"
        val th = Thread({
            try {
                val rc = Native.runTun2proxy(proxyUrl, det, MTU, "")
                Log.i(TAG, "tun2proxy exited rc=$rc")
            } catch (t: Throwable) {
                Log.e(TAG, "tun2proxy: " + t.message)
            } finally {
                tun2proxyRunning.set(false)
            }
        }, "tor-tun2proxy")
        th.start()
        tun2proxyThread = th
        return true
    }

    private fun awaitVerified(budgetMs: Long): Boolean {
        val start = SystemClock.elapsedRealtime()
        var next = 0L
        var tick = 0
        while (SystemClock.elapsedRealtime() - start < budgetMs) {
            if (stopping) return false
            if (proc != null && proc?.isAlive != true) { log("موتور خودش بسته شد"); return false }
            if (SystemClock.elapsedRealtime() >= next) {
                tick++
                if (tick % 3 == 0) {
                    val secs = (SystemClock.elapsedRealtime() - start) / 1000
                    stage("در حال اتصال به شبکهٔ Tor… (" + secs + " ثانیه)")
                }
                val body = traceThroughSocks()
                if (body != null && body.contains("\r\n\r\n")) {
                    verified = true
                    exitIp = Regex("(?m)^ip=(.*)$").find(body)?.groupValues?.getOrNull(1)?.trim() ?: ""
                    loc = Regex("(?m)^loc=(.*)$").find(body)?.groupValues?.getOrNull(1)?.trim() ?: ""
                    stage("وصل شد ✓ · خروجی Tor: " + (loc.ifBlank { exitIp.ifBlank { "—" } }))
                    log("✅ تست واقعی از داخل Tor جواب داد · ip=$exitIp · loc=$loc")
                    return true
                }
                next = SystemClock.elapsedRealtime() + 5000
            }
            try { Thread.sleep(500) } catch (_: InterruptedException) { return false }
        }
        return false
    }

    private fun traceThroughSocks(): String? {
        return try {
        val s = Socket()
        s.soTimeout = 12000
        s.connect(InetSocketAddress("127.0.0.1", PORT), 5000)
        val out = s.getOutputStream()
        val inp = s.getInputStream()
        out.write(byteArrayOf(0x05, 0x01, 0x00)); out.flush()
        val greet = ByteArray(2)
        if (readFully(inp, greet) != 2 || greet[0] != 0x05.toByte() || greet[1] == 0xff.toByte()) {
            try { s.close() } catch (_: Throwable) {}
            return null
        }
        val host = "www.cloudflare.com".toByteArray(Charsets.US_ASCII)
        val req = ByteArray(7 + host.size)
        req[0] = 0x05; req[1] = 0x01; req[2] = 0x00; req[3] = 0x03
        req[4] = host.size.toByte()
        host.copyInto(req, 5)
        req[5 + host.size] = ((443 ushr 8) and 0xFF).toByte()
        req[6 + host.size] = (443 and 0xFF).toByte()
        out.write(req); out.flush()
        val rep = ByteArray(10)
        if (readFully(inp, rep) != 10 || rep[1] != 0x00.toByte()) {
            try { s.close() } catch (_: Throwable) {}
            return null
        }
        val ssl = (SSLSocketFactory.getDefault() as SSLSocketFactory)
            .createSocket(s, "www.cloudflare.com", 443, true)
        ssl.soTimeout = 12000
        val ro = ssl.getOutputStream()
        ro.write(("GET /cdn-cgi/trace HTTP/1.1\r\nHost: www.cloudflare.com\r\nUser-Agent: panels-manager\r\nConnection: close\r\n\r\n").toByteArray(Charsets.US_ASCII))
        ro.flush()
        val body = ssl.getInputStream().readBytes().toString(Charsets.UTF_8)
        try { ssl.close() } catch (_: Throwable) {}
        body
        } catch (t: Throwable) { null }
    }

    private fun readFully(inp: InputStream, b: ByteArray): Int {
        var n = 0
        while (n < b.size) {
            val k = inp.read(b, n, b.size - n)
            if (k < 0) break
            n += k
        }
        return n
    }

    private fun teardown() {
        if (!tornDown.compareAndSet(false, true)) return
        stopping = true
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Throwable) {}
        killEngine()
        if (tun2proxyRunning.get()) {
            val stopper = Thread({
                try { Native.stopTun2proxy() } catch (_: Throwable) {}
            }, "tor-t2p-stop").apply { start() }
            try { stopper.join(2_000) } catch (_: InterruptedException) {}
        }
        try { tun?.close() } catch (_: Throwable) {}
        tun = null
        try { tun2proxyThread?.join(4_000) } catch (_: InterruptedException) {}
        tun2proxyThread = null
        running = false
        stageText = "قطع شد"
    }

    private fun killEngine() {
        val p = proc ?: return
        proc = null
        try { p.destroy() } catch (_: Throwable) {}
        val gone = try { p.waitFor(3, TimeUnit.SECONDS) } catch (_: Throwable) { false }
        if (!gone) { try { p.destroyForcibly() } catch (_: Throwable) {} }
    }

    private fun buildNotif(): Notification {
        val mgr = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Tor", NotificationManager.IMPORTANCE_LOW)
                .apply { description = "وضعیت تونل Tor"; setShowBadge(false) }
            mgr.createNotificationChannel(ch)
        }
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        val openIntent = PendingIntent.getActivity(
            this, 0, launch ?: Intent(),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stopIntent = PendingIntent.getService(
            this, 2,
            Intent(this, TorVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        @Suppress("DEPRECATION")
        val b = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return b
            .setContentTitle("Tor فعال — شبکهٔ پیازی")
            .setContentText("SOCKS 127.0.0.1:$PORT · موتور Arti")
            .setSmallIcon(android.R.drawable.presence_online)
            .setContentIntent(openIntent)
            .addAction(
                Notification.Action.Builder(
                    android.graphics.drawable.Icon.createWithResource(
                        this, android.R.drawable.ic_menu_close_clear_cancel
                    ),
                    "قطع", stopIntent
                ).build()
            )
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val TAG = "TorVpnService"
        private const val CHANNEL_ID = "tor.vpn.status"
        private const val NOTIF_ID = 0x1006
        private const val MTU = 1500
        const val PORT = 20872
        const val LIB = "libtorbin.so"
        const val ACTION_STOP = "com.therealaleph.mhrv.TOR_STOP"
        const val PREFS = "tor_store"
        const val KEY_BRIDGES = "bridges"

        @Volatile @JvmField var running = false
        @Volatile @JvmField var verified = false
        @Volatile var stageText = "آماده"; private set
        @Volatile var err = ""; private set
        @Volatile var exitIp = ""; private set
        @Volatile var loc = ""; private set
        @Volatile private var stopping = false
        private val ring = ArrayDeque<String>()

        fun log(line: String) {
            synchronized(ring) {
                ring.addLast(line)
                while (ring.size > 300) ring.removeFirst()
            }
            Log.i(TAG, line)
        }

        private fun stage(s: String) { stageText = s; log(s) }

        private fun fail(s: String) {
            err = s; stageText = s; running = false
            log("خطا: " + s)
        }

        fun snapshot(): String {
            val o = JSONObject()
            o.put("running", running)
            o.put("verified", verified)
            o.put("stage", stageText)
            o.put("err", err)
            o.put("ip", exitIp)
            o.put("loc", loc)
            val tail = synchronized(ring) { ring.toList().takeLast(14) }
            o.put("logs", tail.joinToString("\n"))
            return o.toString()
        }
    }
}

package com.therealaleph.mhrv

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.util.Log
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStream
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import javax.net.ssl.SSLSocketFactory

/**
 * موتور SlipNet (anonvector/SlipNet — AGPL) — تونل DNS / SSH / VLESS داخل اپ:
 *
 *   باینری slipnet (Go، arm64) یک SOCKS5 محلی روی 127.0.0.1:20871 بالا می‌آورد
 *   (DNSTT / NoizDNS / VayDNS / SSH / VLESS) → کلید VPN سیستم (TUN) → tun2proxy
 *   ترافیک گوشی را داخل همان SOCKS5 می‌ریزد.
 *
 * «وصل» فقط وقتی تأیید می‌شود که یک درخواست واقعی HTTPS از داخل تونل جواب
 * بگیرد (همان استاندارد سخت‌گیرانهٔ تب وارپ قبلی) — به حرف خود موتور اکتفا نمی‌کنیم.
 */
class SlipVpnService : VpnService() {

    private var tun: ParcelFileDescriptor? = null
    private var tun2proxyThread: Thread? = null
    private val tun2proxyRunning = AtomicBoolean(false)
    private val tornDown = AtomicBoolean(false)
    private var proc: Process? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.i(TAG, "onStartCommand action=${intent?.action ?: "<null>"}")
        return when (intent?.action) {
            ACTION_STOP -> {
                try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Throwable) {}
                Thread({ teardown(); stopSelf() }, "slip-stop").start()
                START_NOT_STICKY
            }
            else -> {
                tornDown.set(false)
                startForeground(NOTIF_ID, buildNotif())
                Thread({ startEngine() }, "slip-start").start()
                START_NOT_STICKY
            }
        }
    }

    override fun onRevoke() {
        Thread({ teardown(); stopSelf() }, "slip-revoke").start()
    }

    override fun onDestroy() {
        try { teardown() } catch (t: Throwable) { Log.e(TAG, "onDestroy: ${t.message}") }
        super.onDestroy()
    }

    private fun profileUri(): String =
        getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_URI, "") ?: ""

    private fun dnsOverride(): String =
        getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_DNS, "") ?: ""

    private fun startEngine() {
        stopping = false
        running = true
        verified = false
        err = ""
        stage("شروع موتور SlipNet…")
        val bin = File(applicationInfo.nativeLibraryDir, LIB)
        if (!bin.exists()) { fail("موتور SlipNet داخل APK نیست — نسخهٔ جدید برنامه را نصب کن"); finishFailed(); return }
        val uri = profileUri().trim()
        if (uri.isBlank()) { fail("پروفایل SlipNet خالی است — اول در تب SlipNet پروفایل بساز یا ایمپورت کن"); finishFailed(); return }
        if (!establishTun()) { finishFailed(); return }

        val flags = mutableListOf<String>(
            "--port", PORT.toString(),
            "--host", "127.0.0.1",
        )
        val dns = dnsOverride().trim()
        if (dns.isNotEmpty()) flags.addAll(listOf("--dns", dns))
        flags.add(uri)
        log("cmd: slipnet " + flags.joinToString(" "))
        val p = try {
            ProcessBuilder(listOf(bin.absolutePath) + flags).redirectErrorStream(true).start()
        } catch (t: Throwable) {
            log("exec مستقیم نشد (" + (t.message ?: "?") + ") → از لینکر سیستم")
            try {
                ProcessBuilder(listOf("/system/bin/linker64", bin.absolutePath) + flags)
                    .redirectErrorStream(true).start()
            } catch (t2: Throwable) {
                fail("اجرای موتور SlipNet شکست: " + (t2.message ?: t2.toString()))
                finishFailed(); return
            }
        }
        proc = p
        Thread({
            try {
                BufferedReader(InputStreamReader(p.inputStream, Charsets.UTF_8)).use { r ->
                    while (true) { val line = r.readLine() ?: break; log(line) }
                }
            } catch (_: Throwable) {}
        }, "slip-log").apply { isDaemon = true }.start()

        if (awaitVerified(75_000L)) return
        if (stopping) return
        fail(if (err.isBlank()) "وصل نشد — پروفایل/رزولور را چک کن یا شبکه را عوض کن" else err)
        finishFailed()
    }

    private fun finishFailed() {
        running = false
        try { teardown() } catch (_: Throwable) {}
        try { stopSelf() } catch (_: Throwable) {}
    }

    /** کلید VPN سیستم + tun2proxy: ترافیک گوشی → SOCKS5 خود موتور SlipNet */
    private fun establishTun(): Boolean {
        val builder = Builder()
            .setSession("slipnet")
            .setMtu(MTU)
            .addAddress("10.115.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("1.1.1.1")
            .setBlocking(false)
        try { builder.addDisallowedApplication(packageName) } catch (_: Throwable) {}
        val fd = try { builder.establish() } catch (t: Throwable) {
            Log.e(TAG, "establish: " + t.message); null
        }
        if (fd == null) { fail("مجوز VPN داده نشد یا یک VPN دیگر فعاله"); return false }
        tun = fd
        val det = fd.detachFd()
        tun2proxyRunning.set(true)
        val proxyUrl = "socks5://127.0.0.1:$PORT"
        val th = Thread({
            try {
                val rc = Native.runTun2proxy(proxyUrl, det, MTU, "")
                Log.i(TAG, "tun2proxy exited rc=$rc")
            } catch (t: Throwable) {
                Log.e(TAG, "tun2proxy: " + t.message)
            } finally {
                tun2proxyRunning.set(false)
            }
        }, "slip-tun2proxy")
        th.start()
        tun2proxyThread = th
        return true
    }

    /** تأیید واقعی: درخواست HTTPS از داخل SOCKS موتور (مثل استاندارد تب وارپ) */
    private fun awaitVerified(budgetMs: Long): Boolean {
        val start = SystemClock.elapsedRealtime()
        var next = 0L
        while (SystemClock.elapsedRealtime() - start < budgetMs) {
            if (stopping) return false
            if (proc != null && proc?.isAlive != true) { log("موتور خودش بسته شد"); return false }
            if (SystemClock.elapsedRealtime() >= next) {
                val body = traceThroughSocks()
                if (body != null && body.contains("\r\n\r\n")) {
                    verified = true
                    exitIp = Regex("(?m)^ip=(.*)$").find(body)?.groupValues?.getOrNull(1)?.trim() ?: ""
                    loc = Regex("(?m)^loc=(.*)$").find(body)?.groupValues?.getOrNull(1)?.trim() ?: ""
                    stage("وصل شد ✓ · خروجی: " + (loc.ifBlank { exitIp.ifBlank { "—" } }))
                    log("✅ تست واقعی از داخل تونل جواب داد · ip=$exitIp · loc=$loc")
                    return true
                }
                next = SystemClock.elapsedRealtime() + 4000
            }
            try { Thread.sleep(400) } catch (_: InterruptedException) { return false }
        }
        return false
    }

    private fun traceThroughSocks(): String? {
        return try {
        val s = Socket()
        s.soTimeout = 9000
        s.connect(InetSocketAddress("127.0.0.1", PORT), 4000)
        val out = s.getOutputStream()
        val inp = s.getInputStream()
        out.write(byteArrayOf(0x05, 0x01, 0x00)); out.flush()
        val greet = ByteArray(2)
        if (readFully(inp, greet) != 2 || greet[0] != 0x05.toByte() || greet[1] == 0xff.toByte()) {
            try { s.close() } catch (_: Throwable) {}
            return null
        }
        val host = "www.cloudflare.com".toByteArray(Charsets.US_ASCII)
        val req = ByteArray(7 + host.size)
        req[0] = 0x05; req[1] = 0x01; req[2] = 0x00; req[3] = 0x03
        req[4] = host.size.toByte()
        host.copyInto(req, 5)
        req[5 + host.size] = ((443 ushr 8) and 0xFF).toByte()
        req[6 + host.size] = (443 and 0xFF).toByte()
        out.write(req); out.flush()
        val rep = ByteArray(10)
        if (readFully(inp, rep) != 10 || rep[1] != 0x00.toByte()) {
            try { s.close() } catch (_: Throwable) {}
            return null
        }
        val ssl = (SSLSocketFactory.getDefault() as SSLSocketFactory)
            .createSocket(s, "www.cloudflare.com", 443, true)
        ssl.soTimeout = 9000
        val ro = ssl.getOutputStream()
        ro.write(("GET /cdn-cgi/trace HTTP/1.1\r\nHost: www.cloudflare.com\r\nUser-Agent: panels-manager\r\nConnection: close\r\n\r\n").toByteArray(Charsets.US_ASCII))
        ro.flush()
        val body = ssl.getInputStream().readBytes().toString(Charsets.UTF_8)
        try { ssl.close() } catch (_: Throwable) {}
        body
        } catch (t: Throwable) { null }
    }

    private fun readFully(inp: InputStream, b: ByteArray): Int {
        var n = 0
        while (n < b.size) {
            val k = inp.read(b, n, b.size - n)
            if (k < 0) break
            n += k
        }
        return n
    }

    private fun teardown() {
        if (!tornDown.compareAndSet(false, true)) return
        stopping = true
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Throwable) {}
        killEngine()
        if (tun2proxyRunning.get()) {
            val stopper = Thread({
                try { Native.stopTun2proxy() } catch (_: Throwable) {}
            }, "slip-t2p-stop").apply { start() }
            try { stopper.join(2_000) } catch (_: InterruptedException) {}
        }
        try { tun?.close() } catch (_: Throwable) {}
        tun = null
        try { tun2proxyThread?.join(4_000) } catch (_: InterruptedException) {}
        tun2proxyThread = null
        running = false
        stageText = "قطع شد"
    }

    private fun killEngine() {
        val p = proc ?: return
        proc = null
        try { p.destroy() } catch (_: Throwable) {}
        val gone = try { p.waitFor(3, TimeUnit.SECONDS) } catch (_: Throwable) { false }
        if (!gone) { try { p.destroyForcibly() } catch (_: Throwable) {} }
    }

    private fun buildNotif(): Notification {
        val mgr = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "SlipNet", NotificationManager.IMPORTANCE_LOW)
                .apply { description = "وضعیت تونل SlipNet"; setShowBadge(false) }
            mgr.createNotificationChannel(ch)
        }
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        val openIntent = PendingIntent.getActivity(
            this, 0, launch ?: Intent(),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stopIntent = PendingIntent.getService(
            this, 2,
            Intent(this, SlipVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        @Suppress("DEPRECATION")
        val b = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return b
            .setContentTitle("SlipNet فعال — تونل DNS/SSH")
            .setContentText("SOCKS 127.0.0.1:$PORT · موتور SlipNet")
            .setSmallIcon(android.R.drawable.presence_online)
            .setContentIntent(openIntent)
            .addAction(
                Notification.Action.Builder(
                    android.graphics.drawable.Icon.createWithResource(
                        this, android.R.drawable.ic_menu_close_clear_cancel
                    ),
                    "قطع", stopIntent
                ).build()
            )
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val TAG = "SlipVpnService"
        private const val CHANNEL_ID = "slip.vpn.status"
        private const val NOTIF_ID = 0x1005
        private const val MTU = 1500
        const val PORT = 20871
        const val LIB = "libslipnet.so"
        const val PREFS = "slip_cfg"
        const val KEY_URI = "uri"
        const val KEY_DNS = "dns"
        const val ACTION_STOP = "com.therealaleph.mhrv.SLIP_STOP"

        @Volatile @JvmField var running = false
        @Volatile @JvmField var verified = false
        @Volatile var stageText = "آماده"; private set
        @Volatile var err = ""; private set
        @Volatile var exitIp = ""; private set
        @Volatile var loc = ""; private set
        @Volatile private var stopping = false
        private val ring = ArrayDeque<String>()

        fun log(line: String) {
            synchronized(ring) {
                ring.addLast(line)
                while (ring.size > 300) ring.removeFirst()
            }
            Log.i(TAG, line)
        }

        private fun stage(s: String) { stageText = s; log(s) }

        private fun fail(s: String) {
            err = s; stageText = s; running = false
            log("خطا: " + s)
        }

        fun snapshot(): String {
            val o = JSONObject()
            o.put("running", running)
            o.put("verified", verified)
            o.put("stage", stageText)
            o.put("err", err)
            o.put("ip", exitIp)
            o.put("loc", loc)
            val tail = synchronized(ring) { ring.toList().takeLast(14) }
            o.put("logs", tail.joinToString("\n"))
            return o.toString()
        }

        fun engineAvailable(ctx: android.content.Context): Boolean =
            File(ctx.applicationInfo.nativeLibraryDir, LIB).exists()
    }
}

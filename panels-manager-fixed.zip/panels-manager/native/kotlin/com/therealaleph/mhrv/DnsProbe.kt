package com.therealaleph.mhrv

import android.os.SystemClock
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

/**
 * پینگ واقعی DNS (کوئری A واقعی روی UDP/53) — بعد از حذف سرویس DNS-VPN،
 * این ابزار مستقل برای «تست DNS» تب اختلال و اسکنر رزولور SlipNet باقی ماند.
 */
object DnsProbe {

    /** سؤال استاندارد DNS (A برای example.com) */
    private fun buildQuery(): ByteArray {
        val q = ByteArray(30)
        q[2] = 0x01; q[3] = 0x00 // flags: recursion desired
        q[4] = 0x00; q[5] = 0x01 // qdcount = 1
        var i = 12
        q[i++] = 7; "example".toByteArray(Charsets.US_ASCII).forEach { q[i++] = it }
        q[i++] = 3; "com".toByteArray(Charsets.US_ASCII).forEach { q[i++] = it }
        q[i++] = 0
        q[i++] = 0; q[i++] = 1 // type A
        q[i++] = 0; q[i++] = 1 // class IN
        return q
    }

    /**
     * یک کوئری UDP/53 واقعی می‌فرستد و تأخیر جواب را برمی‌گرداند (ms)؛
     * اگر جواب نیامد -1.
     */
    fun probe(ip: String, tries: Int = 1, timeoutMs: Int = 2000): Int {
        if (!Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(ip.trim())) return -1
        val q = buildQuery()
        repeat(tries) {
            val sock = DatagramSocket()
            try {
                sock.soTimeout = timeoutMs
                val t0 = SystemClock.elapsedRealtime()
                sock.send(DatagramPacket(q, q.size, InetAddress.getByName(ip.trim()), 53))
                val rb = ByteArray(1024)
                val p = DatagramPacket(rb, rb.size)
                sock.receive(p)
                if (p.length > 12) return (SystemClock.elapsedRealtime() - t0).toInt()
            } catch (_: Throwable) {
            } finally {
                try { sock.close() } catch (_: Throwable) {}
            }
        }
        return -1
    }
}

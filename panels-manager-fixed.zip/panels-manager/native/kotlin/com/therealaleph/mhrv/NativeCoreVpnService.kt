package com.therealaleph.mhrv

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.LocalSocket
import android.net.LocalSocketAddress
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.system.Os
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.Socket
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/**
 * v1.31.0 — هسته‌های بومیِ Geph و Lantern، همان مسیری که Mlm VPN (GPL) رفته:
 *
 *   Geph  → باینری رسمیِ خودِ گپ (libgeph.so که CI با تأیید minisign از رلیز رسمی گپ
 *           بیرون می‌کشد) با کانفیگ JSON کامل (broker priority_race + کلیدهای امضا)،
 *           روی اندروید ۸+ مستقیم به‌عنوان VPN (TUN روی stdin با --vpn-fd 0 مثل
 *           اپ رسمی گپ) و روی اندروید ۷ با SOCKS محلی + tun2proxy.
 *   Lantern → باینری lanternproxy (سورس رسمی getlantern/radiance با تگ novpn که
 *           CI می‌سازد) به‌عنوان SOCKS/HTTP محلی روی 127.0.0.1:20840 + tun2proxy.
 *
 * «وصل» فقط با تست واقعی TLS از داخل تونل تأیید می‌شود — نه حرف خود هسته:
 *   Geph  → از port_forward خودِ موتور به www.gstatic.com:443 (تونل VPN_FD) یا
 *           از SOCKS محلی (حالت پل)
 *   Lantern → از SOCKS محلی به www.youtube.com:443
 */
class NativeCoreVpnService : VpnService() {

    private var tun: ParcelFileDescriptor? = null
    private var tun2proxyThread: Thread? = null
    private val tun2proxyRunning = java.util.concurrent.atomic.AtomicBoolean(false)
    private val tornDown = java.util.concurrent.atomic.AtomicBoolean(false)
    private var proc: Process? = null
    private var stdin: OutputStream? = null
    @Volatile private var coreId = "lantern"

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.i(TAG, "onStartCommand action=${intent?.action ?: "<null>"}")
        return when (intent?.action) {
            ACTION_STOP -> {
                try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Throwable) {}
                Thread({ teardown(); stopSelf() }, "nc-stop").start()
                START_NOT_STICKY
            }
            else -> {
                val c = intent?.getStringExtra("core") ?: "lantern"
                if (c != "geph" && c != "lantern") { stopSelf(); return START_NOT_STICKY }
                // استارتِ موتور دوم وقتی اولی بالا است: اول قبلی را جمع کن
                if (coreId != c && (GephS.running || LanternS.running)) {
                    Thread({ teardown() }, "nc-switch").start()
                    try { Thread.sleep(800) } catch (_: InterruptedException) {}
                }
                coreId = c
                tornDown.set(false)
                startForeground(NOTIF_ID, buildNotif())
                Thread({ startEngine() }, "nc-start-$c").start()
                START_NOT_STICKY
            }
        }
    }

    override fun onRevoke() {
        Thread({ teardown(); stopSelf() }, "nc-revoke").start()
    }

    override fun onDestroy() {
        try { teardown() } catch (t: Throwable) { Log.e(TAG, "onDestroy: ${t.message}") }
        super.onDestroy()
    }

    // ── engine selection ───────────────────────────────────────────────────────────────────────

    private fun st() = if (coreId == "geph") GephS else LanternS

    /** ثبت خطا در وضعیت هستهٔ جاری (برای نمایش در UI) — v1.32.1: قبلاً تعریف نشده بود و بیلد را می‌شکست. */
    private fun fail(msg: String) {
        val s = st()
        s.err = msg
        s.log(msg)
    }

    private fun startEngine() {
        val s = st()
        s.running = true; s.verified = false; s.err = ""; s.stopping = false
        s.stage("راه‌اندازی هستهٔ بومی…")
        val bin = File(applicationInfo.nativeLibraryDir, s.lib)
        if (!bin.exists()) {
            fail("هستهٔ " + (if (coreId == "geph") "Geph" else "Lantern") + " در این APK باندل نشده — بیلد جدید (CI) لازم است")
            finishFailed(); return
        }
        val ok = if (coreId == "geph") startGeph(bin) else startLantern(bin)
        if (!ok) { finishFailed(); return }
        val budget = if (coreId == "geph") 150_000L else 120_000L
        if (awaitVerified(budget)) return
        if (s.stopping) return
        fail(if (s.err.isBlank()) "هسته وصل نشد — شبکه یا تنظیمات را چک کن" else s.err)
        finishFailed()
    }

    private fun finishFailed() {
        st().running = false
        try { teardown() } catch (_: Throwable) {}
        try { stopSelf() } catch (_: Throwable) {}
    }

    // ── Geph ───────────────────────────────────────────────────────────────────────────────────

    private fun startGeph(bin: File): Boolean {
        val s = GephS
        val useVpnFd = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
        val socksPort = if (useVpnFd) 0 else s.port
        val verifyPort = s.verifyPort
        // پوشهٔ کار مخصوص موتور؛ cache باید «فایل» باشد وگرنه موتور یک ثانیه‌ای می‌میرد
        val dir = s.dir(this)
        val cfgFile = File(dir, if (useVpnFd) "main.yaml" else "bridge.yaml")
        cfgFile.writeText(gephConfig(this, socksPort, verifyPort, dryRun = false).toString())

        if (useVpnFd && !establishGephTun()) return false
        if (!useVpnFd && !establishTun(s.port)) return false

        val cmd = mutableListOf(bin.absolutePath, "--config", cfgFile.absolutePath)
        if (useVpnFd) cmd.addAll(listOf("--vpn-fd", "0"))
        s.stage(if (useVpnFd) "اجرای هستهٔ Geph (حالت VPN)…" else "اجرای هستهٔ Geph (حالت پل)…")
        val p = try {
            val pb = ProcessBuilder(cmd).redirectErrorStream(true)
            pb.environment().apply {
                put("RUST_LOG", "geph=info,geph5_client=info")
                put("NO_COLOR", "1"); put("CLICOLOR", "0"); put("TERM", "dumb")
                put("HOME", dir.absolutePath)
                put("TMPDIR", cacheDir.absolutePath)
            }
            if (useVpnFd) {
                // TUN به‌عنوان stdin موتور — دقیقاً مثل اپ رسمی گپ (GephDaemon.kt):
                // فقط fd 0 از فیلترِ ProcessBuilder جان سالم می‌بَرد؛ با dup2 همان لحظهٔ
                // fork گذاشته می‌شود و stdin خود اپ فوراً برمی‌گردد.
                synchronized(STDIN_LOCK) {
                    val saved = ParcelFileDescriptor.fromFd(0) // کپیِ stdin خود اپ
                    try {
                        Os.dup2(tun!!.fileDescriptor, 0)
                        try {
                            pb.redirectInput(ProcessBuilder.Redirect.INHERIT).start()
                        } finally {
                            Os.dup2(saved.fileDescriptor, 0)
                        }
                    } finally {
                        try { saved.close() } catch (_: Throwable) {}
                    }
                }
            } else {
                try {
                    pb.start()
                } catch (t: Throwable) {
                    s.log("exec مستقیم نشد (" + (t.message ?: "?") + ") → لینکر سیستم")
                    ProcessBuilder(listOf("/system/bin/linker64") + cmd).redirectErrorStream(true).start()
                }
            }
        } catch (t: Throwable) {
            fail("اجرای هستهٔ Geph شکست: " + (t.message ?: t.toString()))
            return false
        }
        proc = p
        readProc(p, "geph") { line -> s.log(line.take(240)) }
        return true
    }

    /** TUN مخصوص VPN_FD گپ: MTU ۱۶۳۸۴ و آدرس‌های مرجع (ipstack-geph خودش سگمنت ۱۶۳۸۴ می‌خواهد). */
    private fun establishGephTun(): Boolean {
        val builder = Builder()
            .setSession("geph")
            .setMtu(GEPH_VPN_MTU)
            .addAddress(GEPH_TUN_V4, GEPH_TUN_V4_PREFIX)
            .addRoute("0.0.0.0", 0)
            .addDnsServer(GEPH_TUN_DNS)
            .setBlocking(false)
        try { builder.addAddress(GEPH_TUN_V6, GEPH_TUN_V6_PREFIX) } catch (_: Throwable) {}
        try { builder.addRoute("::", 0) } catch (_: Throwable) {}
        try { builder.addDisallowedApplication(packageName) } catch (_: Throwable) {}
        val fd = try { builder.establish() } catch (t: Throwable) {
            Log.e(TAG, "geph establish: " + t.message); null
        }
        if (fd == null) { fail("مجوز VPN داده نشد یا یک VPN دیگر فعاله"); return false }
        tun = fd // در VPN_FD مالکیت fd با موتور است (stdin)؛ اینجا بعد از مرگش بسته می‌شود
        return true
    }

    // ── Lantern ────────────────────────────────────────────────────────────────────────────────

    private fun startLantern(bin: File): Boolean {
        val s = LanternS
        if (!establishTun(s.port)) return false
        val dir = s.dir(this)
        val cmd = mutableListOf(bin.absolutePath,
            "-socks", "127.0.0.1:${s.port}",
            "-configdir", dir.absolutePath)
        s.stage("اجرای هستهٔ Lantern…")
        val p = try {
            val pb = ProcessBuilder(cmd).redirectErrorStream(true)
            pb.environment().apply {
                put("TMPDIR", File(cacheDir, "lantern-tmp").apply { mkdirs() }.absolutePath)
                put("HOME", dir.parentFile?.absolutePath ?: dir.absolutePath)
            }
            try {
                pb.start()
            } catch (t: Throwable) {
                s.log("exec مستقیم نشد (" + (t.message ?: "?") + ") → لینکر سیستم")
                ProcessBuilder(listOf("/system/bin/linker64") + cmd).redirectErrorStream(true).start()
            }
        } catch (t: Throwable) {
            fail("اجرای هستهٔ Lantern شکست: " + (t.message ?: t.toString()))
            return false
        }
        proc = p
        stdin = p.outputStream
        // قرارداد stdout (cmd/lanternproxy): [lantern] config … / listening / proxy ok / exit … / error …
        Thread({
            try {
                BufferedReader(InputStreamReader(p.inputStream, Charsets.UTF_8)).use { r ->
                    while (true) {
                        val line = r.readLine() ?: break
                        val t = line.trim()
                        if (t.isEmpty()) continue
                        if (t.startsWith("[lantern] ")) {
                            val ev = t.removePrefix("[lantern] ")
                            when {
                                ev.startsWith("config cached servers=") ->
                                    s.servers = ev.removePrefix("config cached servers=").toIntOrNull() ?: 0
                                ev.startsWith("config fetched servers=") -> {
                                    s.servers = ev.removePrefix("config fetched servers=").toIntOrNull() ?: 0
                                    s.stage("فهرست سرورها رسید (" + s.servers + ")…")
                                }
                                ev.startsWith("exit ") -> {
                                    val parts = ev.removePrefix("exit ").split("|")
                                    s.exitCity = parts.getOrNull(0)?.trim().orEmpty()
                                    s.exitCountry = parts.getOrNull(1)?.trim().orEmpty()
                                    s.exitCode = parts.getOrNull(2)?.trim()?.uppercase() ?: ""
                                    if (s.exitCode.isNotBlank()) s.stage("خروجی: " + s.exitLabel())
                                }
                                ev.startsWith("error ") -> s.log("خطای هسته: " + ev.removePrefix("error "))
                                ev == "exhausted" -> {
                                    s.err = "هیچ سروری از فهرست لنترن جواب نداد — دوباره تلاش کن یا «فهرست سرور تازه» را بزن"
                                    s.log(s.err)
                                }
                                else -> s.log(ev.take(240))
                            }
                        } else {
                            s.log(t.take(240))
                        }
                    }
                }
            } catch (_: Throwable) {}
        }, "lantern-log").apply { isDaemon = true }.start()
        return true
    }

    // ── TUN + tun2proxy (حالت پل گپ روی اندروید ۷ + همیشه برای لنترن) ─────────────────────────

    private fun establishTun(socksPort: Int): Boolean {
        val builder = Builder()
            .setSession(if (coreId == "geph") "geph" else "lantern")
            .setMtu(MTU)
            .addAddress("10.116.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("1.1.1.1")
            .setBlocking(false)
        try { builder.addDisallowedApplication(packageName) } catch (_: Throwable) {}
        val fd = try { builder.establish() } catch (t: Throwable) {
            Log.e(TAG, "establish: " + t.message); null
        }
        if (fd == null) { fail("مجوز VPN داده نشد یا یک VPN دیگر فعاله"); return false }
        tun = fd
        val det = fd.detachFd()
        tun2proxyRunning.set(true)
        val proxyUrl = "socks5://127.0.0.1:$socksPort"
        val th = Thread({
            try {
                val rc = Native.runTun2proxy(proxyUrl, det, MTU, "")
                Log.i(TAG, "tun2proxy exited rc=$rc")
            } catch (t: Throwable) {
                Log.e(TAG, "tun2proxy: " + t.message)
            } finally {
                tun2proxyRunning.set(false)
            }
        }, "nc-tun2proxy")
        th.start()
        tun2proxyThread = th
        return true
    }

    // ── verify + teardown ──────────────────────────────────────────────────────────────────────

    private fun awaitVerified(budgetMs: Long): Boolean {
        val s = st()
        val start = SystemClock.elapsedRealtime()
        var next = 0L
        var tick = 0
        while (SystemClock.elapsedRealtime() - start < budgetMs) {
            if (s.stopping) return false
            if (proc != null && proc?.isAlive != true) { s.log("هسته خودش بسته شد"); return false }
            if (SystemClock.elapsedRealtime() >= next) {
                tick++
                if (tick % 6 == 0) {
                    val secs = (SystemClock.elapsedRealtime() - start) / 1000
                    s.stage("در حال اتصال به " + (if (coreId == "geph") "Geph" else "Lantern") + "… (" + secs + " ثانیه)")
                }
                val ok = if (coreId == "geph") gephVerify() else lanternVerify()
                if (ok) {
                    s.verified = true
                    s.stage("وصل شد ✓" + (if (s.exitLabel().isNotBlank()) " · خروجی: " + s.exitLabel() else ""))
                    s.log("✅ تست واقعی TLS از داخل تونل جواب داد")
                    return true
                }
                next = SystemClock.elapsedRealtime() + 4000
            }
            try { Thread.sleep(600) } catch (_: InterruptedException) { return false }
        }
        return false
    }

    /** تست گپ: TLS از port_forward خودِ موتور (VPN_FD) یا از SOCKS محلی (حالت پل). */
    private fun gephVerify(): Boolean {
        return if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O)
            tlsThroughSocks(GephS.port, GEPH_VERIFY_HOST)
        else
            tlsThroughForward(GephS.verifyPort, GEPH_VERIFY_HOST)
    }

    /** تست لنترن: هندشیک کامل TLS از SOCKS محلی — نه جواب SOCKS. */
    private fun lanternVerify(): Boolean = tlsThroughSocks(LanternS.port, LANTERN_PROBE_HOST)

    private fun tlsThroughForward(port: Int, host: String): Boolean = try {
        val s = Socket()
        s.soTimeout = 10000
        s.connect(InetSocketAddress("127.0.0.1", port), 5000)
        val ssl = (SSLSocketFactory.getDefault() as SSLSocketFactory).createSocket(s, host, 443, true) as SSLSocket
        ssl.soTimeout = 10000
        ssl.startHandshake()
        try { ssl.close() } catch (_: Throwable) {}
        true
    } catch (_: Throwable) { false }

    private fun tlsThroughSocks(port: Int, host: String): Boolean {
        return try {
        val s = Socket(Proxy.NO_PROXY)
        s.soTimeout = 12000
        s.connect(InetSocketAddress("127.0.0.1", port), 5000)
        val out = s.getOutputStream()
        val inp = s.getInputStream()
        out.write(byteArrayOf(0x05, 0x01, 0x00)); out.flush()
        val greet = ByteArray(2)
        if (readFully(inp, greet) != 2 || greet[0] != 0x05.toByte() || greet[1] != 0x00.toByte()) {
            try { s.close() } catch (_: Throwable) {}; return false
        }
        val h = host.toByteArray(Charsets.US_ASCII)
        val req = ByteArray(7 + h.size)
        req[0] = 0x05; req[1] = 0x01; req[2] = 0x00; req[3] = 0x03
        req[4] = h.size.toByte()
        h.copyInto(req, 5)
        req[5 + h.size] = ((443 ushr 8) and 0xFF).toByte()
        req[6 + h.size] = (443 and 0xFF).toByte()
        out.write(req); out.flush()
        val rep = ByteArray(4)
        if (readFully(inp, rep) != 4 || rep[1] != 0x00.toByte()) {
            try { s.close() } catch (_: Throwable) {}; return false
        }
        val skip = when (rep[3].toInt() and 0xFF) {
            1 -> 4 + 2
            4 -> 16 + 2
            3 -> {
                val l = ByteArray(1)
                if (readFully(inp, l) != 1) { try { s.close() } catch (_: Throwable) {}; return false }
                (l[0].toInt() and 0xFF) + 2
            }
            else -> { try { s.close() } catch (_: Throwable) {}; return false }
        }
        if (skip > 0) {
            val rest = ByteArray(skip)
            if (readFully(inp, rest) != skip) { try { s.close() } catch (_: Throwable) {}; return false }
        }
        val ssl = (SSLSocketFactory.getDefault() as SSLSocketFactory).createSocket(s, host, 443, true) as SSLSocket
        ssl.soTimeout = 12000
        ssl.startHandshake()
        try { ssl.close() } catch (_: Throwable) {}
        true
        } catch (_: Throwable) { false }
    }

    private fun readFully(inp: InputStream, b: ByteArray): Int {
        var n = 0
        while (n < b.size) {
            val k = inp.read(b, n, b.size - n)
            if (k < 0) break
            n += k
        }
        return n
    }

    private fun readProc(p: Process, tag: String, onLine: (String) -> Unit) {
        Thread({
            try {
                BufferedReader(InputStreamReader(p.inputStream, Charsets.UTF_8)).use { r ->
                    while (true) { val line = r.readLine() ?: break; if (line.isNotBlank()) onLine(line) }
                }
            } catch (_: Throwable) {}
            val code = try { p.waitFor() } catch (_: Throwable) { -1 }
            Log.i(TAG, "$tag exited with $code")
            val s = st()
            if (!s.stopping && code != 0) s.err = "هسته ناگهان بسته شد (کد $code)"
        }, "nc-log-$tag").apply { isDaemon = true }.start()
    }

    private fun teardown() {
        if (!tornDown.compareAndSet(false, true)) return
        val s = st()
        s.stopping = true
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Throwable) {}
        if (coreId == "geph") GephOps.stopControlQuietly(this)
        // لنترن: بستن stdin هسته → خودش خارج می‌شود (قرارداد lanternproxy)
        if (coreId == "lantern") {
            try { stdin?.close() } catch (_: Throwable) {}
            stdin = null
        }
        val p = proc
        if (p != null) {
            try { p.destroy() } catch (_: Throwable) {}
            val gone = try { p.waitFor(3, TimeUnit.SECONDS) } catch (_: Throwable) { false }
            if (!gone) { try { p.destroyForcibly() } catch (_: Throwable) {} }
        }
        proc = null
        if (tun2proxyRunning.get()) {
            val stopper = Thread({ try { Native.stopTun2proxy() } catch (_: Throwable) {} }, "nc-t2p-stop").apply { start() }
            try { stopper.join(2_000) } catch (_: InterruptedException) {}
        }
        try { tun?.close() } catch (_: Throwable) {}
        tun = null
        try { tun2proxyThread?.join(4_000) } catch (_: InterruptedException) {}
        tun2proxyThread = null
        s.running = false
        s.stageText = "قطع شد"
    }

    private fun buildNotif(): Notification {
        val name = if (coreId == "geph") "Geph" else "Lantern"
        val mgr = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "هسته‌های بومی", NotificationManager.IMPORTANCE_LOW)
                .apply { description = "وضعیت تونل Geph/Lantern"; setShowBadge(false) }
            mgr.createNotificationChannel(ch)
        }
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        val openIntent = PendingIntent.getActivity(
            this, 0, launch ?: Intent(),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stopIntent = PendingIntent.getService(
            this, 3,
            Intent(this, NativeCoreVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        @Suppress("DEPRECATION")
        val b = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return b
            .setContentTitle("$name فعال")
            .setContentText("هستهٔ بومی $name داخل اپ · وصل با TUN")
            .setSmallIcon(android.R.drawable.presence_online)
            .setContentIntent(openIntent)
            .addAction(
                Notification.Action.Builder(
                    android.graphics.drawable.Icon.createWithResource(
                        this, android.R.drawable.ic_menu_close_clear_cancel
                    ),
                    "قطع", stopIntent
                ).build()
            )
            .setOngoing(true)
            .build()
    }

    // ── state + ثابت‌های کانفیگ ────────────────────────────────────────────────────────────────

    companion object {
        private const val TAG = "NativeCoreVpnService"
        private const val CHANNEL_ID = "nc.vpn.status"
        private const val NOTIF_ID = 0x1007
        private const val MTU = 1500
        const val ACTION_STOP = "com.therealaleph.mhrv.NC_STOP"

        const val GEPH_VERIFY_HOST = "www.gstatic.com"
        const val LANTERN_PROBE_HOST = "www.youtube.com"

        /** ipstack-geph سگمنت‌ها را با ۱۶۳۸۴ می‌سازد؛ TUN باید موافق باشد. */
        const val GEPH_VPN_MTU = 16384
        const val GEPH_TUN_V4 = "100.64.89.64"
        const val GEPH_TUN_V4_PREFIX = 10
        const val GEPH_TUN_V6 = "fd00::1"
        const val GEPH_TUN_V6_PREFIX = 64
        const val GEPH_TUN_DNS = "1.1.1.1"

        private val STDIN_LOCK = Any()

        /** وضعیت دو هسته، جدا — هیچ‌کدام نباید به حرف دیگری دروغ بگویند. */
        class CoreState(val id: String, val lib: String, val port: Int, val verifyPort: Int) {
            @Volatile @JvmField var running = false
            @Volatile @JvmField var verified = false
            @Volatile @JvmField var stopping = false
            @Volatile var stageText = "آماده"
            @Volatile var err = ""
            @Volatile var servers = 0
            @Volatile var exitCity = ""; @Volatile var exitCountry = ""; @Volatile var exitCode = ""
            @Volatile var rx = 0L; @Volatile var tx = 0L
            private val ring = ArrayDeque<String>()

            fun log(line: String) {
                synchronized(ring) {
                    ring.addLast(line)
                    while (ring.size > 200) ring.removeFirst()
                }
                Log.i("NC-$id", line)
            }
            fun stage(s: String) { stageText = s; log(s) }
            fun exitLabel(): String {
                if (exitCode.isBlank() && exitCity.isBlank() && exitCountry.isBlank()) return ""
                val cc = exitCode.ifBlank { exitCountry }
                return if (exitCity.isNotBlank()) exitCity + " · " + cc else cc
            }
            fun dir(ctx: Context): File = File(ctx.noBackupFilesDir, id).apply { mkdirs() }
            fun sockPath(ctx: Context, query: Boolean): String =
                File(dir(ctx), if (query) "control-query.sock" else "control.sock").absolutePath
            fun cacheFile(ctx: Context, query: Boolean): File {
                val tag = if (query) "query" else try {
                    val cred = GephOps.credential(ctx)
                    val h = java.security.MessageDigest.getInstance("SHA-256")
                        .digest((cred?.toString() ?: "none").toByteArray(Charsets.UTF_8))
                    h.joinToString("") { String.format("%02x", it) }.take(24)
                } catch (_: Throwable) { "main" }
                return File(File(dir(ctx), "cache").apply { mkdirs() }, "db-$tag.sqlite")
            }
            fun snapshot(): String {
                val o = JSONObject()
                o.put("core", id)
                o.put("running", running)
                o.put("verified", verified)
                o.put("stage", stageText)
                o.put("err", err)
                o.put("servers", servers)
                o.put("exit", exitLabel())
                o.put("rx", rx); o.put("tx", tx)
                o.put("port", port)
                o.put("lib", lib)
                val ld = libDir
                o.put("available", ld != null && File(ld, lib).exists())
                val tail = synchronized(ring) { ring.toList().takeLast(12) }
                o.put("logs", tail.joinToString("\n"))
                return o.toString()
            }
        }

        @Volatile var libDir: String? = null

        val GephS = CoreState("geph", "libgeph.so", 20850, 20851)
        val LanternS = CoreState("lantern", "liblantern.so", 20840, 0)

        fun snapshot(core: String): String =
            (if (core == "geph") GephS else LanternS).snapshot()

        // ── کانفیگ geph5-client — دقیقاً همان کلیدهای مرجع (Config#[serde(deny_unknown_fields)]) ──

        fun gephConfig(ctx: Context, socksPort: Int, verifyPort: Int, dryRun: Boolean): JSONObject {
            val cred = GephOps.credential(ctx)
            val credJson = cred ?: JSONObject().put("secret", "")
            val exitCc = GephOps.exitCountry(ctx)
            val exitConstraint: Any = if (exitCc.isNullOrBlank()) "auto"
                else JSONObject().put("country", exitCc.uppercase())
            val cfg = JSONObject()
                .put("socks5_listen", if (socksPort > 0) "127.0.0.1:$socksPort" else JSONObject.NULL)
                .put("http_proxy_listen", JSONObject.NULL)
                .put("pac_listen", JSONObject.NULL)
                .put("control_listen", JSONObject.NULL)
                .put("control_listen_unix", GephS.sockPath(ctx, dryRun))
                .put("exit_constraint", exitConstraint)
                .put("allow_direct", false)
                .put("cache", GephS.cacheFile(ctx, dryRun).absolutePath)
                .put("broker", broker())
                .put("tunneled_broker", JSONObject().put("direct", "https://broker.geph.io"))
                .put("broker_keys", brokerKeys())
                .put("spoof_dns", false)
                .put("passthrough_china", false)
                .put("allow_lan", true)
                .put("dry_run", dryRun)
                .put("credentials", credJson)
                .put("sess_metadata", JSONObject().put("filter", JSONObject().put("nsfw", false).put("ads", false)))
                .put("task_limit", JSONObject.NULL)
            // هرگز TCP کنترل نمی‌گذاریم (بدون احراز هویت است) — فقط سوکت یونیکس در پوشهٔ خود اپ
            if (verifyPort > 0) {
                cfg.put("port_forward", JSONArray().put(
                    JSONObject().put("listen", "127.0.0.1:$verifyPort")
                        .put("connect", "$GEPH_VERIFY_HOST:443")))
            } else {
                cfg.put("port_forward", JSONArray())
            }
            return cfg
        }

        /** broker priority_race — عیناً از default-config.yaml خود geph5-app (چهار مسیر مسابقه می‌دهند). */
        fun broker(): JSONObject = JSONObject().put("priority_race", JSONObject()
            .put("2500", JSONObject().put("aws_lambda", JSONObject()
                .put("function_name", "geph-lambda-bouncer")
                .put("region", "us-east-1")
                .put("obfs_key", "855MJGAMB58MCPJBB97NADJ36D64WM2T:C4TN2M1H68VNMRVCCH57GDV2C5VN6V3RB8QMWP235D0P4RT2ACV7GVTRCHX3EC37")))
            .put("1500", JSONObject().put("fronted", JSONObject()
                .put("front", "https://kubernetes.io/")
                .put("host", "svitania-naidallszei-2.netlify.app")
                .put("override_dns", JSONArray().put("75.2.60.5:443"))))
            .put("500", JSONObject().put("fronted", JSONObject()
                .put("front", "https://kubernetes.io/")
                .put("host", "svitania-naidallszei-2.netlify.app")))
            .put("0", JSONObject().put("fronted", JSONObject()
                .put("front", "https://www.cdn77.com/")
                .put("host", "1826209743.rsc.cdn77.org"))))

        /** کلیدهایی که امضای broker را تأیید می‌کنند — عیناً از مرجع. */
        fun brokerKeys(): JSONObject = JSONObject()
            .put("master", "88c1d2d4197bed815b01a22cadfc6c35aa246dddb553682037a118aebfaa3954")
            .put("mizaru_free", "0558216cbab7a9c46f298f4c26e171add9af87d0694988b8a8fe52ee932aa754")
            .put("mizaru_plus", "cf6f58868c6d9459b3a63bc2bd86165631b3e916bad7f62b578cd9614e0bcb3b")
            .put(
                "mizaru_bw",
                "3082010a0282010100d0ae53a794ea37bf2e100cb3a872177ec6c11e8375fdcbf92960ce0293465674eb1426a1841b7622a58979a5ff3f8aa2301a621545e9b90bb39d1a6bfda19d6ca1aae74a3192ddfd2b9558eb652c3c2c22f42bdde272852fb67d93cae5846213512c474bf799844aee019bf718f6fa64223be06364459fc8dec66796b141d450d730c4fffe1cac7df8f05591560afa44bcf274f6c0e2303b39c21ab09d19b459ee594512b8341f3d407c026e2509f42c6d89f82f6a3a36fd5c05ad423cd99ad39089403eb9122ea60ef6648afff65438e8e26ce41fa55b9b18741965c77a627bae947bd38fc345e9adab42d6c458f6e194e4232cfd3f04924d5a5e932fe769610203010001",
            )
    }
}

/**
 * عملیات حساب Geph — کنترل RPC روی سوکت یونیکسِ موتور (nanorpc؛ یک درخواست در هر اتصال).
 * ساخت حساب رایگان = puzzle اثبات‌کار خودِ شبکه (start_registration/poll_registration).
 */
object GephOps {
    private const val PREFS = "nc_geph_store"
    private const val KEY_SECRET = "secret"
    private const val KEY_USER = "legacy_user"
    private const val KEY_PASS = "legacy_pass"
    private const val KEY_EXIT = "exit_country"

    // ── RPC روی سوکت کنترل ────────────────────────────────────────────────────────────────────

    class RpcException(message: String) : java.io.IOException(message)

    private fun call(socketPath: String, method: String, params: JSONArray = JSONArray(), timeoutMs: Int = 10_000): Any? {
        LocalSocket().use { socket ->
            socket.connect(LocalSocketAddress(socketPath, LocalSocketAddress.Namespace.FILESYSTEM))
            socket.soTimeout = timeoutMs
            val request = JSONObject()
                .put("jsonrpc", "2.0").put("method", method).put("params", params).put("id", 1)
            socket.outputStream.write((request.toString() + "\n").toByteArray(Charsets.UTF_8))
            socket.outputStream.flush()
            val line = BufferedReader(InputStreamReader(socket.inputStream, Charsets.UTF_8)).readLine()
                ?: throw java.io.IOException("موتور اتصال کنترل را بست")
            val answer = JSONObject(line)
            answer.optJSONObject("error")?.let { throw RpcException(it.optString("message", "error")) }
            val res = answer.opt("result")?.takeIf { it != JSONObject.NULL } ?: return null
            // بعضی بیلدها Result را {"Ok": …} می‌پیچند
            if (res is JSONObject && res.length() == 1 && res.has("Ok")) return res.opt("Ok")?.takeIf { it != JSONObject.NULL }
            if (res is JSONObject && res.length() == 1 && res.has("Err")) throw RpcException(res.opt("Err")?.toString() ?: "error")
            return res
        }
    }

    private fun reachable(socketPath: String): Boolean = try {
        LocalSocket().use { it.connect(LocalSocketAddress(socketPath, LocalSocketAddress.Namespace.FILESYSTEM)) }
        true
    } catch (_: Throwable) { false }

    // ── query engine: موتور بدون حساب فقط برای کارهای حساب ────────────────────────────────────

    @Volatile private var queryProc: Process? = null
    private val queryLock = Any()

    /** موتور پرس‌وجو (dry_run) — برای حساب/فهرست خروجی‌ها وقتی موتور اصلی بالا نیست. */
    private fun ensureQuery(ctx: Context): String {
        // مسیر RPC درست: موتور اصلی اگر بالا است، وگرنه query
        if (reachable(NativeCoreVpnService.GephS.sockPath(ctx, false)))
            return NativeCoreVpnService.GephS.sockPath(ctx, false)
        if (reachable(NativeCoreVpnService.GephS.sockPath(ctx, true)))
            return NativeCoreVpnService.GephS.sockPath(ctx, true)
        synchronized(queryLock) {
            if (reachable(NativeCoreVpnService.GephS.sockPath(ctx, true)))
                return NativeCoreVpnService.GephS.sockPath(ctx, true)
            val bin = File(ctx.applicationInfo.nativeLibraryDir, NativeCoreVpnService.GephS.lib)
            if (!bin.exists()) throw RpcException("هستهٔ Geph در APK نیست")
            val dir = NativeCoreVpnService.GephS.dir(ctx)
            val cfg = NativeCoreVpnService.gephConfig(ctx, 0, 0, dryRun = true)
            val f = File(dir, "query.yaml")
            f.writeText(cfg.toString())
            val pb = ProcessBuilder(listOf(bin.absolutePath, "--config", f.absolutePath)).redirectErrorStream(true)
            pb.environment().apply {
                put("RUST_LOG", "geph=info,geph5_client=info")
                put("NO_COLOR", "1"); put("CLICOLOR", "0"); put("TERM", "dumb")
                put("HOME", dir.absolutePath); put("TMPDIR", ctx.cacheDir.absolutePath)
            }
            queryProc = try { pb.start() } catch (t: Throwable) { throw RpcException("اجرای هستهٔ پرس‌وجو شکست: " + (t.message ?: "?")) }
            // صبر تا سوکت کنترل بالا بیاید
            val deadline = SystemClock.elapsedRealtime() + 20_000
            while (SystemClock.elapsedRealtime() < deadline) {
                if (reachable(NativeCoreVpnService.GephS.sockPath(ctx, true)))
                    return NativeCoreVpnService.GephS.sockPath(ctx, true)
                if (queryProc?.isAlive != true) throw RpcException("هستهٔ پرس‌وجو بسته شد")
                try { Thread.sleep(250) } catch (_: InterruptedException) {}
            }
            throw RpcException("هستهٔ پرس‌وجو بالا نیامد")
        }
    }

    fun stopQueryQuietly() {
        synchronized(queryLock) {
            val p = queryProc ?: return
            queryProc = null
            try { p.destroy() } catch (_: Throwable) {}
        }
    }

    // ── حساب ───────────────────────────────────────────────────────────────────────────────────

    fun credential(ctx: Context): JSONObject? {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val secret = p.getString(KEY_SECRET, "") ?: ""
        if (secret.isNotBlank()) return JSONObject().put("secret", secret)
        val u = p.getString(KEY_USER, "") ?: ""
        val pw = p.getString(KEY_PASS, "") ?: ""
        if (u.isNotBlank() && pw.isNotBlank())
            return JSONObject().put("legacy_username_password", JSONObject().put("username", u).put("password", pw))
        return null
    }

    fun exitCountry(ctx: Context): String =
        (ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_EXIT, "") ?: "").trim()

    /** اطلاعات حساب — get_user_info_by_cred روی broker (از راه موتور). */
    fun info(ctx: Context): String {
        val cred = credential(ctx) ?: return JSONObject().put("err", "حسابی ذخیره نشده").toString()
        val path = ensureQuery(ctx)
        val ans = call(path, "broker_rpc",
            JSONArray().put("get_user_info_by_cred").put(JSONArray().put(cred)), 25_000)
        val o = ans as? JSONObject
            ?: return JSONObject().put("err", "پاسخ حساب نامفهوم بود").toString()
        val bw = o.optJSONObject("bw_consumption")
        return JSONObject()
            .put("user_id", o.optLong("user_id"))
            .put("plus_expires", o.optLong("plus_expires_unix", 0))
            .put("mb_used", bw?.optInt("mb_used") ?: -1)
            .put("mb_limit", bw?.optInt("mb_limit") ?: -1)
            .put("renew", bw?.optLong("renew_unix") ?: 0)
            .toString()
    }

    /** ساخت حساب رایگان — puzzle اثبات‌کار شبکهٔ گپ (مثل اپ رسمی). */
    fun create(ctx: Context): String {
        val path = ensureQuery(ctx)
        val index = (call(path, "start_registration", timeoutMs = 30_000) as? Number)?.toInt()
            ?: throw RpcException("شروع ثبت‌نام جواب نداد")
        val deadline = SystemClock.elapsedRealtime() + 300_000
        var lastProgress = 0.0
        while (SystemClock.elapsedRealtime() < deadline) {
            val o = call(path, "poll_registration", JSONArray().put(index), 12_000) as? JSONObject
            if (o != null) {
                lastProgress = o.optDouble("progress", lastProgress)
                val secret = o.optString("secret", "")
                if (secret.isNotBlank() && secret != "null") {
                    val norm = normalizeSecret(secret)
                        ?: throw RpcException("کد حساب نامعتبر برگشت")
                    setSecret(ctx, norm)
                    stopQueryQuietly()
                    return JSONObject().put("secret", norm).put("formatted", formatSecret(norm)).toString()
                }
            }
            try { Thread.sleep(1_500) } catch (_: InterruptedException) {}
        }
        throw RpcException("ساخت حساب بیش از حد طول کشید (آخرین پیشرفت: " + (lastProgress * 100).toInt() + "٪)")
    }

    /** فهرست کشورهای خروجی — net_status موتور (خروجی‌ها با دسترسی‌پذیری Free/Plus). */
    fun exits(ctx: Context): String {
        val path = ensureQuery(ctx)
        val ns = call(path, "net_status", timeoutMs = 20_000) as? JSONObject
            ?: return JSONObject().put("err", "net_status نیامد").toString()
        val exits = ns.optJSONObject("exits") ?: return JSONObject().put("countries", JSONArray()).toString()
        val byCc = LinkedHashMap<String, JSONObject>()
        exits.keys().forEach { key ->
            val tuple = exits.optJSONArray(key) ?: return@forEach
            val desc = tuple.optJSONObject(1) ?: return@forEach
            val meta = tuple.optJSONObject(2)
            val cc = desc.optString("country").uppercase()
            if (cc.length != 2) return@forEach
            val levels = meta?.optJSONArray("allowed_levels")
            var free = true
            if (levels != null && levels.length() > 0) {
                free = false
                for (i in 0 until levels.length()) if (levels.optString(i).equals("Free", true)) free = true
            }
            val o = byCc.getOrPut(cc) { JSONObject().put("cc", cc).put("free", free).put("n", 0) }
            if (free && !o.optBoolean("free")) o.put("free", true)
            o.put("n", o.optInt("n") + 1)
        }
        val arr = JSONArray()
        byCc.values.sortedBy { it.optString("cc") }.forEach { arr.put(it) }
        return JSONObject().put("countries", arr).toString()
    }

    fun setExitCountry(ctx: Context, cc: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_EXIT, cc.trim().uppercase().take(2)).apply()
    }

    // ── ذخیرهٔ حساب ────────────────────────────────────────────────────────────────────────────

    /** «۱۲۳۴ ۵۶۷۸ …» برای نمایش، مثل اپ رسمی گپ. */
    fun formatSecret(secret: String): String = secret.chunked(4).joinToString(" ")

    /** ارقام فارسی → لاتین + فقط رقم + طول مجاز ۱۶..۴۰ (مثل مرجع). */
    fun normalizeSecret(input: String): String? {
        val fa = "۰۱۲۳۴۵۶۷۸۹"
        val sb = StringBuilder()
        for (c in input) {
            when {
                c.isDigit() -> sb.append(c)
                fa.indexOf(c) >= 0 -> sb.append(('0' + fa.indexOf(c)))
            }
        }
        val s = sb.toString()
        return if (s.length in 16..40) s else null
    }

    fun setSecret(ctx: Context, secret: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_SECRET, secret).remove(KEY_USER).remove(KEY_PASS).apply()
        deleteCaches(ctx)
    }

    fun setLegacy(ctx: Context, user: String, pass: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_USER, user).putString(KEY_PASS, pass).remove(KEY_SECRET).apply()
        deleteCaches(ctx)
    }

    fun forget(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .remove(KEY_SECRET).remove(KEY_USER).remove(KEY_PASS).apply()
        deleteCaches(ctx)
    }

    private fun deleteCaches(ctx: Context) {
        val d = File(NativeCoreVpnService.GephS.dir(ctx), "cache")
        d.listFiles()?.forEach { it.delete() }
    }

    /** موتور اصلی: RPC «stop» روی سوکت کنترل — موتور خودش ~۱۰۰ms بعد خارج می‌شود. */
    fun stopControlQuietly(ctx: Context) {
        try {
            val path = NativeCoreVpnService.GephS.sockPath(ctx, false)
            if (reachable(path)) call(path, "stop", timeoutMs = 2_000)
        } catch (_: Throwable) {}
        stopQueryQuietly()
    }
}

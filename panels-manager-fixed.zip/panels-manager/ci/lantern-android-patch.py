#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
v1.31.0 — پچ اندرویدِ بدون-cgo برای بیلد Lantern (getlantern/radiance) در CI.

radiance برای اندروید دو مانع دارد و هر دو با فایل‌های cgo هستند که با
CGO_ENABLED=0 از بیلد حذف می‌شوند:
  ۱) github.com/getlantern/osversion — GetString/GetHumanReadable فقط در
     osversion_android.go (cgo) هستند → بدون cgo «undefined» می‌شوند.
  ۲) outline-sdk/x/smart — cname_unix.go با تگ `unix` ولی بدنهٔ cgo؛
     با CGO_ENABLED=0 نه فایل unix (نیاز به cgo) و نه cname.go (!unix)
     انتخاب می‌شوند → lookupCNAME undefined.

راه‌حل (همان مسیر مرجع Mlm VPN که «pure Go بدون cgo» بیلد می‌کند): بعد از
`go mod vendor`، فایل‌های vendored پچ می‌شوند:
  - osversion: یک فایل fallback با تگ `android && !cgo` اضافه می‌شود که
    «نسخهٔ سیستم نامشخص» برمی‌گرداند (تماس‌گیرنده‌ها تلهمتری‌اند و خطا را
    می‌پذیرند).
  - smart: تگ‌ها دقیق می‌شوند (unix&&cgo / !unix||!cgo) تا در حالت بدون cgo
    نسخهٔ خالص Go (net.DefaultResolver) استفاده شود؛ همان رفتاری که برای
    دایالر smart فقط بهینه است و شکستش کشنده نیست.
"""
import io
import os
import sys

ROOT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
VENDOR = os.path.join(ROOT, 'vendor')
if not os.path.isdir(VENDOR):
    print('::error::vendor/ not found — run `go mod vendor` first')
    sys.exit(1)


def write(path, content):
    full = os.path.join(VENDOR, path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    io.open(full, 'w', encoding='utf-8', newline='\n').write(content)
    print('wrote:', path)


def retag(path, old, new):
    full = os.path.join(VENDOR, path)
    if not os.path.isfile(full):
        print('::warning::missing vendored file (skipped):', path)
        return
    s = io.open(full, encoding='utf-8').read()
    if new in s:
        print('already patched:', path)
        return
    if old not in s:
        print('::warning::build-tag anchor not found (skipped):', path)
        return
    io.open(full, 'w', encoding='utf-8', newline='\n').write(s.replace(old, new, 1))
    print('retagged:', path, '→', new)


OSVER = 'github.com/getlantern/osversion/'

# ۱) osversion — fallback برای android بدون cgo
write(OSVER + 'osversion_nocgo.go', """//go:build android && !cgo

package osversion

import "errors"

var errNoCgo = errors.New("osversion: android build without cgo")

// GetString / GetHumanReadable are normally provided by the cgo file that
// reads ro.build.version.*; without cgo on android they are excluded, so the
// two calls report "unknown" the same way an unsupported platform would.
// Callers (telemetry / issue reports) treat the error as "unknown", which is
// exactly right here.
func GetString() (string, error) {
\treturn "", errNoCgo
}

func GetHumanReadable() (string, error) {
\treturn "", errNoCgo
}
""")

# ۲) outline-sdk x/smart — هر دو ماژول (مسیر قدیمی و مسیر جدید)
for mod in ('github.com/Jigsaw-Code/outline-sdk/x/smart/',
            'golang.getoutline.org/sdk/x/smart/'):
    retag(mod + 'cname_unix.go', '//go:build unix', '//go:build unix && cgo')
    retag(mod + 'cname.go', '//go:build !unix', '//go:build !unix || !cgo')

print('lantern android patch: OK')

#!/usr/bin/env bash
# Everything after tool setup lives here (inside the zip), so fixing the build
# never requires editing the GitHub workflow file again.
set -euo pipefail
cd "$(dirname "$0")/.."

NDK_VERSION="${ANDROID_NDK_VERSION:-28.2.13676358}"

echo "::group::free disk space"
# v1.15 build is heavy (Rust core + Arti + SlipNet + NDK + Gradle). The runner
# ships big unused toolchains — removing them frees ~25GB+ and fixes the
# "LLVM ERROR: IO failure on output stream: No space left on device" failure.
sudo rm -rf /usr/local/lib/android/sdk/ndk/* 2>/dev/null || true        # preinstalled NDKs (we install our own below)
sudo rm -rf /usr/local/lib/android/sdk/emulator 2>/dev/null || true     # emulator (not needed for APK builds)
sudo rm -rf /usr/local/lib/android/sdk/system-images 2>/dev/null || true
sudo rm -rf /opt/hostedtoolcache/CodeQL 2>/dev/null || true             # CodeQL bundle
sudo rm -rf /usr/local/.ghcup /opt/ghc 2>/dev/null || true              # Haskell
sudo rm -rf /usr/share/dotnet 2>/dev/null || true                       # .NET
sudo rm -rf /usr/share/swift 2>/dev/null || true                        # Swift
sudo docker image prune -af >/dev/null 2>&1 || true                     # docker images
sudo apt-get clean 2>/dev/null || true
df -h / || true
echo "::endgroup::"

echo "::group::NDK + cargo-ndk"
yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" "ndk;$NDK_VERSION" >/dev/null || true
export ANDROID_NDK_HOME="$ANDROID_HOME/ndk/$NDK_VERSION"
cargo install cargo-ndk --locked
echo "::endgroup::"

echo "::group::flutter create + overlay"
# Save project files that flutter create might overwrite
mkdir -p /tmp/pm-backup
cp -a pubspec.yaml /tmp/pm-backup/
cp -a lib /tmp/pm-backup/
cp -a assets /tmp/pm-backup/

if [ ! -d android ]; then
  flutter create --platforms=android --org com.panels --project-name panels_manager .
fi

# Restore our real pubspec, lib, assets (flutter create replaces them)
cp -a /tmp/pm-backup/pubspec.yaml .
rm -rf lib assets
cp -a /tmp/pm-backup/lib .
cp -a /tmp/pm-backup/assets .

rm -rf test
mkdir -p android/app/src/main/kotlin android/app/src/main/res/xml
cp -r native/kotlin/. android/app/src/main/kotlin/
cp native/res/xml/network_security_config.xml android/app/src/main/res/xml/
cp native/AndroidManifest.xml android/app/src/main/AndroidManifest.xml
find android/app/src/main/java -name 'MainActivity.*' -delete 2>/dev/null || true

# App icon (لوگوی کاربر) — جایگزین آیکون پیش‌فرض Flutter
for d in mipmap-mdpi mipmap-hdpi mipmap-xhdpi mipmap-xxhdpi mipmap-xxxhdpi mipmap-anydpi-v26; do
  if [ -d "native/res/$d" ]; then
    mkdir -p "android/app/src/main/res/$d"
    cp -a "native/res/$d/." "android/app/src/main/res/$d/"
  fi
done
echo "launcher icons installed"

# v1.25.7 — صفحهٔ لانچ تاریک (بدون فلش سفید بین اسپلش سامسونگ و اولین فریم اپ)
if [ -f native/res/drawable/launch_background.xml ]; then
  mkdir -p android/app/src/main/res/drawable
  cp -f native/res/drawable/launch_background.xml android/app/src/main/res/drawable/launch_background.xml
  echo "dark launch screen installed"
fi

echo "=== pubspec.yaml after restore ==="
cat pubspec.yaml
echo "::endgroup::"

echo "::group::Rust core"
( cd rust
  cargo ndk -t arm64-v8a -o ../android/app/src/main/jniLibs build --release )
cd android/app/src/main/jniLibs/arm64-v8a
ls -la
H=$(ls -t libtun2proxy-*.so 2>/dev/null | head -1 || true)
if [ -n "$H" ]; then mv -f "$H" libtun2proxy.so; rm -f libtun2proxy-*.so; fi
test -f libmhrv_rs.so
test -f libtun2proxy.so
cd - >/dev/null
echo "::endgroup::"

echo "::group::bundled engines"
# موتور وارپ حذف شد (تب وارپ از v1.14 کنار گذاشته شد) — جایش:
#  ۱) موتور SlipNet (anonvector/SlipNet، AGPL) از سورس بیلد می‌شود → libslipnet.so
#  ۲) موتور Tor (Arti) اختیاری است؛ اگر بیلدش شکست بخورد APK بدون Tor بالا می‌آید
mkdir -p android/app/src/main/jniLibs/arm64-v8a
rm -f android/app/src/main/jniLibs/arm64-v8a/libwarpplus.so

# ---------- Go toolchain (مشخص‌شده — نه به پیش‌فرضِ رانر اتکا می‌کنیم) ----------
# v1.24.4: go.mod اسلیپ‌نت «go 1.24.4» می‌خواهد؛ گوی رانر ممکن است قدیمی باشد.
# GOTOOLCHAIN=auto خودش دانلود می‌کند ولی اگر گوی نصب‌شده < 1.21 باشد حتی این را
# نمی‌فهمد — پس گوی موجود باید ≥ 1.21 باشد (go1.24.4 ← 1.24 → مینور 24 ≥ 21) وگرنه
# همین‌جا گوی پین‌شده را نصب می‌کنیم.
GO_OK=0
GO_BIN=""
for g in go /usr/local/go/bin/go /usr/lib/go/bin/go "$HOME/go/bin/go"; do
  if command -v "$g" >/dev/null 2>&1 || [ -x "$g" ]; then
    v="$("$g" env GOVERSION 2>/dev/null || true)"          # مثل go1.24.4
    minor="$(printf '%s' "$v" | sed -n 's/^go1\.\([0-9][0-9]*\).*/\1/p')"
    case "$v" in
      go2.*) GO_OK=1; GO_BIN="$(command -v "$g" 2>/dev/null || echo "$g")"; break ;;
      go1.*) if [ -n "$minor" ] && [ "$minor" -ge 21 ] 2>/dev/null; then GO_OK=1; GO_BIN="$(command -v "$g" 2>/dev/null || echo "$g")"; break; fi ;;
    esac
  fi
done
if [ "$GO_OK" != "1" ]; then
  GO_PIN=1.24.4
  echo "-- installing pinned Go ${GO_PIN} (runner Go missing/too old)"
  GO_TGZ="go${GO_PIN}.linux-amd64.tar.gz"
  if curl -fsSL "https://go.dev/dl/${GO_TGZ}" -o "/tmp/${GO_TGZ}" \
     && rm -rf /tmp/go-pin && mkdir -p /tmp/go-pin \
     && tar -C /tmp/go-pin -xzf "/tmp/${GO_TGZ}"; then
    export PATH="/tmp/go-pin/go/bin:$PATH"
    GO_OK=1; GO_BIN="$(command -v go)"
  else
    echo "::warning::pinned Go download failed — falling back to whatever the runner has"
  fi
fi
if [ "$GO_OK" = "1" ]; then
  echo "Go toolchain: $("$GO_BIN" version)"
fi
export GOTOOLCHAIN=auto    # اگر go.mod نسخهٔ تازه‌تری خواست، خودش می‌گیرد
export GOPROXY="https://proxy.golang.org,direct"

echo "-- building SlipNet CLI (Go, android/arm64)"
# v1.24.4 — ریشهٔ واقعی «موتور SlipNet در APK نیست»:
#  cli/go.mod موتور SlipNet چهار ماژول را با replace نسبی می‌خواهد:
#    noizdns => ../noizdns ، vaydns-mobile => ../vaydns-mobile ،
#    github.com/net2share/vaydns => ../vaydns ، dnstt => ../dnstt
#  این‌ها git submodule اند؛ clone ساده (بدون ساب‌مودول) پوشه‌های خالی می‌گذارد →
#  go build شکست می‌خورد → قبلاً فقط warning می‌دادیم و APK بدون موتور می‌رفت
#  (تب SlipNet می‌گفت «موتور در این APK نیست»). حالا: کلون ساده + init گزیدهٔ همین
#  چهار ساب‌مودول + فال‌بک مستقیم + راستی‌آزمایی پوشه‌ها + راستی‌آزمایی باینری —
#  اگر موتور ساخته نشد بیلد کلاً قرمز می‌شود تا APK شکسته بی‌صدا تحویل نشود.
SLIP_OUT="$PWD/android/app/src/main/jniLibs/arm64-v8a/libslipnet.so"
SLIP_NEEDS="dnstt noizdns vaydns vaydns-mobile"
if [ "$GO_OK" = "1" ]; then
  SLIP_WORK="$(mktemp -d)"
  SLIP_DIR="$SLIP_WORK/SlipNet"
  slip_submods_ok() {  # هر چهار پوشهٔ ساب‌مودول باید واقعاً پر باشند
    for s in $SLIP_NEEDS; do
      [ -n "$(ls -A "$SLIP_DIR/$s" 2>/dev/null)" ] || return 1
    done
    return 0
  }
  if git clone --depth 1 https://github.com/anonvector/SlipNet.git "$SLIP_DIR" 2>&1 | tail -1; then
    ( cd "$SLIP_DIR" && for s in $SLIP_NEEDS; do
        git submodule update --init --depth 1 "$s" 2>&1 | tail -1 || true
      done )
  else
    echo "::error::SlipNet clone failed (network/GitHub down?)"
  fi
  if ! slip_submods_ok; then
    echo "::warning::submodule init incomplete — fallback: direct clone of each missing module"
    for s in $SLIP_NEEDS; do
      if [ -z "$(ls -A "$SLIP_DIR/$s" 2>/dev/null)" ]; then
        case "$s" in
          dnstt)         u="https://github.com/anonvector/dnstt.git" ;;
          noizdns)       u="https://github.com/anonvector/noizdns.git" ;;
          vaydns)        u="https://github.com/anonvector/vaydns.git" ;;
          vaydns-mobile) u="https://github.com/anonvector/vaydns-mobile.git" ;;
        esac
        rm -rf "$SLIP_DIR/$s"
        git clone --depth 1 "$u" "$SLIP_DIR/$s" 2>&1 | tail -1 || true
      fi
    done
  fi
  if [ -d "$SLIP_DIR/cli" ] && slip_submods_ok; then
    # resolvers.txt برای //go:embed لازم است — اگر در مخزن نبود، جایگزین می‌سازیم
    if ! ( cd "$SLIP_DIR/cli" && cp -f ../app/src/main/res/raw/resolvers.txt resolvers.txt 2>/dev/null ); then
      printf '8.8.8.8\n1.1.1.1\n9.9.9.9\n' > "$SLIP_DIR/cli/resolvers.txt"
      echo "::warning::resolvers.txt from repo missing — wrote a minimal fallback"
    fi
    if ( cd "$SLIP_DIR/cli" \
      && CGO_ENABLED=0 GOOS=android GOARCH=arm64 go build -trimpath -ldflags='-s -w' -o slipnet . \
      && cp slipnet "$SLIP_OUT" ); then
      echo "SlipNet engine built"
    else
      echo "::error::SlipNet go build failed — see log above (module/submodule errors are printed by go)"
    fi
  else
    echo "::error::SlipNet source/submodules incomplete — cannot build the engine"
  fi
  rm -rf "$SLIP_WORK" 2>/dev/null || true
else
  echo "::error::no usable Go toolchain — cannot build SlipNet engine"
fi
# گیت سخت: بدون libslipnet.so تب SlipNet مرده است — بیلد را قرمز کن
if [ -f "$SLIP_OUT" ] && [ "$(stat -c%s "$SLIP_OUT" 2>/dev/null || echo 0)" -gt 1000000 ]; then
  echo "SlipNet engine OK ($(stat -c%s "$SLIP_OUT") bytes)"
else
  echo "::error::FATAL: libslipnet.so was NOT produced — SlipNet tab would be broken. Failing the build so no dead APK ships. Check the SlipNet build log above."
  exit 1
fi

echo "-- building Tor engine (torbin/Arti — پل‌های obfs4 هم پشتیبانی می‌شود)"
TORBIN_DIR="$PWD/rust/torbin"
TORBIN_OUT="$PWD/android/app/src/main/jniLibs/arm64-v8a/libtorbin.so"
if [ -d "$TORBIN_DIR" ]; then
  # v1.25.1 گیت زودهنگام: Cargo.lock نباید openssl-sys داشته باشد — arti-client از
  # 0.44 به بعد TLS پیش‌فرضش native-tls است که برای کراس اندروید OpenSSL می‌خواهد و
  # رانر ندارد → «Could not find directory of OpenSSL installation». با فیکس v1.25.1
  # موتور Tor روی rustls+ring (بدون هیچ وابستگی سیستمی) بیلد می‌شود و لاک هم کامیت شده
  # (گراف منجمد) — اگر لاک دوباره آلوده شد، همین‌جا با پیام واضح قرمز می‌شود نه وسط کامپایل.
  if [ ! -f "$TORBIN_DIR/Cargo.lock" ]; then
    echo "::error::rust/torbin/Cargo.lock missing — the dependency graph must stay frozen (v1.25.1). Re-add the lock file."
    exit 1
  fi
  if grep -q 'name = "openssl-sys"' "$TORBIN_DIR/Cargo.lock" 2>/dev/null \
     || grep -q 'name = "native-tls"' "$TORBIN_DIR/Cargo.lock" 2>/dev/null; then
    echo "::error::torbin Cargo.lock contains openssl-sys/native-tls — android cross-build WILL fail (no cross OpenSSL on the runner). Restore the rustls-based lock from v1.25.1."
    exit 1
  fi
  echo "torbin lock check OK: rustls-based graph, $(grep -c '^\[\[package\]\]' "$TORBIN_DIR/Cargo.lock") packages, no openssl"
  ( cd "$TORBIN_DIR" \
    && timeout 3000 cargo ndk -t arm64-v8a build --release \
    && cp target/aarch64-linux-android/release/torbin "$TORBIN_OUT" ) \
    && echo "Tor engine OK" || echo "::warning::Tor (torbin) build failed/skipped — APK will build without Tor engine"
fi
# v1.24.7 گیت سخت: تب Tor «اختیاری» نیست — کاربر روی «وصل کردن Tor» کلیک می‌کند و
# انتظار اتصال واقعی به شبکهٔ Tor دارد؛ APK بدون libtorbin.so دیگر تحویل نمی‌شود.
TOR_SIZE="$(stat -c%s "$TORBIN_OUT" 2>/dev/null || echo 0)"
if [ "$TOR_SIZE" -gt 1000000 ]; then
  echo "Tor engine gate OK ($TOR_SIZE bytes)"
else
  echo "::error::FATAL: libtorbin.so was NOT produced — the Tor tab would be dead. Failing the build so no dead APK ships. Check the torbin/cargo log above."
  exit 1
fi

echo "-- building obfs4proxy (Go, android/arm64 — برای پل‌های Tor)"
OBFS_OUT="$PWD/android/app/src/main/jniLibs/arm64-v8a/libobfs4.so"
if command -v go >/dev/null 2>&1 || [ -x /usr/local/go/bin/go ]; then
  export PATH="$PATH:/usr/local/go/bin"
  OBFS_DIR="$(mktemp -d)/obfs4"
  # v1.24.7: کلون گیت‌لب گاهی رد می‌شود — آینهٔ رسمی torproject هم امتحان می‌شود
  if git clone --depth 1 https://gitlab.com/yawning/obfs4.git "$OBFS_DIR" 2>&1 | tail -1; then
    echo "obfs4 source: gitlab.com/yawning/obfs4"
    ( cd "$OBFS_DIR/obfs4proxy" \
      && CGO_ENABLED=0 GOOS=android GOARCH=arm64 go build -trimpath -ldflags='-s -w -checklinkname=0' -o obfs4proxy . \
      && cp obfs4proxy "$OBFS_OUT" ) \
      && echo "obfs4proxy OK" || echo "::warning::obfs4proxy build failed — Tor bridges will not work"
  elif git clone --depth 1 https://gitlab.torproject.org/tpo/anti-censorship/pluggable-transports/obfs4.git "$OBFS_DIR" 2>&1 | tail -1; then
    echo "obfs4 source: gitlab.torproject.org mirror"
    ( cd "$OBFS_DIR/obfs4proxy" \
      && CGO_ENABLED=0 GOOS=android GOARCH=arm64 go build -trimpath -ldflags='-s -w -checklinkname=0' -o obfs4proxy . \
      && cp obfs4proxy "$OBFS_OUT" ) \
      && echo "obfs4proxy OK" || echo "::warning::obfs4proxy build failed — Tor bridges will not work"
  else
    echo "::warning::obfs4 clone failed from both sources — Tor bridges will not work"
  fi
  rm -rf "$OBFS_DIR" 2>/dev/null || true
else
  echo "::warning::Go toolchain not found — Tor bridges will not work"
fi

# ─────────────────────────────────────────────────────────────────────────────
# v1.31.0 — هستهٔ رسمی Geph (مثل Mlm VPN): دانلود libgeph.so از رلیز رسمی خود
# گپ با تأیید زنجیرهٔ اعتماد کامل (metadata.yaml امضاشده با کلید minisign گپ →
# sha256 APK → استخراج lib/arm64-v8a/libgeph.so و چک ELF/PIE).
# گیت سخت: مثل SlipNet/Tor — بدون این فایل تب گپ مرده است و APK شکسته تحویل
# نمی‌شود. (فایل scripts/install-geph-binary.js را ببین.)
# ─────────────────────────────────────────────────────────────────────────────
echo "-- installing Geph official engine (minisign-verified, like Mlm VPN)"
GEPH_OUT="$PWD/android/app/src/main/jniLibs/arm64-v8a/libgeph.so"
if command -v node >/dev/null 2>&1; then
  if GEPH_JNI_DIR="$PWD/android/app/src/main/jniLibs" node scripts/install-geph-binary.js; then
    GEPH_SIZE="$(stat -c%s "$GEPH_OUT" 2>/dev/null || echo 0)"
    if [ "$GEPH_SIZE" -gt 1000000 ]; then
      echo "Geph engine gate OK ($GEPH_SIZE bytes)"
    else
      echo "::error::FATAL: libgeph.so is invalid ($GEPH_SIZE bytes) — the Geph tab would be dead. Failing the build."
      exit 1
    fi
  else
    echo "::error::FATAL: Geph install script failed (mirror/network/minisign) — the Geph tab would be dead. Failing the build. See the log above."
    exit 1
  fi
else
  echo "::error::FATAL: node not found on the runner — cannot verify+install the Geph engine"
  exit 1
fi

# ─────────────────────────────────────────────────────────────────────────────
# v1.31.0 — هستهٔ رسمی Lantern (مثل Mlm VPN): بیلد getlantern/radiance با تگ
# `novpn` + پوشش CLI خودمان (native/lantern-main/main.go، قرارداد stdout همان
# مرجع: [lantern] config … / listening / proxy ok / exit …). خروجی:
# android/app/src/main/jniLibs/arm64-v8a/liblantern.so — یک PIE قابل اجرا از
# طریق /system/bin/linker64 (مثل بقیهٔ موتورها).
# گیت هشدار (به خواست کاربر): اگر بیلد رادیانس شکست بخورد (API مخزن بالا دست
# عوض کند)، APK بدون لنترن بالا می‌آید و تب لنترن وضعیت صادقانه نشان می‌دهد —
# بقیهٔ موتورها آسیب نمی‌بینند.
# ─────────────────────────────────────────────────────────────────────────────
echo "-- building Lantern engine (getlantern/radiance, novpn tag — like Mlm VPN)"
LANT_OUT="$PWD/android/app/src/main/jniLibs/arm64-v8a/liblantern.so"
LANT_COMMIT="334712cb074a116871b83fb8a0c2f32a67ad614f" # pinned 2026-10-31 — بازتولیدپذیر
LANT_OK=0
if [ "$GO_OK" = "1" ]; then
  LANT_WORK="$(mktemp -d)"
  LANT_DIR="$LANT_WORK/radiance"
  if git clone --quiet https://github.com/getlantern/radiance.git "$LANT_DIR" 2>&1 | tail -1; then
    # پین به کامیت مشخص — اگر گیت‌هاب اجازهٔ fetch با SHA نداد، با هشدار از HEAD می‌رویم
    if ! ( cd "$LANT_DIR" && git fetch --quiet origin "$LANT_COMMIT" 2>/dev/null && git checkout --quiet "$LANT_COMMIT" 2>/dev/null ); then
      echo "::warning::radiance commit $LANT_COMMIT not fetchable — building HEAD (drift possible)"
    else
      echo "radiance pinned at $LANT_COMMIT"
    fi
    # پوشش CLI ما داخل خود ماژول می‌رود (replace های go.mod فقط از ماژول اصلی اعمال می‌شوند)
    mkdir -p "$LANT_DIR/cmd/lanternproxy"
    cp -f "$PWD/native/lantern-main/main.go" "$LANT_DIR/cmd/lanternproxy/main.go"
    if ( cd "$LANT_DIR" \
      && go mod vendor \
      && python3 "$PWD/ci/lantern-android-patch.py" "$LANT_DIR" \
      && CGO_ENABLED=0 GOOS=android GOARCH=arm64 go build -mod=vendor -tags novpn -trimpath \
           -ldflags='-s -w -checklinkname=0' -o lanternproxy ./cmd/lanternproxy \
      && cp lanternproxy "$LANT_OUT" ); then
      LANT_OK=1
      echo "Lantern engine OK ($(stat -c%s "$LANT_OUT") bytes)"
    else
      echo "::warning::Lantern (radiance novpn) build failed — APK will ship without the Lantern engine; the Lantern tab will say so honestly. Check the go log above."
    fi
  else
    echo "::warning::radiance clone failed — APK will ship without the Lantern engine"
  fi
  rm -rf "$LANT_WORK" 2>/dev/null || true
  # کش Go بعد از این بیلد سنگین (gvisor/sing-box) آزاد شود
  go clean -cache 2>/dev/null || true
else
  echo "::warning::no usable Go toolchain — cannot build the Lantern engine"
fi
if [ "$LANT_OK" = "1" ]; then
  echo "Lantern engine gate OK (soft gate — build continues)"
else
  echo "Lantern engine: NOT bundled (soft gate) — Lantern tab will show an honest message"
fi

echo "-- building Shir-o-Khorshid engine (psiphon-tunnel-core ConsoleClient + پیکربندی واقعی شبکهٔ Psiphon)"
# v1.24.7 — ریشهٔ واقعی «موتور/شبکهٔ شیر و خورشید در APK نیست» (سه عامل هم‌زمان):
#  (۱) مخزن shirokhorshid-android اصلاً فایل psi_config ندارد؛ پیکربندی‌شان را secret بیلد
#      خودشان موقع build تزریق می‌کند → استخراج psi_config از مخزن همیشه شکست می‌خورد.
#  (۲) بیلد موتور به PSI_CFG="ok" وابسته بود → هرگز اجرا نمی‌شد؛ ضمناً اسم پوشهٔ موتور
#      «ConsoleClient» است (حروف بزرگ) و find با «console_client» در لینوکس هیچ‌وقت
#      پیدایش نمی‌کرد — موتور هرگز ساخته نمی‌شد.
#  (۳) ShkVpnService فیلدهای اشتباه می‌نوشت (ListenSocksPort به‌جای LocalSocksProxyPort).
#  راه‌حل: پیکربندی واقعی (سرورانترهای امضاشدهٔ شبکهٔ Psiphon) از APK رسمی GPL
#  شیر و خورشید استخراج و در native/res/raw/psi_config.json سا شده؛ در CI اگر رلیز
#  تازه در دسترس بود همان refresh می‌شود، وگرنه نسخهٔ سا استفاده می‌شود. بیلد موتور هم
#  مستقل از پیکربندی از مخزن رسمی Psiphon-Labs انجام می‌شود. گیت سخت: بدون موتور یا
#  بدون پیکربندی واقعی، بیلد کل قرمز می‌شود.
# v1.25.16 — ریشهٔ «موتور هست ولی وصل نمی‌شود» (تأییدشده از سورس رسمی tunnel-core):
#  ConsoleClientِ فعلی لیست تعبیه‌شده را «فقط» از فایل فلگ ‎-serverList می‌خواند
#  (TunnelWorker.Init پارامتر config را "" رد می‌کند و فقط با فایل ImportEmbeddedServerEntries
#  صدا می‌زند) و فرمت هر خط باید hex("ip port secret cert {json}") باشد (بدون cert →
#  پیشوند 0 0 0 0؛ طبق encodeServerEntry رسمی). فراخوانیِ قدیمی «shkcore --config» یعنی
#  صفر کاندیداد → اتصال هرگز. فیکس در ShkVpnService.prepareEntryFile است (ساخت
#  shk-entries.txt در ران‌تایم و اجرای «shkcore --config … ‎-serverList …»). فرمت refresh
#  پایین (JSON خام در EmbeddedServerEntryList) عمداً همان است — کانورت در ران‌تایم انجام می‌شود.
mkdir -p android/app/src/main/res/raw
PSI_RAW="$PWD/android/app/src/main/res/raw/psi_config.json"
PSI_OUT="$PWD/android/app/src/main/jniLibs/arm64-v8a/libshkcore.so"

# — ۱) پیکربندی پایه: همیشه از نسخهٔ سا در مخزن شروع کن (هرگز {} جای‌نگهدار نگذار) —
if [ -s native/res/raw/psi_config.json ]; then
  cp -f native/res/raw/psi_config.json "$PSI_RAW"
  echo "psi_config: bundled snapshot copied ($(stat -c%s native/res/raw/psi_config.json) bytes)"
else
  echo "::error::native/res/raw/psi_config.json missing from repo — cannot ship ShK network config"
  printf '{}' > "$PSI_RAW"
fi

# — ۲) refresh بهترین‌تلاش از آخرین رلیز رسمی (سرورانترهای تازه‌تر) —
PSI_REL_URL="$(curl -fsSL --max-time 30 'https://api.github.com/repos/shirokhorshid/shirokhorshid-android/releases/latest' 2>/dev/null | python3 -c 'import json,sys
try:
  d=json.load(sys.stdin)
  for a in d.get("assets",[]):
    if a["name"].endswith(".apk"): print(a["browser_download_url"]); break
except Exception: pass' || true)"
if [ -n "$PSI_REL_URL" ] && [ -s native/res/raw/psi_config.json ]; then
  PSI_WORK="$(mktemp -d)"
  if curl -fsSL --max-time 600 -o "$PSI_WORK/shk.apk" "$PSI_REL_URL" 2>/dev/null; then
    python3 - "$PSI_WORK/shk.apk" "$PSI_WORK/psi_config.json" <<'PYEOF' || echo "::warning::psi_config refresh extraction failed — keeping bundled snapshot"
import json, re, sys, zipfile
z = zipfile.ZipFile(sys.argv[1]); pat = re.compile(rb'[0-9a-f]{600,}'); raws = set()
for n in z.namelist():
    if not re.match(r'classes\d*\.dex$', n): continue
    for m in pat.finditer(z.read(n)): raws.add(m.group(0))
entries = []
for h in raws:
    try: txt = bytes.fromhex(h.decode('ascii')).decode('utf-8', 'strict')
    except Exception: continue
    j = txt.find('{')
    if j < 0: continue
    try: js = json.loads(txt[j:])
    except Exception: continue
    if isinstance(js, dict) and 'ipAddress' in js: entries.append(txt.strip())
entries = list(dict.fromkeys(entries))
if len(entries) < 200: sys.exit(1)
json.dump({'ClientVersion':'1','ClientPlatform':'Android','PropagationChannelId':'FFFFFFFFFFFFFFFF','SponsorId':'FFFFFFFFFFFFFFFF','EmitDiagnosticNotices':False,'EmbeddedServerEntryList':entries}, open(sys.argv[2],'w'), separators=(',',':'))
print('psi_config refreshed from latest release:', len(entries), 'entries')
PYEOF
    if [ -s "$PSI_WORK/psi_config.json" ]; then
      cp -f "$PSI_WORK/psi_config.json" "$PSI_RAW"
      echo "psi_config: updated from latest ShirOKhorshid release"
    fi
  else
    echo "::warning::latest release APK download failed — keeping bundled snapshot"
  fi
  rm -rf "$PSI_WORK" 2>/dev/null || true
else
  echo "psi_config: release check skipped/failed — bundled snapshot will be used"
fi

# — ۳) بیلد موتور: ConsoleClient از مخزن رسمی (مستقل از پیکربندی) —
PSI_BUILT=0
if command -v go >/dev/null 2>&1 || [ -x /usr/local/go/bin/go ]; then
  export PATH="$PATH:/usr/local/go/bin"
  PSI_CORE="$(mktemp -d)/core"
  if git clone --depth 1 https://github.com/Psiphon-Labs/psiphon-tunnel-core.git "$PSI_CORE" 2>&1 | tail -1; then
    # دقت: اسم پکیگ «ConsoleClient» است — console_client کوچک در لینوکس وجود خارجی ندارد
    if [ -d "$PSI_CORE/ConsoleClient" ]; then
      # v1.25.3 — «link: github.com/wlynxg/anet: invalid reference to net.zoneCache»:
      #   از Go 1.23 چکر linkname لینکر به‌صورت پیش‌فرض روشن است و psiphon-tunnel-core از
      #   github.com/wlynxg/anet استفاده می‌کند که با go:linkname به سمبل‌های داخلی net
      #   (zoneCache) دست می‌زند → لینک ConsoleClient می‌میرد و libshkcore.so ساخته نمی‌شود.
      #   فیکسِ رسمیِ خودِ anet (README مخزن): -ldflags "-checklinkname=0" — همین.
      ( cd "$PSI_CORE" \
        && CGO_ENABLED=0 GOOS=android GOARCH=arm64 go build -trimpath -ldflags='-s -w -checklinkname=0' -o shkcore ./ConsoleClient \
        && cp shkcore "$PSI_OUT" ) \
        && PSI_BUILT=1 && echo "ShK (psiphon ConsoleClient) engine OK" \
        || echo "::error::psiphon ConsoleClient go build failed — see go log above"
    else
      echo "::error::ConsoleClient directory not found in psiphon-tunnel-core"
    fi
  else
    echo "::error::psiphon-tunnel-core clone failed"
  fi
  rm -rf "$(dirname "$PSI_CORE")" 2>/dev/null || true
else
  echo "::error::Go toolchain not found — cannot build ShK engine"
fi

# — ۴) گیت سخت: موتور + پیکربندی واقعی، هر دو اجباری —
SHK_SIZE="$(stat -c%s "$PSI_OUT" 2>/dev/null || echo 0)"
if [ "$SHK_SIZE" -gt 1000000 ]; then
  echo "ShK engine gate OK ($SHK_SIZE bytes)"
else
  echo "::error::FATAL: libshkcore.so was NOT produced — the Shir-o-Khorshid tab would be dead. Failing the build so no dead APK ships. Check the ConsoleClient build log above."
  exit 1
fi
PSI_ENTRIES="$(python3 -c "import json;print(len(json.load(open('$PSI_RAW')).get('EmbeddedServerEntryList',[])))" 2>/dev/null || echo 0)"
if [ "$PSI_ENTRIES" -ge 200 ]; then
  echo "psi_config gate OK ($PSI_ENTRIES server entries)"
else
  echo "::error::FATAL: psi_config.json has no real server entries ($PSI_ENTRIES) — ShK would connect to nothing. Failing the build."
  exit 1
fi
ls -la android/app/src/main/res/raw/ 2>/dev/null || true
ls -la android/app/src/main/jniLibs/arm64-v8a
echo "::endgroup::"

echo "::group::cleanup rust intermediates"
# All .so engines are built and copied into jniLibs now. The Rust target dirs
# (Arti alone is multi-GB) and the cargo registry cache are dead weight from
# here on — free the disk before gradle runs.
rm -rf rust/target rust/torbin/target 2>/dev/null || true
rm -rf "$HOME/.cargo/registry/src" "$HOME/.cargo/registry/cache" 2>/dev/null || true
# Go build cache after the engine builds (psiphon-tunnel-core alone ~2GB cache)
go clean -cache 2>/dev/null || true
df -h / || true
echo "::endgroup::"

echo "::group::gradle patch"
G=android/app/build.gradle.kts
if [ -f "$G" ]; then
  sed -i 's/minSdk = flutter.minSdkVersion/minSdk = 24/' "$G"
  # Pin NDK to the one we installed above — otherwise gradle auto-downloads its
  # own full NDK (e.g. r28c, ~5GB extracted) and the disk runs out again.
  sed -i "s/ndkVersion = flutter.ndkVersion/ndkVersion = \"${NDK_VERSION}\"/" "$G"
  sed -i '/^android {/a\    packaging { jniLibs { useLegacyPackaging = true; pickFirsts += "**/libc++_shared.so" } }\n    lint { checkReleaseBuilds = false; abortOnError = false }' "$G"
else
  G=android/app/build.gradle
  sed -i 's/minSdkVersion flutter.minSdkVersion/minSdkVersion 24/' "$G"
  sed -i "s/ndkVersion flutter.ndkVersion/ndkVersion \"${NDK_VERSION}\"/" "$G"
  sed -i "/^android {/a\    packagingOptions { jniLibs { useLegacyPackaging = true; pickFirsts += ['**/libc++_shared.so'] } }\n    lint { checkReleaseBuilds = false; abortOnError = false }" "$G"
fi
# fallback: template without any ndkVersion line
if ! grep -q "ndkVersion" "$G"; then
  sed -i "0,/^android {/s//android {\n    ndkVersion = \"${NDK_VERSION}\"/" "$G"
fi
grep -n "minSdk\|ndkVersion\|packaging\|lint" "$G" || true
echo "::endgroup::"

echo "::group::official Code.gs"
curl -fsSL https://raw.githubusercontent.com/therealaleph/MasterHttpRelayVPN-RUST/main/assets/apps_script/Code.gs -o assets/Code.gs
grep -q AUTH_KEY assets/Code.gs
echo "::endgroup::"

echo "::group::flutter pub get + build"
flutter pub get
# v1.25.18 — گیت سخت درستیِ پین: pubspec دیگر flutter_v2ray را دقیقاً روی 1.0.10 پین کرده؛
# همین‌جا از pubspec.lock مطمئن می‌شویم. (ریشهٔ فیکس v1.25.18: ^1.0.0 روی رانر به 1.0.10
# رزولو می‌شد که مانیفستش خودش PROPERTY_SPECIAL_USE_FGS_SUBTYPE=vpn دارد — تداخل با
# اعلانِ ما یعنی «Manifest merger failed» و بیلد قرمز. پین + این گیت = دیگر drift ممکن نیست.)
# v1.25.20 — فیکس باگِ خودِ گیت (درس بیلد قرمز «got ''»): در قالب واقعی pubspec.lock خطِ
# version هفت خط بعد از کلیدِ پکیج است (dependency/description/name/sha256/url/source) و
# «grep -A2» هرگز آن را نمی‌دید → استخراج همیشه تهی و بیلدِ سالم قرمز می‌شد. پنجره -A12 +
# sed مستقل از تورفتگی؛ در mismatch سکشنِ واقعیِ لاک dump می‌شود تا drift بی‌حدس ریشه‌یابی شود.
_LOCK_V="$(grep -A12 '^  flutter_v2ray:' pubspec.lock 2>/dev/null | sed -n 's/^[[:space:]]*version: *"\([^"]*\)".*/\1/p' | head -1)"
if [ "${_LOCK_V}" != "1.0.10" ]; then
  echo "::error::flutter_v2ray lock mismatch: expected 1.0.10, got '${_LOCK_V}' — pubspec pin broken or pub get failed"
  echo "::group::debug: pubspec.lock flutter_v2ray section"
  if [ ! -f pubspec.lock ]; then
    echo "(pubspec.lock MISSING — flutter pub get failed above; scroll up for the real error)"
  else
    grep -A12 '^  flutter_v2ray:' pubspec.lock 2>/dev/null || echo "(flutter_v2ray not present in pubspec.lock — pub get failed or pin broken)"
  fi
  echo "::endgroup::"
  exit 1
fi
echo "flutter_v2ray locked at ${_LOCK_V} (pinned)"
# v1.25.17 — فیکس کرش «برنامه مدام متوقف می‌شود» (App keeps stopping):
# پلاگین flutter_v2ray دو باگ قطعی دارد که هر دو پروسهٔ :RunSoLibV2RayDaemon
# را می‌کشند و دیالوگ «keeps stopping» را با نام اپ نشان می‌دهند:
#   (۱) onStartCommand روی intent تهی NPE می‌زند — START_STICKY بعد از هر مرگِ
#       پروسه در پس‌زمینه (LMK/Doze) یا استارت Always-on VPN سرویس را با intent
#       تهی ری‌استارت می‌کند → NPE → کرش → دوباره استارت → دوباره NPE = حلقهٔ کرش.
#   (۲) return START_STICKY همین چرخه را بی‌پایان تکرار می‌کند.
# پچ: گاردِ intent تهی + START_NOT_STICKY — سرویس بعد از مرگِ پروسه ساکت stop می‌شود
# (کاربر فقط یک بار دیگر «وصل» می‌زند) به‌جای حلقهٔ بی‌پایانِ کرش.
# (نوع سرویس foreground در AndroidManifest خودمان: v1.25.17 هر دو سرویس را تزریق می‌کرد؛
#  v1.25.18 فقط V2rayProxyOnlyService — پلاگین ۱.۰.۱۰ حالا V2rayVPNService را خودش با
#  type+property اعلان می‌کند و اعلانِ مجدد ما مرجر مانیفست را می‌شکست.)
PLUGIN_VER="1.0.10"
PLUGIN_DIR=$(find "$HOME/.pub-cache" -maxdepth 4 -type d -name "flutter_v2ray-${PLUGIN_VER}" 2>/dev/null | head -1)
if [ -n "$PLUGIN_DIR" ]; then
  python3 - "$PLUGIN_DIR" <<'PYEOF'
import io, sys, os
base = sys.argv[1]
files = [
    "android/src/main/java/com/github/blueboytm/flutter_v2ray/v2ray/services/V2rayVPNService.java",
    "android/src/main/java/com/github/blueboytm/flutter_v2ray/v2ray/services/V2rayProxyOnlyService.java",
]
OLD = '''    public int onStartCommand(Intent intent, int flags, int startId) {
        AppConfigs.V2RAY_SERVICE_COMMANDS startCommand = (AppConfigs.V2RAY_SERVICE_COMMANDS) intent.getSerializableExtra("COMMAND");'''
NEW = '''    public int onStartCommand(Intent intent, int flags, int startId) {
        // v1.25.17 crash fix: START_STICKY restart (process death / Always-on VPN)
        // delivers a NULL intent — the next line NPE'd and put :RunSoLibV2RayDaemon
        // into a crash loop ("App keeps stopping"). Stop quietly instead.
        if (intent == null || intent.getSerializableExtra("COMMAND") == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        AppConfigs.V2RAY_SERVICE_COMMANDS startCommand = (AppConfigs.V2RAY_SERVICE_COMMANDS) intent.getSerializableExtra("COMMAND");'''
for rel in files:
    p = os.path.join(base, rel)
    s = io.open(p, encoding='utf-8').read()
    if 'v1.25.17 crash fix' in s:
        print('already patched:', rel); continue
    if s.count(OLD) != 1:
        print('::error::flutter_v2ray patch target not found (count!=1) in ' + rel); sys.exit(1)
    s = s.replace(OLD, NEW)
    if s.count('return START_STICKY;') != 1:
        print('::error::START_STICKY not found (count!=1) in ' + rel); sys.exit(1)
    s = s.replace('return START_STICKY;', 'return START_NOT_STICKY;')
    io.open(p, 'w', encoding='utf-8').write(s)
    print('patched:', rel)
PYEOF
  # v1.25.36 — فیکس «اعلان روی برنامه می‌آید و نمی‌شود ردش کرد»:
  # کانال اعلان پلاگین IMPORTANCE_DEFAULT بود → صدا + بنر heads-up روی خود اپ.
  # حالا IMPORTANCE_LOW و کاملاً بی‌صدا (بدون صدا/لرزش/چراغ/بج) — دکمهٔ «قطع اتصال» سر جایش است.
  python3 - "$PLUGIN_DIR" <<'PYEOF2'
import io, sys, os
base = sys.argv[1]
p = os.path.join(base, "android/src/main/java/com/github/blueboytm/flutter_v2ray/v2ray/core/V2rayCoreManager.java")
s = io.open(p, encoding='utf-8').read()
OLD1 = "NotificationChannel channel = new NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_DEFAULT);"
NEW1 = "NotificationChannel channel = new NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_LOW);"
OLD2 = "            channel.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);"
NEW2 = ("            channel.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);\n"
        "            // v1.25.36 quiet notification fix: no sound/vibration/lights/badge —\n"
        "            // the VPN notice never pops a heads-up banner over the app anymore.\n"
        "            channel.setSound(null, null);\n"
        "            channel.enableVibration(false);\n"
        "            channel.enableLights(false);\n"
        "            channel.setShowBadge(false);")
if 'v1.25.36 quiet notification fix' in s:
    print('already patched (quiet notify):', p)
else:
    if s.count(OLD1) != 1 or s.count(OLD2) != 1:
        print('::warning::quiet-notify patch target not found in V2rayCoreManager.java — skipped (count1=%d count2=%d)' % (s.count(OLD1), s.count(OLD2)))
    else:
        s = s.replace(OLD1, NEW1).replace(OLD2, NEW2)
        io.open(p, 'w', encoding='utf-8').write(s)
        print('patched (quiet notify):', p)
PYEOF2
else
  echo "::error::flutter_v2ray ${PLUGIN_VER} not found in pub-cache — cannot apply crash patch (pin drift? pubspec.lock mismatch?)"
  exit 1
fi
flutter build apk --release --no-shrink --target-platform android-arm64
echo "::endgroup::"

VER=$(grep -m1 '^version:' pubspec.yaml | sed 's/version:[[:space:]]*//; s/+.*//')
mkdir -p dist
cp build/app/outputs/flutter-apk/app-release.apk "dist/panels-manager-v${VER%.0}.apk"
ls -la dist

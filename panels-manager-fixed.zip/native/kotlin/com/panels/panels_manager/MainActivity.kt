package com.panels.panels_manager

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Environment
import android.os.SystemClock
import android.provider.Settings
import com.therealaleph.mhrv.CaInstall
import com.therealaleph.mhrv.DnsProbe
import com.therealaleph.mhrv.MhrvVpnService
import com.therealaleph.mhrv.Native
import com.therealaleph.mhrv.ShkVpnService
import com.therealaleph.mhrv.SlipVpnService
import com.therealaleph.mhrv.TorVpnService
import com.therealaleph.mhrv.VpnState
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Flutter host activity + a small MethodChannel ("mhrv") that drives the
 * embedded mhrv-rs engine (Rust core via JNI + VpnService) plus the
 * SlipNet (DNS/SSH tunnel) and Tor (Arti) engines.
 *
 * v1.14: تب‌های وارپ و DNS-VPN حذف شدند — موتورهای WarpVpnService و
 * DnsVpnService به‌طور کامل از APK حذف شده‌اند. جای آن‌ها SlipNet و Tor.
 *
 * v1.25.17: فیکس «برنامه مدام متوقف می‌شود» — بخش ۱ (این فایل): ضبطِ کرش.
 * هر استثنای مدیریت‌نشده در هر رشتهٔ پروسهٔ اصلی قبل از مرگ در فایل ذخیره می‌شود
 * (۳ فایل آخر نگه داشته می‌شود) و از داخل برنامه هم قابل دیدن/کپی/حذف است —
 * این‌طوری هر کرش بعدی دیگر «ناشناخته» نیست؛ کاربر فقط از داخل اپ متن خطا را می‌فرستد.
 * ریشهٔ اصلی کرش در پلاگین flutter_v2ray بود (intent تهی در ری‌استارت + نبود
 * foregroundServiceType در اندروید ۱۴+) — پچ آن در ci/run.sh و AndroidManifest است.
 */
class MainActivity : FlutterActivity() {

    private var pendingStart: MethodChannel.Result? = null
    private var pendingShare: String? = null

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, i: Intent) {
            try {
                if (i.action != Intent.ACTION_PACKAGE_ADDED) return
                if (i.getBooleanExtra(Intent.EXTRA_REPLACING, false)) return
                val p = i.data?.schemeSpecificPart ?: return
                SecEngine.lastAdded = p
                SecEngine.lastAddedAt = System.currentTimeMillis()
            } catch (_: Throwable) {}
        }
    }

    private fun handleShareIntent(i: Intent?) {
        try {
            if (i == null) return
            val text = when (i.action) {
                Intent.ACTION_SEND -> i.getStringExtra(Intent.EXTRA_TEXT)
                Intent.ACTION_VIEW -> i.data?.toString()
                else -> null
            } ?: return
            if (text.isNotBlank()) pendingShare = text.trim()
        } catch (_: Throwable) {}
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        setIntent(i)
        handleShareIntent(i)
    }
    private var pendingSlip: MethodChannel.Result? = null
    private var pendingTor: MethodChannel.Result? = null
    private var pendingShk: MethodChannel.Result? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        CrashCatcher.install(this)
        SecEngine.init(this)
        try {
            // v1.25.36 — «برنامهٔ جدید نصب شد» برای سپر امنیت (ثبت در زمان اجرا؛ مجوزی لازم ندارد)
            val f = IntentFilter(Intent.ACTION_PACKAGE_ADDED)
            f.addDataScheme("package")
            registerReceiver(pkgReceiver, f)
        } catch (_: Throwable) {}
        handleShareIntent(intent)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "mhrv")
            .setMethodCallHandler { call, result ->
                try {
                    when (call.method) {
                        "init" -> {
                            Native.setDataDir(filesDir.absolutePath)
                            result.success(Native.version())
                        }
                        "start" -> start(call.argument<String>("config") ?: "", result)
                        "stop" -> {
                            startService(
                                Intent(this, MhrvVpnService::class.java)
                                    .setAction(MhrvVpnService.ACTION_STOP)
                            )
                            result.success(true)
                        }
                        "dnsProbe" -> {
                            // پینگ واقعی DNS (کوئری UDP/53) برای چند IP به‌صورت موازی
                            val ips = (call.argument<List<String>>("ips") ?: emptyList())
                                .map { it.trim() }.filter { it.isNotEmpty() }.take(20)
                            Thread {
                                val arr = JSONArray()
                                val ths = ips.map { ip ->
                                    Thread {
                                        val ms = DnsProbe.probe(ip)
                                        synchronized(arr) {
                                            arr.put(JSONObject().put("ip", ip).put("ms", ms))
                                        }
                                    }
                                }
                                ths.forEach { it.start() }
                                ths.forEach { it.join(5000) }
                                runOnUiThread { result.success(arr.toString()) }
                            }.start()
                        }
                        "slipStart" -> slipStart(
                            call.argument<String>("uri") ?: "",
                            call.argument<String>("dns") ?: "",
                            result
                        )
                        "slipStop" -> {
                            startService(
                                Intent(this, SlipVpnService::class.java)
                                    .setAction(SlipVpnService.ACTION_STOP)
                            )
                            result.success(true)
                        }
                        "slipStatus" -> result.success(SlipVpnService.snapshot())
                        "torStart" -> torStart(call.argument<String>("bridges") ?: "", result)
                        "torStop" -> {
                            startService(
                                Intent(this, TorVpnService::class.java)
                                    .setAction(TorVpnService.ACTION_STOP)
                            )
                            result.success(true)
                        }
                        "torStatus" -> result.success(TorVpnService.snapshot())
                        "shkStart" -> shkStart(result)
                        "shkStop" -> {
                            startService(
                                Intent(this, ShkVpnService::class.java)
                                    .setAction(ShkVpnService.ACTION_STOP)
                            )
                            result.success(true)
                        }
                        "shkStatus" -> result.success(ShkVpnService.snapshot())
                        "engineInfo" -> {
                            // v1.24.4: تب‌ها قبل از زدن «وصل» بدانند موتور واقعاً داخل
                            // APK هست یا نه — دیگر بعد از لمسِ دکمه غافلگیر نمی‌شویم.
                            val o = JSONObject()
                            val nd = applicationInfo.nativeLibraryDir
                            fun has(name: String) = java.io.File(nd, name).exists()
                            o.put("slip", has(SlipVpnService.LIB))
                            o.put("tor", has(TorVpnService.LIB))
                            o.put("shk", has(ShkVpnService.LIB))
                            o.put("obfs4", has("libobfs4.so"))
                            o.put("tun2proxy", has("libtun2proxy.so"))
                            result.success(o.toString())
                        }
                        "status" -> {
                            val o = JSONObject()
                            o.put("running", VpnState.isRunning)
                            val h = VpnState.proxyHandle
                            o.put("stats", if (h != 0L) Native.statsJson(h) else "")
                            o.put("logs", Native.drainLogs())
                            result.success(o.toString())
                        }
                        "caInfo" -> {
                            Native.setDataDir(filesDir.absolutePath)
                            val ok = CaInstall.export(this)
                            val fp = if (ok) CaInstall.fingerprint(this) else null
                            val o = JSONObject()
                            o.put("exists", ok)
                            o.put("installed", fp != null && CaInstall.isInstalled(fp))
                            o.put("fingerprint", if (fp != null) CaInstall.fingerprintHex(fp) else "")
                            result.success(o.toString())
                        }
                        "caInstall" -> {
                            Native.setDataDir(filesDir.absolutePath)
                            val ok = CaInstall.export(this)
                            val saved = if (ok) CaInstall.saveToDownloads(this) else null
                            if (saved != null) {
                                startActivity(
                                    Intent(Settings.ACTION_SECURITY_SETTINGS)
                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            }
                            result.success(saved ?: "")
                        }
                        "kvSet" -> {
                            getSharedPreferences("pm_store", MODE_PRIVATE).edit()
                                .putString(call.argument<String>("k") ?: "", call.argument<String>("v") ?: "")
                                .apply()
                            result.success(true)
                        }
                        "kvDel" -> {
                            getSharedPreferences("pm_store", MODE_PRIVATE)
                                .edit().remove(call.argument<String>("k") ?: "").apply()
                            result.success(true)
                        }
                        "kvGet" -> result.success(
                            getSharedPreferences("pm_store", MODE_PRIVATE)
                                .getString(call.argument<String>("k") ?: "", null)
                        )
                        "crashGet" -> result.success(CrashCatcher.readLogs(this))
                        "crashClear" -> { CrashCatcher.clear(this); result.success(true) }
                        "sec" -> sec(call.arguments as? Map<*, *> ?: emptyMap<Any, Any>(), result)
                        "takeShare" -> {
                            val t = pendingShare
                            pendingShare = null
                            result.success(t ?: "")
                        }
                        "crashLog" -> {
                            // خطای سمت دارت (که پروسه را نمی‌کشد) هم ثبت می‌شود تا تشخیص کامل باشد
                            CrashCatcher.appendDart(
                                this,
                                (call.argument<String>("tag") ?: "dart") + ": " + (call.argument<String>("msg") ?: "")
                            )
                            result.success(true)
                        }
                        else -> result.notImplemented()
                    }
                } catch (t: Throwable) {
                    result.error("mhrv", t.message ?: t.toString(), null)
                }
            }
    }

    private fun start(configJson: String, result: MethodChannel.Result) {
        if (configJson.isBlank()) { result.success("ERR:config خالیه"); return }
        getSharedPreferences(MhrvVpnService.PREFS, MODE_PRIVATE)
            .edit().putString(MhrvVpnService.KEY_CONFIG, configJson).apply()
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        }
        Thread {
            stopEnginesAndWait(stopMhrv = true, stopSlip = true, stopTor = true, stopShk = true)
            runOnUiThread {
                val prep = VpnService.prepare(this)
                if (prep != null) {
                    pendingStart?.success("ERR:درخواست قبلی لغو شد")
                    pendingStart = result
                    startActivityForResult(prep, REQ_VPN)
                } else {
                    launchService()
                    result.success("OK")
                }
            }
        }.start()
    }

    private fun launchService() {
        val i = Intent(this, MhrvVpnService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
    }

    /**
     * فقط یک VPN همزمان — همهٔ موتورهای خودمان را می‌بندد و تا آزاد شدن واقعی
     * اسلات صبر می‌کند.
     */
    private fun stopEnginesAndWait(stopMhrv: Boolean, stopSlip: Boolean, stopTor: Boolean, stopShk: Boolean) {
        if (stopMhrv && VpnState.isRunning) {
            startService(Intent(this, MhrvVpnService::class.java).setAction(MhrvVpnService.ACTION_STOP))
        }
        if (stopSlip && SlipVpnService.running) {
            startService(Intent(this, SlipVpnService::class.java).setAction(SlipVpnService.ACTION_STOP))
        }
        if (stopTor && TorVpnService.running) {
            startService(Intent(this, TorVpnService::class.java).setAction(TorVpnService.ACTION_STOP))
        }
        if (stopShk && ShkVpnService.running) {
            startService(Intent(this, ShkVpnService::class.java).setAction(ShkVpnService.ACTION_STOP))
        }
        val t0 = SystemClock.elapsedRealtime()
        while (SystemClock.elapsedRealtime() - t0 < 9000) {
            if (!VpnState.isRunning && !SlipVpnService.running && !TorVpnService.running && !ShkVpnService.running) {
                // کمی فرصت بعد از فلگ تا TUN واقعاً در کرنل آزاد شود
                try { Thread.sleep(300) } catch (_: InterruptedException) {}
                return
            }
            try { Thread.sleep(150) } catch (_: InterruptedException) { return }
        }
    }

    /**
     * SlipNet engine start. Android has a single VPN slot, so every other
     * engine we own is switched off first and we WAIT for the slot to be
     * released. Heavy work off the UI thread, ONE consent dialog, then
     * startForegroundService.
     */
    private fun slipStart(uri: String, dns: String, result: MethodChannel.Result) {
        if (uri.isBlank()) { result.success("ERR:پروفایل SlipNet خالی است"); return }
        Thread {
            stopEnginesAndWait(stopMhrv = true, stopSlip = true, stopTor = true, stopShk = true)
            getSharedPreferences(SlipVpnService.PREFS, MODE_PRIVATE).edit()
                .putString(SlipVpnService.KEY_URI, uri)
                .putString(SlipVpnService.KEY_DNS, dns)
                .apply()
            runOnUiThread {
                val prep = VpnService.prepare(this)
                if (prep != null) {
                    pendingSlip?.success("ERR:درخواست قبلی لغو شد")
                    pendingSlip = result
                    startActivityForResult(prep, REQ_VPN_SLIP)
                } else {
                    launchSlipService()
                    result.success("OK")
                }
            }
        }.start()
    }

    private fun torStart(bridges: String, result: MethodChannel.Result) {
        Thread {
            stopEnginesAndWait(stopMhrv = true, stopSlip = true, stopTor = true, stopShk = true)
            getSharedPreferences(TorVpnService.PREFS, MODE_PRIVATE).edit()
                .putString(TorVpnService.KEY_BRIDGES, bridges)
                .apply()
            runOnUiThread {
                val prep = VpnService.prepare(this)
                if (prep != null) {
                    pendingTor?.success("ERR:درخواست قبلی لغو شد")
                    pendingTor = result
                    startActivityForResult(prep, REQ_VPN_TOR)
                } else {
                    launchTorService()
                    result.success("OK")
                }
            }
        }.start()
    }

    /**
     * موتور شیر و خورشید (Psiphon داخل اپ) — همان الگوی Tor: صفر کانفیگ،
     * کلید VPN، یک پنجرهٔ اجازه، بعد سرویس foreground.
     */
    private fun shkStart(result: MethodChannel.Result) {
        Thread {
            stopEnginesAndWait(stopMhrv = true, stopSlip = true, stopTor = true, stopShk = true)
            runOnUiThread {
                val prep = VpnService.prepare(this)
                if (prep != null) {
                    pendingShk?.success("ERR:درخواست قبلی لغو شد")
                    pendingShk = result
                    startActivityForResult(prep, REQ_VPN_SHK)
                } else {
                    launchShkService()
                    result.success("OK")
                }
            }
        }.start()
    }

    private fun launchSlipService() {
        val i = Intent(this, SlipVpnService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
    }

    private fun launchTorService() {
        val i = Intent(this, TorVpnService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
    }

    private fun launchShkService() {
        val i = Intent(this, ShkVpnService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQ_VPN) {
            val r = pendingStart
            pendingStart = null
            if (resultCode == Activity.RESULT_OK) {
                launchService()
                r?.success("OK")
            } else {
                r?.success("ERR:مجوز VPN داده نشد")
            }
            return
        }
        if (requestCode == REQ_VPN_SLIP) {
            val r = pendingSlip
            pendingSlip = null
            if (resultCode == Activity.RESULT_OK) {
                launchSlipService()
                r?.success("OK")
            } else {
                r?.success("ERR:مجوز VPN داده نشد")
            }
            return
        }
        if (requestCode == REQ_VPN_TOR) {
            val r = pendingTor
            pendingTor = null
            if (resultCode == Activity.RESULT_OK) {
                launchTorService()
                r?.success("OK")
            } else {
                r?.success("ERR:مجوز VPN داده نشد")
            }
            return
        }
        if (requestCode == REQ_VPN_SHK) {
            val r = pendingShk
            pendingShk = null
            if (resultCode == Activity.RESULT_OK) {
                launchShkService()
                r?.success("OK")
            } else {
                r?.success("ERR:مجوز VPN داده نشد")
            }
            return
        }
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
    }

    /**
     * v1.25.36 — موتور مرکز امنیت (سپر): رم، پاکسازی، اسکن برنامه‌ها، اسکن فایل‌ها،
     * برنامه‌های جدید. صداقت: پاکسازی رم = بستن پردازش‌های «کش‌شده» (همان کاری که
     * اندروید مجاز است) + اندازه‌گیری واقعی قبل/بعد؛ اسکن فایل‌ها بدون اجازهٔ
     * «همهٔ فایل‌ها» فقط کش‌های خود اپ را حساب می‌کند (needPerm=true برمی‌گردد).
     */
    private fun sec(args: Map<*, *>, result: MethodChannel.Result) {
        Thread {
            val op = (args["op"] as? String) ?: ""
            val out: String = try {
                when (op) {
                    "mem" -> SecEngine.mem(this)
                    "clean" -> SecEngine.clean(this)
                    "apps" -> SecEngine.apps(this, args["pkg"] as? String)
                    "files" -> SecEngine.files(this)
                    "cleanfiles" -> SecEngine.cleanFiles(this)
                    "lastPkg" -> SecEngine.lastPkg(this)
                    else -> "{\"err\":\"unknown op\"}"
                }
            } catch (t: Throwable) {
                "{\"err\":\"" + (t.message ?: t.toString()).take(200) + "\"}"
            }
            runOnUiThread { result.success(out) }
        }.start()
    }

    companion object {
        private const val REQ_VPN = 4711
        private const val REQ_VPN_SLIP = 4717
        private const val REQ_VPN_TOR = 4719
        private const val REQ_VPN_SHK = 4723
    }

    /**
     * v1.25.17 — ضبط‌کنندهٔ کرش پروسهٔ اصلی.
     * استثنای مدیریت‌نشده → فایل crash-N.log (چرخشی، آخرین ۳ تا) → بعد به هندلر پیش‌فرض
     * سپرده می‌شود (رفتار سیستم دست نمی‌خورد). لاگ‌ها از داخل اپ (متد crashGet) خوانده
     * می‌شوند و کاربر می‌تواند متنش را برای ما بفرستد — دیگر هیچ کرش ناشناخته‌ای نمی‌ماند.
     */
    object CrashCatcher {
        private const val MAX_FILES = 3
        private const val MAX_DART_BYTES = 64 * 1024

        fun install(ctx: Context) {
            val prev = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler { t, e ->
                try { write(ctx, t, e) } catch (_: Throwable) {}
                prev?.uncaughtException(t, e)
            }
        }

        private fun shift(ctx: Context) {
            for (i in MAX_FILES - 1 downTo 1) {
                val f = File(ctx.filesDir, "crash-$i.log")
                if (f.exists()) {
                    val n = File(ctx.filesDir, "crash-${i + 1}.log")
                    if (i == MAX_FILES - 1) f.delete() else f.renameTo(n)
                }
            }
        }

        private fun write(ctx: Context, t: Thread, e: Throwable) {
            shift(ctx)
            val sw = StringWriter()
            e.printStackTrace(PrintWriter(sw))
            val ver = try {
                ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "?"
            } catch (_: Throwable) { "?" }
            val sb = StringBuilder()
            sb.append("== CRASH ")
                .append(SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()))
                .append(" · v").append(ver)
                .append(" · ").append(Build.MANUFACTURER).append(" ").append(Build.MODEL)
                .append(" · API ").append(Build.VERSION.SDK_INT)
                .append(" · thread=").append(t.name).append('\n')
            sb.append(sw.toString())
            try {
                sb.append("-- engine state --\n")
                sb.append("mhrv.running=").append(VpnState.isRunning).append('\n')
                sb.append("slip=").append(SlipVpnService.running)
                    .append(" tor=").append(TorVpnService.running)
                    .append(" shk=").append(ShkVpnService.running).append('\n')
                sb.append("slip.stage=").append(SlipVpnService.stageText).append('\n')
                sb.append("shk.stage=").append(ShkVpnService.stageText).append('\n')
                sb.append("tor.stage=").append(TorVpnService.stageText).append('\n')
            } catch (_: Throwable) {}
            try {
                File(ctx.filesDir, "crash-1.log").writeText(sb.toString())
            } catch (_: Throwable) {}
        }

        /** خروجی: JSON {"logs": متن، "count": تعداد فایل‌های حاضر} — از تازه به کهنه. */
        fun readLogs(ctx: Context): String {
            val o = JSONObject()
            var count = 0
            val sb = StringBuilder()
            for (i in 1..MAX_FILES) {
                val f = File(ctx.filesDir, "crash-$i.log")
                if (!f.exists()) continue
                count++
                if (sb.isNotEmpty()) sb.append("\n\n----------------\n\n")
                sb.append(f.readText())
                if (sb.length > 12000) { sb.setLength(12000); sb.append("\n… (بریده شد)"); break }
            }
            val dart = File(ctx.filesDir, "crash-dart.log")
            if (dart.exists()) {
                try {
                    val dt = dart.readText()
                    if (dt.isNotBlank()) {
                        sb.append("\n\n== خطاهای دارت ==\n").append(dt.take(4000))
                    }
                } catch (_: Throwable) {}
            }
            if (sb.isEmpty()) sb.append("هیچ گزارش کرشی ثبت نشده — از آخرین نصب تا الان هیچ کرشی نداشته‌ایم.")
            o.put("logs", sb.toString())
            o.put("count", count)
            return o.toString()
        }

        fun clear(ctx: Context) {
            for (i in 1..MAX_FILES) { try { File(ctx.filesDir, "crash-$i.log").delete() } catch (_: Throwable) {} }
            try { File(ctx.filesDir, "crash-dart.log").delete() } catch (_: Throwable) {}
        }

        fun appendDart(ctx: Context, line: String) {
            try {
                val f = File(ctx.filesDir, "crash-dart.log")
                if (f.length() > MAX_DART_BYTES) f.writeText("")
                f.appendText(SimpleDateFormat("MM-dd HH:mm:ss ", Locale.US).format(Date()) + line.take(500) + "\n")
            } catch (_: Throwable) {}
        }
    }

    /**
     * v1.25.36 — مجموعهٔ ابزارهای مرکز امنیت. همهٔ خروجی‌ها JSON هستند و
     * فقط روی خود گوشی ساخته می‌شوند (هیچ داده‌ای جایی فرستاده نمی‌شود).
     */
    object SecEngine {
        var lastAdded: String? = null
        var lastAddedAt: Long = 0
        private var initialized = false

        fun init(ctx: Context) {
            if (initialized) return
            initialized = true
            try {
                val p = ctx.getSharedPreferences("pm_sec", Context.MODE_PRIVATE)
                lastAdded = p.getString("lastPkg", null)
                lastAddedAt = p.getLong("lastPkgAt", 0)
            } catch (_: Throwable) {}
        }

        private fun persist(ctx: Context) {
            try {
                ctx.getSharedPreferences("pm_sec", Context.MODE_PRIVATE).edit()
                    .putString("lastPkg", lastAdded ?: "")
                    .putLong("lastPkgAt", lastAddedAt)
                    .apply()
            } catch (_: Throwable) {}
        }

        fun mem(ctx: Context): String {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            val total = mi.totalMem
            val avail = mi.availMem
            val usedPct = if (total > 0) ((total - avail) * 100.0 / total) else 0.0
            val o = JSONObject()
            o.put("total", total).put("avail", avail)
            o.put("usedPct", Math.round(usedPct * 10) / 10.0)
            o.put("low", mi.lowMemory)
            o.put("threshold", mi.threshold)
            return o.toString()
        }

        @Suppress("DEPRECATION")
        fun clean(ctx: Context): String {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val before = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.availMem
            var killed = 0
            try {
                val pm = ctx.packageManager
                val launchables = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                val list = pm.queryIntentActivities(launchables, 0)
                val seen = HashSet<String>()
                for (ri in list) {
                    val pkg = ri.activityInfo?.packageName ?: continue
                    if (pkg == ctx.packageName || !seen.add(pkg)) continue
                    try {
                        am.killBackgroundProcesses(pkg)
                        killed++
                    } catch (_: Throwable) {}
                }
            } catch (_: Throwable) {}
            try { Thread.sleep(700) } catch (_: InterruptedException) {}
            System.gc()
            try { Thread.sleep(300) } catch (_: InterruptedException) {}
            val after = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.availMem
            val freed = if (after > before) after - before else 0L
            val o = JSONObject()
            o.put("before", before).put("after", after).put("freed", freed).put("killed", killed)
            return o.toString()
        }

        private val DANGEROUS = mapOf(
            "android.permission.RECORD_AUDIO" to "میکروفن",
            "android.permission.CAMERA" to "دوربین",
            "android.permission.SEND_SMS" to "ارسال پیامک",
            "android.permission.READ_SMS" to "خواندن پیامک",
            "android.permission.RECEIVE_SMS" to "دریافت پیامک",
            "android.permission.READ_CONTACTS" to "مخاطبین",
            "android.permission.READ_PHONE_STATE" to "اطلاعات تماس/سیم‌کارت",
            "android.permission.ACCESS_FINE_LOCATION" to "موقعیت دقیق",
            "android.permission.READ_CALL_LOG" to "گزارش تماس‌ها",
            "android.permission.BODY_SENSORS" to "سنسورهای بدن",
            "android.permission.WRITE_EXTERNAL_STORAGE" to "نوشتن فایل‌ها"
        )
        private val SUSPICIOUS = Regex("spy|track|hack|keylog|sms|loan|_predict|steal|monitor|record.call", RegexOption.IGNORE_CASE)

        @Suppress("DEPRECATION")
        fun apps(ctx: Context, onlyPkg: String?): String {
            val pm = ctx.packageManager
            val flags = PackageManager.GET_PERMISSIONS
            val pis: List<PackageInfo> = try {
                if (Build.VERSION.SDK_INT >= 33) {
                    pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(flags.toLong()))
                } else {
                    pm.getInstalledPackages(flags)
                }
            } catch (_: Throwable) { emptyList() }
            val now = System.currentTimeMillis()
            val risky = JSONArray()
            var newN = 0
            var count = 0
            for (pi in pis) {
                val ai = pi.applicationInfo ?: continue
                if (onlyPkg != null) {
                    if (pi.packageName != onlyPkg) continue
                } else {
                    if (ai.flags and ApplicationInfo.FLAG_SYSTEM != 0) continue
                }
                count++
                val age = now - (pi.firstInstallTime ?: 0)
                if (age <= 14L * 24 * 3600 * 1000) newN++
                val perms = (pi.requestedPermissions ?: emptyArray())
                    .mapNotNull { DANGEROUS[it] }
                var side = false
                try {
                    /* v1.25.45 — فیلد قدیمی «installerPackageName» از android.jarهای جدید حذف شده
                       و بیلد را می‌شکند (Unresolved reference)؛ جایگزین رسمی‌اش
                       getInstallSourceInfo است (اندروید ۱۱+). روی اندرویدهای قدیمی‌تر
                       NoSuchMethodError هم مثل بقیهٔ خطاها همین‌جا بی‌صدا گرفته می‌شود. */
                    val src = pm.getInstallSourceInfo(pi.packageName)
                        .installingPackageName ?: ""
                    side = src != "com.android.vending" && src.isNotBlank()
                } catch (_: Throwable) {}
                val label = try { pm.getApplicationLabel(ai).toString() } catch (_: Throwable) { pi.packageName }
                var score = 0
                val why = ArrayList<String>()
                if (side) { score += 30; why.add("نصب‌شده از بیرون فروشگاه") }
                if (perms.isNotEmpty()) { score += 15 * perms.size; why.add("دسترسی: " + perms.joinToString("، ")) }
                if (SUSPICIOUS.containsMatchIn(label + " " + pi.packageName)) { score += 25; why.add("نام مشکوک") }
                if (perms.contains("خواندن پیامک") && perms.contains("مخاطبین")) { score += 20; why.add("ترکیب خطرناک پیامک+مخاطبین") }
                if (score >= 40 || onlyPkg != null) {
                    risky.put(JSONObject()
                        .put("name", label)
                        .put("pkg", pi.packageName)
                        .put("score", Math.min(99, score))
                        .put("side", side)
                        .put("why", JSONArray(why)))
                }
            }
            // نزولی بر اساس خطر
            val arr = JSONArray()
            val items = (0 until risky.length()).map { risky.getJSONObject(it) }
                .sortedByDescending { it.optInt("score", 0) }
            items.forEach { arr.put(it) }
            val o = JSONObject()
            o.put("count", count).put("riskyN", if (onlyPkg != null) 0 else arr.length())
                .put("newN", newN).put("risky", arr)
            return o.toString()
        }

        private fun dirSize(d: File, budget: LongArray): Long {
            var sz = 0L
            val fs = try { d.listFiles() ?: return 0 } catch (_: Throwable) { return 0 }
            for (f in fs) {
                if (budget[0] <= 0) break
                budget[0] -= 1
                try {
                    if (f.isDirectory) sz += dirSize(f, budget) else sz += f.length()
                } catch (_: Throwable) {}
            }
            return sz
        }

        fun files(ctx: Context): String {
            val o = JSONObject()
            val apk = JSONArray()
            var apkCount = 0
            var needPerm = false
            var junk = 0L
            var total = 0L
            var free = 0L
            val caches = JSONArray()
            // کش‌های خود اپ — بدون هیچ مجوزی
            for (c in listOf(ctx.cacheDir, ctx.externalCacheDir)) {
                if (c == null) continue
                val s = dirSize(c, longArrayOf(4000))
                junk += s
                caches.put(JSONObject().put("path", c.absolutePath).put("size", s))
            }
            try {
                val canAll = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else true
                if (!canAll) {
                    needPerm = true
                } else {
                    val root = Environment.getExternalStorageDirectory()
                    val st = android.os.StatFs(root.absolutePath)
                    total = st.totalBytes
                    free = st.availableBytes
                    // پیمایش محدود: تا ۳ سطح + Download/Bluetooth، سقف ۶۰۰۰ فایل
                    val budget = longArrayOf(6000)
                    val scan = ArrayDeque<File>()
                    scan.add(root)
                    var depth = 0
                    while (scan.isNotEmpty() && depth < 3 && budget[0] > 0) {
                        val n = scan.size
                        repeat(n) {
                            val d = scan.removeFirst() ?: return@repeat
                            val fs = try { d.listFiles() ?: return@repeat } catch (_: Throwable) { return@repeat }
                            for (f in fs) {
                                if (budget[0] <= 0) break
                                budget[0] -= 1
                                try {
                                    if (f.isDirectory) scan.add(f)
                                    else if (f.name.endsWith(".apk", true)) {
                                        apkCount++
                                        if (apk.length() < 12) apk.put(JSONObject().put("path", f.absolutePath).put("size", f.length()))
                                    } else if (f.name.equals("LOST.DIR", true)) {
                                        junk += f.length()
                                    }
                                } catch (_: Throwable) {}
                            }
                        }
                        depth++
                    }
                }
            } catch (_: Throwable) { needPerm = true }
            o.put("apk", apk).put("apkCount", apkCount)
            o.put("junk", junk).put("caches", caches)
            o.put("total", total).put("free", free).put("needPerm", needPerm)
            return o.toString()
        }

        fun cleanFiles(ctx: Context): String {
            var freed = 0L
            for (c in listOf(ctx.cacheDir, ctx.externalCacheDir)) {
                if (c == null) continue
                val fs = try { c.listFiles() ?: continue } catch (_: Throwable) { continue }
                for (f in fs) {
                    try {
                        val sz = if (f.isDirectory) dirSize(f, longArrayOf(4000)) else f.length()
                        val ok = if (f.isDirectory) f.deleteRecursively() else f.delete()
                        if (ok) freed += sz
                    } catch (_: Throwable) {}
                }
            }
            val o = JSONObject()
            o.put("freed", freed)
            return o.toString()
        }

        fun lastPkg(ctx: Context): String {
            val o = JSONObject()
            o.put("pkg", lastAdded ?: "")
            o.put("at", lastAddedAt)
            return o.toString()
        }
    }
}

package com.panels.panels_manager

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.DownloadManager
import android.app.KeyguardManager
import android.app.admin.DevicePolicyManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.media.MediaRecorder
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Environment
import android.os.Process
import android.os.SystemClock
import android.provider.Settings
import android.util.Base64
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.webkit.WebView
import com.therealaleph.mhrv.CaInstall
import com.therealaleph.mhrv.DnsProbe
import com.therealaleph.mhrv.MhrvVpnService
import com.therealaleph.mhrv.Native
import com.therealaleph.mhrv.ShkVpnService
import com.therealaleph.mhrv.SlipVpnService
import com.therealaleph.mhrv.TorVpnService
import com.therealaleph.mhrv.VpnState
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.math.BigInteger
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.net.ssl.HttpsURLConnection

/**
 * Flutter host activity + a small MethodChannel ("mhrv") that drives the
 * embedded mhrv-rs engine (Rust core via JNI + VpnService) plus the
 * SlipNet (DNS/SSH tunnel) and Tor (Arti) engines.
 *
 * v1.14: تب‌های وارپ و DNS-VPN حذف شدند — موتورهای WarpVpnService و
 * DnsVpnService به‌طور کامل از APK حذف شده‌اند. جای آن‌ها SlipNet و Tor.
 *
 * v1.25.17: فیکس «برنامه مدام متوقف می‌شود» — بخش ۱ (این فایل): ضبطِ کرش.
 * هر استثنای مدیریت‌نشده در هر رشتهٔ پروسهٔ اصلی قبل از مرگ در فایل ذخیره می‌شود
 * (۳ فایل آخر نگه داشته می‌شود) و از داخل برنامه هم قابل دیدن/کپی/حذف است —
 * این‌طوری هر کرش بعدی دیگر «ناشناخته» نیست؛ کاربر فقط از داخل اپ متن خطا را می‌فرستد.
 * ریشهٔ اصلی کرش در پلاگین flutter_v2ray بود (intent تهی در ری‌استارت + نبود
 * foregroundServiceType در اندروید ۱۴+) — پچ آن در ci/run.sh و AndroidManifest است.
 */
class MainActivity : FlutterActivity() {

    private var pendingStart: MethodChannel.Result? = null
    private var pendingShare: String? = null
    /* v1.26.0 — نتیجهٔ معلق اجازهٔ میکروفن (ضبط صدا برای شناسایی موسیقی) */
    private var pendingMic: MethodChannel.Result? = null
    private val dlMap = java.util.concurrent.ConcurrentHashMap<String, Long>()
    private val micOps = java.util.concurrent.ConcurrentLinkedQueue<JSONObject>()
    @Volatile private var micReg = false

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, i: Intent) {
            try {
                if (i.action != Intent.ACTION_PACKAGE_ADDED) return
                if (i.getBooleanExtra(Intent.EXTRA_REPLACING, false)) return
                val p = i.data?.schemeSpecificPart ?: return
                SecEngine.lastAdded = p
                SecEngine.lastAddedAt = System.currentTimeMillis()
            } catch (_: Throwable) {}
        }
    }

    private fun handleShareIntent(i: Intent?) {
        try {
            if (i == null) return
            val text = when (i.action) {
                Intent.ACTION_SEND -> i.getStringExtra(Intent.EXTRA_TEXT)
                Intent.ACTION_VIEW -> i.data?.toString()
                else -> null
            } ?: return
            if (text.isNotBlank()) pendingShare = text.trim()
        } catch (_: Throwable) {}
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        setIntent(i)
        handleShareIntent(i)
    }
    private var pendingSlip: MethodChannel.Result? = null
    private var pendingTor: MethodChannel.Result? = null
    private var pendingShk: MethodChannel.Result? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        CrashCatcher.install(this)
        SecEngine.init(this)
        try {
            // v1.25.36 — «برنامهٔ جدید نصب شد» برای سپر امنیت (ثبت در زمان اجرا؛ مجوزی لازم ندارد)
            val f = IntentFilter(Intent.ACTION_PACKAGE_ADDED)
            f.addDataScheme("package")
            registerReceiver(pkgReceiver, f)
        } catch (_: Throwable) {}
        handleShareIntent(intent)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "mhrv")
            .setMethodCallHandler { call, result ->
                try {
                    when (call.method) {
                        "init" -> {
                            Native.setDataDir(filesDir.absolutePath)
                            result.success(Native.version())
                        }
                        "start" -> start(call.argument<String>("config") ?: "", result)
                        "stop" -> {
                            startService(
                                Intent(this, MhrvVpnService::class.java)
                                    .setAction(MhrvVpnService.ACTION_STOP)
                            )
                            result.success(true)
                        }
                        "dnsProbe" -> {
                            // پینگ واقعی DNS (کوئری UDP/53) برای چند IP به‌صورت موازی
                            val ips = (call.argument<List<String>>("ips") ?: emptyList())
                                .map { it.trim() }.filter { it.isNotEmpty() }.take(20)
                            Thread {
                                val arr = JSONArray()
                                val ths = ips.map { ip ->
                                    Thread {
                                        val ms = DnsProbe.probe(ip)
                                        synchronized(arr) {
                                            arr.put(JSONObject().put("ip", ip).put("ms", ms))
                                        }
                                    }
                                }
                                ths.forEach { it.start() }
                                ths.forEach { it.join(5000) }
                                runOnUiThread { result.success(arr.toString()) }
                            }.start()
                        }
                        "slipStart" -> slipStart(
                            call.argument<String>("uri") ?: "",
                            call.argument<String>("dns") ?: "",
                            result
                        )
                        "slipStop" -> {
                            startService(
                                Intent(this, SlipVpnService::class.java)
                                    .setAction(SlipVpnService.ACTION_STOP)
                            )
                            result.success(true)
                        }
                        "slipStatus" -> result.success(SlipVpnService.snapshot())
                        "torStart" -> torStart(call.argument<String>("bridges") ?: "", result)
                        "torStop" -> {
                            startService(
                                Intent(this, TorVpnService::class.java)
                                    .setAction(TorVpnService.ACTION_STOP)
                            )
                            result.success(true)
                        }
                        "torStatus" -> result.success(TorVpnService.snapshot())
                        "shkStart" -> { ShkVpnService.region = (call.argument<String>("region") ?: "").trim(); shkStart(result) }
                        "shkStop" -> {
                            startService(
                                Intent(this, ShkVpnService::class.java)
                                    .setAction(ShkVpnService.ACTION_STOP)
                            )
                            result.success(true)
                        }
                        "shkStatus" -> result.success(ShkVpnService.snapshot())
                        "engineInfo" -> {
                            // v1.24.4: تب‌ها قبل از زدن «وصل» بدانند موتور واقعاً داخل
                            // APK هست یا نه — دیگر بعد از لمسِ دکمه غافلگیر نمی‌شویم.
                            val o = JSONObject()
                            val nd = applicationInfo.nativeLibraryDir
                            fun has(name: String) = java.io.File(nd, name).exists()
                            o.put("slip", has(SlipVpnService.LIB))
                            o.put("tor", has(TorVpnService.LIB))
                            o.put("shk", has(ShkVpnService.LIB))
                            o.put("obfs4", has("libobfs4.so"))
                            o.put("tun2proxy", has("libtun2proxy.so"))
                            result.success(o.toString())
                        }
                        "status" -> {
                            val o = JSONObject()
                            o.put("running", VpnState.isRunning)
                            val h = VpnState.proxyHandle
                            o.put("stats", if (h != 0L) Native.statsJson(h) else "")
                            o.put("logs", Native.drainLogs())
                            result.success(o.toString())
                        }
                        "caInfo" -> {
                            Native.setDataDir(filesDir.absolutePath)
                            val ok = CaInstall.export(this)
                            val fp = if (ok) CaInstall.fingerprint(this) else null
                            val o = JSONObject()
                            o.put("exists", ok)
                            o.put("installed", fp != null && CaInstall.isInstalled(fp))
                            o.put("fingerprint", if (fp != null) CaInstall.fingerprintHex(fp) else "")
                            result.success(o.toString())
                        }
                        "caInstall" -> {
                            Native.setDataDir(filesDir.absolutePath)
                            val ok = CaInstall.export(this)
                            val saved = if (ok) CaInstall.saveToDownloads(this) else null
                            if (saved != null) {
                                startActivity(
                                    Intent(Settings.ACTION_SECURITY_SETTINGS)
                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            }
                            result.success(saved ?: "")
                        }
                        "kvSet" -> {
                            getSharedPreferences("pm_store", MODE_PRIVATE).edit()
                                .putString(call.argument<String>("k") ?: "", call.argument<String>("v") ?: "")
                                .apply()
                            result.success(true)
                        }
                        "kvDel" -> {
                            getSharedPreferences("pm_store", MODE_PRIVATE)
                                .edit().remove(call.argument<String>("k") ?: "").apply()
                            result.success(true)
                        }
                        "kvGet" -> result.success(
                            getSharedPreferences("pm_store", MODE_PRIVATE)
                                .getString(call.argument<String>("k") ?: "", null)
                        )
                        "crashGet" -> result.success(CrashCatcher.readLogs(this))
                        "crashClear" -> { CrashCatcher.clear(this); result.success(true) }
                        "sec" -> sec(call.arguments as? Map<*, *> ?: emptyMap<Any, Any>(), result)
                        "takeShare" -> {
                            val t = pendingShare
                            pendingShare = null
                            result.success(t ?: "")
                        }
                        "crashLog" -> {
                            // خطای سمت دارت (که پروسه را نمی‌کشد) هم ثبت می‌شود تا تشخیص کامل باشد
                            CrashCatcher.appendDart(
                                this,
                                (call.argument<String>("tag") ?: "dart") + ": " + (call.argument<String>("msg") ?: "")
                            )
                            result.success(true)
                        }
                        else -> result.notImplemented()
                    }
                } catch (t: Throwable) {
                    result.error("mhrv", t.message ?: t.toString(), null)
                }
            }
    }

    private fun start(configJson: String, result: MethodChannel.Result) {
        if (configJson.isBlank()) { result.success("ERR:config خالیه"); return }
        getSharedPreferences(MhrvVpnService.PREFS, MODE_PRIVATE)
            .edit().putString(MhrvVpnService.KEY_CONFIG, configJson).apply()
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        }
        Thread {
            stopEnginesAndWait(stopMhrv = true, stopSlip = true, stopTor = true, stopShk = true)
            runOnUiThread {
                val prep = VpnService.prepare(this)
                if (prep != null) {
                    pendingStart?.success("ERR:درخواست قبلی لغو شد")
                    pendingStart = result
                    startActivityForResult(prep, REQ_VPN)
                } else {
                    launchService()
                    result.success("OK")
                }
            }
        }.start()
    }

    private fun launchService() {
        val i = Intent(this, MhrvVpnService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
    }

    /**
     * فقط یک VPN همزمان — همهٔ موتورهای خودمان را می‌بندد و تا آزاد شدن واقعی
     * اسلات صبر می‌کند.
     */
    private fun stopEnginesAndWait(stopMhrv: Boolean, stopSlip: Boolean, stopTor: Boolean, stopShk: Boolean) {
        if (stopMhrv && VpnState.isRunning) {
            startService(Intent(this, MhrvVpnService::class.java).setAction(MhrvVpnService.ACTION_STOP))
        }
        if (stopSlip && SlipVpnService.running) {
            startService(Intent(this, SlipVpnService::class.java).setAction(SlipVpnService.ACTION_STOP))
        }
        if (stopTor && TorVpnService.running) {
            startService(Intent(this, TorVpnService::class.java).setAction(TorVpnService.ACTION_STOP))
        }
        if (stopShk && ShkVpnService.running) {
            startService(Intent(this, ShkVpnService::class.java).setAction(ShkVpnService.ACTION_STOP))
        }
        val t0 = SystemClock.elapsedRealtime()
        while (SystemClock.elapsedRealtime() - t0 < 9000) {
            if (!VpnState.isRunning && !SlipVpnService.running && !TorVpnService.running && !ShkVpnService.running) {
                // کمی فرصت بعد از فلگ تا TUN واقعاً در کرنل آزاد شود
                try { Thread.sleep(300) } catch (_: InterruptedException) {}
                return
            }
            try { Thread.sleep(150) } catch (_: InterruptedException) { return }
        }
    }

    /**
     * SlipNet engine start. Android has a single VPN slot, so every other
     * engine we own is switched off first and we WAIT for the slot to be
     * released. Heavy work off the UI thread, ONE consent dialog, then
     * startForegroundService.
     */
    private fun slipStart(uri: String, dns: String, result: MethodChannel.Result) {
        if (uri.isBlank()) { result.success("ERR:پروفایل SlipNet خالی است"); return }
        Thread {
            stopEnginesAndWait(stopMhrv = true, stopSlip = true, stopTor = true, stopShk = true)
            getSharedPreferences(SlipVpnService.PREFS, MODE_PRIVATE).edit()
                .putString(SlipVpnService.KEY_URI, uri)
                .putString(SlipVpnService.KEY_DNS, dns)
                .apply()
            runOnUiThread {
                val prep = VpnService.prepare(this)
                if (prep != null) {
                    pendingSlip?.success("ERR:درخواست قبلی لغو شد")
                    pendingSlip = result
                    startActivityForResult(prep, REQ_VPN_SLIP)
                } else {
                    launchSlipService()
                    result.success("OK")
                }
            }
        }.start()
    }

    private fun torStart(bridges: String, result: MethodChannel.Result) {
        Thread {
            stopEnginesAndWait(stopMhrv = true, stopSlip = true, stopTor = true, stopShk = true)
            getSharedPreferences(TorVpnService.PREFS, MODE_PRIVATE).edit()
                .putString(TorVpnService.KEY_BRIDGES, bridges)
                .apply()
            runOnUiThread {
                val prep = VpnService.prepare(this)
                if (prep != null) {
                    pendingTor?.success("ERR:درخواست قبلی لغو شد")
                    pendingTor = result
                    startActivityForResult(prep, REQ_VPN_TOR)
                } else {
                    launchTorService()
                    result.success("OK")
                }
            }
        }.start()
    }

    /**
     * موتور سایفون (Psiphon داخل اپ) — همان الگوی Tor: صفر کانفیگ،
     * کلید VPN، یک پنجرهٔ اجازه، بعد سرویس foreground.
     */
    private fun shkStart(result: MethodChannel.Result) {
        Thread {
            stopEnginesAndWait(stopMhrv = true, stopSlip = true, stopTor = true, stopShk = true)
            runOnUiThread {
                val prep = VpnService.prepare(this)
                if (prep != null) {
                    pendingShk?.success("ERR:درخواست قبلی لغو شد")
                    pendingShk = result
                    startActivityForResult(prep, REQ_VPN_SHK)
                } else {
                    launchShkService()
                    result.success("OK")
                }
            }
        }.start()
    }

    private fun launchSlipService() {
        val i = Intent(this, SlipVpnService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
    }

    private fun launchTorService() {
        val i = Intent(this, TorVpnService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
    }

    private fun launchShkService() {
        val i = Intent(this, ShkVpnService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQ_VPN) {
            val r = pendingStart
            pendingStart = null
            if (resultCode == Activity.RESULT_OK) {
                launchService()
                r?.success("OK")
            } else {
                r?.success("ERR:مجوز VPN داده نشد")
            }
            return
        }
        if (requestCode == REQ_VPN_SLIP) {
            val r = pendingSlip
            pendingSlip = null
            if (resultCode == Activity.RESULT_OK) {
                launchSlipService()
                r?.success("OK")
            } else {
                r?.success("ERR:مجوز VPN داده نشد")
            }
            return
        }
        if (requestCode == REQ_VPN_TOR) {
            val r = pendingTor
            pendingTor = null
            if (resultCode == Activity.RESULT_OK) {
                launchTorService()
                r?.success("OK")
            } else {
                r?.success("ERR:مجوز VPN داده نشد")
            }
            return
        }
        if (requestCode == REQ_VPN_SHK) {
            val r = pendingShk
            pendingShk = null
            if (resultCode == Activity.RESULT_OK) {
                launchShkService()
                r?.success("OK")
            } else {
                r?.success("ERR:مجوز VPN داده نشد")
            }
            return
        }
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
    }

    /**
     * v1.25.36 — موتور مرکز امنیت (سپر): رم، پاکسازی، اسکن برنامه‌ها، اسکن فایل‌ها،
     * برنامه‌های جدید. صداقت: پاکسازی رم = بستن پردازش‌های «کش‌شده» (همان کاری که
     * اندروید مجاز است) + اندازه‌گیری واقعی قبل/بعد؛ اسکن فایل‌ها بدون اجازهٔ
     * «همهٔ فایل‌ها» فقط کش‌های خود اپ را حساب می‌کند (needPerm=true برمی‌گردد).
     */
    private fun sec(args: Map<*, *>, result: MethodChannel.Result) {
        val op = (args["op"] as? String) ?: ""
        /* v1.26.0 — اجازهٔ میکروفن: باید روی رشتهٔ UI درخواست شود؛ نتیجهٔ واقعی
           بعداً در onRequestPermissionsResult برمی‌گردد */
        if (op == "micPerm") {
            val granted = try {
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            } catch (_: Throwable) { false }
            if (granted) { result.success("{\"granted\":1}"); return }
            pendingMic = result
            runOnUiThread {
                try { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC) }
                catch (t: Throwable) {
                    val r = pendingMic; pendingMic = null
                    r?.success("{\"granted\":0,\"err\":\"" + (t.message ?: "perm").take(120) + "\"}")
                }
            }
            return
        }
        Thread {
            val out: String = try {
                when (op) {
                    "mem" -> SecEngine.mem(this)
                    "clean" -> SecEngine.clean(this)
                    "apps" -> SecEngine.apps(this, args["pkg"] as? String)
                    "files" -> SecEngine.files(this)
                    "cleanfiles" -> SecEngine.cleanFiles(this)
                    "lastPkg" -> SecEngine.lastPkg(this)
                    /* v1.26.0 — سپر حرفه‌ای + رسانه: همه با API استاندارد اندروید */
                    /* v1.26.2 — نام‌های «dev» و «wbc» از سمت JS با نام‌های قدیمی می‌آمدند و
                       «unknown op» برمی‌گشت (ریشهٔ «–»های کارت سلامت دستگاه) — هر دو نام مجاز شد */
                    "dev", "devInfo" -> SecEngine.devInfo(this)
                    "micwatch" -> SecEngine.micWatch(this, micOps, { micReg }, { micReg = it })
                    "wbc", "wbClean" -> SecEngine.wbClean(this, args["cookies"] == true)
                    "dlAdd" -> SecEngine.dlAdd(this, args, dlMap)
                    "dlQ" -> SecEngine.dlQ(this, args, dlMap)
                    "dlCancel" -> SecEngine.dlCancel(this, args, dlMap)
                    "mrecStart" -> SecEngine.mrecStart(this, args)
                    "mrecStop" -> SecEngine.mrecStop()
                    /* اسکن دستکاری DNS + واکشی نسخه */
                    "dnsCheck" -> SecEngine.dnsCheck()
                    "updFetch" -> SecEngine.updFetch(args)
                    else -> "{\"err\":\"unknown op\"}"
                }
            } catch (t: Throwable) {
                "{\"err\":\"" + (t.message ?: t.toString()).take(200) + "\"}"
            }
            runOnUiThread { result.success(out) }
        }.start()
    }

    /* v1.26.0 — نتیجهٔ مجوز میکروفن → جاوااسکریپت */
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_MIC) {
            val r = pendingMic; pendingMic = null
            val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            r?.success("{\"granted\":" + (if (ok) "1" else "0") + "}")
        }
    }

    companion object {
        private const val REQ_VPN = 4711
        private const val REQ_VPN_SLIP = 4717
        private const val REQ_VPN_TOR = 4719
        private const val REQ_VPN_SHK = 4723
        private const val REQ_MIC = 4729
    }

    /**
     * v1.25.17 — ضبط‌کنندهٔ کرش پروسهٔ اصلی.
     * استثنای مدیریت‌نشده → فایل crash-N.log (چرخشی، آخرین ۳ تا) → بعد به هندلر پیش‌فرض
     * سپرده می‌شود (رفتار سیستم دست نمی‌خورد). لاگ‌ها از داخل اپ (متد crashGet) خوانده
     * می‌شوند و کاربر می‌تواند متنش را برای ما بفرستد — دیگر هیچ کرش ناشناخته‌ای نمی‌ماند.
     */
    object CrashCatcher {
        private const val MAX_FILES = 3
        private const val MAX_DART_BYTES = 64 * 1024

        fun install(ctx: Context) {
            val prev = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler { t, e ->
                try { write(ctx, t, e) } catch (_: Throwable) {}
                prev?.uncaughtException(t, e)
            }
        }

        private fun shift(ctx: Context) {
            for (i in MAX_FILES - 1 downTo 1) {
                val f = File(ctx.filesDir, "crash-$i.log")
                if (f.exists()) {
                    val n = File(ctx.filesDir, "crash-${i + 1}.log")
                    if (i == MAX_FILES - 1) f.delete() else f.renameTo(n)
                }
            }
        }

        private fun write(ctx: Context, t: Thread, e: Throwable) {
            shift(ctx)
            val sw = StringWriter()
            e.printStackTrace(PrintWriter(sw))
            val ver = try {
                ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "?"
            } catch (_: Throwable) { "?" }
            val sb = StringBuilder()
            sb.append("== CRASH ")
                .append(SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()))
                .append(" · v").append(ver)
                .append(" · ").append(Build.MANUFACTURER).append(" ").append(Build.MODEL)
                .append(" · API ").append(Build.VERSION.SDK_INT)
                .append(" · thread=").append(t.name).append('\n')
            sb.append(sw.toString())
            try {
                sb.append("-- engine state --\n")
                sb.append("mhrv.running=").append(VpnState.isRunning).append('\n')
                sb.append("slip=").append(SlipVpnService.running)
                    .append(" tor=").append(TorVpnService.running)
                    .append(" shk=").append(ShkVpnService.running).append('\n')
                sb.append("slip.stage=").append(SlipVpnService.stageText).append('\n')
                sb.append("shk.stage=").append(ShkVpnService.stageText).append('\n')
                sb.append("tor.stage=").append(TorVpnService.stageText).append('\n')
            } catch (_: Throwable) {}
            try {
                File(ctx.filesDir, "crash-1.log").writeText(sb.toString())
            } catch (_: Throwable) {}
        }

        /** خروجی: JSON {"logs": متن، "count": تعداد فایل‌های حاضر} — از تازه به کهنه. */
        fun readLogs(ctx: Context): String {
            val o = JSONObject()
            var count = 0
            val sb = StringBuilder()
            for (i in 1..MAX_FILES) {
                val f = File(ctx.filesDir, "crash-$i.log")
                if (!f.exists()) continue
                count++
                if (sb.isNotEmpty()) sb.append("\n\n----------------\n\n")
                sb.append(f.readText())
                if (sb.length > 12000) { sb.setLength(12000); sb.append("\n… (بریده شد)"); break }
            }
            val dart = File(ctx.filesDir, "crash-dart.log")
            if (dart.exists()) {
                try {
                    val dt = dart.readText()
                    if (dt.isNotBlank()) {
                        sb.append("\n\n== خطاهای دارت ==\n").append(dt.take(4000))
                    }
                } catch (_: Throwable) {}
            }
            if (sb.isEmpty()) sb.append("هیچ گزارش کرشی ثبت نشده — از آخرین نصب تا الان هیچ کرشی نداشته‌ایم.")
            o.put("logs", sb.toString())
            o.put("count", count)
            return o.toString()
        }

        fun clear(ctx: Context) {
            for (i in 1..MAX_FILES) { try { File(ctx.filesDir, "crash-$i.log").delete() } catch (_: Throwable) {} }
            try { File(ctx.filesDir, "crash-dart.log").delete() } catch (_: Throwable) {}
        }

        fun appendDart(ctx: Context, line: String) {
            try {
                val f = File(ctx.filesDir, "crash-dart.log")
                if (f.length() > MAX_DART_BYTES) f.writeText("")
                f.appendText(SimpleDateFormat("MM-dd HH:mm:ss ", Locale.US).format(Date()) + line.take(500) + "\n")
            } catch (_: Throwable) {}
        }
    }

    /**
     * v1.25.36 — مجموعهٔ ابزارهای مرکز امنیت. همهٔ خروجی‌ها JSON هستند و
     * فقط روی خود گوشی ساخته می‌شوند (هیچ داده‌ای جایی فرستاده نمی‌شود).
     */
    object SecEngine {
        var lastAdded: String? = null
        var lastAddedAt: Long = 0
        private var initialized = false

        fun init(ctx: Context) {
            if (initialized) return
            initialized = true
            try {
                val p = ctx.getSharedPreferences("pm_sec", Context.MODE_PRIVATE)
                lastAdded = p.getString("lastPkg", null)
                lastAddedAt = p.getLong("lastPkgAt", 0)
            } catch (_: Throwable) {}
        }

        private fun persist(ctx: Context) {
            try {
                ctx.getSharedPreferences("pm_sec", Context.MODE_PRIVATE).edit()
                    .putString("lastPkg", lastAdded ?: "")
                    .putLong("lastPkgAt", lastAddedAt)
                    .apply()
            } catch (_: Throwable) {}
        }

        fun mem(ctx: Context): String {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            val total = mi.totalMem
            val avail = mi.availMem
            val usedPct = if (total > 0) ((total - avail) * 100.0 / total) else 0.0
            val o = JSONObject()
            o.put("total", total).put("avail", avail)
            o.put("usedPct", Math.round(usedPct * 10) / 10.0)
            o.put("low", mi.lowMemory)
            o.put("threshold", mi.threshold)
            return o.toString()
        }

        @Suppress("DEPRECATION")
        fun clean(ctx: Context): String {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val before = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.availMem
            var killed = 0
            try {
                val pm = ctx.packageManager
                val launchables = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                val list = pm.queryIntentActivities(launchables, 0)
                val seen = HashSet<String>()
                for (ri in list) {
                    val pkg = ri.activityInfo?.packageName ?: continue
                    if (pkg == ctx.packageName || !seen.add(pkg)) continue
                    try {
                        am.killBackgroundProcesses(pkg)
                        killed++
                    } catch (_: Throwable) {}
                }
            } catch (_: Throwable) {}
            try { Thread.sleep(700) } catch (_: InterruptedException) {}
            System.gc()
            try { Thread.sleep(300) } catch (_: InterruptedException) {}
            val after = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.availMem
            val freed = if (after > before) after - before else 0L
            val o = JSONObject()
            o.put("before", before).put("after", after).put("freed", freed).put("killed", killed)
            return o.toString()
        }

        private val DANGEROUS = mapOf(
            "android.permission.RECORD_AUDIO" to "میکروفن",
            "android.permission.CAMERA" to "دوربین",
            "android.permission.SEND_SMS" to "ارسال پیامک",
            "android.permission.READ_SMS" to "خواندن پیامک",
            "android.permission.RECEIVE_SMS" to "دریافت پیامک",
            "android.permission.READ_CONTACTS" to "مخاطبین",
            "android.permission.READ_PHONE_STATE" to "اطلاعات تماس/سیم‌کارت",
            "android.permission.ACCESS_FINE_LOCATION" to "موقعیت دقیق",
            "android.permission.READ_CALL_LOG" to "گزارش تماس‌ها",
            "android.permission.BODY_SENSORS" to "سنسورهای بدن",
            "android.permission.WRITE_EXTERNAL_STORAGE" to "نوشتن فایل‌ها"
        )
        private val SUSPICIOUS = Regex("spy|track|hack|keylog|sms|loan|_predict|steal|monitor|record.call", RegexOption.IGNORE_CASE)

        @Suppress("DEPRECATION")
        fun apps(ctx: Context, onlyPkg: String?): String {
            val pm = ctx.packageManager
            val flags = PackageManager.GET_PERMISSIONS
            val pis: List<PackageInfo> = try {
                if (Build.VERSION.SDK_INT >= 33) {
                    pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(flags.toLong()))
                } else {
                    pm.getInstalledPackages(flags)
                }
            } catch (_: Throwable) { emptyList() }
            val now = System.currentTimeMillis()
            val risky = JSONArray()
            var newN = 0
            var count = 0
            for (pi in pis) {
                val ai = pi.applicationInfo ?: continue
                if (onlyPkg != null) {
                    if (pi.packageName != onlyPkg) continue
                } else {
                    if (ai.flags and ApplicationInfo.FLAG_SYSTEM != 0) continue
                }
                count++
                val age = now - (pi.firstInstallTime ?: 0)
                if (age <= 14L * 24 * 3600 * 1000) newN++
                val perms = (pi.requestedPermissions ?: emptyArray())
                    .mapNotNull { DANGEROUS[it] }
                var side = false
                try {
                    /* v1.25.45 — فیلد قدیمی «installerPackageName» از android.jarهای جدید حذف شده
                       و بیلد را می‌شکند (Unresolved reference)؛ جایگزین رسمی‌اش
                       getInstallSourceInfo است (اندروید ۱۱+). روی اندرویدهای قدیمی‌تر
                       NoSuchMethodError هم مثل بقیهٔ خطاها همین‌جا بی‌صدا گرفته می‌شود. */
                    val src = pm.getInstallSourceInfo(pi.packageName)
                        .installingPackageName ?: ""
                    side = src != "com.android.vending" && src.isNotBlank()
                } catch (_: Throwable) {}
                val label = try { pm.getApplicationLabel(ai).toString() } catch (_: Throwable) { pi.packageName }
                var score = 0
                val why = ArrayList<String>()
                if (side) { score += 30; why.add("نصب‌شده از بیرون فروشگاه") }
                if (perms.isNotEmpty()) { score += 15 * perms.size; why.add("دسترسی: " + perms.joinToString("، ")) }
                if (SUSPICIOUS.containsMatchIn(label + " " + pi.packageName)) { score += 25; why.add("نام مشکوک") }
                if (perms.contains("خواندن پیامک") && perms.contains("مخاطبین")) { score += 20; why.add("ترکیب خطرناک پیامک+مخاطبین") }
                if (score >= 40 || onlyPkg != null) {
                    risky.put(JSONObject()
                        .put("name", label)
                        .put("pkg", pi.packageName)
                        .put("score", Math.min(99, score))
                        .put("side", side)
                        .put("why", JSONArray(why)))
                }
            }
            // نزولی بر اساس خطر
            val arr = JSONArray()
            val items = (0 until risky.length()).map { risky.getJSONObject(it) }
                .sortedByDescending { it.optInt("score", 0) }
            items.forEach { arr.put(it) }
            val o = JSONObject()
            o.put("count", count).put("riskyN", if (onlyPkg != null) 0 else arr.length())
                .put("newN", newN).put("risky", arr)
            return o.toString()
        }

        private fun dirSize(d: File, budget: LongArray): Long {
            var sz = 0L
            val fs = try { d.listFiles() ?: return 0 } catch (_: Throwable) { return 0 }
            for (f in fs) {
                if (budget[0] <= 0) break
                budget[0] -= 1
                try {
                    if (f.isDirectory) sz += dirSize(f, budget) else sz += f.length()
                } catch (_: Throwable) {}
            }
            return sz
        }

        fun files(ctx: Context): String {
            val o = JSONObject()
            val apk = JSONArray()
            var apkCount = 0
            var needPerm = false
            var junk = 0L
            var total = 0L
            var free = 0L
            val caches = JSONArray()
            // کش‌های خود اپ — بدون هیچ مجوزی
            for (c in listOf(ctx.cacheDir, ctx.externalCacheDir)) {
                if (c == null) continue
                val s = dirSize(c, longArrayOf(4000))
                junk += s
                caches.put(JSONObject().put("path", c.absolutePath).put("size", s))
            }
            try {
                val canAll = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else true
                if (!canAll) {
                    needPerm = true
                } else {
                    val root = Environment.getExternalStorageDirectory()
                    val st = android.os.StatFs(root.absolutePath)
                    total = st.totalBytes
                    free = st.availableBytes
                    // پیمایش محدود: تا ۳ سطح + Download/Bluetooth، سقف ۶۰۰۰ فایل
                    val budget = longArrayOf(6000)
                    val scan = ArrayDeque<File>()
                    scan.add(root)
                    var depth = 0
                    while (scan.isNotEmpty() && depth < 3 && budget[0] > 0) {
                        val n = scan.size
                        repeat(n) {
                            val d = scan.removeFirst() ?: return@repeat
                            val fs = try { d.listFiles() ?: return@repeat } catch (_: Throwable) { return@repeat }
                            for (f in fs) {
                                if (budget[0] <= 0) break
                                budget[0] -= 1
                                try {
                                    if (f.isDirectory) scan.add(f)
                                    else if (f.name.endsWith(".apk", true)) {
                                        apkCount++
                                        if (apk.length() < 12) apk.put(JSONObject().put("path", f.absolutePath).put("size", f.length()))
                                    } else if (f.name.equals("LOST.DIR", true)) {
                                        junk += f.length()
                                    }
                                } catch (_: Throwable) {}
                            }
                        }
                        depth++
                    }
                }
            } catch (_: Throwable) { needPerm = true }
            o.put("apk", apk).put("apkCount", apkCount)
            o.put("junk", junk).put("caches", caches)
            o.put("total", total).put("free", free).put("needPerm", needPerm)
            return o.toString()
        }

        fun cleanFiles(ctx: Context): String {
            var freed = 0L
            for (c in listOf(ctx.cacheDir, ctx.externalCacheDir)) {
                if (c == null) continue
                val fs = try { c.listFiles() ?: continue } catch (_: Throwable) { continue }
                for (f in fs) {
                    try {
                        val sz = if (f.isDirectory) dirSize(f, longArrayOf(4000)) else f.length()
                        val ok = if (f.isDirectory) f.deleteRecursively() else f.delete()
                        if (ok) freed += sz
                    } catch (_: Throwable) {}
                }
            }
            val o = JSONObject()
            o.put("freed", freed)
            return o.toString()
        }

        fun lastPkg(ctx: Context): String {
            val o = JSONObject()
            o.put("pkg", lastAdded ?: "")
            o.put("at", lastAddedAt)
            return o.toString()
        }

        /* ═══════ v1.26.0 — قابلیت‌های واقعی سپر + رسانه (همه API استاندارد اندروید) ═══════ */

        private fun labelOf(ctx: Context, pkg: String): String = try {
            val ai = ctx.packageManager.getApplicationInfo(pkg, 0)
            (ctx.packageManager.getApplicationLabel(ai) ?: pkg).toString()
        } catch (_: Throwable) { pkg }

        /** سلامت دستگاه: قفل صفحه، رمزنگاری، پچ امنیتی، گزینه‌های توسعه، USB debugging،
         *  سرویس‌های دسترسی، شنونده‌های اعلان، ادمین‌های دستگاه، اجازهٔ نصب از منابع ناشناس. */
        fun devInfo(ctx: Context): String {
            val o = JSONObject()
            val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
            o.put("screenLock", try { km?.isDeviceSecure ?: false } catch (_: Throwable) { false })
            val dpm = try { ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager } catch (_: Throwable) { null }
            o.put("encrypted", try { (dpm?.storageEncryptionStatus ?: 0) >= DevicePolicyManager.ENCRYPTION_STATUS_ACTIVE } catch (_: Throwable) { false })
            o.put("patch", try { Build.VERSION.SECURITY_PATCH ?: "" } catch (_: Throwable) { "" })
            o.put("devOpts", try { Settings.Global.getInt(ctx.contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1 } catch (_: Throwable) { false })
            o.put("adb", try { Settings.Global.getInt(ctx.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1 } catch (_: Throwable) { false })
            o.put("pdns", try {
                val m = Settings.Global.getString(ctx.contentResolver, "private_dns_mode")
                val s = Settings.Global.getString(ctx.contentResolver, "private_dns_specifier")
                if (m == "off") "off" else if (m == "hostname" && !s.isNullOrBlank()) s else if (m == "opportunistic") "auto" else "?"
            } catch (_: Throwable) { "?" })
            val acc = JSONArray()
            try {
                val sv = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
                sv.split(':').filter { it.isNotBlank() }.forEach { c ->
                    val p = try { c.substringBefore('/').substringBefore('.') } catch (_: Throwable) { return@forEach }
                    acc.put(JSONObject().put("pkg", p).put("label", labelOf(ctx, p)).put("comp", c))
                }
            } catch (_: Throwable) {}
            val ntf = JSONArray()
            try {
                val sv = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners") ?: ""
                sv.split(':').filter { it.isNotBlank() }.forEach { c ->
                    val p = try { c.substringBefore('/').substringBefore('.') } catch (_: Throwable) { return@forEach }
                    ntf.put(JSONObject().put("pkg", p).put("label", labelOf(ctx, p)).put("comp", c))
                }
            } catch (_: Throwable) {}
            val adm = JSONArray()
            try { dpm?.activeAdmins?.forEach { a -> adm.put(JSONObject().put("pkg", a.packageName).put("label", labelOf(ctx, a.packageName))) } } catch (_: Throwable) {}
            val unk = JSONArray()
            try {
                if (Build.VERSION.SDK_INT >= 26) {
                    val am = ctx.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager
                    val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    val ris: List<ResolveInfo> = ctx.packageManager.queryIntentActivities(launch, 0)
                    val seen = HashSet<String>()
                    for (ri in ris) {
                        val p = ri.activityInfo.packageName
                        if (p == ctx.packageName || !seen.add(p)) continue
                        try {
                            val mode = am!!.checkOpNoThrow(AppOpsManager.permissionToOp(Manifest.permission.REQUEST_INSTALL_PACKAGES) ?: "android:request_install_packages",
                                ctx.packageManager.getApplicationInfo(p, 0).uid, p)
                            if (mode == AppOpsManager.MODE_ALLOWED) {
                                unk.put(JSONObject().put("pkg", p).put("label", labelOf(ctx, p)))
                                if (unk.length() >= 40) break
                            }
                        } catch (_: Throwable) {}
                    }
                }
            } catch (_: Throwable) {}
            o.put("acc", acc).put("ntf", ntf).put("adm", adm).put("unk", unk)
            return o.toString()
        }

        /** سپر میکروفن/دوربین: با AppOpsManager.startWatchingActive (API 29+، بدون مجوز خاص)
         *  هر اپی که همین حالا میکروفن/دوربین فعال دارد گزارش می‌شود؛ رویدادها در صف جمع و
         *  با هر فراخوانی تخلیه می‌شوند (صف و فلگ ثبت در اکتیویتی زندگی می‌کنند).
         *  v1.26.1 — فیکس بیلد: امضای واقعی SDK:
         *    startWatchingActive(String[] ops, Executor executor, OnOpActiveChangedListener cb)
         *  نسخهٔ دوپارامتری حذف شده است — Executor اجباری است (mainExecutor خود اپ،
         *  API 28+ و ما بالاتر از ۲۹ هستیم)؛ خود لیسنر (op, uid, pkg, active) بستهٔ واقعی
         *  نام بسته را می‌دهد و دست‌نخورده ماند. */
        fun micWatch(ctx: Context, q: java.util.concurrent.ConcurrentLinkedQueue<JSONObject>, isReg: () -> Boolean, setReg: (Boolean) -> Unit): String {
            if (Build.VERSION.SDK_INT < 29) return "{\"err\":\"api\",\"list\":[]}"
            val am = ctx.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager ?: return "{\"err\":\"noops\",\"list\":[]}"
            if (!isReg()) {
                try {
                    val ops = arrayOf(AppOpsManager.permissionToOp(Manifest.permission.RECORD_AUDIO),
                        AppOpsManager.permissionToOp(Manifest.permission.CAMERA)).filterNotNull().toTypedArray()
                    if (ops.isNotEmpty()) {
                        val l = AppOpsManager.OnOpActiveChangedListener { op, _, pkg, active ->
                            try {
                                if (active) {
                                    q.add(JSONObject().put("op", if (op.contains("microphone")) "mic" else "cam").put("pkg", pkg).put("ts", System.currentTimeMillis()))
                                    while (q.size > 40) q.poll()
                                }
                            } catch (_: Throwable) {}
                        }
                        am.startWatchingActive(ops, ctx.mainExecutor, l)
                        setReg(true)
                    }
                } catch (t: Throwable) {
                    return "{\"err\":\"reg\",\"m\":\"" + (t.message ?: "").take(80) + "\",\"list\":[]}"
                }
            }
            val arr = JSONArray()
            while (q.isNotEmpty()) {
                val j = q.poll() ?: break
                try { j.put("label", labelOf(ctx, j.optString("pkg"))); arr.put(j) } catch (_: Throwable) {}
            }
            return JSONObject().put("list", arr).put("reg", if (isReg()) 1 else 0).toString()
        }

        /** ردپای مرورگر داخلی: کش WebView همیشه؛ کوکی‌ها فقط با تأیید صریح کاربر (خروج از پنل‌ها). */
        fun wbClean(ctx: Context, cookiesToo: Boolean): String {
            var cache = false
            try { val wv = WebView(ctx); wv.clearCache(true); wv.destroy(); cache = true } catch (_: Throwable) {}
            var cookies = false
            if (cookiesToo) {
                try { CookieManager.getInstance().removeAllCookies(null); CookieManager.getInstance().flush(); cookies = true } catch (_: Throwable) {}
            }
            return JSONObject().put("cache", cache).put("cookies", cookies).toString()
        }

        /** دانلودر استاندارد: android.app.DownloadManager — دانلود در پس‌زمینهٔ سیستم،
         *  ذخیره در Downloads (MediaStore)، اعلان پیشرفت، ادامه از سمت سیستم. */
        fun dlAdd(ctx: Context, args: Map<*, *>, map: java.util.concurrent.ConcurrentHashMap<String, Long>): String {
            val id = (args["id"] as? String) ?: ""
            val url = (args["url"] as? String) ?: ""
            if (id.isEmpty() || url.isEmpty()) return "{\"err\":\"args\"}"
            val u = try { Uri.parse(url) } catch (_: Throwable) { return "{\"err\":\"url\"}" }
            val sch = u.scheme ?: ""
            if (sch != "http" && sch != "https") return "{\"err\":\"scheme\"}"
            var name = ((args["name"] as? String) ?: "").trim().ifEmpty { "download-" + System.currentTimeMillis() }
            name = name.replace(Regex("[\\\\/:*?\"<>|]"), "-").take(90)
            return try {
                val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                val req = DownloadManager.Request(u)
                req.setTitle(name).setDescription("Mlm VPN · رسانه")
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
                val mime = (args["mime"] as? String)?.trim()
                if (!mime.isNullOrEmpty()) req.setMimeType(mime)
                try { val ck = CookieManager.getInstance().getCookie(url); if (!ck.isNullOrBlank()) req.addRequestHeader("Cookie", ck) } catch (_: Throwable) {}
                try { val ua = System.getProperty("http.agent"); if (!ua.isNullOrBlank()) req.addRequestHeader("User-Agent", ua) } catch (_: Throwable) {}
                val dmid = dm.enqueue(req)
                map[id] = dmid
                JSONObject().put("ok", 1).put("dm", dmid).put("name", name).toString()
            } catch (t: Throwable) { "{\"err\":\"" + (t.message ?: "dl").take(160) + "\"}" }
        }

        fun dlQ(ctx: Context, args: Map<*, *>, map: java.util.concurrent.ConcurrentHashMap<String, Long>): String {
            val id = (args["id"] as? String) ?: ""
            val dmid = map[id] ?: return "{\"err\":\"none\"}"
            val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as? DownloadManager ?: return "{\"err\":\"nosvc\"}"
            val c = try { dm.query(DownloadManager.Query().setFilterById(dmid)) } catch (_: Throwable) { null }
                ?: return "{\"err\":\"query\"}"
            c.use {
                if (!it.moveToFirst()) return "{\"id\":\"" + id + "\",\"err\":\"gone\"}"
                fun ci(n: String): Int { return try { it.getColumnIndexOrThrow(n) } catch (_: Throwable) { -1 } }
                val st = if (ci(DownloadManager.COLUMN_STATUS) >= 0) it.getInt(ci(DownloadManager.COLUMN_STATUS)) else 0
                val bytes = if (ci(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR) >= 0) it.getLong(ci(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)) else 0L
                val total = if (ci(DownloadManager.COLUMN_TOTAL_SIZE_BYTES) >= 0) it.getLong(ci(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)) else 0L
                val reason = if (ci(DownloadManager.COLUMN_REASON) >= 0) it.getInt(ci(DownloadManager.COLUMN_REASON)) else 0
                val local = if (ci(DownloadManager.COLUMN_LOCAL_URI) >= 0) (it.getString(ci(DownloadManager.COLUMN_LOCAL_URI)) ?: "") else ""
                return JSONObject().put("id", id).put("status", st).put("bytes", bytes).put("total", total).put("reason", reason).put("path", local).toString()
            }
        }

        fun dlCancel(ctx: Context, args: Map<*, *>, map: java.util.concurrent.ConcurrentHashMap<String, Long>): String {
            val id = (args["id"] as? String) ?: ""
            val dmid = map.remove(id)
            if (dmid != null) {
                try { (ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).remove(dmid) } catch (_: Throwable) {}
            }
            return "{\"ok\":1}"
        }

        /** ضبط صدا با MediaRecorder (استاندارد اندروید) برای شناسایی موسیقی. */
        @Volatile private var rec: MediaRecorder? = null
        @Volatile private var recFile: File? = null

        fun mrecStart(ctx: Context, args: Map<*, *>): String {
            if (rec != null) return "{\"ok\":1,\"already\":1}"
            val granted = try {
                ctx.checkPermission(Manifest.permission.RECORD_AUDIO, Process.myPid(), Process.myUid()) == PackageManager.PERMISSION_GRANTED
            } catch (_: Throwable) { false }
            if (!granted) return "{\"needPerm\":1}"
            val secs = (((args["secs"] as? Number)?.toInt() ?: 10)).coerceIn(3, 18)
            val f = File(ctx.cacheDir, "pm-rec-" + System.currentTimeMillis() + ".m4a")
            val mr = MediaRecorder()
            try {
                mr.setAudioSource(MediaRecorder.AudioSource.MIC)
                mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                mr.setAudioEncodingBitRate(96000)
                mr.setAudioSamplingRate(44100)
                mr.setAudioChannels(1)
                mr.setOutputFile(f.absolutePath)
                mr.setMaxDuration(secs * 1000)
                mr.prepare()
                mr.start()
            } catch (t: Throwable) {
                try { mr.release() } catch (_: Throwable) {}
                try { f.delete() } catch (_: Throwable) {}
                return "{\"err\":\"rec\",\"m\":\"" + (t.message ?: "").take(120) + "\"}"
            }
            rec = mr; recFile = f
            return JSONObject().put("ok", 1).put("secs", secs).toString()
        }

        fun mrecStop(): String {
            val mr = rec; rec = null
            val f = recFile; recFile = null
            if (mr == null || f == null) return "{\"err\":\"no_rec\"}"
            try { mr.stop() } catch (_: Throwable) {}
            try { mr.release() } catch (_: Throwable) {}
            try {
                if (!f.exists() || f.length() < 512) { f.delete(); return "{\"err\":\"empty\"}" }
                if (f.length() > 1_600_000) { f.delete(); return "{\"err\":\"too_big\"}" }
                val bytes = f.readBytes()
                f.delete()
                return JSONObject().put("b64", Base64.encodeToString(bytes, Base64.NO_WRAP)).put("mime", "audio/mp4").put("bytes", bytes.size).toString()
            } catch (t: Throwable) { try { f.delete() } catch (_: Throwable) {}; return "{\"err\":\"read\"}" }
        }

        /* ═══════ v1.26.2 — وارپ واقعی · اسکن دستکاری DNS · واکشی نسخه (همه API استاندارد) ═══════ */

        /** درخواست HTTPS کوچک؛ cf=true فقط برای API رسمی کلادفلر (هدرهای رسمی اپ کلادفلر). */
        private fun httpReq(urlS: String, method: String, body: String?, cf: Boolean): Pair<Boolean, String> {
            val c = java.net.URL(urlS).openConnection() as HttpsURLConnection
            c.requestMethod = method
            c.connectTimeout = 15000; c.readTimeout = 15000
            c.setRequestProperty("Accept", "application/json")
            if (cf) {
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("User-Agent", "okhttp/3.12.1")
                c.setRequestProperty("CF-Client-Version", "a-6.10-2158")
            } else {
                c.setRequestProperty("User-Agent", "MlmVPN/1.26.2")
            }
            if (body != null) c.doOutput = true
            try {
                if (body != null) c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = c.responseCode
                val s = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
                return Pair(code in 200..299, s)
            } finally { try { c.disconnect() } catch (_: Throwable) {} }
        }

        private fun jsonErr(tag: String, m: String): String =
            "{\"err\":\"" + (tag + ": " + m).take(150).replace("\"", "'").replace("\n", " ") + "\"}"

        /** کوئری DNS خام (UDP/53، نوع A) — بدون هیچ کتابخانهٔ بیرونی. */
        private fun dnsQueryUdp(server: String, name: String, timeoutMs: Int): List<String> {
            val id = ByteArray(2).also { SecureRandom().nextBytes(it) }
            val q = ArrayList<Byte>()
            q.add(id[0]); q.add(id[1]); q.add(0x01); q.add(0x00)
            q.add(0); q.add(1); q.add(0); q.add(0); q.add(0); q.add(0); q.add(0); q.add(0)
            name.split('.').filter { it.isNotBlank() }.forEach { lb ->
                val b = lb.toByteArray(Charsets.US_ASCII)
                q.add(b.size.toByte()); for (c in b) q.add(c)
            }
            q.add(0); q.add(0); q.add(1); q.add(0); q.add(1)
            val out = ByteArray(q.size); q.forEachIndexed { i, v -> out[i] = v }
            DatagramSocket().use { so ->
                so.soTimeout = timeoutMs
                so.send(DatagramPacket(out, out.size, InetAddress.getByName(server), 53))
                val buf = ByteArray(1024)
                val pk = DatagramPacket(buf, buf.size)
                so.receive(pk)
                return dnsParseA(buf, pk.length)
            }
        }

        /** خواندن نام DNS با پشتیبانی فشرده‌سازی (پوینتر 0xC0). */
        private fun dnsName(buf: ByteArray, ptr0: Int): Int {
            var p = ptr0; var jumped = false; var end = p; var guard = 0
            while (guard++ < 64) {
                if (p >= buf.size) break
                val len = buf[p].toInt() and 0xff
                if (len == 0) { if (!jumped) end = p + 1; break }
                if (len and 0xc0 == 0xc0) {
                    if (p + 1 >= buf.size) break
                    val np = ((len and 0x3f) shl 8) or (buf[p + 1].toInt() and 0xff)
                    if (!jumped) end = p + 2
                    jumped = true; p = np; continue
                }
                p += len + 1
            }
            return end
        }

        /** استخراج رکوردهای A از پاسخ DNS. */
        private fun dnsParseA(buf: ByteArray, n: Int): List<String> {
            if (n < 12) return emptyList()
            val an = ((buf[6].toInt() and 0xff) shl 8) or (buf[7].toInt() and 0xff)
            var p = dnsName(buf, 12) + 4
            val ips = ArrayList<String>()
            for (i in 0 until an) {
                if (p >= n) break
                p = dnsName(buf, p)
                if (p + 10 > n) break
                val typ = ((buf[p].toInt() and 0xff) shl 8) or (buf[p + 1].toInt() and 0xff)
                val rdlen = ((buf[p + 8].toInt() and 0xff) shl 8) or (buf[p + 9].toInt() and 0xff)
                val rd = p + 10
                if (typ == 1 && rdlen == 4 && rd + 4 <= n) {
                    ips.add((buf[rd].toInt() and 0xff).toString() + "." + (buf[rd + 1].toInt() and 0xff) + "." +
                            (buf[rd + 2].toInt() and 0xff) + "." + (buf[rd + 3].toInt() and 0xff))
                }
                p = rd + rdlen
            }
            return ips
        }

        private fun dnsDoh(name: String): List<String> {
            val u = "https://cloudflare-dns.com/dns-query?name=" + java.net.URLEncoder.encode(name, "UTF-8") + "&type=A"
            val r = try { httpReq(u, "GET", null, false) } catch (_: Throwable) { return emptyList() }
            if (!r.first) return emptyList()
            return try {
                val ans = JSONObject(r.second).optJSONArray("Answer") ?: return emptyList()
                val out = ArrayList<String>()
                for (i in 0 until ans.length()) {
                    val a = ans.getJSONObject(i)
                    if (a.optInt("type") == 1) out.add(a.optString("data"))
                }
                out
            } catch (_: Throwable) { emptyList() }
        }

        /**
         * اسکن دستکاری DNS (سپر DNS): برای چند دامنه، جواب UDP/53 از 8.8.8.8 با جواب رمزشدهٔ
         * DoH کلادفلر مقایسه می‌شود. نشانه‌های فیلتر: 10.10.34.x (صفحهٔ مسدودی)، 0.0.0.0/127.0.0.1،
         * یا جواب خالی UDP در حالی که DoH جواب دارد. فرق IPهای CDN فیلتر نیست (سرویس درست است).
         */
        fun dnsCheck(): String {
            val names = arrayOf("youtube.com", "x.com", "example.com")
            val rows = JSONArray()
            var hijack = 0
            for (nm in names) {
                val udp = try { dnsQueryUdp("8.8.8.8", nm, 4000) } catch (_: Throwable) { emptyList() }
                val doh = try { dnsDoh(nm) } catch (_: Throwable) { emptyList() }
                val bad = udp.any { it.startsWith("10.10.34.") || it == "0.0.0.0" || it == "127.0.0.1" }
                        || (udp.isEmpty() && doh.isNotEmpty())
                if (bad) hijack = 1
                rows.put(JSONObject().put("name", nm)
                    .put("udp", JSONArray(udp.take(4)))
                    .put("doh", JSONArray(doh.take(4)))
                    .put("bad", if (bad) 1 else 0))
            }
            return JSONObject().put("hijack", hijack).put("rows", rows)
                .put("ts", System.currentTimeMillis()).toString()
        }

        /** واکشی سبک برای «سپر نسخهٔ برنامهٔ جدید» — فقط https، سقف ۶ کیلوبایت. */
        fun updFetch(args: Map<*, *>): String {
            val urlS = ((args["url"] as? String) ?: "").trim()
            if (!urlS.startsWith("https://")) return "{\"err\":\"https\"}"
            val r = try { httpReq(urlS, "GET", null, false) } catch (t: Throwable) { return jsonErr("fetch", t.message ?: "timeout") }
            return JSONObject().put("ok", if (r.first) 1 else 0)
                .put("body", if (r.first) r.second.take(6000) else "")
                .put("err", if (r.first) "" else r.second.take(140)).toString()
        }

    }
}

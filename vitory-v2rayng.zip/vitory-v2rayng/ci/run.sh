#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════
# v2rayNG + پنل‌ها (مدیریت پنل‌ها) — full APK build:
#   libhev-socks5-tunnel (NDK) + libv2ray.aar (Xray release)
#   + Rust cores (mhrv-rs, torbin/Arti) via cargo-ndk
#   + Go engines (SlipNet, obfs4proxy, Psiphon ConsoleClient)
#   + gradle assemblePlaystoreRelease (arm64-v8a)
# Everything after tool setup lives here, so fixing the build never
# requires editing the GitHub workflow file.
# ═══════════════════════════════════════════════════════════════════
set -euo pipefail
cd "$(dirname "$0")/.."

NDK_VERSION="${ANDROID_NDK_VERSION:-28.2.13676358}"
ABI="arm64-v8a"
RUST_TARGET="aarch64-linux-android"
LIBS_DIR="$PWD/V2rayNG/app/libs/$ABI"

echo "::group::free disk space"
# The build is heavy (Rust core + Arti + SlipNet + NDK + Gradle). Removing
# unused runner toolchains frees ~25GB+ and fixes "No space left on device".
sudo rm -rf /usr/local/lib/android/sdk/ndk/* 2>/dev/null || true
sudo rm -rf /usr/local/lib/android/sdk/emulator 2>/dev/null || true
sudo rm -rf /usr/local/lib/android/sdk/system-images 2>/dev/null || true
sudo rm -rf /opt/hostedtoolcache/CodeQL 2>/dev/null || true
sudo rm -rf /usr/local/.ghcup /opt/ghc 2>/dev/null || true
sudo rm -rf /usr/share/dotnet 2>/dev/null || true
sudo rm -rf /usr/share/swift 2>/dev/null || true
sudo docker image prune -af >/dev/null 2>&1 || true
sudo apt-get clean 2>/dev/null || true
df -h / || true
echo "::endgroup::"

echo "::group::NDK + rust + cargo-ndk"
yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" "ndk;$NDK_VERSION" >/dev/null || true
export ANDROID_NDK_HOME="$ANDROID_HOME/ndk/$NDK_VERSION"
export NDK_HOME="$ANDROID_NDK_HOME"
rustup target add "$RUST_TARGET" 2>/dev/null || true
cargo install cargo-ndk --locked
mkdir -p "$LIBS_DIR"
echo "::endgroup::"

echo "::group::libhev-socks5-tunnel (NDK — v2rayNG native TUN)"
bash compile-hevtun.sh
# compile-hevtun.sh outputs repo-root libs/<abi>/ — same place the official
# workflow copies into V2rayNG/app/libs (jniLibs.srcDirs).
cp -r libs "$PWD/V2rayNG/app/" 2>/dev/null || true
test -f "$PWD/V2rayNG/app/libs/$ABI/libhev-socks5-tunnel.so"
echo "libhev-socks5-tunnel OK"
echo "::endgroup::"

echo "::group::libv2ray.aar (Xray core — official prebuilt release)"
AAR_OUT="$PWD/V2rayNG/app/libs/libv2ray.aar"
mkdir -p "$PWD/V2rayNG/app/libs"
curl -fsSL --retry 3 \
  "https://github.com/2dust/AndroidLibXrayLite/releases/latest/download/libv2ray.aar" \
  -o "$AAR_OUT"
test -s "$AAR_OUT"
echo "libv2ray.aar OK ($(stat -c%s "$AAR_OUT") bytes)"
echo "::endgroup::"

echo "::group::Rust core (mhrv-rs)"
(
  cd rust
  cargo ndk -t "$ABI" -o "$LIBS_DIR" build --release
)
H=$(ls -t "$LIBS_DIR"/libtun2proxy-*.so 2>/dev/null | head -1 || true)
if [ -n "$H" ]; then mv -f "$H" "$LIBS_DIR/libtun2proxy.so"; rm -f "$LIBS_DIR"/libtun2proxy-*.so; fi
test -f "$LIBS_DIR/libmhrv_rs.so"
echo "libmhrv_rs.so OK ($(stat -c%s "$LIBS_DIR/libmhrv_rs.so") bytes)"
echo "::endgroup::"

echo "::group::Tor engine (torbin/Arti)"
TORBIN_DIR="$PWD/rust/torbin"
TORBIN_OUT="$LIBS_DIR/libtorbin.so"
if [ ! -f "$TORBIN_DIR/Cargo.lock" ]; then
  echo "::error::rust/torbin/Cargo.lock missing — the dependency graph must stay frozen."
  exit 1
fi
if grep -q 'name = "openssl-sys"' "$TORBIN_DIR/Cargo.lock" 2>/dev/null \
  || grep -q 'name = "native-tls"' "$TORBIN_DIR/Cargo.lock" 2>/dev/null; then
  echo "::error::torbin Cargo.lock contains openssl-sys/native-tls — android cross-build WILL fail. Restore the rustls-based lock."
  exit 1
fi
(
  cd "$TORBIN_DIR" \
    && timeout 3500 cargo ndk -t "$ABI" build --release \
    && cp target/aarch64-linux-android/release/torbin "$TORBIN_OUT"
)
TOR_SIZE="$(stat -c%s "$TORBIN_OUT" 2>/dev/null || echo 0)"
if [ "$TOR_SIZE" -gt 1000000 ]; then
  echo "Tor engine OK ($TOR_SIZE bytes)"
else
  echo "::error::FATAL: libtorbin.so was NOT produced — the Tor tab would be dead. Failing the build."
  exit 1
fi
echo "::endgroup::"

echo "::group::Go toolchain"
GO_OK=0
GO_BIN=""
for g in go /usr/local/go/bin/go /usr/lib/go/bin/go "$HOME/go/bin/go"; do
  if command -v "$g" >/dev/null 2>&1 || [ -x "$g" ]; then
    v="$("$g" env GOVERSION 2>/dev/null || true)"
    minor="$(printf '%s' "$v" | sed -n 's/^go1\.\([0-9][0-9]*\).*/\1/p')"
    case "$v" in
      go2.*) GO_OK=1; GO_BIN="$(command -v "$g" 2>/dev/null || echo "$g")"; break ;;
      go1.*) if [ -n "$minor" ] && [ "$minor" -ge 21 ] 2>/dev/null; then GO_OK=1; GO_BIN="$(command -v "$g" 2>/dev/null || echo "$g")"; break; fi ;;
    esac
  fi
done
if [ "$GO_OK" != "1" ]; then
  GO_PIN=1.24.4
  echo "-- installing pinned Go ${GO_PIN} (runner Go missing/too old)"
  GO_TGZ="go${GO_PIN}.linux-amd64.tar.gz"
  if curl -fsSL "https://go.dev/dl/${GO_TGZ}" -o "/tmp/${GO_TGZ}" \
    && rm -rf /tmp/go-pin && mkdir -p /tmp/go-pin \
    && tar -C /tmp/go-pin -xzf "/tmp/${GO_TGZ}"; then
    export PATH="/tmp/go-pin/go/bin:$PATH"
    GO_OK=1
  else
    echo "::warning::pinned Go download failed — falling back to whatever the runner has"
  fi
fi
export GOTOOLCHAIN=auto
export GOPROXY="https://proxy.golang.org,direct"
if [ "$GO_OK" = "1" ]; then
  echo "Go toolchain: $("$HOME/go/bin/go" version 2>/dev/null || go version 2>/dev/null || echo present)"
fi
echo "::endgroup::"

echo "::group::SlipNet engine (Go, android/arm64)"
SLIP_OUT="$LIBS_DIR/libslipnet.so"
SLIP_NEEDS="dnstt noizdns vaydns vaydns-mobile"
if command -v go >/dev/null 2>&1 || [ -x /usr/local/go/bin/go ]; then
  export PATH="$PATH:/usr/local/go/bin"
  SLIP_WORK="$(mktemp -d)"
  SLIP_DIR="$SLIP_WORK/SlipNet"
  slip_submods_ok() {
    for s in $SLIP_NEEDS; do
      [ -n "$(ls -A "$SLIP_DIR/$s" 2>/dev/null)" ] || return 1
    done
    return 0
  }
  if git clone --depth 1 https://github.com/anonvector/SlipNet.git "$SLIP_DIR" 2>&1 | tail -1; then
    ( cd "$SLIP_DIR" && for s in $SLIP_NEEDS; do
        git submodule update --init --depth 1 "$s" 2>&1 | tail -1 || true
      done )
  else
    echo "::error::SlipNet clone failed (network/GitHub down?)"
  fi
  if ! slip_submods_ok; then
    echo "::warning::submodule init incomplete — fallback: direct clone of each missing module"
    for s in $SLIP_NEEDS; do
      if [ -z "$(ls -A "$SLIP_DIR/$s" 2>/dev/null)" ]; then
        case "$s" in
          dnstt) u="https://github.com/anonvector/dnstt.git" ;;
          noizdns) u="https://github.com/anonvector/noizdns.git" ;;
          vaydns) u="https://github.com/anonvector/vaydns.git" ;;
          vaydns-mobile) u="https://github.com/anonvector/vaydns-mobile.git" ;;
        esac
        rm -rf "$SLIP_DIR/$s"
        git clone --depth 1 "$u" "$SLIP_DIR/$s" 2>&1 | tail -1 || true
      fi
    done
  fi
  if [ -d "$SLIP_DIR/cli" ] && slip_submods_ok; then
    if ! ( cd "$SLIP_DIR/cli" && cp -f ../app/src/main/res/raw/resolvers.txt resolvers.txt 2>/dev/null ); then
      printf '8.8.8.8\n1.1.1.1\n9.9.9.9\n' > "$SLIP_DIR/cli/resolvers.txt"
      echo "::warning::resolvers.txt from repo missing — wrote a minimal fallback"
    fi
    if ( cd "$SLIP_DIR/cli" \
      && CGO_ENABLED=0 GOOS=android GOARCH=arm64 go build -trimpath -ldflags='-s -w' -o slipnet . \
      && cp slipnet "$SLIP_OUT" ); then
      echo "SlipNet engine built"
    else
      echo "::error::SlipNet go build failed — see log above"
    fi
  else
    echo "::error::SlipNet source/submodules incomplete — cannot build the engine"
  fi
  rm -rf "$SLIP_WORK" 2>/dev/null || true
else
  echo "::error::no usable Go toolchain — cannot build SlipNet engine"
fi
if [ -f "$SLIP_OUT" ] && [ "$(stat -c%s "$SLIP_OUT" 2>/dev/null || echo 0)" -gt 1000000 ]; then
  echo "SlipNet engine OK ($(stat -c%s "$SLIP_OUT") bytes)"
else
  echo "::error::FATAL: libslipnet.so was NOT produced — SlipNet tab would be broken. Failing the build."
  exit 1
fi
echo "::endgroup::"

echo "::group::obfs4proxy (Go — Tor bridges)"
OBFS_OUT="$LIBS_DIR/libobfs4.so"
if command -v go >/dev/null 2>&1 || [ -x /usr/local/go/bin/go ]; then
  export PATH="$PATH:/usr/local/go/bin"
  OBFS_DIR="$(mktemp -d)/obfs4"
  if git clone --depth 1 https://gitlab.com/yawning/obfs4.git "$OBFS_DIR" 2>&1 | tail -1; then
    ( cd "$OBFS_DIR/obfs4proxy" \
      && CGO_ENABLED=0 GOOS=android GOARCH=arm64 go build -trimpath -ldflags='-s -w -checklinkname=0' -o obfs4proxy . \
      && cp obfs4proxy "$OBFS_OUT" ) \
      && echo "obfs4proxy OK" || echo "::warning::obfs4proxy build failed — Tor bridges will not work"
  elif git clone --depth 1 https://gitlab.torproject.org/tpo/anti-censorship/pluggable-transports/obfs4.git "$OBFS_DIR" 2>&1 | tail -1; then
    ( cd "$OBFS_DIR/obfs4proxy" \
      && CGO_ENABLED=0 GOOS=android GOARCH=arm64 go build -trimpath -ldflags='-s -w -checklinkname=0' -o obfs4proxy . \
      && cp obfs4proxy "$OBFS_OUT" ) \
      && echo "obfs4proxy OK" || echo "::warning::obfs4proxy build failed — Tor bridges will not work"
  else
    echo "::warning::obfs4 clone failed from both sources — Tor bridges will not work"
  fi
  rm -rf "$OBFS_DIR" 2>/dev/null || true
else
  echo "::warning::Go toolchain not found — Tor bridges will not work"
fi
echo "::endgroup::"

echo "::group::Shir-o-Khorshid engine (psiphon-tunnel-core ConsoleClient)"
mkdir -p "$PWD/V2rayNG/app/src/main/res/raw"
PSI_RAW="$PWD/V2rayNG/app/src/main/res/raw/psi_config.json"
PSI_OUT="$LIBS_DIR/libshkcore.so"

# 1) base config: always start from the bundled snapshot (kept in-repo so a
#    plain Android Studio build without this script also compiles)
if [ -s "$PSI_RAW" ]; then
  echo "psi_config: bundled snapshot in place ($(stat -c%s "$PSI_RAW") bytes)"
else
  echo "::error::V2rayNG/app/src/main/res/raw/psi_config.json missing from repo — cannot ship ShK network config"
  printf '{}' > "$PSI_RAW"
fi

# 2) best-effort refresh from the latest official ShirOKhorshid release
PSI_REL_URL="$(curl -fsSL --max-time 30 'https://api.github.com/repos/shirokhorshid/shirokhorshid-android/releases/latest' 2>/dev/null | python3 -c 'import json,sys
try:
  d=json.load(sys.stdin)
  for a in d.get("assets",[]):
    if a["name"].endswith(".apk"): print(a["browser_download_url"]); break
except Exception: pass' || true)"
if [ -n "$PSI_REL_URL" ]; then
  PSI_WORK="$(mktemp -d)"
  if curl -fsSL --max-time 600 -o "$PSI_WORK/shk.apk" "$PSI_REL_URL" 2>/dev/null; then
    python3 - "$PSI_WORK/shk.apk" "$PSI_WORK/psi_config.json" <<'PYEOF' || echo "::warning::psi_config refresh extraction failed — keeping bundled snapshot"
import json, re, sys, zipfile
z = zipfile.ZipFile(sys.argv[1]); pat = re.compile(rb'[0-9a-f]{600,}'); raws = set()
for n in z.namelist():
    if not re.match(r'classes\d*\.dex$', n): continue
    for m in pat.finditer(z.read(n)): raws.add(m.group(0))
entries = []
for h in raws:
    try: txt = bytes.fromhex(h.decode('ascii')).decode('utf-8', 'strict')
    except Exception: continue
    j = txt.find('{')
    if j < 0: continue
    try: js = json.loads(txt[j:])
    except Exception: continue
    if isinstance(js, dict) and 'ipAddress' in js: entries.append(txt.strip())
entries = list(dict.fromkeys(entries))
if len(entries) < 200: sys.exit(1)
json.dump({'ClientVersion':'1','ClientPlatform':'Android','PropagationChannelId':'FFFFFFFFFFFFFFFF','SponsorId':'FFFFFFFFFFFFFFFF','EmitDiagnosticNotices':False,'EmbeddedServerEntryList':entries}, open(sys.argv[2],'w'), separators=(',',':'))
print('psi_config refreshed from latest release:', len(entries), 'entries')
PYEOF
    if [ -s "$PSI_WORK/psi_config.json" ]; then
      cp -f "$PSI_WORK/psi_config.json" "$PSI_RAW"
      echo "psi_config: updated from latest ShirOKhorshid release"
    fi
  else
    echo "::warning::latest release APK download failed — keeping bundled snapshot"
  fi
  rm -rf "$PSI_WORK" 2>/dev/null || true
else
  echo "psi_config: release check skipped/failed — bundled snapshot will be used"
fi

# 3) build the engine from the official repo
if command -v go >/dev/null 2>&1 || [ -x /usr/local/go/bin/go ]; then
  export PATH="$PATH:/usr/local/go/bin"
  PSI_CORE="$(mktemp -d)/core"
  if git clone --depth 1 https://github.com/Psiphon-Labs/psiphon-tunnel-core.git "$PSI_CORE" 2>&1 | tail -1; then
    if [ -d "$PSI_CORE/ConsoleClient" ]; then
      ( cd "$PSI_CORE" \
        && CGO_ENABLED=0 GOOS=android GOARCH=arm64 go build -trimpath -ldflags='-s -w -checklinkname=0' -o shkcore ./ConsoleClient \
        && cp shkcore "$PSI_OUT" ) \
        && echo "ShK (psiphon ConsoleClient) engine OK" \
        || echo "::error::psiphon ConsoleClient go build failed — see go log above"
    else
      echo "::error::ConsoleClient directory not found in psiphon-tunnel-core"
    fi
  else
    echo "::error::psiphon-tunnel-core clone failed"
  fi
  rm -rf "$(dirname "$PSI_CORE")" 2>/dev/null || true
else
  echo "::error::Go toolchain not found — cannot build ShK engine"
fi

# 4) hard gates: engine + real network config
SHK_SIZE="$(stat -c%s "$PSI_OUT" 2>/dev/null || echo 0)"
if [ "$SHK_SIZE" -gt 1000000 ]; then
  echo "ShK engine gate OK ($SHK_SIZE bytes)"
else
  echo "::error::FATAL: libshkcore.so was NOT produced — the Shir-o-Khorshid tab would be dead. Failing the build."
  exit 1
fi
PSI_ENTRIES="$(python3 -c "import json;print(len(json.load(open('$PSI_RAW')).get('EmbeddedServerEntryList',[])))" 2>/dev/null || echo 0)"
if [ "$PSI_ENTRIES" -ge 200 ]; then
  echo "psi_config gate OK ($PSI_ENTRIES server entries)"
else
  echo "::error::FATAL: psi_config.json has no real server entries ($PSI_ENTRIES) — ShK would connect to nothing. Failing the build."
  exit 1
fi
echo "::endgroup::"

echo "::group::cleanup build intermediates"
rm -rf rust/target rust/torbin/target 2>/dev/null || true
rm -rf "$HOME/.cargo/registry/src" "$HOME/.cargo/registry/cache" 2>/dev/null || true
go clean -cache 2>/dev/null || true
df -h / || true
echo "::endgroup::"

echo "::group::official Code.gs (Apps Script relay)"
curl -fsSL https://raw.githubusercontent.com/therealaleph/MasterHttpRelayVPN-RUST/main/assets/apps_script/Code.gs \
  -o "$PWD/V2rayNG/app/src/main/assets/code_gs.txt"
grep -q AUTH_KEY "$PWD/V2rayNG/app/src/main/assets/code_gs.txt"
echo "Code.gs OK ($(stat -c%s "$PWD/V2rayNG/app/src/main/assets/code_gs.txt") bytes)"
echo "::endgroup::"

echo "::group::signing"
KS_FILE=""
KS_PASS="v2rayng-panels-$(date +%s)"
KS_ALIAS="v2rayng_panels"
if [ -n "${APP_KEYSTORE_BASE64:-}" ]; then
  echo "$APP_KEYSTORE_BASE64" | base64 -d > /tmp/keystore.jks
  KS_FILE="/tmp/keystore.jks"
  KS_PASS="${APP_KEYSTORE_PASSWORD:-$KS_PASS}"
  KS_ALIAS="${APP_KEYSTORE_ALIAS:-$KS_ALIAS}"
  echo "using provided keystore"
else
  keytool -genkeypair -v \
    -keystore /tmp/keystore.jks \
    -alias "$KS_ALIAS" \
    -keyalg RSA -keysize 2048 -validity 10950 \
    -storepass "$KS_PASS" -keypass "$KS_PASS" \
    -dname "CN=v2rayNG Panels, OU=Panels, O=Panels, L=Tehran, C=IR" >/dev/null 2>&1
  KS_FILE="/tmp/keystore.jks"
  echo "::warning::no APP_KEYSTORE_BASE64 secret found — generated an ephemeral signing key (re-install instead of upgrade over a previous signed build)"
fi
echo "::endgroup::"

echo "::group::gradle build"
cd "$PWD/V2rayNG"
echo "sdk.dir=${ANDROID_HOME}" > local.properties
chmod 755 gradlew
./gradlew assemblePlaystoreRelease \
  -PABI_FILTERS="$ABI" \
  -Pandroid.injected.signing.store.file="$KS_FILE" \
  -Pandroid.injected.signing.store.password="$KS_PASS" \
  -Pandroid.injected.signing.key.alias="$KS_ALIAS" \
  -Pandroid.injected.signing.key.password="$KS_PASS"
echo "::endgroup::"

echo "::group::collect APK"
mkdir -p "$PWD/dist"
find "$PWD/V2rayNG/app/build/outputs/apk" -type f -name "*arm64*.apk" -exec cp -v {} "$PWD/dist/" \;
ls -la "$PWD/dist"
echo "::endgroup::"

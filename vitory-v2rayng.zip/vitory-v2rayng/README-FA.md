# v2rayNG + پنل‌ها (نسخهٔ ویتوری)

خودِ **v2rayNG رسمی (نسخهٔ ۲.۳.۱۵ با طراحی جدید Compose)** — با تمام تنظیمات و قابلیت‌هایش — به‌اضافهٔ **۱۳ قابلیتِ برنامهٔ «مدیریت پنل‌ها»** که با طراحی خود v2rayNG بازنویسی شده‌اند و در **منوی همبرگری، زیر «تنظیمات»** اضافه شده‌اند.

## منوی همبرگری

بالای منو (خود v2rayNG):
- اشتراک‌ها · پروکسی هر اپ · مسیریابی · فایل‌های Asset · تنظیمات

زیر تنظیمات (پنل‌های منتقل‌شده):
1. اسلیپ‌نت (SlipNet — تونل DNS/SSH/VLESS)
2. تور (Tor — موتور Arti داخل اپ)
3. شیر و خورشید (سایفون داخل اپ + انتخاب کشور خروجی)
4. مصرف (شمارندهٔ درخواست‌های هر پنل)
5. اختلال (ضد فیلتر: IP تمیز + SNI + تعمیرکار هوشمند روی پروفایل خود ویتوری)
6. اسکن IP (IP / دامنه / پروکسی / DNS — پروب واقعی)
7. ترکیبی (پنل ادمین X4G روی KV کلادفلر)
8. گوگل / MHR (تونل Apps Script با موتور Rust)
9. سپر ایمی (سلامت دستگاه، رم، اسکن اپ/فایل، میکروفن/دوربین، سپر DNS و نسخه)
10. کنترل پنل (لیست پنل‌ها + ایمپورت بکاپ مدیریت پنل‌ها)
11. ابزارها (وضعیت سرور، UUID/رمز، بکاپ KV کلادفلر)
12. مرورگر پنل (باز کردن پنل داخل اپ)
13. اطلاعات (موتورهای داخل APK و پنل‌های ثبت‌شده)

آیتم‌های قبلی — Promotion، Logcat، Check for update، Backup & Restore و About — از منو **حذف شده‌اند** (طبق درخواست).

حذف‌شده‌ها از فایل اصلی: رسانه، PattNG، ویندسکرایب، WARP+1.1.1.1، لنترن، گپ، پروتون VPN.

## بیلد APK روی گیت‌هاب

1. کل محتوای این پوشه را در یک ریپوی جدید آپلود کن (اسم پوشهٔ داخل زیپ = ریشهٔ ریپو).
2. تب **Actions** ← ورک‌فلو **Build APK** — با هر پوش به `master`/`main` خودکار بیلد می‌شود؛ دستی هم می‌شود از «Run workflow» اجرا کرد.
3. بعد از سبز شدن بیلد، در همان اجرا پایین صفحه بخش **Artifacts** ← `v2rayNG-panels-apk` ← فایل APK (arm64-v8a، امضاشده و قابل نصب).
4. اگر خواستی ریلیز هم بسازد: «Run workflow» ← در فیلد `release_tag` مثلاً `v1.0` بگذار — APK روی Releases هم می‌رود.

نکتهٔ امضا: اگر Secrets به نام‌های `APP_KEYSTORE_BASE64` و `APP_KEYSTORE_PASSWORD` و `APP_KEYSTORE_ALIAS` تعریف کنی با کلید خودت امضا می‌شود؛ وگرنه بیلد خودش یک کلید موقتی می‌سازد (هر بیلد کلید جدید → آپدیت روی نسخهٔ قبلی نصب‌شده نمی‌شود، اول پاک کن بعد نصب کن).

## موتورهای داخل APK

بیلد CI این‌ها را کامپایل می‌کند و داخل APK می‌گذارد (همه arm64-v8a):

| موتور | تب | منبع |
| --- | --- | --- |
| libmhrv_rs.so + libtun2proxy.so | گوگل / MHR | هستهٔ Rust این ریپو (`rust/`، MIT) |
| libtorbin.so | تور | `rust/torbin/` (Arti — rustls، بدون OpenSSL) |
| libobfs4.so | پل‌های تور | obfs4proxy (Go) |
| libslipnet.so | اسلیپ‌نت | anonvector/SlipNet (AGPL، بیلد از سورس) |
| libshkcore.so + psi_config.json | شیر و خورشید | psiphon-tunnel-core (GPL) از مخزن رسمی + پیکربندی شبکهٔ تعبیه‌شدهٔ اپ رسمی شیر و خورشید |
| libv2ray.aar | هستهٔ اصلی خود v2rayNG | رلیز رسمی 2dust/AndroidLibXrayLite |
| libhev-socks5-tunnel.so | TUN خود v2rayNG | سورس وندورشدهٔ `hev-socks5-tunnel/` |

## مجوزها

مجوزهای خود v2rayNG + `MANAGE_EXTERNAL_STORAGE` (فقط برای «اسکن فایل‌ها» در سپر ایمی؛ اگر ندهی همان صفحه به‌جایش کش خود اپ را می‌سنجد).

## ساختار پروژه

```
.github/workflows/build.yml    بیلد کامل (Rust + Go + NDK + Gradle)
ci/run.sh                      تمام منطق بیلد (اصلاح بیلد = همین فایل)
rust/                          هستهٔ mhrv-rs + torbin (بدون تغییر، MIT)
V2rayNG/                       سورس v2rayNG (Compose) + پنل‌ها:
  app/src/main/java/com/v2ray/ang/panels/       ۱۳ صفحهٔ جدید (Kotlin/Compose)
  app/src/main/java/com/therealaleph/mhrv/       سرویس‌های VPN موتورها
  app/src/main/res/raw/psi_config.json           پیکربندی شبکهٔ سایفون
  app/src/main/assets/code_gs.txt                Code.gs (موتور MHR)
hev-socks5-tunnel/             سورس وندورشده (دیگر ساب‌ماژول نیست)
```

لایسنس‌ها: v2rayNG (GPL-3.0) · mhrv-rs (MIT) · SlipNet (AGPL-3.0) · psiphon-tunnel-core (GPL-3.0) · obfs4 (MIT/自由) — استفاده و تغییر طبق همان لایسنس‌ها.

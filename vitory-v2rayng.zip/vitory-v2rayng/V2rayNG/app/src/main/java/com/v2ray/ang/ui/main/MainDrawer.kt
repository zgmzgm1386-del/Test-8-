package com.v2ray.ang.ui.main

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DrawerState
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import com.v2ray.ang.ui.compose.AppDivider
import com.v2ray.ang.ui.compose.LocalDarkTheme
import com.v2ray.ang.ui.compose.verticalScrollbar

enum class MainDestination(@DrawableRes val iconRes: Int, @StringRes val labelRes: Int) {
    Subscriptions(R.drawable.ic_subscriptions_24dp, R.string.title_sub_setting),
    PerAppProxy(R.drawable.ic_per_apps_24dp, R.string.per_app_proxy_settings),
    Routing(R.drawable.ic_routing_24dp, R.string.routing_settings_title),
    UserAssets(R.drawable.ic_file_24dp, R.string.title_user_asset_setting),
    Settings(R.drawable.ic_settings_24dp, R.string.title_settings),
    // ── پنل‌های منتقل‌شده از «مدیریت پنل‌ها» (زیر تنظیمات؛ جایگزین Promotion/Logcat/Update/Backup/About) ──
    PanelSlipnet(R.drawable.ic_panel_slipnet_24dp, R.string.title_panel_slipnet),
    PanelTor(R.drawable.ic_panel_tor_24dp, R.string.title_panel_tor),
    PanelShk(R.drawable.ic_panel_shk_24dp, R.string.title_panel_shk),
    PanelUsage(R.drawable.ic_panel_usage_24dp, R.string.title_panel_usage),
    PanelEkhtelal(R.drawable.ic_panel_ekhtelal_24dp, R.string.title_panel_ekhtelal),
    PanelScan(R.drawable.ic_scan_24dp, R.string.title_panel_scan),
    PanelW222(R.drawable.ic_panel_w222_24dp, R.string.title_panel_w222),
    PanelMhr(R.drawable.ic_panel_mhr_24dp, R.string.title_panel_mhr),
    PanelShield(R.drawable.ic_panel_shield_24dp, R.string.title_panel_shield),
    PanelControl(R.drawable.ic_panel_pctl_24dp, R.string.title_panel_pctl),
    PanelTools(R.drawable.ic_panel_tools_24dp, R.string.title_panel_tools),
    PanelBrowser(R.drawable.ic_panel_browser_24dp, R.string.title_panel_browser),
    PanelInfo(R.drawable.ic_panel_info_24dp, R.string.title_panel_info)
}

private val primaryDrawerItems = listOf(
    MainDestination.Subscriptions,
    MainDestination.PerAppProxy,
    MainDestination.Routing,
    MainDestination.UserAssets,
    MainDestination.Settings
)

private val panelDrawerItems = listOf(
    MainDestination.PanelSlipnet,
    MainDestination.PanelTor,
    MainDestination.PanelShk,
    MainDestination.PanelUsage,
    MainDestination.PanelEkhtelal,
    MainDestination.PanelScan,
    MainDestination.PanelW222,
    MainDestination.PanelMhr,
    MainDestination.PanelShield,
    MainDestination.PanelControl,
    MainDestination.PanelTools,
    MainDestination.PanelBrowser,
    MainDestination.PanelInfo
)

private val drawerItems = primaryDrawerItems + panelDrawerItems

@Composable
fun MainDrawerContent(drawerState: DrawerState, onNavigate: (MainDestination) -> Unit) {
    val drawerScrollState = rememberScrollState()

    ModalDrawerSheet(
        drawerState = drawerState,
        modifier = Modifier.fillMaxWidth(0.75f),
        drawerContainerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .verticalScroll(drawerScrollState)
                .verticalScrollbar(drawerScrollState)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    val isDarkTheme = LocalDarkTheme.current
                    Image(
                        painter = painterResource(R.mipmap.ic_launcher_foreground),
                        contentDescription = null,
                        modifier = Modifier.size(120.dp),
                        colorFilter = if (isDarkTheme) {
                            ColorFilter.tint(Color.White, BlendMode.SrcIn)
                        } else {
                            null
                        }
                    )
                    Text(
                        text = stringResource(R.string.app_name),
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
            drawerItems.forEachIndexed { index, item ->
                if (index == primaryDrawerItems.size) AppDivider()
                NavigationDrawerItem(
                    label = { Text(stringResource(item.labelRes)) },
                    selected = false,
                    onClick = { onNavigate(item) },
                    icon = { Icon(painterResource(item.iconRes), contentDescription = null) },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
            }
        }
    }
}

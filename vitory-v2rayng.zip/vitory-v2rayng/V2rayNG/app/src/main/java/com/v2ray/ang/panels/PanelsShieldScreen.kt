package com.v2ray.ang.panels

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import com.v2ray.ang.ui.base.BaseComponentActivity
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import com.v2ray.ang.ui.compose.SettingsEditItem
import com.v2ray.ang.ui.compose.SettingsMenuItem
import com.v2ray.ang.ui.compose.SettingsSwitchItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * سپر ایمی — port of the panels-manager security center: shield score,
 * device health, RAM cleaner, app/file scan, new-app shield, mic/cam
 * watcher, browser footprint, DNS shield, connection shield, update shield.
 */
class ShieldActivity : BaseComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    @Composable
    override fun ScreenContent() = ShieldScreen(onBackClick = { finish() })
}

@Composable
fun ShieldScreen(onBackClick: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var mem by remember { mutableStateOf<JSONObject?>(null) }
    var dev by remember { mutableStateOf<JSONObject?>(null) }
    var apps by remember { mutableStateOf<JSONObject?>(null) }
    var files by remember { mutableStateOf<JSONObject?>(null) }
    var dnsShield by remember { mutableStateOf<JSONObject?>(null) }
    var updUrl by PanelsStore.rememberPanelString("sec_upd_url", "")
    var updAuto by PanelsStore.rememberPanelBool("sec_upd_auto", true)
    var dnsGuard by PanelsStore.rememberPanelBool("sec_dns_guard", true)
    var newAppScan by PanelsStore.rememberPanelBool("sec_newapp", true)
    var lastPkgText by remember { mutableStateOf("") }
    var micList by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    val storagePerm = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        scope.launch(Dispatchers.IO) {
            files = try { JSONObject(PanelsSecEngine.files(context)) } catch (_: Throwable) { null }
        }
    }

    // "new app installed" receiver (same as panels-manager pkgReceiver)
    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, i: Intent) {
                try {
                    if (i.action != Intent.ACTION_PACKAGE_ADDED) return
                    if (i.getBooleanExtra(Intent.EXTRA_REPLACING, false)) return
                    val p = i.data?.schemeSpecificPart ?: return
                    PanelsSecEngine.onPackageAdded(p)
                    lastPkgText = "برنامهٔ جدید: $p — اسکنش کن"
                } catch (_: Throwable) {
                }
            }
        }
        try {
            val f = IntentFilter(Intent.ACTION_PACKAGE_ADDED)
            f.addDataScheme("package")
            context.registerReceiver(receiver, f)
        } catch (_: Throwable) {
        }
        onDispose {
            try { context.unregisterReceiver(receiver) } catch (_: Throwable) {}
        }
    }

    // initial load
    androidx.compose.runtime.LaunchedEffect(Unit) {
        PanelsSecEngine.restoreLastPkg()
        withContext(Dispatchers.IO) {
            mem = try { JSONObject(PanelsSecEngine.mem(context)) } catch (_: Throwable) { null }
            dev = try { JSONObject(PanelsSecEngine.devInfo(context)) } catch (_: Throwable) { null }
            files = try { JSONObject(PanelsSecEngine.files(context)) } catch (_: Throwable) { null }
            lastPkgText = PanelsSecEngine.lastAdded.ifBlank { "" }
        }
    }

    // shield score = average of the available sub-checks (same spirit as panels-manager)
    var scoreOk by remember { mutableStateOf(0) }
    var scoreTotal by remember { mutableStateOf(0) }
    fun bump(ok: Boolean) {
        scoreTotal++
        if (ok) scoreOk++
    }
    scoreOk = 0; scoreTotal = 0
    mem?.let { bump(it.optDouble("usedPct", 100.0) < 85.0) }
    dev?.let {
        bump(it.optBoolean("screenLock", false))
        bump(it.optBoolean("encrypted", false))
        bump(!it.optBoolean("adb", false))
        bump(it.optJSONArray("acc")?.length() == 0)
        bump(it.optJSONArray("ntf")?.length() == 0)
    }
    apps?.let { bump(it.optInt("riskyN", 1) == 0) }
    dnsShield?.let { bump(it.optInt("hijack", 1) == 0) }
    val scorePct = if (scoreTotal > 0) scoreOk.toFloat() / scoreTotal else 0f

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = { AppTopBar(title = stringResource(R.string.title_panel_shield), onBackClick = onBackClick) }
    ) { innerPadding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            // score ring
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(vertical = 8.dp)
            ) {
                PanelRing(scorePct, "${(scorePct * 100).toInt()}")
                Spacer(Modifier.height(0.dp))
                Column(Modifier.padding(start = 16.dp)) {
                    Text("امتیاز سپر", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "بر پایهٔ سلامت دستگاه، رم، برنامه‌ها و سپر DNS — همه بررسی واقعی",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(Modifier.height(6.dp))

            // connection shield (v2rayNG native state)
            PanelCard(title = "سپر اتصال", chipText = "فعال/غیرفعال", chipGood = false) {
                Text(
                    "وضعیت اتصال از هستهٔ خود ویتوری خوانده می‌شود — برای حفاظت، همان اتصال اصلی را روشن نگه دار.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(10.dp))

            // DNS shield
            PanelCard(
                title = "سپر DNS",
                chipText = if (dnsShield == null) "بررسی کن" else if (dnsShield?.optInt("hijack", 1) == 0) "سالم ✓" else "دستکاری!",
                chipGood = dnsShield?.optInt("hijack", 1) == 0,
            ) {
                SettingsSwitchItem(
                    title = "هشدار دستکاری DNS",
                    summary = "UDP/53 در برابر DoH رمزشده سنجیده می‌شود",
                    checked = dnsGuard,
                    onCheckedChange = { dnsGuard = it }
                )
                SettingsMenuItem(
                    icon = painterResource(R.drawable.ic_panel_slipnet_24dp),
                    title = "اجرای اسکن DNS",
                    subtitle = "youtube.com / x.com / example.com",
                    onClick = {
                        scope.launch(Dispatchers.IO) {
                            val r = try { JSONObject(PanelsSecEngine.dnsCheck()) } catch (_: Throwable) { null }
                            withContext(Dispatchers.Main) { dnsShield = r }
                        }
                    }
                )
                dnsShield?.optJSONArray("rows")?.let { rows ->
                    for (i in 0 until rows.length()) {
                        val r = rows.optJSONObject(i) ?: continue
                        PanelKeyValue(r.optString("name"), if (r.optInt("bad") == 1) "مشکوک" else "سالم")
                    }
                }
            }
            Spacer(Modifier.height(10.dp))

            // device health
            PanelCard(title = "سلامت دستگاه") {
                dev?.let { d ->
                    PanelKeyValue("قفل صفحه", if (d.optBoolean("screenLock")) "فعال ✓" else "غیرفعال!")
                    PanelKeyValue("رمزنگاری", if (d.optBoolean("encrypted")) "فعال ✓" else "نامشخص")
                    PanelKeyValue("پچ امنیتی", d.optString("patch", "—"))
                    PanelKeyValue("گزینه‌های توسعه", if (d.optBoolean("devOpts")) "روشن" else "خاموش ✓")
                    PanelKeyValue("USB دیباگ", if (d.optBoolean("adb")) "روشن!" else "خاموش ✓")
                    PanelKeyValue("سرویس دسترسی", (d.optJSONArray("acc")?.length() ?: 0).toString() + " مورد")
                    PanelKeyValue("شنوندهٔ اعلان", (d.optJSONArray("ntf")?.length() ?: 0).toString() + " مورد")
                    PanelKeyValue("ادمین دستگاه", (d.optJSONArray("adm")?.length() ?: 0).toString() + " مورد")
                    PanelKeyValue("اجازهٔ نصب ناشناس", (d.optJSONArray("unk")?.length() ?: 0).toString() + " اپ")
                } ?: Text("…", style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(10.dp))

            // RAM
            PanelCard(title = "رم و پاکسازی") {
                mem?.let { m ->
                    PanelKeyValue("رم کل", (m.optLong("total") / 1048576L).toString() + " MB")
                    PanelKeyValue("آزاد", (m.optLong("avail") / 1048576L).toString() + " MB")
                    PanelKeyValue("مصرف", m.optDouble("usedPct", 0.0).toString() + "٪")
                }
                SettingsMenuItem(
                    icon = painterResource(R.drawable.ic_delete_24dp),
                    title = "پاکسازی رم",
                    subtitle = "بستن پردازش‌های پس‌زمینه (مجاز اندروید)",
                    onClick = {
                        scope.launch(Dispatchers.IO) {
                            val r = try { JSONObject(PanelsSecEngine.clean(context)) } catch (_: Throwable) { null }
                            withContext(Dispatchers.Main) {
                                r?.let {
                                    message = "پاکسازی شد — " + (it.optLong("freed") / 1048576L) + "MB آزاد شد"
                                    mem = try { JSONObject(PanelsSecEngine.mem(context)) } catch (_: Throwable) { null }
                                }
                            }
                        }
                    }
                )
            }
            Spacer(Modifier.height(10.dp))

            // apps
            PanelCard(
                title = "اسکن برنامه‌ها",
                chipText = apps?.let { "خطرناک: " + it.optInt("riskyN", 0) } ?: "بررسی کن",
                chipGood = apps?.optInt("riskyN", 1) == 0,
            ) {
                SettingsMenuItem(
                    icon = painterResource(R.drawable.ic_per_apps_24dp),
                    title = "اسکن برنامه‌های نصب‌شده",
                    subtitle = "دسترسی‌های حساس + نصب بیرون فروشگاه",
                    onClick = {
                        scope.launch(Dispatchers.IO) {
                            val r = try { JSONObject(PanelsSecEngine.apps(context, null)) } catch (_: Throwable) { null }
                            withContext(Dispatchers.Main) { apps = r }
                        }
                    }
                )
                apps?.optJSONArray("risky")?.let { risky ->
                    for (i in 0 until minOf(6, risky.length())) {
                        val a = risky.optJSONObject(i) ?: continue
                        PanelKeyValue(
                            a.optString("name") + " (" + a.optInt("score") + ")",
                            a.optJSONArray("why")?.optString(0) ?: ""
                        )
                    }
                }
            }
            Spacer(Modifier.height(10.dp))

            // files
            PanelCard(title = "اسکن فایل‌ها") {
                files?.let { f ->
                    PanelKeyValue("فایل‌های APK", f.optInt("apkCount", 0).toString())
                    PanelKeyValue("زبالهٔ کش", (f.optLong("junk") / 1048576L).toString() + " MB")
                }
                if (files?.optBoolean("needPerm", false) == true) {
                    SettingsMenuItem(
                        icon = painterResource(R.drawable.ic_per_apps_24dp),
                        title = "اجازهٔ همهٔ فایل‌ها",
                        subtitle = "برای اسکن کامل حافظه",
                        onClick = {
                            if (Build.VERSION.SDK_INT >= 30) {
                                try {
                                    storagePerm.launch(
                                        Intent(
                                            Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                            Uri.parse("package:" + context.packageName)
                                        )
                                    )
                                } catch (_: Throwable) {
                                    try {
                                        storagePerm.launch(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                                    } catch (_: Throwable) {
                                    }
                                }
                            }
                        }
                    )
                }
                SettingsMenuItem(
                    icon = painterResource(R.drawable.ic_delete_24dp),
                    title = "پاکسازی کش",
                    subtitle = "کش‌های خود اپ",
                    onClick = {
                        scope.launch(Dispatchers.IO) {
                            val r = try { JSONObject(PanelsSecEngine.cleanFiles(context)) } catch (_: Throwable) { null }
                            withContext(Dispatchers.Main) {
                                message = "کش پاک شد — " + ((r?.optLong("freed") ?: 0) / 1048576L) + "MB"
                                files = try { JSONObject(PanelsSecEngine.files(context)) } catch (_: Throwable) { null }
                            }
                        }
                    }
                )
            }
            Spacer(Modifier.height(10.dp))

            // new app shield
            PanelCard(title = "سپر برنامهٔ جدید") {
                SettingsSwitchItem(
                    icon = painterResource(R.drawable.ic_per_apps_24dp),
                    title = "بررسی خودکار نصب جدید",
                    summary = "هر برنامهٔ تازه‌نصب گزارش می‌شود",
                    checked = newAppScan,
                    onCheckedChange = { newAppScan = it }
                )
                if (lastPkgText.isNotBlank()) {
                    PanelKeyValue("آخرین نصب", lastPkgText)
                    SettingsMenuItem(
                        icon = painterResource(R.drawable.ic_qu_start_24dp),
                        title = "اسکن همان برنامه",
                        onClick = {
                            scope.launch(Dispatchers.IO) {
                                val r = try { JSONObject(PanelsSecEngine.apps(context, PanelsSecEngine.lastAdded)) } catch (_: Throwable) { null }
                                withContext(Dispatchers.Main) {
                                    val w = r?.optJSONArray("why")
                                    message = if (w != null && w.length() > 0) "هشدار: " + w.optString(0) else "مشکلی پیدا نشد ✓"
                                }
                            }
                        }
                    )
                }
            }
            Spacer(Modifier.height(10.dp))

            // mic / cam watcher
            PanelCard(title = "سپر میکروفن و دوربین") {
                Text(
                    "با AppOps اندروید (بدون مجوز): هر اپی که همین حالا میکروفن/دوربین را فعال کند گزارش می‌شود.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                SettingsMenuItem(
                    icon = painterResource(R.drawable.ic_panel_shield_24dp),
                    title = "بررسی رویدادها",
                    subtitle = if (micList.isBlank()) "فعال‌سازی و نمایش" else micList,
                    onClick = {
                        scope.launch(Dispatchers.IO) {
                            val r = try { JSONObject(PanelsSecEngine.micWatch(context)) } catch (_: Throwable) { null }
                            withContext(Dispatchers.Main) {
                                val list = r?.optJSONArray("list")
                                micList = if (list != null && list.length() > 0) {
                                    (0 until list.length()).joinToString(" · ") { k ->
                                        val e = list.optJSONObject(k)
                                        (if (e?.optString("op") == "mic") "🎙" else "📷") + " " + e?.optString("label")
                                    }
                                } else if (r?.optInt("reg", 0) == 1) "فعال است — فعلاً رویدادی نیست"
                                else "پشتیبانی نمی‌شود (اندروید ۱۰+)"
                            }
                        }
                    }
                )
            }
            Spacer(Modifier.height(10.dp))

            // browser footprint
            PanelCard(title = "ردپای مرورگر") {
                SettingsMenuItem(
                    icon = painterResource(R.drawable.ic_delete_24dp),
                    title = "پاکسازی WebView",
                    subtitle = "کش + کوکی‌ها (با تأیید)",
                    onClick = {
                        scope.launch(Dispatchers.IO) {
                            val r = try { JSONObject(PanelsSecEngine.wbClean(context, true)) } catch (_: Throwable) { null }
                            withContext(Dispatchers.Main) {
                                message = if (r?.optBoolean("cookies", false) == true) "کش و کوکی‌ها پاک شد ✓" else "کش پاک شد"
                            }
                        }
                    }
                )
            }
            Spacer(Modifier.height(10.dp))

            // update shield
            PanelCard(title = "سپر نسخهٔ برنامه") {
                SettingsSwitchItem(
                    icon = painterResource(R.drawable.ic_qu_start_24dp),
                    title = "بررسی خودکار",
                    summary = "هر نیم ساعت آدرس انتشار چک می‌شود",
                    checked = updAuto,
                    onCheckedChange = { updAuto = it }
                )
                SettingsEditItem(
                    title = "آدرس انتشار (GitHub API)",
                    value = updUrl,
                    onValueChanged = { updUrl = it }
                )
                SettingsMenuItem(
                    icon = painterResource(R.drawable.ic_qu_start_24dp),
                    title = "بررسی نسخهٔ جدید",
                    subtitle = "واکشی واقعی از آدرس بالا",
                    onClick = {
                        if (updUrl.isBlank()) {
                            message = "اول آدرس انتشار را بده (مثل https://api.github.com/repos/USER/REPO/releases/latest)"
                            return@SettingsMenuItem
                        }
                        scope.launch(Dispatchers.IO) {
                            val r = try { JSONObject(PanelsSecEngine.updFetch(updUrl)) } catch (_: Throwable) { null }
                            withContext(Dispatchers.Main) {
                                val body = r?.optString("body") ?: ""
                                val tag = try { JSONObject(body).optString("tag_name") } catch (_: Throwable) { "" }
                                message = if (tag.isNotBlank()) "آخرین نسخهٔ منتشرشده: $tag" else "آدرس جواب نداد"
                            }
                        }
                    }
                )
            }
            if (message.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            NavigationBarsSpacer()
        }
    }
}

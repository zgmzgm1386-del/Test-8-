package com.v2ray.ang.panels

import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.SystemClock
import com.therealaleph.mhrv.CaInstall
import com.therealaleph.mhrv.DnsProbe
import com.therealaleph.mhrv.MhrvVpnService
import com.therealaleph.mhrv.Native
import com.therealaleph.mhrv.ShkVpnService
import com.therealaleph.mhrv.SlipVpnService
import com.therealaleph.mhrv.TorVpnService
import com.therealaleph.mhrv.VpnState
import com.v2ray.ang.core.LauncherManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** The four local engines this app can drive (one active VPN at a time). */
enum class PanelEngine(val libName: String) {
    MHRV("libmhrv_rs.so"),
    SLIP("libslipnet.so"),
    TOR("libtorbin.so"),
    SHK("libshkcore.so"),
}

/**
 * Native bridge between the Compose screens and the ported engines
 * (mhrv-rs / SlipNet / Tor / Psiphon). Port of the panels-manager
 * MethodChannel("mhrv") dispatch — direct Kotlin calls instead of Flutter.
 */
object PanelsBridge {

    private const val POLL_STOP_MAX_MS = 9000L

    /** Warm up the Rust core (must run once before startProxy / exportCa). */
    fun initNative(context: Context) {
        try {
            Native.setDataDir(context.filesDir.absolutePath)
        } catch (_: Throwable) {
        }
    }

    fun engineInfo(context: Context): JSONObject {
        val o = JSONObject()
        val nd = context.applicationInfo.nativeLibraryDir
        fun has(name: String) = File(nd, name).exists()
        o.put("slip", has(SlipVpnService.LIB))
        o.put("tor", has(TorVpnService.LIB))
        o.put("shk", has(ShkVpnService.LIB))
        o.put("mhrv", has("libmhrv_rs.so"))
        o.put("obfs4", has("libobfs4.so"))
        o.put("tun2proxy", has("libtun2proxy.so"))
        return o
    }

    /**
     * Only one VPN at a time — stop the v2rayNG core AND all our engines and
     * WAIT until the TUN slot is really released (port of panels-manager
     * stopEnginesAndWait, extended for the host core).
     */
    fun stopEnginesAndWait(context: Context) {
        // the host core (Xray VPN) holds the single VPN slot too — stop it as well
        try {
            LauncherManager.stopService(context)
        } catch (_: Throwable) {
        }
        if (VpnState.isRunning) {
            context.startService(Intent(context, MhrvVpnService::class.java).setAction(MhrvVpnService.ACTION_STOP))
        }
        if (SlipVpnService.running) {
            context.startService(Intent(context, SlipVpnService::class.java).setAction(SlipVpnService.ACTION_STOP))
        }
        if (TorVpnService.running) {
            context.startService(Intent(context, TorVpnService::class.java).setAction(TorVpnService.ACTION_STOP))
        }
        if (ShkVpnService.running) {
            context.startService(Intent(context, ShkVpnService::class.java).setAction(ShkVpnService.ACTION_STOP))
        }
        val t0 = SystemClock.elapsedRealtime()
        while (SystemClock.elapsedRealtime() - t0 < POLL_STOP_MAX_MS) {
            if (!VpnState.isRunning && !SlipVpnService.running && !TorVpnService.running && !ShkVpnService.running) {
                try { Thread.sleep(300) } catch (_: InterruptedException) {}
                // give the host core's async teardown a moment too
                try { Thread.sleep(800) } catch (_: InterruptedException) {}
                return
            }
            try { Thread.sleep(150) } catch (_: InterruptedException) { return }
        }
    }

    /** Call AFTER VpnService.prepare() returned null or consent was granted. */
    fun launchEngine(context: Context, engine: PanelEngine) {
        val svc = when (engine) {
            PanelEngine.MHRV -> MhrvVpnService::class.java
            PanelEngine.SLIP -> SlipVpnService::class.java
            PanelEngine.TOR -> TorVpnService::class.java
            PanelEngine.SHK -> ShkVpnService::class.java
        }
        val i = Intent(context, svc)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(i)
        } else {
            context.startService(i)
        }
    }

    /** Returns the consent intent when the system VPN permission dialog must be shown. */
    fun prepareVpn(context: Context): Intent? = VpnService.prepare(context)

    // ------------------------------------------------------------------
    // mhrv-rs (MHR / گوگل اسکریپت)
    // ------------------------------------------------------------------
    fun mhrvSaveConfig(context: Context, configJson: String) {
        context.getSharedPreferences(MhrvVpnService.PREFS, Context.MODE_PRIVATE)
            .edit().putString(MhrvVpnService.KEY_CONFIG, configJson).apply()
    }

    fun mhrvStop(context: Context) {
        context.startService(Intent(context, MhrvVpnService::class.java).setAction(MhrvVpnService.ACTION_STOP))
    }

    fun mhrvStatus(): JSONObject {
        val o = JSONObject()
        o.put("running", VpnState.isRunning)
        val h = VpnState.proxyHandle
        o.put("stats", if (h != 0L) Native.statsJson(h) else "")
        o.put("logs", Native.drainLogs())
        return o
    }

    fun buildMhrvConfig(scriptIds: List<String>, authKey: String): String {
        val o = JSONObject()
        o.put("mode", "apps_script")
        o.put("listen_host", "127.0.0.1")
        o.put("listen_port", 8080)
        o.put("socks5_port", 1080)
        o.put("script_ids", JSONArray(scriptIds))
        o.put("auth_key", authKey)
        o.put("front_domain", "www.google.com")
        o.put("google_ip", "142.251.36.68")
        o.put("verify_ssl", true)
        return o.toString()
    }

    // ------------------------------------------------------------------
    // SlipNet / Tor / Psiphon
    // ------------------------------------------------------------------
    fun slipSave(context: Context, uri: String, dns: String) {
        context.getSharedPreferences(SlipVpnService.PREFS, Context.MODE_PRIVATE).edit()
            .putString(SlipVpnService.KEY_URI, uri)
            .putString(SlipVpnService.KEY_DNS, dns)
            .apply()
    }

    fun torSave(context: Context, bridges: String) {
        context.getSharedPreferences(TorVpnService.PREFS, Context.MODE_PRIVATE).edit()
            .putString(TorVpnService.KEY_BRIDGES, bridges)
            .apply()
    }

    fun shkSetRegion(region: String) {
        ShkVpnService.region = region.trim()
    }

    fun stopEngine(context: Context, engine: PanelEngine) {
        val svc = when (engine) {
            PanelEngine.MHRV -> MhrvVpnService::class.java
            PanelEngine.SLIP -> SlipVpnService::class.java
            PanelEngine.TOR -> TorVpnService::class.java
            PanelEngine.SHK -> ShkVpnService::class.java
        }
        val action = when (engine) {
            PanelEngine.MHRV -> MhrvVpnService.ACTION_STOP
            PanelEngine.SLIP -> SlipVpnService.ACTION_STOP
            PanelEngine.TOR -> TorVpnService.ACTION_STOP
            PanelEngine.SHK -> ShkVpnService.ACTION_STOP
        }
        context.startService(Intent(context, svc).setAction(action))
    }

    // ------------------------------------------------------------------
    // Shared helpers
    // ------------------------------------------------------------------
    fun dnsProbe(ips: List<String>): JSONArray {
        val arr = JSONArray()
        val list = ips.map { it.trim() }.filter { it.isNotEmpty() }.take(20)
        val ths = list.map { ip ->
            Thread {
                val ms = DnsProbe.probe(ip)
                synchronized(arr) {
                    arr.put(JSONObject().put("ip", ip).put("ms", ms))
                }
            }
        }
        ths.forEach { it.start() }
        ths.forEach { it.join(5000) }
        return arr
    }

    fun caInfo(context: Context): JSONObject {
        initNative(context)
        val ok = try { CaInstall.export(context) } catch (_: Throwable) { false }
        val fp = if (ok) try { CaInstall.fingerprint(context) } catch (_: Throwable) { null } else null
        val o = JSONObject()
        o.put("exists", ok)
        o.put("installed", fp != null && try { CaInstall.isInstalled(fp) } catch (_: Throwable) { false })
        o.put("fingerprint", if (fp != null) try { CaInstall.fingerprintHex(fp) } catch (_: Throwable) { "" } else "")
        return o
    }

    /** Exports the CA into Downloads and opens the security settings (returns file name or ""). */
    fun caInstall(context: Context): String {
        initNative(context)
        val ok = try { CaInstall.export(context) } catch (_: Throwable) { false }
        val saved = if (ok) try { CaInstall.saveToDownloads(context) } catch (_: Throwable) { null } else null
        if (saved != null) {
            val i = Intent(android.provider.Settings.ACTION_SECURITY_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(i)
        }
        return saved ?: ""
    }
}

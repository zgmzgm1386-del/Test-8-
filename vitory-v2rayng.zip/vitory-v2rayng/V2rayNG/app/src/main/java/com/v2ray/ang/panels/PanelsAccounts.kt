package com.v2ray.ang.panels

import org.json.JSONArray
import org.json.JSONObject

/**
 * Panel "accounts" (پنل‌های مستقرشده روی Cloudflare / Railway / Reflex).
 *
 * Same data model as the panels-manager `acc_v1` store so the user can import
 * accounts created there (via the Import button) and keep using them here.
 */
data class PanelAccount(
    val id: String,
    val platform: String,      // "cf" | "rw" | "rf"
    val preset: String,        // edge / x4gg / x4g / nahan / nova / zeus / cfnew / bpb / miliconfig / px / 3x / rvgx ...
    val name: String,          // workerName / service name
    val host: String,          // panel host (e.g. my-worker.workers.dev)
    val token: String,         // API token
    val email: String,
    val uuid: String,
    val trPass: String,        // admin password
    val subPath: String,
    val accountId: String,     // cf account id
    val projectId: String,     // railway project id
    val serviceId: String,     // railway service id
    val environmentId: String, // railway environment id
    val apiRoute: String,      // nahan api route
)

object PanelsAccounts {

    private const val KEY_ACCOUNTS = "accounts_v1"

    fun load(): MutableList<PanelAccount> {
        val out = ArrayList<PanelAccount>()
        val raw = PanelsStore.getString(KEY_ACCOUNTS, "")
        if (raw.isBlank()) return out
        return try {
            val o = JSONObject(raw)
            val arr = o.optJSONArray("a") ?: return out
            for (i in 0 until arr.length()) {
                val a = arr.optJSONObject(i) ?: continue
                out.add(
                    PanelAccount(
                        id = PanelsStore.optString(a, "id"),
                        platform = PanelsStore.optString(a, "platform"),
                        preset = PanelsStore.optString(a, "preset"),
                        name = PanelsStore.optString(a, "workerName").ifBlank { PanelsStore.optString(a, "name") },
                        host = PanelsStore.optString(a, "host"),
                        token = PanelsStore.optString(a, "token"),
                        email = PanelsStore.optString(a, "email"),
                        uuid = PanelsStore.optString(a, "uuid"),
                        trPass = PanelsStore.optString(a, "trPass"),
                        subPath = PanelsStore.optString(a, "subPath"),
                        accountId = PanelsStore.optString(a, "accountId"),
                        projectId = PanelsStore.optString(a, "projectId"),
                        serviceId = PanelsStore.optString(a, "serviceId"),
                        environmentId = PanelsStore.optString(a, "environmentId"),
                        apiRoute = PanelsStore.optString(a, "apiRoute"),
                    )
                )
            }
            out
        } catch (_: Throwable) {
            out
        }
    }

    fun save(accounts: List<PanelAccount>) {
        val arr = JSONArray()
        accounts.forEach { a ->
            arr.put(
                JSONObject()
                    .put("id", a.id)
                    .put("platform", a.platform)
                    .put("preset", a.preset)
                    .put("workerName", a.name)
                    .put("host", a.host)
                    .put("token", a.token)
                    .put("email", a.email)
                    .put("uuid", a.uuid)
                    .put("trPass", a.trPass)
                    .put("subPath", a.subPath)
                    .put("accountId", a.accountId)
                    .put("projectId", a.projectId)
                    .put("serviceId", a.serviceId)
                    .put("environmentId", a.environmentId)
                    .put("apiRoute", a.apiRoute)
            )
        }
        if (arr.length() == 0) PanelsStore.remove(KEY_ACCOUNTS)
        else PanelsStore.putString(KEY_ACCOUNTS, JSONObject().put("a", arr).toString())
    }

    /** Import from the panels-manager clipboard/file backup (`acc_v1` JSON). */
    fun importFromPanelsManagerBackup(json: String): Int {
        val o = try { JSONObject(json) } catch (_: Throwable) { return 0 }
        val arr = o.optJSONArray("a") ?: return 0
        val current = load()
        var added = 0
        for (i in 0 until arr.length()) {
            val a = arr.optJSONObject(i) ?: continue
            val id = PanelsStore.optString(a, "id").ifBlank {
                PanelsStore.optString(a, "platform") + "::" + PanelsStore.optString(a, "workerName")
            }
            if (current.any { it.id == id }) continue
            current.add(
                PanelAccount(
                    id = id,
                    platform = PanelsStore.optString(a, "platform"),
                    preset = PanelsStore.optString(a, "preset"),
                    name = PanelsStore.optString(a, "workerName").ifBlank { PanelsStore.optString(a, "name") },
                    host = PanelsStore.optString(a, "host"),
                    token = PanelsStore.optString(a, "token"),
                    email = PanelsStore.optString(a, "email"),
                    uuid = PanelsStore.optString(a, "uuid"),
                    trPass = PanelsStore.optString(a, "trPass"),
                    subPath = PanelsStore.optString(a, "subPath"),
                    accountId = PanelsStore.optString(a, "accountId"),
                    projectId = PanelsStore.optString(a, "projectId"),
                    serviceId = PanelsStore.optString(a, "serviceId"),
                    environmentId = PanelsStore.optString(a, "environmentId"),
                    apiRoute = PanelsStore.optString(a, "apiRoute"),
                )
            )
            added++
        }
        if (added > 0) save(current)
        return added
    }

    /** Path of the real admin panel of an account (same mapping as panels-manager `panelPath`). */
    fun panelPath(a: PanelAccount): String = when {
        a.platform == "rf" -> if (a.preset == "rvgx" || a.preset == "rvgx2") "/login" else "/"
        a.platform == "rw" -> "/"
        else -> when (a.preset) {
            "edge", "x4gg", "x4g" -> "/admin"
            "nahan" -> if (a.apiRoute.isNotBlank()) "/" + a.apiRoute + "/dash" else "/sync/dash"
            "px" -> "/"
            "bpb" -> "/panel"
            "miliconfig" -> "/" + a.uuid.ifBlank { "panel" }
            "cfnew" -> "/"
            "nova" -> "/panel"
            "zeus" -> "/panel"
            else -> "/panel"
        }
    }

    fun panelUrl(a: PanelAccount): String =
        if (a.host.isBlank()) "" else "https://" + a.host + panelPath(a)

    fun platformName(p: String): String = when (p) {
        "cf" -> "Cloudflare"
        "rw" -> "Railway"
        "rf" -> "Reflex"
        else -> p
    }

    fun presetName(p: String): String = when (p) {
        "edge" -> "EdgeTunnel"
        "x4gg" -> "ترکیبی X4G"
        "x4g" -> "X4G"
        "nahan" -> "Nahan"
        "nova" -> "Nova"
        "zeus" -> "ZEUS"
        "cfnew" -> "CFnew"
        "bpb" -> "BPB"
        "miliconfig" -> "MiLiConfig"
        "px" -> "PX"
        "3x" -> "3x-ui"
        "rvgx", "rvgx2" -> "RVG Reflex"
        else -> p
    }
}

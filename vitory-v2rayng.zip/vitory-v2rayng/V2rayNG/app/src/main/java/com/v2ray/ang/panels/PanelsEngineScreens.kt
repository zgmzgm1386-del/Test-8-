package com.v2ray.ang.panels

import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import com.v2ray.ang.ui.base.BaseComponentActivity
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import com.v2ray.ang.ui.compose.SettingsEditItem
import com.v2ray.ang.ui.compose.SettingsMenuItem
import com.v2ray.ang.ui.compose.SettingsSwitchItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * The four local engine screens (SlipNet / Tor / Shir-o-Khorshid / MHR).
 * Connection flow is a faithful port of the panels-manager engines:
 * stop other engines → wait for TUN slot → VPN consent → foreground service,
 * verification done inside the services by a real HTTPS probe.
 */

// ═══════════════════════════════════════════════════════════════════
// SlipNet
// ═══════════════════════════════════════════════════════════════════
class SlipnetActivity : BaseComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    @Composable
    override fun ScreenContent() = SlipnetScreen(onBackClick = { finish() })
}

@Composable
fun SlipnetScreen(onBackClick: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var profilesJson by PanelsStore.rememberPanelString("slip_profiles", "[]")
    var sel by PanelsStore.rememberPanelString("slip_sel", "0")
    var dnsOverride by PanelsStore.rememberPanelString("slip_dns", "")
    var autoRescan by PanelsStore.rememberPanelBool("slip_autores", false)
    var snap by remember { mutableStateOf(JSONObject()) }
    var busy by remember { mutableStateOf(false) }
    var probeText by remember { mutableStateOf("") }

    val vpnConsent = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == android.app.Activity.RESULT_OK) {
            PanelsBridge.launchEngine(context, PanelEngine.SLIP)
        }
    }

    fun connect(uri: String, dns: String) {
        if (uri.isBlank()) return
        busy = true
        scope.launch(Dispatchers.IO) {
            PanelsBridge.stopEnginesAndWait(context)
            PanelsBridge.slipSave(context, uri, dns)
            withContext(Dispatchers.Main) {
                busy = false
                val intent = PanelsBridge.prepareVpn(context)
                if (intent != null) vpnConsent.launch(intent)
                else PanelsBridge.launchEngine(context, PanelEngine.SLIP)
            }
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            try {
                snap = JSONObject(SlipVpnServiceSnapshot())
            } catch (_: Throwable) {
            }
            delay(1500)
        }
    }

    val profiles = remember(profilesJson) {
        PanelsStore.fromJsonArray(profilesJson).mapNotNull { PanelsSlip.SlipProfile.fromJson(it) }
    }
    val selIdx = sel.toIntOrNull()?.coerceIn(0, if (profiles.isEmpty()) 0 else profiles.size - 1) ?: 0
    val running = snap.optBoolean("running", false)
    val verified = snap.optBoolean("verified", false)

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = { AppTopBar(title = stringResource(R.string.title_panel_slipnet), onBackClick = onBackClick) }
    ) { innerPadding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            PanelCard(
                title = "تونل SlipNet",
                chipText = if (running) (if (verified) "وصل شد ✓" else "در حال اتصال…") else "قطع",
                chipGood = verified,
            ) {
                Text(
                    if (running) snap.optString("stage", "").ifBlank { "…" }
                    else "تونل داخل DNS (DNSTT/NoizDNS/VayDNS)، SSH یا VLESS — پروفایل را بساز یا لینک slipnet:// ایمپورت کن.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                if (running) {
                    PanelKeyValue("IP خروجی", snap.optString("ip", "").ifBlank { "—" })
                    PanelKeyValue("کشور", snap.optString("loc", "").ifBlank { "—" })
                    Spacer(Modifier.height(6.dp))
                }
                if (running && snap.optString("err", "").isNotBlank()) {
                    Text(
                        snap.optString("err"),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                    Spacer(Modifier.height(6.dp))
                }
                PanelActionRow(
                    connected = running,
                    busy = busy,
                    onConnect = {
                        val p = profiles.getOrNull(selIdx)
                        connect(p?.uri() ?: "", dnsOverride)
                    },
                    onStop = {
                        scope.launch(Dispatchers.IO) { PanelsBridge.stopEngine(context, PanelEngine.SLIP) }
                    },
                    connectLabel = "وصل کردن SlipNet",
                    stopLabel = "قطع",
                )
            }
            Spacer(Modifier.height(10.dp))

            // Profile list
            if (profiles.isEmpty()) {
                Text(
                    "هنوز پروفایلی نداری — «پروفایل جدید» را بزن یا لینک slipnet:// را ایمپورت کن.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                profiles.forEachIndexed { i, p ->
                    val selected = i == selIdx
                    SettingsMenuItem(
                        icon = painterResource(R.drawable.ic_panel_slipnet_24dp),
                        title = (if (selected) "● " else "") + p.name.ifBlank { "SlipNet" },
                        subtitle = p.type + (if (p.domain.isNotBlank()) " · " + p.domain else ""),
                        onClick = { sel = i.toString() }
                    )
                }
            }
            SettingsMenuItem(
                icon = painterResource(R.drawable.ic_add_24dp),
                title = "پروفایل جدید",
                subtitle = "ساخت فرم DNSTT / SSH / VLESS",
                onClick = { showSlipEditorDialog = true }
            )
            SettingsMenuItem(
                icon = painterResource(R.drawable.ic_cloud_download_24dp),
                title = "ایمپورت از کلیپ‌بورد",
                subtitle = "لینک slipnet:// یا vless://",
                onClick = {
                    val text = com.v2ray.ang.util.Utils.getClipboard(context)
                    val p = PanelsSlip.parse(text ?: "")
                    if (p != null) {
                        val list = PanelsStore.fromJsonArray(profilesJson).toMutableList()
                        list.add(p.toJson())
                        profilesJson = PanelsStore.toJsonArray(list)
                        sel = (list.size - 1).toString()
                        probeText = "پروفایل ایمپورت شد ✓"
                    } else {
                        probeText = "لینک slipnet:// معتبر پیدا نشد"
                    }
                }
            )
            SettingsEditItem(
                icon = painterResource(R.drawable.ic_panel_slipnet_24dp),
                title = "رزولور DNS (اختیاری)",
                value = dnsOverride,
                onValueChanged = { dnsOverride = it }
            )
            SettingsSwitchItem(
                icon = painterResource(R.drawable.ic_scan_24dp),
                title = "اسکن رزولورها",
                summary = "پینگ واقعی UDP/53 روی ۸ رزولور معروف",
                checked = autoRescan,
                onCheckedChange = { autoRescan = it }
            )
            SettingsMenuItem(
                icon = painterResource(R.drawable.ic_scan_24dp),
                title = "اجرای اسکن رزولور",
                subtitle = probeText.ifBlank { "سریع‌ترین رزولور سالم را پیدا کن" },
                onClick = {
                    scope.launch(Dispatchers.IO) {
                        val arr = PanelsBridge.dnsProbe(PanelsScanner.RESOLVERS)
                        val good = (0 until arr.length()).map { arr.getJSONObject(it) }
                            .filter { it.optInt("ms", -1) > 0 }
                            .minByOrNull { it.optInt("ms", Int.MAX_VALUE) }
                        withContext(Dispatchers.Main) {
                            probeText = if (good != null)
                                "سریع‌ترین: " + good.optString("ip") + " (" + good.optInt("ms") + "ms) — آن را در فیلد رزولور بنویس"
                            else "هیچ رزولوری جواب نداد — پورت ۵۳ اپراتورت بسته است"
                        }
                    }
                }
            )
            Spacer(Modifier.height(10.dp))
            if (running) {
                PreferenceHeader("لاگ موتور")
                PanelLogBox(snap.optString("logs", ""))
            }
            NavigationBarsSpacer()
        }
    }

    if (showSlipEditorDialog) {
        SlipEditorDialog(
            onDismiss = { showSlipEditorDialog = false },
            onSave = { p ->
                val list = PanelsStore.fromJsonArray(profilesJson).toMutableList()
                list.add(p.toJson())
                profilesJson = PanelsStore.toJsonArray(list)
                sel = (list.size - 1).toString()
                showSlipEditorDialog = false
            }
        )
    }
}

private var showSlipEditorDialog by mutableStateOf(false)

@Composable
private fun PreferenceHeader(title: String) {
    com.v2ray.ang.ui.compose.PreferenceGroupHeader(title = title)
}

@Composable
private fun SlipEditorDialog(onDismiss: () -> Unit, onSave: (PanelsSlip.SlipProfile) -> Unit) {
    var type by remember { mutableStateOf("dnstt") }
    var name by remember { mutableStateOf("") }
    var domain by remember { mutableStateOf("") }
    var resolvers by remember { mutableStateOf("8.8.8.8:53:0") }
    var pubkey by remember { mutableStateOf("") }
    var sshHost by remember { mutableStateOf("") }
    var sshPort by remember { mutableStateOf("22") }
    var sshUser by remember { mutableStateOf("root") }
    var sshPass by remember { mutableStateOf("") }
    val isSsh = type == "ssh" || type == "socks5" || type.contains("_ssh")

    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text("پروفایل جدید SlipNet") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    "DNSTT/NoizDNS/VayDNS = تونل داخل DNS. SSH/SOCKS5/VLESS = مستقیم.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                com.v2ray.ang.ui.compose.FormDropdownField(
                    label = "نوع تونل",
                    value = PanelsSlip.TYPES.firstOrNull { it.first == type }?.second ?: "DNSTT (پیشنهادی)",
                    options = PanelsSlip.TYPES.map { it.second },
                    onValueChange = { label -> type = PanelsSlip.TYPES.firstOrNull { it.second == label }?.first ?: "dnstt" }
                )
                com.v2ray.ang.ui.compose.FormTextField(label = "نام پروفایل", value = name, onValueChange = { name = it })
                com.v2ray.ang.ui.compose.FormTextField(label = "دامنهٔ تونل (NS)", value = domain, onValueChange = { domain = it })
                com.v2ray.ang.ui.compose.FormTextField(label = "رزولورها", value = resolvers, onValueChange = { resolvers = it })
                com.v2ray.ang.ui.compose.FormTextField(label = "کلید عمومی Noise", value = pubkey, onValueChange = { pubkey = it })
                if (isSsh) {
                    com.v2ray.ang.ui.compose.FormTextField(label = "سرور SSH", value = sshHost, onValueChange = { sshHost = it })
                    com.v2ray.ang.ui.compose.FormTextField(label = "پورت SSH", value = sshPort, onValueChange = { sshPort = it })
                    com.v2ray.ang.ui.compose.FormTextField(label = "کاربر SSH", value = sshUser, onValueChange = { sshUser = it })
                    com.v2ray.ang.ui.compose.FormTextField(label = "رمز SSH", value = sshPass, onValueChange = { sshPass = it })
                }
            }
        },
        confirmButton = {
            androidx.compose.material3.TextButton(onClick = {
                val p = PanelsSlip.SlipProfile(
                    type = type, name = name.ifBlank { "SlipNet" }, domain = domain, resolvers = resolvers,
                    pubkey = pubkey, sshHost = sshHost, sshPort = sshPort.toIntOrNull() ?: 22,
                    sshUser = sshUser, sshPass = sshPass,
                )
                if (p.domain.isBlank() && p.type != "vless" && p.type != "ssh" && p.type != "socks5") return@TextButton
                onSave(p)
            }) { Text("ذخیره پروفایل") }
        },
        dismissButton = {
            androidx.compose.material3.TextButton(onClick = onDismiss) { Text("لغو") }
        }
    )
}

/** helper so the polling loop can read the service snapshot without importing internals twice */
private fun SlipVpnServiceSnapshot(): String = com.therealaleph.mhrv.SlipVpnService.snapshot()

// ═══════════════════════════════════════════════════════════════════
// Tor
// ═══════════════════════════════════════════════════════════════════
class TorActivity : BaseComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    @Composable
    override fun ScreenContent() = TorScreen(onBackClick = { finish() })
}

@Composable
fun TorScreen(onBackClick: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var bridges by PanelsStore.rememberPanelString("tor_bridges", "")
    var snap by remember { mutableStateOf(JSONObject()) }
    var busy by remember { mutableStateOf(false) }

    val vpnConsent = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == android.app.Activity.RESULT_OK) {
            PanelsBridge.launchEngine(context, PanelEngine.TOR)
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            try {
                snap = JSONObject(com.therealaleph.mhrv.TorVpnService.snapshot())
            } catch (_: Throwable) {
            }
            delay(1500)
        }
    }

    val running = snap.optBoolean("running", false)
    val verified = snap.optBoolean("verified", false)

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = { AppTopBar(title = stringResource(R.string.title_panel_tor), onBackClick = onBackClick) }
    ) { innerPadding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            PanelCard(
                title = "شبکهٔ پیازی Tor (Arti)",
                chipText = if (running) (if (verified) "وصل شد ✓" else "در حال اتصال…") else "قطع",
                chipGood = verified,
            ) {
                Text(
                    if (running) snap.optString("stage", "").ifBlank { "…" }
                    else "موتور Tor داخل APK — بدون کانفیگ وصل می‌شود. اگر اپراتورت Tor را می‌بندد، پل obfs4 بده.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                if (running) {
                    PanelKeyValue("IP خروجی", snap.optString("ip", "").ifBlank { "—" })
                    PanelKeyValue("کشور", snap.optString("loc", "").ifBlank { "—" })
                    Spacer(Modifier.height(6.dp))
                }
                PanelActionRow(
                    connected = running,
                    busy = busy,
                    onConnect = {
                        busy = true
                        scope.launch(Dispatchers.IO) {
                            PanelsBridge.stopEnginesAndWait(context)
                            PanelsBridge.torSave(context, bridges)
                            withContext(Dispatchers.Main) {
                                busy = false
                                val intent = PanelsBridge.prepareVpn(context)
                                if (intent != null) vpnConsent.launch(intent)
                                else PanelsBridge.launchEngine(context, PanelEngine.TOR)
                            }
                        }
                    },
                    onStop = {
                        scope.launch(Dispatchers.IO) { PanelsBridge.stopEngine(context, PanelEngine.TOR) }
                    },
                    connectLabel = "وصل کردن Tor",
                    stopLabel = "قطع",
                )
            }
            Spacer(Modifier.height(10.dp))
            SettingsEditItem(
                icon = painterResource(R.drawable.ic_panel_tor_24dp),
                title = "پل‌های obfs4",
                value = bridges,
                onValueChanged = { bridges = it },
            )
            SettingsMenuItem(
                icon = painterResource(R.drawable.ic_cloud_download_24dp),
                title = "گرفتن خودکار پل",
                subtitle = "bridges.torproject.org — پل‌های obfs4 امروز",
                onClick = {
                    scope.launch(Dispatchers.IO) {
                        val r = PanelsSecEngine.oFetch(
                            "https://bridges.torproject.org/bridges?transport=obfs4",
                            ua = "Mozilla/5.0 (X11; Linux x86_64; rv:120.0) Gecko/20100101 Firefox/120.0"
                        )
                        val body = try { JSONObject(r).optString("body", "") } catch (_: Throwable) { "" }
                        val lines = Regex("obfs4 [^\\s<]+[^\\n<]*").findAll(body)
                            .map { it.value.trim() }.toList().joinToString("\n")
                        withContext(Dispatchers.Main) {
                            if (lines.isNotBlank()) bridges = lines
                        }
                    }
                }
            )
            Spacer(Modifier.height(10.dp))
            if (running) {
                PreferenceHeader("لاگ موتور")
                PanelLogBox(snap.optString("logs", ""))
            }
            NavigationBarsSpacer()
        }
    }
}

// ═══════════════════════════════════════════════════════════════════
// Shir-o-Khorshid (Psiphon)
// ═══════════════════════════════════════════════════════════════════
class ShkActivity : BaseComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    @Composable
    override fun ScreenContent() = ShkScreen(onBackClick = { finish() })
}

private val SHK_REGIONS = listOf(
    "" to "🌐 خودکار", "DE" to "🇩🇪 آلمان", "NL" to "🇳🇱 هلند", "GB" to "🇬🇧 انگلیس",
    "US" to "🇺🇸 آمریکا", "FR" to "🇫🇷 فرانسه", "CA" to "🇨🇦 کانادا", "SE" to "🇸🇪 سوئد",
    "CH" to "🇨🇭 سوئیس", "JP" to "🇯🇵 ژاپن", "SG" to "🇸🇬 سنگاپور", "IN" to "🇮🇳 هند",
    "HK" to "🇭🇰 هنگ‌کنگ", "AT" to "🇦🇹 اتریش", "BE" to "🇧🇪 بلژیک", "ES" to "🇪🇸 اسپانیا",
    "IT" to "🇮🇹 ایتالیا", "PL" to "🇵🇱 لهستان", "NO" to "🇳🇴 نروژ", "DK" to "🇩🇰 دانمارک",
)

@Composable
fun ShkScreen(onBackClick: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var region by PanelsStore.rememberPanelString("shk_region", "")
    var snap by remember { mutableStateOf(JSONObject()) }
    var busy by remember { mutableStateOf(false) }

    val vpnConsent = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == android.app.Activity.RESULT_OK) {
            PanelsBridge.launchEngine(context, PanelEngine.SHK)
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            try {
                snap = JSONObject(com.therealaleph.mhrv.ShkVpnService.snapshot())
            } catch (_: Throwable) {
            }
            delay(1500)
        }
    }

    val running = snap.optBoolean("running", false)
    val verified = snap.optBoolean("verified", false)

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = { AppTopBar(title = stringResource(R.string.title_panel_shk), onBackClick = onBackClick) }
    ) { innerPadding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            PanelCard(
                title = "شیر و خورشید (سایفون داخل اپ)",
                chipText = if (running) (if (verified) "وصل شد ✓" else "در حال اتصال…") else "قطع",
                chipGood = verified,
            ) {
                Text(
                    if (running) snap.optString("stage", "").ifBlank { "…" }
                    else "هستهٔ Psiphon با پیکربندی تعبیه‌شدهٔ شبکه — صفر کانفیگ، فقط وصل بزن.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                if (running) {
                    PanelKeyValue("IP خروجی", snap.optString("ip", "").ifBlank { "—" })
                    PanelKeyValue("کشور", snap.optString("loc", "").ifBlank { "—" })
                    Spacer(Modifier.height(6.dp))
                }
                PanelActionRow(
                    connected = running,
                    busy = busy,
                    onConnect = {
                        busy = true
                        scope.launch(Dispatchers.IO) {
                            PanelsBridge.stopEnginesAndWait(context)
                            PanelsBridge.shkSetRegion(region)
                            withContext(Dispatchers.Main) {
                                busy = false
                                val intent = PanelsBridge.prepareVpn(context)
                                if (intent != null) vpnConsent.launch(intent)
                                else PanelsBridge.launchEngine(context, PanelEngine.SHK)
                            }
                        }
                    },
                    onStop = {
                        scope.launch(Dispatchers.IO) { PanelsBridge.stopEngine(context, PanelEngine.SHK) }
                    },
                    connectLabel = "وصل کردن سایفون",
                    stopLabel = "قطع",
                )
            }
            Spacer(Modifier.height(10.dp))
            PreferenceHeader("🌍 کشور خروجی")
            Text(
                "اگر کشور انتخابی سرور نداشته باشد Psiphon خودش نزدیک‌ترین را می‌گیرد. بعد از تغییر یک بار قطع و وصل کن.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            RegionGrid(selected = region, onSelect = { region = it })
            Spacer(Modifier.height(10.dp))
            if (running) {
                PreferenceHeader("لاگ موتور")
                PanelLogBox(snap.optString("logs", ""), maxLines = 8)
            }
            NavigationBarsSpacer()
        }
    }
}

@Composable
private fun RegionGrid(selected: String, onSelect: (String) -> Unit) {
    // simple flow of chips (4 per row) built without flow-layout dependency
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        SHK_REGIONS.chunked(4).forEach { rowItems ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowItems.forEach { (code, label) ->
                    val on = code == selected
                    androidx.compose.material3.Surface(
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
                        color = if (on) MaterialTheme.colorScheme.secondaryContainer
                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onSelect(code) }
                    ) {
                        Text(
                            label,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (on) MaterialTheme.colorScheme.onSecondaryContainer
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
                repeat(4 - rowItems.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════
// گوگل / MHR (mhrv-rs)
// ═══════════════════════════════════════════════════════════════════
class MhrActivity : BaseComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    @Composable
    override fun ScreenContent() = MhrScreen(onBackClick = { finish() })
}

@Composable
fun MhrScreen(onBackClick: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var authKey by PanelsStore.rememberPanelString("mhr_key", "")
    var deployIds by PanelsStore.rememberPanelString("mhr_ids", "")
    var caState by remember { mutableStateOf(JSONObject()) }
    var status by remember { mutableStateOf(JSONObject()) }
    var busy by remember { mutableStateOf(false) }
    var testResult by remember { mutableStateOf("") }

    val vpnConsent = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == android.app.Activity.RESULT_OK) {
            PanelsBridge.launchEngine(context, PanelEngine.MHRV)
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            try {
                status = PanelsBridge.mhrvStatus()
            } catch (_: Throwable) {
            }
            delay(1500)
        }
    }

    val running = status.optBoolean("running", false)

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = { AppTopBar(title = stringResource(R.string.title_panel_mhr), onBackClick = onBackClick) }
    ) { innerPadding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            PanelCard(
                title = "گوگل اسکریپت / MHR",
                chipText = if (running) "فعال" else "قطع",
                chipGood = running,
            ) {
                Text(
                    "تونل عبوری از Google Apps Script — موتور mhrv-rs داخل اپ. اول Code.gs را با کلید خودت دیپلوی کن، بعد Deployment ID را بده.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                PanelActionRow(
                    connected = running,
                    busy = busy,
                    onConnect = {
                        if (authKey.isBlank() || deployIds.isBlank()) {
                            testResult = "اول کلید و Deployment ID را پر کن"
                            return@PanelActionRow
                        }
                        busy = true
                        scope.launch(Dispatchers.IO) {
                            PanelsBridge.stopEnginesAndWait(context)
                            val ids = deployIds.lines().map { it.trim() }.filter { it.isNotBlank() }
                            PanelsBridge.mhrvSaveConfig(context, PanelsBridge.buildMhrvConfig(ids, authKey))
                            withContext(Dispatchers.Main) {
                                busy = false
                                val intent = PanelsBridge.prepareVpn(context)
                                if (intent != null) vpnConsent.launch(intent)
                                else PanelsBridge.launchEngine(context, PanelEngine.MHRV)
                            }
                        }
                    },
                    onStop = {
                        scope.launch(Dispatchers.IO) { PanelsBridge.stopEngine(context, PanelEngine.MHRV) }
                    },
                    connectLabel = "شروع MHR",
                    stopLabel = "قطع",
                )
            }
            Spacer(Modifier.height(10.dp))
            SettingsEditItem(
                icon = painterResource(R.drawable.ic_lock_24dp),
                title = "کلید AUTH (رمز Code.gs)",
                value = authKey,
                onValueChanged = { authKey = it },
                isPassword = true
            )
            SettingsEditItem(
                icon = painterResource(R.drawable.ic_description_24dp),
                title = "Deployment IDها (هر خط یکی)",
                value = deployIds,
                onValueChanged = { deployIds = it }
            )
            SettingsMenuItem(
                icon = painterResource(R.drawable.ic_copy),
                title = "کپی Code.gs (با کلید خودت)",
                subtitle = "برای دیپلوی در script.google.com",
                onClick = {
                    scope.launch(Dispatchers.IO) {
                        val gs = try {
                            context.assets.open("code_gs.txt").bufferedReader().use { it.readText() }
                        } catch (_: Throwable) {
                            ""
                        }
                        val out = if (gs.isNotBlank()) gs.replace("CHANGE_ME_TO_A_STRONG_SECRET", authKey.ifBlank { "CHANGE_ME_TO_A_STRONG_SECRET" }) else ""
                        withContext(Dispatchers.Main) {
                            if (out.isNotBlank()) {
                                com.v2ray.ang.util.Utils.setClipboard(context, out)
                                testResult = "Code.gs کپی شد — در Apps Script پیست و Deploy کن"
                            } else testResult = "Code.gs در APK نیست"
                        }
                    }
                }
            )
            SettingsMenuItem(
                icon = painterResource(R.drawable.ic_lock_24dp),
                title = "گواهی CA",
                subtitle = try {
                    if (caState.optBoolean("installed", false)) "نصب شده ✓ " + caState.optString("fingerprint").take(16)
                    else if (caState.optBoolean("exists", false)) "ساخته شده — نصبش کن"
                    else "برای دیدن وضعیت لمس کن"
                } catch (_: Throwable) {
                    ""
                },
                onClick = {
                    scope.launch(Dispatchers.IO) {
                        val info = PanelsBridge.caInfo(context)
                        withContext(Dispatchers.Main) { caState = info }
                        if (!info.optBoolean("installed", false)) {
                            PanelsBridge.caInstall(context)
                        }
                    }
                }
            )
            SettingsMenuItem(
                icon = painterResource(R.drawable.ic_qu_start_24dp),
                title = "تست رله",
                subtitle = testResult.ifBlank { "درخواست واقعی به script.google.com" },
                onClick = {
                    if (deployIds.isBlank()) {
                        testResult = "اول Deployment ID بده"
                        return@SettingsMenuItem
                    }
                    scope.launch(Dispatchers.IO) {
                        val id = deployIds.lines().map { it.trim() }.firstOrNull { it.isNotBlank() } ?: ""
                        val r = PanelsSecEngine.oFetch("https://script.google.com/macros/s/$id/exec")
                        val ok = try { JSONObject(r).optInt("ok", 0) == 1 } catch (_: Throwable) { false }
                        withContext(Dispatchers.Main) {
                            testResult = if (ok) "رله جواب داد ✓ (کد " + try { JSONObject(r).optInt("status") } catch (_: Throwable) { 0 } + ")" else "رله جواب نداد — ID/دیسپلوی را چک کن"
                        }
                    }
                }
            )
            if (running) {
                val stats = try { JSONObject(status.optString("stats", "{}")) } catch (_: Throwable) { JSONObject() }
                if (stats.length() > 0) {
                    Spacer(Modifier.height(10.dp))
                    PreferenceHeader("آمار موتور (سهمیهٔ امروز)")
                    PanelKeyValue("درخواست‌های امروز", stats.optInt("today_calls", 0).toString())
                    PanelKeyValue("رله کل", stats.optInt("relay_calls", 0).toString())
                    PanelKeyValue("خطاها", stats.optInt("relay_failures", 0).toString())
                }
                Spacer(Modifier.height(10.dp))
                PreferenceHeader("لاگ موتور")
                PanelLogBox(status.optString("logs", ""))
            }
            NavigationBarsSpacer()
        }
    }
}

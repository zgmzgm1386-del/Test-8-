package com.v2ray.ang.panels

import android.os.Bundle
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import com.v2ray.ang.ui.base.BaseComponentActivity
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import com.v2ray.ang.ui.compose.SettingsEditItem
import com.v2ray.ang.ui.compose.SettingsMenuItem
import com.v2ray.ang.ui.compose.SettingsSwitchItem
import com.v2ray.ang.util.Utils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * اسکن IP — port of the panels-manager scanner: 4 modes (IP / دامنه /
 * پروکسی / DNS) probing real TLS/TCP/DNS. Results can be copied and pushed
 * to the اختلال screen (clean-IP memory).
 */
class ScanActivity : BaseComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    @Composable
    override fun ScreenContent() = ScanScreen(onBackClick = { finish() })
}

private data class ScanRow(val host: String, val ok: Boolean, val ms: Int)

@Composable
fun ScanScreen(onBackClick: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var mode by remember { mutableStateOf("ip") }
    var hardScan by PanelsStore.rememberPanelBool("scan_hard", false)
    var customList by PanelsStore.rememberPanelString("scan_custom", "")
    var running by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0f) }
    var rows by remember { mutableStateOf(listOf<ScanRow>()) }

    val timeout = if (hardScan) 6000 else 3500

    fun buildTargets(m: String): List<String> = when (m) {
        "ip" -> {
            val out = ArrayList<String>()
            val per = if (hardScan) 24 else 12
            PanelsScanner.CF_RANGES_V4.forEach { r -> repeat(per) { out.add(PanelsScanner.randomIpInCidr(r)) } }
            if (customList.isNotBlank()) out.addAll(
                customList.lines().map { it.trim() }.filter { PanelsEkhtelal.isIp(it) }
            )
            out.distinct()
        }
        "dom" -> PanelsScanner.SNI_DOMAINS.toList()
        "proxy" -> {
            val base = listOf(
                "speed.cloudflare.com", "api.ip.sb", "ipinfo.io", "ifconfig.me", "icanhazip.com",
                "api.myip.com", "www.cloudflare.com", "1.1.1.1", "8.8.8.8", "cloudflare-dns.com",
            )
            val custom = customList.lines().map { it.trim() }.filter { it.isNotBlank() }
            (base + custom).distinct()
        }
        "dns" -> (PanelsScanner.RESOLVERS + customList.lines().map { it.trim() }
            .filter { PanelsEkhtelal.isIp(it) }).distinct()
        else -> emptyList()
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = { AppTopBar(title = stringResource(R.string.title_panel_scan), onBackClick = onBackClick) }
    ) { innerPadding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth()) {
                listOf("ip" to "IP", "dom" to "دامنه", "proxy" to "پروکسی", "dns" to "DNS")
                    .forEach { (m, label) ->
                        FilterChip(
                            selected = mode == m,
                            onClick = { if (!running) mode = m },
                            label = { Text(label) },
                            modifier = Modifier
                                .padding(end = 6.dp)
                                .weight(1f)
                        )
                    }
            }
            Spacer(Modifier.height(8.dp))
            SettingsSwitchItem(
                icon = painterResource(R.drawable.ic_scan_24dp),
                title = "اسکن Max",
                summary = "تایم‌اوت بیشتر و تعداد نمونهٔ بیشتر — دقیق‌تر ولی کندتر",
                checked = hardScan,
                onCheckedChange = { hardScan = it }
            )
            SettingsEditItem(
                icon = painterResource(R.drawable.ic_add_24dp),
                title = "لیست دلخواه (هر خط یک مورد)",
                value = customList,
                onValueChanged = { customList = it }
            )
            Spacer(Modifier.height(6.dp))
            PanelActionRow(
                connected = false,
                busy = running,
                onConnect = {
                    val targets = buildTargets(mode)
                    if (targets.isEmpty()) return@PanelActionRow
                    running = true
                    rows = emptyList()
                    progress = 0f
                    scope.launch(Dispatchers.IO) {
                        val m = mode
                        val to = timeout
                        val res = PanelsScanner.probeBatch(targets, if (m == "dns") "dns" else if (m == "dom") "tls" else "tcp", to, 12) { done, total ->
                            progress = if (total > 0) done.toFloat() / total else 0f
                        }
                        withContext(Dispatchers.Main) {
                            rows = res.map { ScanRow(it.host, it.ok, it.ms) }
                                .sortedWith(compareByDescending<ScanRow> { it.ok }.thenBy { if (it.ms <= 0) Int.MAX_VALUE else it.ms })
                            running = false
                            progress = 1f
                        }
                    }
                },
                onStop = { running = false },
                connectLabel = "شروع اسکن",
                stopLabel = "توقف",
            )
            Spacer(Modifier.height(8.dp))
            PanelProgressBar(progress)
            SettingsMenuItem(
                icon = painterResource(R.drawable.ic_copy),
                title = "کپی همهٔ سالم‌ها",
                subtitle = "IP/دامنه‌های سبز، مرتب بر اساس تأخیر",
                onClick = {
                    val ok = rows.filter { it.ok }.joinToString("\n") { it.host }
                    if (ok.isNotBlank()) {
                        Utils.setClipboard(context, ok)
                    }
                }
            )
            SettingsMenuItem(
                icon = painterResource(R.drawable.ic_panel_ekhtelal_24dp),
                title = "اعمال بهترین روی اختلال",
                subtitle = "بهترین IP سالم به‌عنوان IP تمیز ذخیره می‌شود",
                onClick = {
                    val best = rows.filter { it.ok && PanelsEkhtelal.isIp(it.host) }.minByOrNull { it.ms }
                    if (best != null) {
                        PanelsStore.putString("ekht_ip", best.host)
                    }
                }
            )
            Spacer(Modifier.height(8.dp))
            Text(
                if (running) "در حال اسکن… ${(progress * 100).toInt()}٪"
                else if (rows.isEmpty()) "شروع اسکن را بزن — پروب واقعی TLS/TCP/DNS می‌زند"
                else "سالم: ${rows.count { it.ok }} از ${rows.size}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            Box(Modifier.height(320.dp)) {
                LazyColumn {
                    items(rows) { r ->
                        PanelDotRow(r.host, "", r.ok, if (r.ok) "${r.ms}ms" else "بی‌جواب")
                    }
                }
            }
            NavigationBarsSpacer()
        }
    }
}

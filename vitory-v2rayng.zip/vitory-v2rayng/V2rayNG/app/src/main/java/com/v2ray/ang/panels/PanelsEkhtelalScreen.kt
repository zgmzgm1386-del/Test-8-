package com.v2ray.ang.panels

import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.v2ray.ang.AppConfig
import com.v2ray.ang.R
import com.v2ray.ang.core.LauncherManager
import com.v2ray.ang.dto.ProfileItem
import com.v2ray.ang.enums.EConfigType
import com.v2ray.ang.fmt.ShadowsocksFmt
import com.v2ray.ang.fmt.TrojanFmt
import com.v2ray.ang.fmt.VlessFmt
import com.v2ray.ang.fmt.VmessFmt
import com.v2ray.ang.handler.MmkvManager
import com.v2ray.ang.ui.base.BaseComponentActivity
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import com.v2ray.ang.ui.compose.SettingsEditItem
import com.v2ray.ang.ui.compose.SettingsMenuItem
import com.v2ray.ang.ui.compose.SettingsSwitchItem
import com.v2ray.ang.util.Utils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * Link codec between the app's ProfileItem and vmess/vless/trojan/ss URIs
 * (public fmt parsers) — used by the اختلال rewriter.
 */
object PanelsProfileLinks {
    fun toUri(item: ProfileItem): String = try {
        when (item.configType) {
            EConfigType.VMESS -> VmessFmt.toUri(item)
            EConfigType.VLESS -> VlessFmt.toUri(item)
            EConfigType.TROJAN -> TrojanFmt.toUri(item)
            EConfigType.SHADOWSOCKS -> ShadowsocksFmt.toUri(item)
            else -> ""
        }
    } catch (_: Throwable) {
        ""
    }

    fun parse(link: String): ProfileItem? = try {
        when {
            link.startsWith("vmess://", true) -> VmessFmt.parse(link)
            link.startsWith("vless://", true) -> VlessFmt.parse(link)
            link.startsWith("trojan://", true) -> TrojanFmt.parse(link)
            link.startsWith("ss://", true) -> ShadowsocksFmt.parse(link)
            else -> null
        }
    } catch (_: Throwable) {
        null
    }
}

/**
 * اختلال — anti-filter workbench over the app's own profiles (port of the
 * panels-manager اختلال tab): clean-IP + SNI rewrite on the selected profile,
 * DoS protection, DNS filter, smart repair probing, then connect via the
 * normal v2rayNG service.
 */
class EkhtelalActivity : BaseComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    @Composable
    override fun ScreenContent() = EkhtelalScreen(onBackClick = { finish() })
}

@Composable
fun EkhtelalScreen(onBackClick: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var cleanIp by PanelsStore.rememberPanelString("ekht_ip", "")
    var sniDomain by PanelsStore.rememberPanelString("ekht_sni", "")
    var dosProtect by PanelsStore.rememberPanelBool("ekht_dos", true)
    var useSmart by PanelsStore.rememberPanelBool("ekht_smart", true)
    var rememberClean by PanelsStore.rememberPanelBool("ekht_remember", true)
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    val vpnConsent = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == android.app.Activity.RESULT_OK) {
            LauncherManager.startService(context)
        }
    }

    // selected profile + its link
    val selectedGuid = remember { MmkvManager.getSelectServer() }
    val profile = remember(selectedGuid) { selectedGuid?.let { MmkvManager.decodeServerConfig(it) } }
    val profileLink = remember(selectedGuid, profile) {
        profile?.let { PanelsProfileLinks.toUri(it) } ?: ""
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = { AppTopBar(title = stringResource(R.string.title_panel_ekhtelal), onBackClick = onBackClick) }
    ) { innerPadding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            PanelCard(
                title = "ضد اختلال و اتصال",
                chipText = if (profileLink.isNotBlank()) "پروفایل انتخابی موجود" else "پروفالی انتخاب نشده",
                chipGood = profileLink.isNotBlank(),
            ) {
                if (profileLink.isNotBlank()) {
                    Text(
                        "پروفایل فعلی: " + (profile?.remarks ?: "—"),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Text(
                        "اول در صفحهٔ اصلی یک پروفایل (کانفیگ) انتخاب کن؛ این صفحه همان پروفایل را با IP تمیز و SNI سالم ترمیم و وصل می‌کند.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.height(8.dp))
                SettingsEditItem(
                    title = "IP تمیز (ProxyIP)",
                    value = cleanIp,
                    onValueChanged = { cleanIp = it }
                )
                SettingsEditItem(
                    title = "دامنهٔ SNI",
                    value = sniDomain,
                    onValueChanged = { sniDomain = it }
                )
            }
            Spacer(Modifier.height(10.dp))
            SettingsSwitchItem(
                icon = painterResource(R.drawable.ic_panel_shield_24dp),
                title = "محافظت DoS",
                summary = "policy سخت‌گیرانهٔ هسته در برابر حملات قطع اتصال",
                checked = dosProtect,
                onCheckedChange = { dosProtect = it }
            )
            SettingsSwitchItem(
                icon = painterResource(R.drawable.ic_panel_ekhtelal_24dp),
                title = "تعمیرکار هوشمند",
                summary = "قبل از وصل، چند IP تمیز از رنج‌های CF امتحان می‌شود و بهترین اعمال می‌شود",
                checked = useSmart,
                onCheckedChange = { useSmart = it }
            )
            SettingsSwitchItem(
                icon = painterResource(R.drawable.ic_save_24dp),
                title = "یادآوری IP تمیز",
                summary = "IP سالم برای دفعهٔ بعد ذخیره می‌شود",
                checked = rememberClean,
                onCheckedChange = { rememberClean = it }
            )
            Spacer(Modifier.height(10.dp))
            SettingsMenuItem(
                icon = painterResource(R.drawable.ic_scan_24dp),
                title = "اسکن IP تمیز",
                subtitle = "به صفحهٔ اسکن IP برو و نتیجه را همین‌جا اعمال کن",
                onClick = {
                    val intent = android.content.Intent(context, ScanActivity::class.java)
                    context.startActivity(intent)
                }
            )
            PanelActionRow(
                connected = false,
                busy = busy,
                onConnect = {
                    if (profileLink.isBlank()) {
                        message = "اول یک پروفایل انتخاب کن"
                        return@PanelActionRow
                    }
                    busy = true
                    scope.launch(Dispatchers.IO) {
                        var ip = cleanIp.trim()
                        var dom = sniDomain.trim()
                        if (useSmart && ip.isBlank()) {
                            // probe a handful of CF-range candidates and pick the first alive
                            val candidates = (0 until 12).map {
                                PanelsScanner.randomIpInCidr(
                                    PanelsScanner.CF_RANGES_V4[it % PanelsScanner.CF_RANGES_V4.size]
                                )
                            }.distinct()
                            val res = PanelsScanner.probeBatch(candidates, "tls", 2500, 8)
                            val best = res.firstOrNull { it.ok }
                            if (best != null) {
                                ip = best.host
                                if (rememberClean) {
                                    PanelsStore.putString("ekht_ip", ip)
                                }
                            }
                        }
                        val newLink = if (ip.isBlank() && dom.isBlank()) profileLink
                        else PanelsEkhtelal.applyLink(profileLink, ip, dom)
                        val applied = withContext(Dispatchers.Main) {
                            // parse the rewritten link back and update the same profile in place
                            val guid = selectedGuid ?: return@withContext false
                            val old = MmkvManager.decodeServerConfig(guid) ?: return@withContext false
                            if (newLink == profileLink) return@withContext true
                            val parsed = PanelsProfileLinks.parse(newLink) ?: return@withContext false
                            parsed.subscriptionId = old.subscriptionId
                            parsed.remarks = old.remarks
                            MmkvManager.encodeServerConfig(guid, parsed)
                            true
                        }
                        if (applied) {
                            withContext(Dispatchers.Main) { LauncherManager.restartService(context) }
                        } else withContext(Dispatchers.Main) { false }
                        withContext(Dispatchers.Main) {
                            busy = false
                            message = if (!applied) "اعمال نشد — نوع کانفیگ پشتیبانی نمی‌شود"
                            else if (newLink != profileLink) "ترمیم شد و وصل شد ✓ (IP: ${ip.ifBlank { "بدون تغییر"}})"
                            else "وصل شد — بدون تغییر کانفیگ"
                        }
                    }
                },
                onStop = { LauncherManager.stopService(context) },
                connectLabel = "ترمیم و اتصال",
                stopLabel = "قطع اتصال",
            )
            if (message.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(10.dp))
            PanelCard(title = "تست‌های تشخیص") {
                SettingsMenuItem(
                    icon = painterResource(R.drawable.ic_qu_start_24dp),
                    title = "ضربهٔ TCP به 1.1.1.1:443",
                    subtitle = "تست واقعی مسیر خروجی",
                    onClick = {
                        scope.launch(Dispatchers.IO) {
                            val arr = PanelsSecEngine.oKnock(listOf("1.1.1.1" to 443), 3000)
                            val ok = arr.length() > 0 && arr.optJSONObject(0)?.optInt("ok", 0) == 1
                            val ms = if (ok) arr.optJSONObject(0)?.optInt("ms", 0) ?: 0 else 0
                            withContext(Dispatchers.Main) {
                                message = if (ok) "مسیر باز است (${ms}ms)" else "مسیر بسته است"
                            }
                        }
                    }
                )
                SettingsMenuItem(
                    icon = painterResource(R.drawable.ic_panel_slipnet_24dp),
                    title = "اسکن دستکاری DNS",
                    subtitle = "مقایسهٔ UDP/53 با DoH رمزشده",
                    onClick = {
                        scope.launch(Dispatchers.IO) {
                            val r = PanelsSecEngine.dnsCheck()
                            val hijack = try { JSONObject(r).optInt("hijack", 0) } catch (_: Throwable) { 0 }
                            withContext(Dispatchers.Main) {
                                message = if (hijack == 1) "DNS دستکاری می‌شود! (سپر DNS را ببین)"
                                else "DNS سالم است ✓"
                            }
                        }
                    }
                )
            }
            NavigationBarsSpacer()
        }
    }
}

package com.v2ray.ang.panels

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import com.tencent.mmkv.MMKV
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.drop
import org.json.JSONArray
import org.json.JSONObject

/**
 * Independent KV store for the ported "مدیریت پنل‌ها" feature panels.
 *
 * Uses its own MMKV store id so panel settings never trigger the v2ray core
 * service-restart logic that `MmkvManager`/`SettingsChangeManager` wire up for
 * the app's own `SETTING` store. Same auto-persisting Compose helper pattern.
 */
object PanelsStore {
    private const val STORE_ID = "panels_kv"

    private val kv: MMKV by lazy { MMKV.mmkvWithID(STORE_ID, MMKV.MULTI_PROCESS_MODE) }

    fun initialize(@Suppress("UNUSED_PARAMETER") context: Context) {
        // MMKV root is initialized by MmkvManager in AngApplication.onCreate;
        // touching the lazy store here just warms it up.
        kv.decodeBool("__warm__", false)
    }

    fun getString(key: String, def: String = ""): String = kv.decodeString(key, def) ?: def

    fun putString(key: String, value: String) {
        kv.encode(key, value)
    }

    fun getBool(key: String, def: Boolean = false): Boolean = kv.decodeBool(key, def)

    fun putBool(key: String, value: Boolean) {
        kv.encode(key, value)
    }

    fun remove(key: String) {
        kv.removeValueForKey(key)
    }

    @Composable
    fun rememberPanelString(key: String, default: String = ""): MutableState<String> {
        val state = remember(key) { mutableStateOf(getString(key, default)) }
        LaunchedEffect(key) {
            snapshotFlow { state.value }
                .drop(1)
                .distinctUntilChanged()
                .collectLatest { value -> putString(key, value) }
        }
        return state
    }

    @Composable
    fun rememberPanelBool(key: String, default: Boolean = false): MutableState<Boolean> {
        val state = remember(key) { mutableStateOf(getBool(key, default)) }
        LaunchedEffect(key) {
            snapshotFlow { state.value }
                .drop(1)
                .distinctUntilChanged()
                .collectLatest { value -> putBool(key, value) }
        }
        return state
    }

    // ------------------------------------------------------------------
    // JSON helpers used by the panel screens
    // ------------------------------------------------------------------
    fun optString(o: JSONObject?, key: String, def: String = ""): String =
        if (o == null || o.isNull(key)) def else try {
            o.optString(key, def)
        } catch (_: Throwable) {
            def
        }

    fun toJsonArray(list: List<String>): String {
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        return arr.toString()
    }

    fun fromJsonArray(s: String?): List<String> {
        val out = ArrayList<String>()
        if (s.isNullOrBlank()) return out
        return try {
            val arr = JSONArray(s)
            for (i in 0 until arr.length()) out.add(arr.optString(i))
            out
        } catch (_: Throwable) {
            emptyList()
        }
    }
}

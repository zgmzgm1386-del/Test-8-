package com.v2ray.ang.panels

import android.Manifest
import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.KeyguardManager
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.SystemClock
import android.provider.Settings
import android.util.Base64
import android.webkit.CookieManager
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.URL
import java.security.SecureRandom
import java.util.concurrent.ConcurrentLinkedQueue
import javax.net.ssl.HttpsURLConnection

/**
 * Security-center engine — faithful port of the panels-manager `SecEngine`
 * (device health, RAM, app/file scan, mic-cam watcher, DNS shield, update
 * fetch, generic HTTPS fetch, TCP knock). Media-only and service-API-only
 * ops (downloads, music recognition, WARP/Proton/Windscribe keygen) were
 * dropped together with the excluded tabs.
 */
object PanelsSecEngine {

    private val DANGEROUS = mapOf(
        "android.permission.RECORD_AUDIO" to "میکروفن",
        "android.permission.CAMERA" to "دوربین",
        "android.permission.SEND_SMS" to "ارسال پیامک",
        "android.permission.READ_SMS" to "خواندن پیامک",
        "android.permission.RECEIVE_SMS" to "دریافت پیامک",
        "android.permission.READ_CONTACTS" to "مخاطبین",
        "android.permission.READ_PHONE_STATE" to "اطلاعات تماس/سیم‌کارت",
        "android.permission.ACCESS_FINE_LOCATION" to "موقعیت دقیق",
        "android.permission.READ_CALL_LOG" to "گزارش تماس‌ها",
        "android.permission.BODY_SENSORS" to "سنسورهای بدن",
        "android.permission.WRITE_EXTERNAL_STORAGE" to "نوشتن فایل‌ها",
    )

    private val SUSPICIOUS =
        Regex("spy|track|hack|keylog|sms|loan|_predict|steal|monitor|record.call", RegexOption.IGNORE_CASE)

    // "new app installed" state (persisted so it survives process death)
    @Volatile var lastAdded: String = ""
    @Volatile var lastAddedAt: Long = 0L

    // mic/cam AppOps watcher state
    private val micOps = ConcurrentLinkedQueue<JSONObject>()
    @Volatile private var micReg = false

    fun onPackageAdded(pkg: String) {
        lastAdded = pkg
        lastAddedAt = System.currentTimeMillis()
        try {
            PanelsStore.putString("sec_last_pkg", pkg)
            PanelsStore.putString("sec_last_pkg_at", lastAddedAt.toString())
        } catch (_: Throwable) {
        }
    }

    fun restoreLastPkg() {
        if (lastAdded.isBlank()) {
            lastAdded = PanelsStore.getString("sec_last_pkg", "")
            lastAddedAt = PanelsStore.getString("sec_last_pkg_at", "0").toLongOrNull() ?: 0L
        }
    }

    // ------------------------------------------------------------------
    // RAM
    // ------------------------------------------------------------------
    fun mem(ctx: Context): String {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val usedPct = if (mi.totalMem > 0) ((mi.totalMem - mi.availMem) * 100.0 / mi.totalMem) else 0.0
        return JSONObject()
            .put("total", mi.totalMem).put("avail", mi.availMem)
            .put("usedPct", Math.round(usedPct * 10) / 10.0)
            .put("low", mi.lowMemory).put("threshold", mi.threshold)
            .toString()
    }

    @Suppress("DEPRECATION")
    fun clean(ctx: Context): String {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val before = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.availMem
        var killed = 0
        try {
            val launchables = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = ctx.packageManager.queryIntentActivities(launchables, 0)
            val seen = HashSet<String>()
            for (ri in list) {
                val pkg = ri.activityInfo?.packageName ?: continue
                if (pkg == ctx.packageName || !seen.add(pkg)) continue
                try {
                    am.killBackgroundProcesses(pkg)
                    killed++
                } catch (_: Throwable) {
                }
            }
        } catch (_: Throwable) {
        }
        try { Thread.sleep(700) } catch (_: InterruptedException) {}
        System.gc()
        try { Thread.sleep(300) } catch (_: InterruptedException) {}
        val after = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.availMem
        val freed = if (after > before) after - before else 0L
        return JSONObject()
            .put("before", before).put("after", after).put("freed", freed).put("killed", killed)
            .toString()
    }

    // ------------------------------------------------------------------
    // App scan
    // ------------------------------------------------------------------
    fun apps(ctx: Context, onlyPkg: String?): String {
        val pm = ctx.packageManager
        val flags = PackageManager.GET_PERMISSIONS
        val pis: List<PackageInfo> = try {
            if (Build.VERSION.SDK_INT >= 33) {
                pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(flags.toLong()))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledPackages(flags)
            }
        } catch (_: Throwable) {
            emptyList()
        }
        val now = System.currentTimeMillis()
        val risky = ArrayList<JSONObject>()
        var newN = 0
        var count = 0
        for (pi in pis) {
            val ai = pi.applicationInfo ?: continue
            if (onlyPkg != null) {
                if (pi.packageName != onlyPkg) continue
            } else {
                if (ai.flags and ApplicationInfo.FLAG_SYSTEM != 0) continue
            }
            count++
            val age = now - pi.firstInstallTime
            if (age <= 14L * 24 * 3600 * 1000) newN++
            val perms = (pi.requestedPermissions ?: emptyArray()).mapNotNull { DANGEROUS[it] }
            var side = false
            try {
                val src = pm.getInstallSourceInfo(pi.packageName).installingPackageName ?: ""
                side = src != "com.android.vending" && src.isNotBlank()
            } catch (_: Throwable) {
            }
            val label = try {
                pm.getApplicationLabel(ai).toString()
            } catch (_: Throwable) {
                pi.packageName
            }
            var score = 0
            val why = ArrayList<String>()
            if (side) { score += 30; why.add("نصب‌شده از بیرون فروشگاه") }
            if (perms.isNotEmpty()) { score += 15 * perms.size; why.add("دسترسی: " + perms.joinToString("، ")) }
            if (SUSPICIOUS.containsMatchIn(label + " " + pi.packageName)) { score += 25; why.add("نام مشکوک") }
            if (perms.contains("خواندن پیامک") && perms.contains("مخاطبین")) { score += 20; why.add("ترکیب خطرناک پیامک+مخاطبین") }
            if (score >= 40 || onlyPkg != null) {
                risky.add(
                    JSONObject()
                        .put("name", label)
                        .put("pkg", pi.packageName)
                        .put("score", Math.min(99, score))
                        .put("side", side)
                        .put("why", JSONArray(why))
                )
            }
        }
        risky.sortByDescending { it.optInt("score", 0) }
        val arr = JSONArray()
        risky.forEach { arr.put(it) }
        return JSONObject()
            .put("count", count).put("riskyN", if (onlyPkg != null) 0 else arr.length())
            .put("newN", newN).put("risky", arr)
            .toString()
    }

    // ------------------------------------------------------------------
    // File scan
    // ------------------------------------------------------------------
    private fun dirSize(d: File, budget: LongArray): Long {
        var sz = 0L
        val fs = try { d.listFiles() ?: return 0 } catch (_: Throwable) { return 0 }
        for (f in fs) {
            if (budget[0] <= 0) break
            budget[0] -= 1
            try {
                if (f.isDirectory) sz += dirSize(f, budget) else sz += f.length()
            } catch (_: Throwable) {
            }
        }
        return sz
    }

    fun files(ctx: Context): String {
        val apk = JSONArray()
        var apkCount = 0
        var needPerm = false
        var junk = 0L
        var total = 0L
        var free = 0L
        val caches = JSONArray()
        for (c in listOf(ctx.cacheDir, ctx.externalCacheDir)) {
            if (c == null) continue
            val s = dirSize(c, longArrayOf(4000))
            junk += s
            caches.put(JSONObject().put("path", c.absolutePath).put("size", s))
        }
        try {
            val canAll = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else true
            if (!canAll) {
                needPerm = true
            } else {
                val root = Environment.getExternalStorageDirectory()
                val st = android.os.StatFs(root.absolutePath)
                total = st.totalBytes
                free = st.availableBytes
                val budget = longArrayOf(6000)
                val scan = ArrayDeque<File>()
                scan.add(root)
                var depth = 0
                while (scan.isNotEmpty() && depth < 3 && budget[0] > 0) {
                    val n = scan.size
                    repeat(n) {
                        val d = scan.removeFirst() ?: return@repeat
                        val fs = try { d.listFiles() ?: return@repeat } catch (_: Throwable) { return@repeat }
                        for (f in fs) {
                            if (budget[0] <= 0) break
                            budget[0] -= 1
                            try {
                                if (f.isDirectory) scan.add(f)
                                else if (f.name.endsWith(".apk", true)) {
                                    apkCount++
                                    if (apk.length() < 12) apk.put(
                                        JSONObject().put("path", f.absolutePath).put("size", f.length())
                                    )
                                } else if (f.name.equals("LOST.DIR", true)) {
                                    junk += f.length()
                                }
                            } catch (_: Throwable) {
                            }
                        }
                    }
                    depth++
                }
            }
        } catch (_: Throwable) {
            needPerm = true
        }
        return JSONObject()
            .put("apk", apk).put("apkCount", apkCount)
            .put("junk", junk).put("caches", caches)
            .put("total", total).put("free", free).put("needPerm", needPerm)
            .toString()
    }

    fun cleanFiles(ctx: Context): String {
        var freed = 0L
        for (c in listOf(ctx.cacheDir, ctx.externalCacheDir)) {
            if (c == null) continue
            val fs = try { c.listFiles() ?: continue } catch (_: Throwable) { continue }
            for (f in fs) {
                try {
                    val sz = if (f.isDirectory) dirSize(f, longArrayOf(4000)) else f.length()
                    val ok = if (f.isDirectory) f.deleteRecursively() else f.delete()
                    if (ok) freed += sz
                } catch (_: Throwable) {
                }
            }
        }
        return JSONObject().put("freed", freed).toString()
    }

    // ------------------------------------------------------------------
    // Device health
    // ------------------------------------------------------------------
    private fun labelOf(ctx: Context, pkg: String): String = try {
        val ai = ctx.packageManager.getApplicationInfo(pkg, 0)
        (ctx.packageManager.getApplicationLabel(ai) ?: pkg).toString()
    } catch (_: Throwable) {
        pkg
    }

    fun devInfo(ctx: Context): String {
        val o = JSONObject()
        val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        o.put("screenLock", try { km?.isDeviceSecure ?: false } catch (_: Throwable) { false })
        val dpm = try {
            ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
        } catch (_: Throwable) {
            null
        }
        o.put(
            "encrypted",
            try {
                (dpm?.storageEncryptionStatus ?: 0) >= DevicePolicyManager.ENCRYPTION_STATUS_ACTIVE
            } catch (_: Throwable) {
                false
            }
        )
        o.put("patch", try { Build.VERSION.SECURITY_PATCH ?: "" } catch (_: Throwable) { "" })
        o.put(
            "devOpts",
            try {
                Settings.Global.getInt(ctx.contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
            } catch (_: Throwable) {
                false
            }
        )
        o.put(
            "adb",
            try {
                Settings.Global.getInt(ctx.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1
            } catch (_: Throwable) {
                false
            }
        )
        o.put(
            "pdns",
            try {
                val m = Settings.Global.getString(ctx.contentResolver, "private_dns_mode")
                val s = Settings.Global.getString(ctx.contentResolver, "private_dns_specifier")
                if (m == "off") "off"
                else if (m == "hostname" && !s.isNullOrBlank()) s
                else if (m == "opportunistic") "auto" else "?"
            } catch (_: Throwable) {
                "?"
            }
        )
        val acc = JSONArray()
        try {
            val sv = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
            sv.split(':').filter { it.isNotBlank() }.forEach { c ->
                val p = try { c.substringBefore('/').substringBefore('.') } catch (_: Throwable) { return@forEach }
                acc.put(JSONObject().put("pkg", p).put("label", labelOf(ctx, p)).put("comp", c))
            }
        } catch (_: Throwable) {
        }
        val ntf = JSONArray()
        try {
            val sv = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners") ?: ""
            sv.split(':').filter { it.isNotBlank() }.forEach { c ->
                val p = try { c.substringBefore('/').substringBefore('.') } catch (_: Throwable) { return@forEach }
                ntf.put(JSONObject().put("pkg", p).put("label", labelOf(ctx, p)).put("comp", c))
            }
        } catch (_: Throwable) {
        }
        val adm = JSONArray()
        try {
            dpm?.activeAdmins?.forEach { a ->
                adm.put(JSONObject().put("pkg", a.packageName).put("label", labelOf(ctx, a.packageName)))
            }
        } catch (_: Throwable) {
        }
        val unk = JSONArray()
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                val am = ctx.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager
                val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                val ris: List<ResolveInfo> = ctx.packageManager.queryIntentActivities(launch, 0)
                val seen = HashSet<String>()
                for (ri in ris) {
                    val p = ri.activityInfo.packageName
                    if (p == ctx.packageName || !seen.add(p)) continue
                    try {
                        val mode = am!!.checkOpNoThrow(
                            AppOpsManager.permissionToOp(Manifest.permission.REQUEST_INSTALL_PACKAGES)
                                ?: "android:request_install_packages",
                            ctx.packageManager.getApplicationInfo(p, 0).uid, p
                        )
                        if (mode == AppOpsManager.MODE_ALLOWED) {
                            unk.put(JSONObject().put("pkg", p).put("label", labelOf(ctx, p)))
                            if (unk.length() >= 40) break
                        }
                    } catch (_: Throwable) {
                    }
                }
            }
        } catch (_: Throwable) {
        }
        o.put("acc", acc).put("ntf", ntf).put("adm", adm).put("unk", unk)
        return o.toString()
    }

    // ------------------------------------------------------------------
    // Mic / camera watcher (AppOps, API 29+)
    // ------------------------------------------------------------------
    fun micWatch(ctx: Context): String {
        if (Build.VERSION.SDK_INT < 29) return "{\"err\":\"api\",\"list\":[]}"
        val am = ctx.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager
            ?: return "{\"err\":\"noops\",\"list\":[]}"
        if (!micReg) {
            try {
                val ops = arrayOf(
                    AppOpsManager.permissionToOp(Manifest.permission.RECORD_AUDIO),
                    AppOpsManager.permissionToOp(Manifest.permission.CAMERA),
                ).filterNotNull().toTypedArray()
                if (ops.isNotEmpty()) {
                    val l = AppOpsManager.OnOpActiveChangedListener { op, _, pkg, active ->
                        try {
                            if (active) {
                                micOps.add(
                                    JSONObject()
                                        .put("op", if (op.contains("microphone")) "mic" else "cam")
                                        .put("pkg", pkg)
                                        .put("ts", System.currentTimeMillis())
                                )
                                while (micOps.size > 40) micOps.poll()
                            }
                        } catch (_: Throwable) {
                        }
                    }
                    am.startWatchingActive(ops, ctx.mainExecutor, l)
                    micReg = true
                }
            } catch (t: Throwable) {
                return "{\"err\":\"reg\",\"m\":\"" + (t.message ?: "").take(80) + "\",\"list\":[]}"
            }
        }
        val arr = JSONArray()
        while (micOps.isNotEmpty()) {
            val j = micOps.poll() ?: break
            try {
                j.put("label", labelOf(ctx, j.optString("pkg")))
                arr.put(j)
            } catch (_: Throwable) {
            }
        }
        return JSONObject().put("list", arr).put("reg", if (micReg) 1 else 0).toString()
    }

    // ------------------------------------------------------------------
    // Browser footprint
    // ------------------------------------------------------------------
    fun wbClean(ctx: Context, cookiesToo: Boolean): String {
        var cache = false
        try {
            val wv = WebView(ctx)
            wv.clearCache(true)
            wv.destroy()
            cache = true
        } catch (_: Throwable) {
        }
        var cookies = false
        if (cookiesToo) {
            try {
                CookieManager.getInstance().removeAllCookies(null)
                CookieManager.getInstance().flush()
                cookies = true
            } catch (_: Throwable) {
            }
        }
        return JSONObject().put("cache", cache).put("cookies", cookies).toString()
    }

    // ------------------------------------------------------------------
    // HTTP helpers
    // ------------------------------------------------------------------
    private fun httpReq(urlS: String, method: String, body: String?, cf: Boolean): Pair<Boolean, String> {
        val c = URL(urlS).openConnection() as HttpsURLConnection
        c.requestMethod = method
        c.connectTimeout = 15000
        c.readTimeout = 15000
        c.setRequestProperty("Accept", "application/json")
        if (cf) {
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("User-Agent", "okhttp/3.12.1")
            c.setRequestProperty("CF-Client-Version", "a-6.10-2158")
        } else {
            c.setRequestProperty("User-Agent", "v2rayNG-Panels/2.3")
        }
        if (body != null) c.doOutput = true
        try {
            if (body != null) c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val s = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            return Pair(code in 200..299, s)
        } finally {
            try { c.disconnect() } catch (_: Throwable) {}
        }
    }

    private fun jsonErr(tag: String, m: String): String =
        "{\"err\":\"" + (tag + ": " + m).take(150).replace("\"", "'").replace("\n", " ") + "\"}"

    // ------------------------------------------------------------------
    // DNS shield
    // ------------------------------------------------------------------
    fun dnsQueryUdp(server: String, name: String, timeoutMs: Int = 4000): List<String> {
        val id = ByteArray(2).also { SecureRandom().nextBytes(it) }
        val q = ArrayList<Byte>()
        q.add(id[0]); q.add(id[1]); q.add(0x01); q.add(0x00)
        q.add(0); q.add(1); q.add(0); q.add(0); q.add(0); q.add(0); q.add(0); q.add(0)
        name.split('.').filter { it.isNotBlank() }.forEach { lb ->
            val b = lb.toByteArray(Charsets.US_ASCII)
            q.add(b.size.toByte()); for (c in b) q.add(c)
        }
        q.add(0); q.add(0); q.add(1); q.add(0); q.add(1)
        val out = ByteArray(q.size)
        q.forEachIndexed { i, v -> out[i] = v }
        DatagramSocket().use { so ->
            so.soTimeout = timeoutMs
            so.send(DatagramPacket(out, out.size, InetAddress.getByName(server), 53))
            val buf = ByteArray(1024)
            val pk = DatagramPacket(buf, buf.size)
            so.receive(pk)
            return dnsParseA(buf, pk.length)
        }
    }

    /** Latency probe used by the scanner in "dns" mode. */
    fun dnsQueryUdpMs(server: String): Int {
        if (!Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(server.trim())) return -1
        val t0 = SystemClock.elapsedRealtime()
        return try {
            val r = dnsQueryUdp(server, "example.com")
            if (r.isEmpty()) -1 else (SystemClock.elapsedRealtime() - t0).toInt()
        } catch (_: Throwable) {
            -1
        }
    }

    private fun dnsName(buf: ByteArray, ptr0: Int): Int {
        var p = ptr0
        var jumped = false
        var end = p
        var guard = 0
        while (guard++ < 64) {
            if (p >= buf.size) break
            val len = buf[p].toInt() and 0xff
            if (len == 0) {
                if (!jumped) end = p + 1
                break
            }
            if (len and 0xc0 == 0xc0) {
                if (p + 1 >= buf.size) break
                val np = ((len and 0x3f) shl 8) or (buf[p + 1].toInt() and 0xff)
                if (!jumped) end = p + 2
                jumped = true
                p = np
                continue
            }
            p += len + 1
        }
        return end
    }

    private fun dnsParseA(buf: ByteArray, n: Int): List<String> {
        if (n < 12) return emptyList()
        val an = ((buf[6].toInt() and 0xff) shl 8) or (buf[7].toInt() and 0xff)
        var p = dnsName(buf, 12) + 4
        val ips = ArrayList<String>()
        for (i in 0 until an) {
            if (p >= n) break
            p = dnsName(buf, p)
            if (p + 10 > n) break
            val typ = ((buf[p].toInt() and 0xff) shl 8) or (buf[p + 1].toInt() and 0xff)
            val rdlen = ((buf[p + 8].toInt() and 0xff) shl 8) or (buf[p + 9].toInt() and 0xff)
            val rd = p + 10
            if (typ == 1 && rdlen == 4 && rd + 4 <= n) {
                ips.add(
                    (buf[rd].toInt() and 0xff).toString() + "." + (buf[rd + 1].toInt() and 0xff) + "." +
                        (buf[rd + 2].toInt() and 0xff) + "." + (buf[rd + 3].toInt() and 0xff)
                )
            }
            p = rd + rdlen
        }
        return ips
    }

    private fun dnsDoh(name: String): List<String> {
        val u = "https://cloudflare-dns.com/dns-query?name=" +
            java.net.URLEncoder.encode(name, "UTF-8") + "&type=A"
        val r = try { httpReq(u, "GET", null, false) } catch (_: Throwable) { return emptyList() }
        if (!r.first) return emptyList()
        return try {
            val ans = JSONObject(r.second).optJSONArray("Answer") ?: return emptyList()
            val out = ArrayList<String>()
            for (i in 0 until ans.length()) {
                val a = ans.getJSONObject(i)
                if (a.optInt("type") == 1) out.add(a.optString("data"))
            }
            out
        } catch (_: Throwable) {
            emptyList()
        }
    }

    fun dnsCheck(): String {
        val names = arrayOf("youtube.com", "x.com", "example.com")
        val rows = JSONArray()
        var hijack = 0
        for (nm in names) {
            val udp = try { dnsQueryUdp("8.8.8.8", nm) } catch (_: Throwable) { emptyList() }
            val doh = try { dnsDoh(nm) } catch (_: Throwable) { emptyList() }
            val bad = udp.any { it.startsWith("10.10.34.") || it == "0.0.0.0" || it == "127.0.0.1" } ||
                (udp.isEmpty() && doh.isNotEmpty())
            if (bad) hijack = 1
            rows.put(
                JSONObject().put("name", nm)
                    .put("udp", JSONArray(udp.take(4)))
                    .put("doh", JSONArray(doh.take(4)))
                    .put("bad", if (bad) 1 else 0)
            )
        }
        return JSONObject().put("hijack", hijack).put("rows", rows)
            .put("ts", System.currentTimeMillis()).toString()
    }

    // ------------------------------------------------------------------
    // Update fetch / generic fetch / md5 / knock
    // ------------------------------------------------------------------
    fun updFetch(urlS: String): String {
        val url = urlS.trim()
        if (!url.startsWith("https://")) return "{\"err\":\"https\"}"
        val r = try { httpReq(url, "GET", null, false) } catch (t: Throwable) {
            return jsonErr("fetch", t.message ?: "timeout")
        }
        return JSONObject().put("ok", if (r.first) 1 else 0)
            .put("body", if (r.first) r.second.take(6000) else "")
            .put("err", if (r.first) "" else r.second.take(140)).toString()
    }

    fun oFetch(
        urlS: String,
        method: String = "GET",
        body: String? = null,
        ua: String = "v2rayNG-Panels/2.3",
        headers: Map<String, String> = emptyMap(),
        maxKb: Int = 3072,
    ): String {
        val url = urlS.trim()
        if (!url.startsWith("https://")) return jsonErr("ofetch", "https only")
        val m = method.uppercase()
        return try {
            val c = URL(url).openConnection() as HttpsURLConnection
            c.requestMethod = if (m == "POST") "POST" else "GET"
            c.connectTimeout = 15000
            c.readTimeout = 25000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", ua)
            c.setRequestProperty("Accept", "*/*")
            var hasCT = false
            headers.forEach { (k, v) ->
                c.setRequestProperty(k, v)
                if (k.equals("Content-Type", true)) hasCT = true
            }
            if (m == "POST" && body != null) {
                c.doOutput = true
                if (!hasCT) c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val ins = if (code in 200..299) c.inputStream else c.errorStream
            val sb = StringBuilder()
            if (ins != null) {
                val buf = ByteArray(16384)
                ins.use { rd ->
                    while (true) {
                        val n = rd.read(buf)
                        if (n < 0) break
                        sb.append(String(buf, 0, n, Charsets.UTF_8))
                        if (sb.length > maxKb * 1024) break
                    }
                }
            }
            JSONObject().put("ok", if (code in 200..299) 1 else 0).put("status", code).put("body", sb.toString())
                .toString()
        } catch (t: Throwable) {
            jsonErr("ofetch", t.message ?: "net")
        }
    }

    fun md5(s: String): String {
        val d = java.security.MessageDigest.getInstance("MD5").digest(s.toByteArray(Charsets.UTF_8))
        return JSONObject().put("ok", 1).put("hex", d.joinToString("") { String.format("%02x", it) }).toString()
    }

    /** Parallel TCP knock (host ranking for the scanner/ekhtelal). */
    fun oKnock(list: List<Pair<String, Int>>, toMs: Int = 3500): JSONArray {
        val arr = JSONArray()
        val ex = java.util.concurrent.Executors.newFixedThreadPool(12)
        try {
            val futs = ArrayList<java.util.concurrent.Future<JSONObject>>()
            for ((host, port) in list) {
                futs.add(ex.submit(java.util.concurrent.Callable<JSONObject> {
                    val o = JSONObject()
                    val t0 = System.nanoTime()
                    try {
                        java.net.Socket().use { s -> s.connect(java.net.InetSocketAddress(host, port), toMs) }
                        o.put("ok", 1).put("ms", (System.nanoTime() - t0) / 1000000L)
                    } catch (_: Throwable) {
                        o.put("ok", 0).put("ms", 0)
                    }
                    o
                }))
            }
            for (f in futs) arr.put(f.get())
        } catch (_: Throwable) {
        } finally {
            ex.shutdown()
        }
        return arr
    }
}

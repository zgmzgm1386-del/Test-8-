package com.v2ray.ang.panels

import android.os.SystemClock
import org.json.JSONObject
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Base64
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import java.security.cert.X509Certificate

/**
 * Real network probes for the IP/domain/proxy/DNS scanner and the SNI
 * anti-filter engine (port of panels-manager ScanBridge + sni engine).
 */
object PanelsScanner {

    /** Official Cloudflare IPv4 ranges (same list as panels-manager S.ranges). */
    val CF_RANGES_V4 = listOf(
        "173.245.48.0/20", "103.21.244.0/22", "103.22.200.0/22", "103.31.4.0/22",
        "141.101.64.0/18", "108.162.192.0/18", "190.93.240.0/20", "188.114.96.0/20",
        "197.234.240.0/22", "198.41.128.0/17", "162.158.0.0/15", "104.16.0.0/13",
        "104.24.0.0/14", "172.64.0.0/13", "131.0.72.0/22",
    )

    /** Well-known Cloudflare-fronted domains used by the SNI tester. */
    val SNI_DOMAINS = listOf(
        "www.cloudflare.com", "cloudflare.net", "cdnjs.cloudflare.com", "static.cloudflareinsights.com",
        "challenges.cloudflare.com", "cloudflare-dns.com", "one.one.one.one", "quic.cloudflare.com",
        "workers.dev", "pages.dev", "r2.dev", "trycloudflare.com", "www.cloudflarestatus.com",
        "chatgpt.com", "chat.openai.com", "openai.com", "api.openai.com", "platform.openai.com",
        "claude.ai", "anthropic.com", "gemini.google.com", "bard.google.com", "copilot.microsoft.com",
        "perplexity.ai", "midjourney.com", "huggingface.co", "replicate.com", "groq.com",
        "www.instagram.com", "www.facebook.com", "www.youtube.com", "www.twitch.tv", "discord.com",
        "www.reddit.com", "x.com", "twitter.com", "t.me", "telegram.org",
        "www.wikipedia.org", "archive.org", "www.redditmedia.com", "github.com", "gist.github.com",
        "raw.githubusercontent.com", "objects.githubusercontent.com", "codeload.github.com",
        "fonts.googleapis.com", "fonts.gstatic.com", "www.google.com", "www.gstatic.com",
        "store.steampowered.com", "api.steampowered.com", "steamcommunity.com",
        "cdn.jsdelivr.net", "fastly.jsdelivr.net", "unpkg.com", "js.org",
        "vercel.app", "netlify.app", "deno.dev", "onrender.com", "railway.app",
        "www.farsnews.com", "www.varzesh3.com", "www.zoomit.ir", "divar.ir", "www.digikala.com",
    )

    /** Default DNS resolvers probed by the SlipNet resolver scanner. */
    val RESOLVERS = listOf(
        "8.8.8.8", "1.1.1.1", "9.9.9.9", "94.140.14.14", "208.67.222.222",
        "185.228.168.9", "76.76.2.0", "94.140.24.20",
    )

    private val relaxedTlsFactory: SSLContext by lazy {
        val tm = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}
            override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
        }
        SSLContext.getInstance("TLS").apply { init(null, arrayOf<TrustManager>(tm), null) }
    }

    /** Raw TCP connect — returns latency ms or -1. */
    fun probeTcp(host: String, port: Int, timeoutMs: Int = 3500): Int {
        val t0 = SystemClock.elapsedRealtime()
        return try {
            Socket().use { s ->
                s.connect(InetSocketAddress(host, port), timeoutMs)
                (SystemClock.elapsedRealtime() - t0).toInt()
            }
        } catch (_: Throwable) {
            -1
        }
    }

    /** TLS handshake against `host:443` presenting `sni` — returns latency ms or -1. */
    fun probeTls(host: String, sni: String = host, timeoutMs: Int = 3500): Int {
        val t0 = SystemClock.elapsedRealtime()
        return try {
            val underlying = Socket()
            underlying.soTimeout = timeoutMs
            underlying.connect(InetSocketAddress(host, 443), timeoutMs)
            val ssl = relaxedTlsFactory.socketFactory.createSocket(underlying, sni, 443, true) as SSLSocket
            ssl.soTimeout = timeoutMs
            ssl.startHandshake()
            ssl.session?.isValid
            ssl.close()
            (SystemClock.elapsedRealtime() - t0).toInt()
        } catch (_: Throwable) {
            -1
        }
    }

    data class ScanResult(val host: String, val ok: Boolean, val ms: Int)

    /** Parallel batch probe (worker threads, order preserved). */
    fun probeBatch(
        hosts: List<String>,
        mode: String,
        timeoutMs: Int = 3500,
        concurrency: Int = 12,
        progress: (done: Int, total: Int) -> Unit = { _, _ -> },
    ): List<ScanResult> {
        val results = arrayOfNulls<ScanResult>(hosts.size)
        val done = AtomicInteger(0)
        val pool = Executors.newFixedThreadPool(concurrency.coerceIn(1, 16))
        try {
            val futures = hosts.mapIndexed { idx, h ->
                pool.submit {
                    val ms = when (mode) {
                        "tls" -> probeTls(h, h, timeoutMs)
                        "tcp" -> probeTcp(h, 443, timeoutMs)
                        "dns" -> PanelsSecEngine.dnsQueryUdpMs(h)
                        else -> probeTcp(h, 443, timeoutMs)
                    }
                    results[idx] = ScanResult(h, ms >= 0, ms)
                    progress(done.incrementAndGet(), hosts.size)
                }
            }
            futures.forEach { try { it.get() } catch (_: Throwable) {} }
        } finally {
            pool.shutdown()
        }
        return results.map { it ?: ScanResult("", false, -1) }
    }

    /** Random IPv4 address inside a CIDR range (a.b.c.d style, host part randomized). */
    fun randomIpInCidr(cidr: String): String {
        return try {
            val p = cidr.split("/")
            val base = p[0].split(".").map { it.toInt() }
            val prefix = if (p.size > 1) p[1].toInt() else 32
            if (prefix >= 32) return cidr.split("/")[0]
            val hostBits = 32 - prefix
            val rand = (0 until hostBits).map { if (Math.random() < 0.5) 0 else 1 }
            var value = 0
            for (b in base) value = (value shl 8) or (b and 0xFF)
            val mask = if (prefix == 0) 0 else (-1 shl (32 - prefix))
            val network = value and mask
            var host = 0
            for (b in rand) host = (host shl 1) or b
            host = host.coerceIn(1, (1 shl hostBits) - 2)
            val ip = network or host
            listOf(
                (ip ushr 24) and 0xFF, (ip ushr 16) and 0xFF, (ip ushr 8) and 0xFF, ip and 0xFF
            ).joinToString(".")
        } catch (_: Throwable) {
            "188.114.97.6"
        }
    }
}

/**
 * slipnet:// codec — exact port of the panels-manager v24 pipe format
 * (slipBuildUri / slipParseUri / slipPatchRaw) so imported links keep working.
 */
object PanelsSlip {

    val TYPES = listOf(
        "dnstt" to "DNSTT (پیشنهادی)",
        "sayedns" to "NoizDNS",
        "vaydns" to "VayDNS",
        "dnstt_ssh" to "DNSTT + SSH",
        "ssh" to "SSH مستقیم",
        "socks5" to "SOCKS5 (از طریق SSH)",
        "vless" to "VLESS (لینک)",
    )

    data class SlipProfile(
        var type: String = "dnstt",
        var name: String = "SlipNet",
        var domain: String = "",
        var resolvers: String = "8.8.8.8:53:0",
        var pubkey: String = "",
        var port: Int = 10880,
        var cc: String = "bbr",
        var keepAlive: Int = 15,
        var sshHost: String = "",
        var sshPort: Int = 22,
        var sshUser: String = "",
        var sshPass: String = "",
        var sshTls: Boolean = false,
        var sshTlsSni: String = "",
        var noizStealth: Boolean = false,
        var resolverMode: String = "fanout",
        var raw: String = "",
    ) {
        val isSshFamily: Boolean
            get() = type == "ssh" || type == "socks5" || type.contains("_ssh")

        fun uri(): String {
            if (raw.isNotBlank()) return patchRaw(raw, this)
            return build(this)
        }

        fun toJson(): String = JSONObject()
            .put("type", type).put("name", name).put("domain", domain)
            .put("resolvers", resolvers).put("pubkey", pubkey).put("port", port)
            .put("cc", cc).put("keepAlive", keepAlive)
            .put("sshHost", sshHost).put("sshPort", sshPort)
            .put("sshUser", sshUser).put("sshPass", sshPass)
            .put("sshTls", sshTls).put("sshTlsSni", sshTlsSni)
            .put("noizStealth", noizStealth).put("resolverMode", resolverMode)
            .put("raw", raw)
            .toString()

        companion object {
            fun fromJson(s: String): SlipProfile? = try {
                val o = JSONObject(s)
                SlipProfile(
                    type = PanelsStore.optString(o, "type", "dnstt"),
                    name = PanelsStore.optString(o, "name", "SlipNet"),
                    domain = PanelsStore.optString(o, "domain"),
                    resolvers = PanelsStore.optString(o, "resolvers", "8.8.8.8:53:0"),
                    pubkey = PanelsStore.optString(o, "pubkey"),
                    port = o.optInt("port", 10880),
                    cc = PanelsStore.optString(o, "cc", "bbr"),
                    keepAlive = o.optInt("keepAlive", 15),
                    sshHost = PanelsStore.optString(o, "sshHost"),
                    sshPort = o.optInt("sshPort", 22),
                    sshUser = PanelsStore.optString(o, "sshUser"),
                    sshPass = PanelsStore.optString(o, "sshPass"),
                    sshTls = o.optBoolean("sshTls", false),
                    sshTlsSni = PanelsStore.optString(o, "sshTlsSni"),
                    noizStealth = o.optBoolean("noizStealth", false),
                    resolverMode = PanelsStore.optString(o, "resolverMode", "fanout"),
                    raw = PanelsStore.optString(o, "raw"),
                )
            } catch (_: Throwable) {
                null
            }
        }
    }

    private fun latin1(s: String): String {
        val sb = StringBuilder()
        for (c in s) if (c.code in 0..255) sb.append(c)
        return sb.toString()
    }

    fun build(p: SlipProfile): String {
        val f = arrayOfNulls<String>(62)
        f[0] = "24"; f[1] = p.type.ifBlank { "dnstt" }; f[2] = p.name.ifBlank { "SlipNet" }; f[3] = p.domain
        f[4] = p.resolvers; f[5] = if (p.sshPass.isNotBlank() || p.sshUser.isNotBlank()) "1" else "0"
        f[6] = p.keepAlive.toString(); f[7] = p.cc.ifBlank { "bbr" }
        f[8] = p.port.toString(); f[9] = "127.0.0.1"; f[10] = "0"; f[11] = p.pubkey
        f[12] = ""; f[13] = ""
        f[14] = if (p.type.contains("_ssh") || p.type == "ssh" || p.type == "socks5") "1" else "0"
        f[15] = p.sshUser; f[16] = p.sshPass; f[17] = p.sshPort.toString(); f[18] = "0"; f[19] = p.sshHost
        f[20] = "0"; f[21] = ""; f[22] = "udp"
        f[23] = "password"
        f[31] = "0"; f[38] = if (p.noizStealth) "1" else "0"; f[39] = "0"; f[40] = "1080"
        f[41] = "0"; f[42] = "TXT"; f[43] = "180"; f[44] = "0"; f[45] = "30"; f[46] = "15"
        f[47] = "5000"; f[48] = "3"; f[49] = "8"
        f[50] = if (p.sshTls) "1" else "0"; f[51] = p.sshTlsSni; f[55] = "0"
        f[59] = ""; f[60] = p.resolverMode.ifBlank { "fanout" }; f[61] = "2"
        val joined = f.joinToString("|") { it ?: "" }
        val b64 = Base64.getEncoder().encodeToString(joined.toByteArray(Charsets.ISO_8859_1))
        return "slipnet://" + b64
    }

    fun parse(uri: String): SlipProfile? {
        return try {
            val u = uri.trim()
            if (u.startsWith("vless://", true)) {
                return SlipProfile(type = "vless", name = "VLESS", raw = u)
            }
            if (u.startsWith("slipnet-enc://")) return null
            if (!u.startsWith("slipnet://")) return null
            var b = u.removePrefix("slipnet://").replace(Regex("\\s+"), "")
            while (b.length % 4 != 0) b += "="
            val rawArr = String(Base64.getDecoder().decode(b), Charsets.ISO_8859_1).split("|")
            fun g(i: Int, def: String = ""): String = rawArr.getOrNull(i)?.takeIf { it.isNotEmpty() } ?: def
            SlipProfile(
                type = g(1, "dnstt"),
                name = g(2, "SlipNet"),
                domain = g(3),
                resolvers = g(4, "8.8.8.8:53:0"),
                pubkey = g(11),
                port = g(8).toIntOrNull() ?: 10880,
                cc = g(7, "bbr"),
                sshPort = g(17).toIntOrNull() ?: 22,
                sshUser = g(15),
                sshPass = g(16),
                sshHost = g(19),
                sshTls = g(50) == "1",
                sshTlsSni = g(51),
                noizStealth = g(38) == "1",
                resolverMode = g(60, "fanout"),
                raw = u,
            )
        } catch (_: Throwable) {
            null
        }
    }

    /** Patch editable fields INSIDE a raw slipnet:// link (panels-manager slipPatchRaw). */
    fun patchRaw(rawUri: String, p: SlipProfile): String {
        return try {
            if (!rawUri.startsWith("slipnet://")) return rawUri
            var b = rawUri.removePrefix("slipnet://").replace(Regex("\\s+"), "")
            while (b.length % 4 != 0) b += "="
            val f = Array(62) { i ->
                String(Base64.getDecoder().decode(b), Charsets.ISO_8859_1).split("|").getOrNull(i) ?: ""
            }
            f[1] = latin1(p.type).ifBlank { f[1].ifBlank { "dnstt" } }
            f[2] = latin1(p.name).ifBlank { "SlipNet" }
            f[3] = latin1(p.domain)
            f[4] = latin1(p.resolvers)
            f[11] = latin1(p.pubkey)
            f[15] = latin1(p.sshUser)
            f[16] = latin1(p.sshPass)
            f[17] = latin1(p.sshPort.toString()).ifBlank { "22" }
            f[19] = latin1(p.sshHost)
            f[50] = if (p.sshTls) "1" else "0"
            f[51] = latin1(p.sshTlsSni)
            "slipnet://" + Base64.getEncoder().encodeToString(f.joinToString("|").toByteArray(Charsets.ISO_8859_1))
        } catch (_: Throwable) {
            rawUri
        }
    }
}

/**
 * SNI / clean-IP anti-filter link rewriter — exact port of panels-manager
 * `sniApplyLink` (anti-1001 rule: address = clean IP, Host/SNI always the
 * real domain).
 */
object PanelsEkhtelal {

    fun isIp(s: String): Boolean = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(s)

    fun applyLink(link: String, ip: String, dom: String): String {
        return try {
            var l = link
            if (l.startsWith("vmess://", true)) {
                var raw = l.substring(8)
                raw = try { java.net.URLDecoder.decode(raw, "UTF-8") } catch (_: Throwable) { raw }
                val o = JSONObject(String(Base64.getDecoder().decode(padB64(raw)), Charsets.UTF_8))
                val orig = if (o.has("add")) o.optString("add") else o.optString("host")
                if (ip.isNotBlank()) o.put("add", ip)
                val sniDom = dom.ifBlank {
                    if (o.has("sni") && o.optString("sni").isNotBlank()) o.optString("sni")
                    else if (o.optString("host").isNotBlank()) o.optString("host") else orig
                }
                if (sniDom.isNotBlank() && !isIp(sniDom)) {
                    o.put("sni", sniDom)
                    o.put("host", sniDom)
                }
                o.put("fp", "chrome")
                o.put("alpn", "http/1.1")
                if (!o.has("scy") || o.optString("scy") == "auto") o.put("scy", "none")
                return "vmess://" + Base64.getEncoder().encodeToString(o.toString().toByteArray(Charsets.UTF_8))
            }
            val m = Regex("^(vless|trojan)://([^@]+)@([^:?/]+)(?::(\\d+))?(\\?[^#]*)?(#.*)?$", RegexOption.IGNORE_CASE).find(l)
                ?: return l
            val proto = m.groupValues[1]
            val user = m.groupValues[2]
            val origHost = m.groupValues[3]
            val port = m.groupValues[4].ifBlank { "443" }
            val hash = m.groupValues[6]
            val q = m.groupValues[5].removePrefix("?")
            val params = LinkedHashMap<String, String>()
            q.split("&").forEach { p ->
                if (p.isBlank()) return@forEach
                val i = p.indexOf('=')
                if (i < 0) params[java.net.URLDecoder.decode(p, "UTF-8")] = ""
                else params[java.net.URLDecoder.decode(p.substring(0, i), "UTF-8")] =
                    java.net.URLDecoder.decode(p.substring(i + 1), "UTF-8")
            }
            val sniDom = dom.ifBlank {
                (params["sni"]?.takeIf { it.isNotBlank() }
                    ?: params["host"]?.takeIf { it.isNotBlank() }
                    ?: origHost)
            }
            val addr = ip.ifBlank { origHost }
            if (sniDom.isNotBlank() && !isIp(sniDom)) {
                params["sni"] = sniDom
                params["host"] = sniDom
            }
            if (params["fp"].isNullOrBlank()) params["fp"] = "chrome"
            if (params["fingerprint"].isNullOrBlank()) params["fingerprint"] = params["fp"] ?: "chrome"
            if (params["alpn"].isNullOrBlank()) params["alpn"] = "http/1.1"
            if (params["security"].isNullOrBlank() || params["security"] == "auto") {
                params["security"] = if (port == "443" || port == "8443") "tls" else (params["security"] ?: "none")
            }
            if (params["fragment"].isNullOrBlank() && params["security"] == "tls") {
                params["fragment"] = "1,2-4,8-12,20-30,40-50,tlshello"
            }
            val qs = params.entries.joinToString("&") { (k, v) ->
                java.net.URLEncoder.encode(k, "UTF-8") + "=" + java.net.URLEncoder.encode(v, "UTF-8")
            }
            proto + "://" + user + "@" + addr + ":" + port + "?" + qs + hash
        } catch (_: Throwable) {
            link
        }
    }

    private fun padB64(s: String): String {
        var b = s.replace(Regex("\\s+"), "")
        while (b.length % 4 != 0) b += "="
        return b
    }
}

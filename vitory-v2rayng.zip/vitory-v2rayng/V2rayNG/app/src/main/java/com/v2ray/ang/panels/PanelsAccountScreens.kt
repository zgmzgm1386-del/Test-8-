package com.v2ray.ang.panels

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.v2ray.ang.R
import com.v2ray.ang.ui.base.BaseComponentActivity
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import com.v2ray.ang.ui.compose.SettingsEditItem
import com.v2ray.ang.ui.compose.SettingsMenuItem
import com.v2ray.ang.util.Utils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * Account-driven panel screens (کنترل پنل / مصرف / ابزارها / ترکیبی /
 * مرورگر پنل / اطلاعات) — port of the panels-manager account system.
 * Accounts can be added manually or imported from a panels-manager backup.
 */

// ═══════════════════════════════════════════════════════════════════
// کنترل پنل
// ═══════════════════════════════════════════════════════════════════
class PanelControlActivity : BaseComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    @Composable
    override fun ScreenContent() = PanelControlScreen(onBackClick = { finish() })
}

@Composable
fun PanelControlScreen(onBackClick: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var accounts by remember { mutableStateOf(PanelsAccounts.load()) }
    var statusText by remember { mutableStateOf(mapOf<String, String>()) }
    var editing by remember { mutableStateOf<PanelAccount?>(null) }
    var adding by remember { mutableStateOf(false) }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = { AppTopBar(title = stringResource(R.string.title_panel_pctl), onBackClick = onBackClick) }
    ) { innerPadding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            Text(
                "پنل‌های مستقرشده روی Cloudflare / Railway / Reflex. با «افزودن» دستی وارد کن یا بکاپ مدیریت پنل‌ها را ایمپورت کن.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            accounts.forEach { a ->
                PanelCard(
                    title = a.name.ifBlank { a.id },
                    chipText = statusText[a.id] ?: PanelsAccounts.presetName(a.preset),
                    chipGood = statusText[a.id]?.contains("آنلاین") == true,
                ) {
                    PanelKeyValue("پلتفرم", PanelsAccounts.platformName(a.platform))
                    if (a.host.isNotBlank()) PanelKeyValue("هاست", a.host)
                    SettingsMenuItem(
                        icon = painterResource(R.drawable.ic_qu_start_24dp),
                        title = "بررسی آنلاین",
                        subtitle = "ضربهٔ واقعی TCP به هاست",
                        onClick = {
                            scope.launch(Dispatchers.IO) {
                                val ms = PanelsScanner.probeTcp(a.host.ifBlank { "1.1.1.1" }, 443, 4000)
                                withContext(Dispatchers.Main) {
                                    statusText = statusText + (a.id to if (ms >= 0) "آنلاین (${ms}ms)" else "آفلاین")
                                }
                            }
                        }
                    )
                    if (a.host.isNotBlank()) {
                        SettingsMenuItem(
                            icon = painterResource(R.drawable.ic_panel_browser_24dp),
                            title = "باز کردن پنل در اپ",
                            subtitle = PanelsAccounts.panelUrl(a),
                            onClick = {
                                val i = android.content.Intent(context, PanelBrowserActivity::class.java)
                                i.putExtra("url", PanelsAccounts.panelUrl(a))
                                context.startActivity(i)
                            }
                        )
                        SettingsMenuItem(
                            icon = painterResource(R.drawable.ic_copy),
                            title = "کپی آدرس",
                            onClick = { Utils.setClipboard(context, PanelsAccounts.panelUrl(a)) }
                        )
                    }
                    SettingsMenuItem(
                        icon = painterResource(R.drawable.ic_edit_24dp),
                        title = "ویرایش",
                        onClick = { editing = a }
                    )
                    SettingsMenuItem(
                        icon = painterResource(R.drawable.ic_delete_24dp),
                        title = "حذف",
                        onClick = {
                            accounts = accounts.filter { it.id != a.id }.toMutableList()
                            PanelsAccounts.save(accounts)
                        }
                    )
                }
                Spacer(Modifier.height(10.dp))
            }
            SettingsMenuItem(
                icon = painterResource(R.drawable.ic_add_24dp),
                title = "افزودن پنل",
                subtitle = "ورود دستی مشخصات",
                onClick = { adding = true }
            )
            SettingsMenuItem(
                icon = painterResource(R.drawable.ic_cloud_download_24dp),
                title = "ایمپورت بکاپ مدیریت پنل‌ها",
                subtitle = "JSON کلایپ‌بورد (acc_v1)",
                onClick = {
                    val text = Utils.getClipboard(context) ?: ""
                    val n = PanelsAccounts.importFromPanelsManagerBackup(text)
                    accounts = PanelsAccounts.load()
                    statusText = statusText + ("__msg" to if (n > 0) "$n پنل ایمپورت شد ✓" else "بکاپ معتبر در کلیپ‌بورد نبود")
                }
            )
            if (statusText["__msg"] != null) {
                Text(
                    statusText["__msg"] ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            NavigationBarsSpacer()
        }
    }

    if (adding || editing != null) {
        AccountEditDialog(
            initial = editing,
            onDismiss = { adding = false; editing = null },
            onSave = { a ->
                accounts = (accounts.filter { it.id != a.id } + a).toMutableList()
                PanelsAccounts.save(accounts)
                adding = false
                editing = null
            }
        )
    }
}

@Composable
private fun AccountEditDialog(
    initial: PanelAccount?,
    onDismiss: () -> Unit,
    onSave: (PanelAccount) -> Unit,
) {
    var platform by remember { mutableStateOf(initial?.platform ?: "cf") }
    var preset by remember { mutableStateOf(initial?.preset ?: "") }
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var host by remember { mutableStateOf(initial?.host ?: "") }
    var token by remember { mutableStateOf(initial?.token ?: "") }
    var uuid by remember { mutableStateOf(initial?.uuid ?: "") }
    var trPass by remember { mutableStateOf(initial?.trPass ?: "") }
    var accountId by remember { mutableStateOf(initial?.accountId ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text(if (initial == null) "افزودن پنل" else "ویرایش پنل") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                com.v2ray.ang.ui.compose.FormDropdownField(
                    label = "پلتفرم",
                    value = PanelsAccounts.platformName(platform),
                    options = listOf("Cloudflare", "Railway", "Reflex"),
                    onValueChange = { v ->
                        platform = when (v) {
                            "Cloudflare" -> "cf"
                            "Railway" -> "rw"
                            else -> "rf"
                        }
                    }
                )
                com.v2ray.ang.ui.compose.FormTextField(label = "نوع (preset — اختیاری)", value = preset, onValueChange = { preset = it })
                com.v2ray.ang.ui.compose.FormTextField(label = "نام", value = name, onValueChange = { name = it })
                com.v2ray.ang.ui.compose.FormTextField(label = "هاست (مثل my-worker.workers.dev)", value = host, onValueChange = { host = it })
                com.v2ray.ang.ui.compose.FormTextField(label = "توکن API", value = token, onValueChange = { token = it })
                com.v2ray.ang.ui.compose.FormTextField(label = "Account ID (کلادفلر)", value = accountId, onValueChange = { accountId = it })
                com.v2ray.ang.ui.compose.FormTextField(label = "UUID", value = uuid, onValueChange = { uuid = it })
                com.v2ray.ang.ui.compose.FormTextField(label = "رمز ادمین", value = trPass, onValueChange = { trPass = it })
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val a = PanelAccount(
                    id = initial?.id ?: (platform + "::" + name.ifBlank { host }),
                    platform = platform,
                    preset = preset,
                    name = name,
                    host = host.trim(),
                    token = token.trim(),
                    email = initial?.email ?: "",
                    uuid = uuid.trim(),
                    trPass = trPass.trim(),
                    subPath = initial?.subPath ?: "",
                    accountId = accountId.trim(),
                    projectId = initial?.projectId ?: "",
                    serviceId = initial?.serviceId ?: "",
                    environmentId = initial?.environmentId ?: "",
                    apiRoute = initial?.apiRoute ?: "",
                )
                onSave(a)
            }) { Text("ذخیره") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("لغو") }
        }
    )
}

// ═══════════════════════════════════════════════════════════════════
// مصرف
// ═══════════════════════════════════════════════════════════════════
class UsageActivity : BaseComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    @Composable
    override fun ScreenContent() = UsageScreen(onBackClick = { finish() })
}

private val USAGE_SOFT = mapOf("cf" to 100000, "rw" to 50000, "rf" to 100000)

@Composable
fun UsageScreen(onBackClick: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var usage by PanelsStore.rememberPanelString("usage_v1", "{}")
    var accounts by remember { mutableStateOf(PanelsAccounts.load()) }
    var message by remember { mutableStateOf("") }

    fun todayKey(): String = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        .format(java.util.Date())

    fun usageOf(accId: String): Int = try {
        val o = JSONObject(usage)
        val perAcc = o.optJSONObject(accId) ?: return 0
        if (perAcc.optString("date") == todayKey()) perAcc.optInt("count", 0) else 0
    } catch (_: Throwable) {
        0
    }

    fun bumpUsage(accId: String) {
        try {
            val o = JSONObject(usage)
            val total = (0 until o.length()).sumOf { k ->
                val p = o.optJSONObject(o.names().getString(k)) ?: return@sumOf 0
                if (p.optString("date") == todayKey()) p.optInt("count", 0) else 0
            }
            val perAcc = o.optJSONObject(accId) ?: JSONObject().put("date", todayKey()).put("count", 0)
            perAcc.put("date", todayKey())
            perAcc.put("count", perAcc.optInt("count", 0) + 1)
            o.put(accId, perAcc)
            o.put("__total", total + 1)
            usage = o.toString()
        } catch (_: Throwable) {
        }
    }

    val totalToday = try {
        JSONObject(usage).optInt("__total", 0)
    } catch (_: Throwable) {
        0
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = { AppTopBar(title = stringResource(R.string.title_panel_usage), onBackClick = onBackClick) }
    ) { innerPadding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                PanelRing(
                    progress = (totalToday.toFloat() / 1000f).coerceIn(0f, 1f),
                    label = totalToday.toString(),
                )
                Column(Modifier.padding(start = 16.dp)) {
                    Text("درخواست‌های امروز", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "شمارندهٔ چک‌های واقعی هر پنل (سقف نرم: cf ${USAGE_SOFT["cf"]} · rw ${USAGE_SOFT["rw"]} · rf ${USAGE_SOFT["rf"]})",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            if (accounts.isEmpty()) {
                Text(
                    "پنلی ثبت نشده — از «کنترل پنل» اضافه کن.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            accounts.forEach { a ->
                val used = usageOf(a.id)
                val soft = USAGE_SOFT[a.platform] ?: 50000
                PanelCard(
                    title = a.name.ifBlank { a.id },
                    chipText = "$used / $soft",
                    chipGood = used < soft,
                ) {
                    PanelProgressBar((used.toFloat() / soft).coerceIn(0f, 1f))
                    Spacer(Modifier.height(6.dp))
                    SettingsMenuItem(
                        icon = painterResource(R.drawable.ic_qu_start_24dp),
                        title = "چک مصرف (درخواست واقعی)",
                        subtitle = "درخواست HTTPS به خود پنل + شمارش",
                        onClick = {
                            if (a.host.isBlank()) {
                                message = "هاستی ثبت نشده"
                                return@SettingsMenuItem
                            }
                            scope.launch(Dispatchers.IO) {
                                val r = PanelsSecEngine.oFetch("https://" + a.host + "/", maxKb = 64)
                                val ok = try { JSONObject(r).optInt("ok", 0) == 1 } catch (_: Throwable) { false }
                                withContext(Dispatchers.Main) {
                                    bumpUsage(a.id)
                                    message = if (ok) "پنل جواب داد ✓ (+1)" else "پنل جواب نداد (+1 ثبت شد)"
                                }
                            }
                        }
                    )
                }
                Spacer(Modifier.height(10.dp))
            }
            if (message.isNotBlank()) {
                Text(message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            NavigationBarsSpacer()
        }
    }
}

// ═══════════════════════════════════════════════════════════════════
// ابزارها
// ═══════════════════════════════════════════════════════════════════
class ToolsActivity : BaseComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    @Composable
    override fun ScreenContent() = ToolsScreen(onBackClick = { finish() })
}

@Composable
fun ToolsScreen(onBackClick: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var accounts by remember { mutableStateOf(PanelsAccounts.load()) }
    var selId by PanelsStore.rememberPanelString("tools_sel", "")
    var message by remember { mutableStateOf("") }
    var kvDump by remember { mutableStateOf("") }

    val selected = accounts.firstOrNull { it.id == selId } ?: accounts.firstOrNull()

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = { AppTopBar(title = stringResource(R.string.title_panel_tools), onBackClick = onBackClick) }
    ) { innerPadding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            if (accounts.isEmpty()) {
                Text(
                    "پنلی ثبت نشده — از «کنترل پنل» اضافه کن.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                NavigationBarsSpacer()
                return@Column
            }
            Text("پنل فعال:", style = MaterialTheme.typography.titleSmall)
            accounts.forEach { a ->
                SettingsMenuItem(
                    icon = painterResource(R.drawable.ic_panel_pctl_24dp),
                    title = (if (a.id == selected?.id) "● " else "") + a.name.ifBlank { a.id },
                    subtitle = PanelsAccounts.platformName(a.platform) + " · " + PanelsAccounts.presetName(a.preset),
                    onClick = { selId = a.id }
                )
            }
            if (selected == null) {
                NavigationBarsSpacer()
                return@Column
            }
            Spacer(Modifier.height(8.dp))
            PanelCard(title = "ابزارهای " + (selected.name.ifBlank { selected.id })) {
                SettingsMenuItem(
                    icon = painterResource(R.drawable.ic_qu_start_24dp),
                    title = "وضعیت سرور",
                    subtitle = "TCP 443 و 80 واقعی",
                    onClick = {
                        scope.launch(Dispatchers.IO) {
                            val ms443 = PanelsScanner.probeTcp(selected.host, 443, 4000)
                            val ms80 = PanelsScanner.probeTcp(selected.host, 80, 4000)
                            withContext(Dispatchers.Main) {
                                message = "443: " + (if (ms443 >= 0) "${ms443}ms ✓" else "بسته") +
                                    " · 80: " + (if (ms80 >= 0) "${ms80}ms ✓" else "بسته")
                            }
                        }
                    }
                )
                SettingsMenuItem(
                    icon = painterResource(R.drawable.ic_lock_24dp),
                    title = "UUID و رمز جدید",
                    subtitle = "تولید و کپی (در خود پنل هم جایگزین کن)",
                    onClick = {
                        val newUuid = java.util.UUID.randomUUID().toString()
                        val newPass = (1..18).map { "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"[(Math.random() * 56).toInt()] }.joinToString("")
                        Utils.setClipboard(context, "UUID: $newUuid\nPASS: $newPass")
                        message = "UUID و رمز جدید کپی شد"
                    }
                )
                SettingsMenuItem(
                    icon = painterResource(R.drawable.ic_save_24dp),
                    title = "بکاپ مشخصات",
                    subtitle = "کل JSON پنل در کلیپ‌بورد",
                    onClick = {
                        val o = JSONObject()
                            .put("id", selected.id).put("platform", selected.platform)
                            .put("preset", selected.preset).put("workerName", selected.name)
                            .put("host", selected.host).put("uuid", selected.uuid)
                            .put("trPass", selected.trPass).put("subPath", selected.subPath)
                            .put("accountId", selected.accountId)
                        Utils.setClipboard(context, o.toString())
                        message = "بکاپ کپی شد"
                    }
                )
                if (selected.platform == "cf" && selected.token.isNotBlank() && selected.accountId.isNotBlank()) {
                    SettingsMenuItem(
                        icon = painterResource(R.drawable.ic_file_24dp),
                        title = "خواندن KV ورکر (بکاپ کامل)",
                        subtitle = "لیست namespaceها و مقادیر",
                        onClick = {
                            scope.launch(Dispatchers.IO) {
                                val dump = PanelsCloudflare.dumpAllKv(selected.token, selected.accountId)
                                withContext(Dispatchers.Main) {
                                    kvDump = dump.first
                                    message = if (dump.second.isNotBlank()) dump.second else ""
                                }
                            }
                        }
                    )
                    if (kvDump.isNotBlank()) {
                        SettingsMenuItem(
                            icon = painterResource(R.drawable.ic_copy),
                            title = "کپی خروجی KV",
                            subtitle = kvDump.take(60) + "…",
                            onClick = {
                                Utils.setClipboard(context, kvDump)
                                message = "کپی شد"
                            }
                        )
                    }
                }
            }
            if (message.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            NavigationBarsSpacer()
        }
    }
}

// ═══════════════════════════════════════════════════════════════════
// ترکیبی (X4G admin over Cloudflare KV REST)
// ═══════════════════════════════════════════════════════════════════
class W222Activity : BaseComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    @Composable
    override fun ScreenContent() = W222Screen(onBackClick = { finish() })
}

@Composable
fun W222Screen(onBackClick: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var accounts by remember { mutableStateOf(PanelsAccounts.load().filter { it.platform == "cf" }) }
    var selId by PanelsStore.rememberPanelString("w2_sel", "")
    var railwayConfig by PanelsStore.rememberPanelString("w2_cfg", "")
    var whiteIps by PanelsStore.rememberPanelString("w2_ips", "")
    var ports by PanelsStore.rememberPanelString("w2_ports", "80")
    var subs by remember { mutableStateOf(listOf<Pair<String, String>>()) } // id -> url
    var message by remember { mutableStateOf("") }
    var nsId by remember { mutableStateOf("") }

    val selected = accounts.firstOrNull { it.id == selId } ?: accounts.firstOrNull()

    fun subUrl(): String =
        if (selected?.host.isNullOrBlank()) "" else "https://" + selected!!.host + "/sub/"

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = { AppTopBar(title = stringResource(R.string.title_panel_w222), onBackClick = onBackClick) }
    ) { innerPadding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            Text(
                "پنل ادمین ورکر ترکیبی X4G — با KV REST رسمی کلادفلر مستقیم به namespace ورکر وصل می‌شود.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            if (selected == null) {
                Text(
                    "پنل کلادفلری ثبت نشده — از «کنترل پنل» با توکن API و Account ID اضافه کن.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                NavigationBarsSpacer()
                return@Column
            }
            Text("ورکر فعال: " + selected.name.ifBlank { selected.id }, style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(8.dp))
            SettingsEditItem(
                icon = painterResource(R.drawable.ic_panel_mhr_24dp),
                title = "کانفیگ Railway (VLESS)",
                value = railwayConfig,
                onValueChanged = { railwayConfig = it }
            )
            SettingsEditItem(
                icon = painterResource(R.drawable.ic_panel_shield_24dp),
                title = "IPهای سفید (هر خط یکی)",
                value = whiteIps,
                onValueChanged = { whiteIps = it }
            )
            SettingsEditItem(
                icon = painterResource(R.drawable.ic_description_24dp),
                title = "پورت‌های بدون TLS (با کاما)",
                value = ports,
                onValueChanged = { ports = it }
            )
            SettingsMenuItem(
                icon = painterResource(R.drawable.ic_save_24dp),
                title = "ذخیره در ورکر (admin_data)",
                subtitle = if (nsId.isBlank()) "اول namespace را انتخاب کن" else "namespace: " + nsId,
                onClick = {
                    scope.launch(Dispatchers.IO) {
                        val ns = if (nsId.isBlank()) PanelsCloudflare.pickNamespace(selected.token, selected.accountId)
                        else PanelsCloudflare.NamespaceRef(nsId, nsId)
                        if (ns == null) {
                            withContext(Dispatchers.Main) { message = "توکن/Account ID درست نیست یا namespace پیدا نشد" }
                            return@launch
                        }
                        nsId = ns.id
                        val admin = JSONObject()
                            .put("whiteIps", org.json.JSONArray(whiteIps.lines().map { it.trim() }.filter { it.isNotBlank() }))
                            .put(
                                "selectedPorts",
                                org.json.JSONArray(ports.split(",").map { it.trim() }.filter { it.isNotBlank() })
                            )
                            .put("minConfigs", 1)
                            .put("configNamePrefix", "X4G")
                            .put("config", railwayConfig.trim())
                            .put("directUuid", "")
                            .put("directPath", "/direct")
                            .put("proxyIP", "")
                        val r = PanelsCloudflare.kvPut(selected.token, selected.accountId, ns.id, "admin_data", admin.toString())
                        withContext(Dispatchers.Main) {
                            message = if (r) "admin_data ذخیره شد ✓" else "ذخیره نشد — توکن را چک کن"
                        }
                    }
                }
            )
            SettingsMenuItem(
                icon = painterResource(R.drawable.ic_add_24dp),
                title = "ساخت اشتراک جدید",
                subtitle = "رکورد sub_<id> در KV + کپی لینک",
                onClick = {
                    scope.launch(Dispatchers.IO) {
                        val ns = if (nsId.isBlank()) PanelsCloudflare.pickNamespace(selected.token, selected.accountId)
                        else PanelsCloudflare.NamespaceRef(nsId, nsId)
                        if (ns == null) {
                            withContext(Dispatchers.Main) { message = "namespace پیدا نشد" }
                            return@launch
                        }
                        nsId = ns.id
                        val subId = (1..16).map { "abcdef0123456789"[(Math.random() * 16).toInt()] }.joinToString("")
                        val sub = JSONObject()
                            .put("id", subId)
                            .put("name", selected.name.ifBlank { "X4G" })
                            .put("config", railwayConfig.trim())
                            .put("connType", "indirect")
                            .put(
                                "whiteIps",
                                org.json.JSONArray(whiteIps.lines().map { it.trim() }.filter { it.isNotBlank() })
                            )
                            .put("ports", org.json.JSONArray(ports.split(",").map { it.trim() }.filter { it.isNotBlank() }))
                            .put("count", 1)
                            .put("configNamePrefix", "X4G")
                            .put("createdAt", System.currentTimeMillis())
                        val ok = PanelsCloudflare.kvPut(selected.token, selected.accountId, ns.id, "sub_$subId", sub.toString())
                        withContext(Dispatchers.Main) {
                            if (ok) {
                                subs = subs + (subId to (subUrl() + subId))
                                Utils.setClipboard(context, subUrl() + subId)
                                message = "اشتراک ساخته شد و لینکش کپی شد ✓"
                            } else message = "ساخت اشتراک شکست خورد"
                        }
                    }
                }
            )
            SettingsMenuItem(
                icon = painterResource(R.drawable.ic_file_24dp),
                title = "لیست اشتراک‌ها (کلیدهای sub_)",
                onClick = {
                    scope.launch(Dispatchers.IO) {
                        val ns = if (nsId.isBlank()) PanelsCloudflare.pickNamespace(selected.token, selected.accountId)
                        else PanelsCloudflare.NamespaceRef(nsId, nsId)
                        if (ns == null) {
                            withContext(Dispatchers.Main) { message = "namespace پیدا نشد" }
                            return@launch
                        }
                        nsId = ns.id
                        val keys = PanelsCloudflare.kvListKeys(selected.token, selected.accountId, ns.id, "sub_")
                        withContext(Dispatchers.Main) {
                            subs = keys.map { k ->
                                val id = k.removePrefix("sub_")
                                id to (subUrl() + id)
                            }
                            message = if (keys.isEmpty()) "اشتراکی نیست" else "${keys.size} اشتراک"
                        }
                    }
                }
            )
            subs.forEach { (id, url) ->
                PanelCard(title = id) {
                    Text(
                        url,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    SettingsMenuItem(
                        icon = painterResource(R.drawable.ic_copy),
                        title = "کپی لینک",
                        onClick = { Utils.setClipboard(context, url) }
                    )
                    SettingsMenuItem(
                        icon = painterResource(R.drawable.ic_delete_24dp),
                        title = "حذف اشتراک",
                        onClick = {
                            scope.launch(Dispatchers.IO) {
                                val ok = PanelsCloudflare.kvDelete(selected.token, selected.accountId, nsId, "sub_$id")
                                withContext(Dispatchers.Main) {
                                    if (ok) subs = subs.filter { it.first != id }
                                    message = if (ok) "حذف شد ✓" else "حذف نشد"
                                }
                            }
                        }
                    )
                }
                Spacer(Modifier.height(8.dp))
            }
            if (message.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            NavigationBarsSpacer()
        }
    }
}

/** Minimal Cloudflare KV REST client (account token + account id). */
object PanelsCloudflare {
    data class NamespaceRef(val id: String, val title: String)

    private fun api(token: String, path: String): Pair<Boolean, String> {
        return try {
            val c = java.net.URL("https://api.cloudflare.com/client/v4$path").openConnection() as javax.net.ssl.HttpsURLConnection
            c.requestMethod = "GET"
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.setRequestProperty("Authorization", "Bearer $token")
            c.setRequestProperty("Content-Type", "application/json")
            val code = c.responseCode
            val body = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            Pair(code in 200..299, body)
        } catch (t: Throwable) {
            Pair(false, t.message ?: "net")
        }
    }

    private fun apiBody(token: String, method: String, path: String, body: String?): Pair<Boolean, String> {
        return try {
            val c = java.net.URL("https://api.cloudflare.com/client/v4$path").openConnection() as javax.net.ssl.HttpsURLConnection
            c.requestMethod = method
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.setRequestProperty("Authorization", "Bearer $token")
            c.setRequestProperty("Content-Type", "application/json")
            if (body != null) {
                c.doOutput = true
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val resp = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            Pair(code in 200..299, resp)
        } catch (t: Throwable) {
            Pair(false, t.message ?: "net")
        }
    }

    fun listNamespaces(token: String, accountId: String): List<NamespaceRef> {
        val (ok, body) = api(token, "/accounts/$accountId/storage/kv/namespaces?per_page=50")
        if (!ok) return emptyList()
        return try {
            val result = JSONObject(body).optJSONArray("result") ?: return emptyList()
            (0 until result.length()).mapNotNull {
                val ns = result.optJSONObject(it) ?: return@mapNotNull null
                NamespaceRef(ns.optString("id"), ns.optString("title"))
            }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    /** Pick the most plausible worker namespace (prefers worker-created ones). */
    fun pickNamespace(token: String, accountId: String): NamespaceRef? {
        val list = listNamespaces(token, accountId)
        return list.firstOrNull { it.title.contains("worker", true) } ?: list.firstOrNull()
    }

    fun kvListKeys(token: String, accountId: String, ns: String, prefix: String): List<String> {
        val (ok, body) = api(token, "/accounts/$accountId/storage/kv/namespaces/$ns/keys?limit=100&prefix=$prefix")
        if (!ok) return emptyList()
        return try {
            val result = JSONObject(body).optJSONArray("result") ?: return emptyList()
            (0 until result.length()).mapNotNull { result.optJSONObject(it)?.optString("name") }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    fun kvGet(token: String, accountId: String, ns: String, key: String): String? {
        val (ok, body) = api(token, "/accounts/$accountId/storage/kv/namespaces/$ns/values/$key")
        return if (ok) body else null
    }

    fun kvPut(token: String, accountId: String, ns: String, key: String, value: String): Boolean {
        val (ok, _) = apiBody(token, "PUT", "/accounts/$accountId/storage/kv/namespaces/$ns/values/$key", value)
        return ok
    }

    fun kvDelete(token: String, accountId: String, ns: String, key: String): Boolean {
        val (ok, _) = apiBody(token, "DELETE", "/accounts/$accountId/storage/kv/namespaces/$ns/values/$key", null)
        return ok
    }

    /** Backup: every namespace → every key → value (bounded). Returns (dump, warning). */
    fun dumpAllKv(token: String, accountId: String): Pair<String, String> {
        val out = JSONObject()
        val namespaces = listNamespaces(token, accountId)
        if (namespaces.isEmpty()) return Pair("", "هیچ namespace پیدا نشد — توکن را چک کن")
        var warn = ""
        namespaces.forEach { ns ->
            val nsObj = JSONObject()
            val keys = kvListKeys(token, accountId, ns.id, "")
            keys.take(60).forEach { k ->
                val v = kvGet(token, accountId, ns.id, k) ?: ""
                nsObj.put(k, v.take(20000))
            }
            if (keys.size > 60) warn = "بیش از ۶۰ کلید در ${ns.title} — فقط ۶۰تای اول"
            out.put(ns.title.ifBlank { ns.id }, nsObj)
        }
        return Pair(out.toString(), warn)
    }
}

// ═══════════════════════════════════════════════════════════════════
// مرورگر پنل
// ═══════════════════════════════════════════════════════════════════
class PanelBrowserActivity : BaseComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    @Composable
    override fun ScreenContent() = PanelBrowserScreen(
        onBackClick = { finish() },
        initialUrl = intent?.getStringExtra("url") ?: ""
    )
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun PanelBrowserScreen(onBackClick: () -> Unit, initialUrl: String) {
    val context = LocalContext.current
    var url by remember { mutableStateOf(initialUrl.ifBlank { "https://" }) }
    var currentUrl by remember { mutableStateOf(initialUrl) }
    var reloadKey by remember { mutableStateOf(0) }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = {
            AppTopBar(title = stringResource(R.string.title_panel_browser), onBackClick = onBackClick)
        }
    ) { innerPadding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("https://…") }
                )
                Spacer(Modifier.width(8.dp))
                androidx.compose.material3.Button(onClick = {
                    if (!url.startsWith("http")) url = "https://" + url
                    currentUrl = url
                    reloadKey++
                }) { Text("برو") }
            }
            Box(Modifier.weight(1f)) {
                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.userAgentString =
                                "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                            webViewClient = object : WebViewClient() {
                                override fun onPageFinished(view: WebView, u: String) {
                                    currentUrl = u
                                }
                            }
                            CookieManager.getInstance().setAcceptCookie(true)
                            if (initialUrl.isNotBlank()) loadUrl(initialUrl)
                        }
                    },
                    update = { view ->
                        if (reloadKey > 0 && view.url != currentUrl) view.loadUrl(currentUrl)
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
            NavigationBarsSpacer()
        }
    }
}

// ═══════════════════════════════════════════════════════════════════
// اطلاعات
// ═══════════════════════════════════════════════════════════════════
class PanelsInfoActivity : BaseComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    @Composable
    override fun ScreenContent() = PanelsInfoScreen(onBackClick = { finish() })
}

@Composable
fun PanelsInfoScreen(onBackClick: () -> Unit) {
    val context = LocalContext.current
    val accounts = remember { PanelsAccounts.load() }
    val engineInfo = remember { PanelsBridge.engineInfo(context) }
    val versionText = "v" + com.v2ray.ang.BuildConfig.VERSION_NAME

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = { AppTopBar(title = stringResource(R.string.title_panel_info), onBackClick = onBackClick) }
    ) { innerPadding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            PanelCard(title = "موتورهای داخل APK") {
                PanelKeyValue("SlipNet", if (engineInfo.optBoolean("slip")) "داخل APK ✓" else "نیست")
                PanelKeyValue("Tor (Arti)", if (engineInfo.optBoolean("tor")) "داخل APK ✓" else "نیست")
                PanelKeyValue("سایفون (Psiphon)", if (engineInfo.optBoolean("shk")) "داخل APK ✓" else "نیست")
                PanelKeyValue("MHR (Rust)", if (engineInfo.optBoolean("mhrv")) "داخل APK ✓" else "نیست")
                PanelKeyValue("obfs4", if (engineInfo.optBoolean("obfs4")) "داخل APK ✓" else "نیست")
                PanelKeyValue("tun2proxy", if (engineInfo.optBoolean("tun2proxy")) "داخل APK ✓" else "نیست")
            }
            Spacer(Modifier.height(10.dp))
            PanelCard(title = "پنل‌های ثبت‌شده") {
                if (accounts.isEmpty()) {
                    Text("پنلی نیست", style = MaterialTheme.typography.bodySmall)
                } else accounts.forEach { a ->
                    PanelKeyValue(
                        a.name.ifBlank { a.id },
                        PanelsAccounts.platformName(a.platform) + " · " + PanelsAccounts.presetName(a.preset)
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            com.v2ray.ang.ui.compose.VersionInfoBlock(
                versionText = versionText,
                appIdText = com.v2ray.ang.BuildConfig.APPLICATION_ID
            )
            NavigationBarsSpacer()
        }
    }
}

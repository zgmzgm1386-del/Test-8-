package com.v2ray.ang.panels

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp

/**
 * Shared Compose building blocks for the ported panels screens — built only
 * from the v2rayNG Material3 design tokens so the panels look native here.
 */

/** Status pill (e.g. "وصل شد ✓" / "قطع"). */
@Composable
fun PanelStatusChip(text: String, good: Boolean) {
    val bg = if (good) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant
    val fg = if (good) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
    Surface(shape = RoundedCornerShape(8.dp), color = bg) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = fg,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
        )
    }
}

/** Primary action row used by the connection screens (وصل / قطع). */
@Composable
fun PanelActionRow(
    connected: Boolean,
    busy: Boolean,
    onConnect: () -> Unit,
    onStop: () -> Unit,
    connectLabel: String,
    stopLabel: String,
) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
        Button(
            onClick = onConnect,
            enabled = !busy && !connected,
            modifier = Modifier.weight(1f)
        ) {
            Text(if (busy) "…" else connectLabel)
        }
        OutlinedButton(
            onClick = onStop,
            enabled = !busy && connected,
            modifier = Modifier.weight(1f)
        ) {
            Text(stopLabel)
        }
    }
}

/** Card wrapper with an optional header row (title + status chip). */
@Composable
fun PanelCard(
    title: String,
    chipText: String? = null,
    chipGood: Boolean = false,
    content: @Composable () -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    title,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
                if (chipText != null) PanelStatusChip(chipText, chipGood)
            }
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

/** Monospace log tail. */
@Composable
fun PanelLogBox(logs: String, maxLines: Int = 10) {
    val visible = logs.lines().takeLast(maxLines).joinToString("\n")
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = visible.ifBlank { "—" },
            style = MaterialTheme.typography.bodySmall,
            fontFamily = FontFamily.Monospace,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp)
        )
    }
}

/** Simple labeled value row. */
@Composable
fun PanelKeyValue(key: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
    ) {
        Text(
            key,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(0.42f)
        )
        Text(
            value,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(0.58f)
        )
    }
}

/** Thin circular gauge (shield score / usage). */
@Composable
fun PanelRing(progress: Float, label: String, sizeDp: Int = 96) {
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(sizeDp.dp)) {
        val track = MaterialTheme.colorScheme.surfaceVariant
        val fg = MaterialTheme.colorScheme.secondary
        Canvas(Modifier.size(sizeDp.dp)) {
            val stroke = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)
            drawArc(color = track, startAngle = 0f, sweepAngle = 360f, useCenter = false, style = stroke)
            drawArc(
                color = fg,
                startAngle = -90f,
                sweepAngle = (progress.coerceIn(0f, 1f) * 360f),
                useCenter = false,
                style = stroke
            )
        }
        Text(label, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
    }
}

/** Horizontal progress used in scan screens. */
@Composable
fun PanelProgressBar(progress: Float) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(6.dp)
            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(3.dp))
    ) {
        Box(
            Modifier
                .fillMaxWidth(progress.coerceIn(0f, 1f))
                .height(6.dp)
                .background(MaterialTheme.colorScheme.secondary, RoundedCornerShape(3.dp))
        )
    }
}

/** Colored dot + text row (probe results). */
@Composable
fun PanelDotRow(title: String, subtitle: String, ok: Boolean, trailing: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
        Box(
            Modifier
                .size(10.dp)
                .background(
                    if (ok) Color(0xFF3DDC97) else MaterialTheme.colorScheme.error,
                    RoundedCornerShape(5.dp)
                )
        )
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
            if (subtitle.isNotBlank()) {
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Text(
            trailing,
            style = MaterialTheme.typography.bodySmall,
            color = if (ok) Color(0xFF3DDC97) else MaterialTheme.colorScheme.error
        )
    }
}

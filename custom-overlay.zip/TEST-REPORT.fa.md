# گزارش آزمون — v2rayNG نسخه سفارشی

تاریخ: ۱۴۰۵/۰۸/۱۲ (2026-11-03) · محیط: سندباکس لینوکس (2 CPU، 4GB RAM) · Build: Gradle 9.8.2 / AGP 9.4.1 / Kotlin 2.4.21 / JDK 21 (Temurin)

قاعده گزارش: هر آزمون فقط وقتی PASS است که واقعاً اجرا شده باشد. آنچه اجرا نشده، NOT TESTED و آنچه به‌خاطر فقدان منبع ممکن نیست، BLOCKED ثبت شده است.

---

## ۱. آزمون‌های اجراشده و موفق (PASS)

| آزمون | روش اجرا | نتیجه |
|---|---|---|
| کامپایل کامل سورس (Kotlin + Java + Resources + Manifest) | `./gradlew :app:compileFdroidDebugKotlin` + زنجیره tasks | **PASS** — بدون خطا |
| تست‌های واحد کل پروژه | `./gradlew :app:testFdroidDebugUnitTest` | **PASS** — ۱۳۷ تست، ۰ شکست، ۰ خطا، ۰ رد |
| — از جمله ۹ تست جدید NetDiagnosticsTest (CIDR، DoH parser، قالب‌بندی) | JUnit 6 (JVM) | **PASS** |
| — از جمله ۴ تست جدید VpnServiceControllerTest (منطق تک‌سرویس فعال) | JUnit 6 (JVM) | **PASS** |
| — از جمله ۲۴+ تست‌های رسمی upstream (fmt، handler، service و ...) | JUnit 6 (JVM) | **PASS** (همچنان سبز) |
| ساخت APK طعم fdroid (۵ APK: universal + ۴ ABI) | `./gradlew :app:assembleFdroidDebug` | **PASS** — universal = 84.2MB |
| ساخت APK طعم playstore (۵ APK: universal + ۴ ABI) | `./gradlew :app:assemblePlaystoreDebug` | **PASS** — universal = 84.2MB |
| ثبت ۱۰ اکتیویتی جدید در APK | `aapt2 dump xmltree --file AndroidManifest.xml` | **PASS** — هر ۱۰ مورد یافت شد |
| مجوز PACKAGE_USAGE_STATS در APK | `aapt2 dump badging` | **PASS** |
| بسته‌شدن کتابخانه‌های بومی برای هر ۴ ABI | `unzip -l` روی universal APK | **PASS** — `libgojni.so`، `libhev-socks5-tunnel.so`، `libhevsockstun.so` برای arm64-v8a/armeabi-v7a/x86/x86_64 |
| ساخت کتابخانه بومی hev از سورس | `bash compile-hevtun.sh` با NDK 30 | **PASS** — هر ۴ ABI |
| منوی همبرگری (حذف ۵ + افزودن ۱۰) | بازبینی کد `MainDrawer.kt` + کامپایل موفق | **PASS** (ساختاری) |
| حسابرسی قابلیت‌های سیاه‌لیست | grep روی کل سورس main+test | **PASS** — ۰ مورد از Proton/Geph/Lantern/Windscribe/WARP/PattNG/Media در کد (دو نام بسته Proton از لیست تشخیص اپ‌ها حذف شد) |

## ۲. اجرا نشده — باید روی دستگاه واقعی آزمایش شود (NOT TESTED)

| سناریو | دلیل عدم اجرا | چه کسی باید تست کند |
|---|---|---|
| نصب APK روی گوشی/شبیه‌ساز | سندباکس فاقد دستگاه اندروید یا شبیه‌ساز (KVM در دسترس نیست) | کاربر: نصب نسخه universal |
| اتصال/قطع Xray از صفحه اصلی | همان بالا | کاربر: با یک کانفیگ واقعی |
| جریان تعویض موتور (STOP_THEN_START) در زمان اجرا | نیاز به دستگاه واقعی؛ منطق تصمیم با تست JVM پوشش داده شد، اجرای زمان‌اجرای آن نشده | کاربر: پس از همراه‌شدن موتورها |
| صفحه‌های Usage (با مجوز اعطاشده)، Diagnostic، Safety Shield، IP Scan، Tools در زمان اجرا | نیاز به دستگاه + شبکه واقعی | کاربر: هر صفحه یک دکمه اجرا دارد |
| اعلان Foreground و Tile سریع پس از تغییرات | نیاز به دستگاه | کاربر |
| ورود/خروج کاربر در تم تاریک/روشن صفحه‌های جدید | نیاز به دستگاه | کاربر |

## ۳. مسدود شده (BLOCKED)

| قابلیت | علت | راه رفع |
|---|---|---|
| موتور SlipNet | ZIP تحویل و بررسی شد اما فقط **سورس Rust** دارد (`mhrv-rs` با crate-type `cdylib`)؛ تولید `libmhrv_rs.so` نیازمند cross-compile با Rust + NDK است که در سندباکس ساخت (۲ هسته، فضای محدود) ممکن نشد | ساخت کتابخانه موتور با cargo-ndk + افزودن `assets/engines/slipnet/BUNDLE_MARKER` |
| موتور Tor (بومی) | همان بالا — crate `torbin` در ZIP سورس است و باینری اندروید ندارد | همان الگو |
| موتور Psiphon (شیر و خورشید) | ZIP فقط `psi_config.json` و اسکلت `native/kotlin` را دارد؛ کتابخانه Psiphon اندروید در ZIP نیست | ادغام کتابخانه Psiphon + همان الگو |
| APK امضاشده Release | Keystore/Secret در دسترس نیست (عمداً — امضای جعلی ممنوع) | تنظیم ۴ Secret در مخزن GitHub و اجرای `android-fork-release.yml` |
| سرویس واقعی GAS/MHR | نمونه endpoint واقعی ارائه نشده (صفحه واکشی/واردسازی واقعی بر اساس پروتکل Code.gs پیاده شد) | کاربر آدرس اسکریپت خودش را در صفحه وارد می‌کند |

## ۴. یادداشت‌های صداقت

- هیچ تستی «روی کاغذ» پاس نشده است؛ اعداد ۱۳۷/۰ مستقیماً از XML خروجی `test-results` استخراج شده‌اند.
- APKهای ضمیمه **debug-signed** هستند (کلید دیباگ اندروید) — برای تست نهایی مناسب‌اند؛ ادعای «امضای Release» درباره آن‌ها مطرح نیست.
- منطق تعویض موتور در زمان اجرا (نظر زدن برادکست‌های دیمون) فقط روی دستگاه واقعی قابل اثبات است و تا آن زمان «تأییدشده» محسوب نمی‌شود.

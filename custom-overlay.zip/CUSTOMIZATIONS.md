# CUSTOMIZATIONS — تغییرات این فورک نسبت به v2rayNG رسمی (2.3.15)

مرز بین کد upstream و تغییرات سفارشی این فایل مشخص می‌شود. همه چیز خارج از این فهرست، کد رسمی upstream است و دست نخورده باقی مانده.

## فایل‌های جدید

| فایل | توضیح |
|---|---|
| `V2rayNG/app/src/main/java/com/v2ray/ang/core/VpnServiceController.kt` | کنترلر مرکزی VPN — تک‌سرویس فعال، تعویض امن موتورها، منطق خالص تست‌پذیر |
| `V2rayNG/app/src/main/java/com/v2ray/ang/core/ExternalEngineManager.kt` | رجیستری موتورهای خارجی + بررسی صادقانه «همراه بودن» (BUNDLE_MARKER) |
| `V2rayNG/app/src/main/java/com/v2ray/ang/util/NetDiagnostics.kt` | ابزارهای واقعی شبکه (DoH، پروب HTTP، اسکن TCP، تست سرعت) + هلپرهای خالص |
| `V2rayNG/app/src/main/java/com/v2ray/ang/ui/engines/` | `EngineCommon.kt`، `SlipNetActivity.kt`، `TorActivity.kt`، `PsiphonActivity.kt` |
| `V2rayNG/app/src/main/java/com/v2ray/ang/ui/gasmhr/GasMhrActivity.kt` | واکشی و واردسازی واقعی GAS/MHR |
| `V2rayNG/app/src/main/java/com/v2ray/ang/ui/ipscan/IpScanActivity.kt` | اسکن IP واقعی (CIDR ≤1024، ۶۴ اتصال موازی) |
| `V2rayNG/app/src/main/java/com/v2ray/ang/ui/usage/UsageActivity.kt` | مصرف واقعی (NetworkStatsManager + TrafficStats) |
| `V2rayNG/app/src/main/java/com/v2ray/ang/ui/diagnostic/DiagnosticActivity.kt` | عیب‌یابی واقعی |
| `V2rayNG/app/src/main/java/com/v2ray/ang/ui/safety/SafetyShieldActivity.kt` | سپر ایمنی واقعی |
| `V2rayNG/app/src/main/java/com/v2ray/ang/ui/controlpanel/ControlPanelActivity.kt` | داشبورد کنترلر |
| `V2rayNG/app/src/main/java/com/v2ray/ang/ui/tools/ToolsActivity.kt` | ابزارها (TCPing/DNS/Speed/Base64) |
| `V2rayNG/app/src/test/java/com/v2ray/ang/util/NetDiagnosticsTest.kt` | ۹ تست JVM |
| `V2rayNG/app/src/test/java/com/v2ray/ang/core/VpnServiceControllerTest.kt` | ۴ تست JVM |
| `V2rayNG/app/src/main/res/drawable/ic_slipnet_24dp.xml` … `ic_tools_24dp.xml` | ۱۰ آیکون برداری جدید |
| `.github/workflows/android-fork-debug.yml` | ساخت Debug خودکار + Artifact |
| `.github/workflows/android-fork-release.yml` | Release امضاشده اختیاری با Secrets |
| `README.fa.md`، `TEST-REPORT.fa.md`، `CUSTOMIZATIONS.md` | مستندات فارسی |

## فایل‌های upstream که تغییر کرده‌اند

| فایل | تغییر |
|---|---|
| `V2rayNG/app/src/main/java/com/v2ray/ang/ui/main/MainDrawer.kt` | حذف ۵ آیتم زیر separator از منو (کلاس‌ها سر جای‌اند) + افزودن ۱۰ مقصد جدید |
| `V2rayNG/app/src/main/java/com/v2ray/ang/ui/main/MainActivity.kt` | افزودن مسیر ناوبری ۱۰ صفحه جدید (case های حذف‌شده برای سازگاری حفظ شدند) |
| `V2rayNG/app/src/main/AndroidManifest.xml` | ثبت ۱۰ اکتیویتی جدید + مجوز `PACKAGE_USAGE_STATS` |
| `V2rayNG/app/src/main/res/values/strings.xml` | +۱۰۷ رشته انگلیسی برای صفحات جدید |
| `V2rayNG/app/src/main/res/values-fa/strings.xml` | +۱۰۷ رشته فارسی |
| `V2rayNG/app/src/main/assets/proxy_package_name` | حذف ۲ نام بسته Proton (سیاه‌لیست) — سایر ۴۱۰ خط دست‌نخورده |
| `V2rayNG/app/libs/` (جدید، باینری) | `libv2ray.aar` رسمی (تگ v26.10.31) + .soهای hev ساخته‌شده از ساب‌مدیول رسمی — برای Build آفلاین |

## تصمیم‌های صریح

1. **ثابت‌های DNS خود upstream (مثل `1.1.1.1` به‌عنوان DNS پیش‌فرض VPN)** دست نخورده‌اند: حذف آن‌ها یعنی شکستن قابلیت موجود v2rayNG که طبق توافق ممنوع بود. هیچ قابلیت «برنامه 1.1.1.1/WARP» اضافه نشده و در کد جدید هیچ ارجاعی به آن‌ها نیست.
2. **Promotion/Logcat/CheckUpdate/BackupRestore/About** فقط از منو حذف شدند؛ کلاس‌ها و قابلیت‌های زیرین (مثلاً Backup از Settings یا Logcat داخلی) سالم و قابل فراخوانی‌اند.
3. **موتورهای SlipNet/Tor/Psiphon** هیچ سرویس ساختگی‌ای برایشان ساخته نشده؛ بدون `BUNDLE_MARKER` واقعی، هیچ تونلی شروع نمی‌شود و UI این را صادقانه اعلام می‌کند.
4. **انحراف شناخته‌شده از راهنمای AGENTS صفحه‌های upstream:** راهنمای `ui/AGENTS.md` الگوی ViewModel/StateFlow را الزامی می‌کند؛ صفحه‌های این فورک برای سادگی وضعیت پایدار را در Activity (mutableStateOf + ذخیره در MMKV هنگام عملیات کاربر) نگه می‌دارند. عملکرد درست است اما اگر در آینده بخواهید کاملاً با الگوی upstream هم‌راستا شود، وضعیت هر صفحه باید به ViewModel منتقل شود.

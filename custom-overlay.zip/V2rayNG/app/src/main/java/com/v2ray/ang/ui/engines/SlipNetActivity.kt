package com.v2ray.ang.ui.engines

import android.content.Intent
import android.os.Bundle
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.v2ray.ang.AppConfig
import com.v2ray.ang.R
import com.v2ray.ang.core.ExternalEngineManager
import com.v2ray.ang.core.VpnServiceController
import com.v2ray.ang.extension.toastError
import com.v2ray.ang.extension.toastSuccess
import com.v2ray.ang.handler.MmkvManager
import com.v2ray.ang.ui.base.BaseComponentActivity
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.FormTextField
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import com.v2ray.ang.util.LogUtil
import kotlinx.coroutines.launch

/**
 * SlipNet engine page. Start/stop is routed through the central VPN Service
 * Controller so only one VPN engine can ever run at the same time.
 */
class SlipNetActivity : BaseComponentActivity() {

    /** Hoisted so lifecycleScope coroutines can read the latest UI value. */
    private val endpointState = mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        VpnServiceController.initialize(this)
        endpointState.value = MmkvManager.decodeSettingsString(PREF_SLIPNET_ENDPOINT, "").orEmpty()
    }

    @Composable
    override fun ScreenContent() {
        var endpoint by remember { endpointState }

        Scaffold(
            topBar = {
                AppTopBar(title = stringResource(R.string.title_slipnet), onBackClick = { finish() })
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = stringResource(R.string.slipnet_summary),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
                EngineStatusCard(engine = VpnServiceController.EngineType.SLIPNET) {
                    EngineStartStopButtons(
                        engine = VpnServiceController.EngineType.SLIPNET,
                        onStart = { startEngine() },
                        onStop = { stopEngine() }
                    )
                }
                EngineSectionDivider()
                Text(
                    text = stringResource(R.string.engine_section_settings),
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                FormTextField(
                    label = stringResource(R.string.slipnet_endpoint),
                    value = endpoint,
                    onValueChange = { endpoint = it },
                    maxLines = 6
                )
                NavigationBarsSpacer()
            }
        }
    }

    private fun startEngine() {
        MmkvManager.encodeSettings(PREF_SLIPNET_ENDPOINT, endpointState.value)
        lifecycleScope.launch {
            val error = VpnServiceController.startEngine(
                this@SlipNetActivity,
                VpnServiceController.EngineType.SLIPNET
            ) { ctx ->
                // Explicit ComponentName per repository service rules. The engine is
                // only started when its library is really bundled in this build.
                val serviceClass = ExternalEngineManager.descriptorOf(
                    VpnServiceController.EngineType.SLIPNET
                )?.serviceClassName ?: error("engine service not configured")
                val intent = Intent().setClassName(ctx.packageName, serviceClass)
                androidx.core.content.ContextCompat.startForegroundService(ctx, intent)
            }
            if (error != null) {
                LogUtil.w(AppConfig.TAG, "SlipNet start rejected: $error")
                toastError(getString(R.string.msg_engine_not_bundled, getString(R.string.title_slipnet)))
            } else {
                toastSuccess(R.string.toast_success)
            }
        }
    }

    private fun stopEngine() {
        VpnServiceController.stopActive(this)
    }

    companion object {
        private const val PREF_SLIPNET_ENDPOINT = "pref_custom_slipnet_endpoint"
    }
}

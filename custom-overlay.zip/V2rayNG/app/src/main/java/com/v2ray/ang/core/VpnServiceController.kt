package com.v2ray.ang.core

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import com.v2ray.ang.AppConfig
import com.v2ray.ang.helper.MessageHelper
import com.v2ray.ang.util.LogUtil
import com.v2ray.ang.util.Utils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Decision taken by [VpnServiceController] for a requested start.
 * Pure value used for JVM-level unit testing of arbitration rules.
 */
enum class StartDecision {
    /** Requested engine is already the active and running one. Nothing to do. */
    ALREADY_RUNNING,

    /** No engine is running; start the requested engine directly. */
    START,

    /** A different engine is running; it must be stopped and released first. */
    STOP_THEN_START
}

/**
 * Central VPN Service Controller.
 *
 * Guarantees that at most ONE VPN engine is active at any moment (Xray core or any
 * external engine such as SlipNet / Tor / Psiphon when their libraries are bundled).
 *
 * Rules enforced here:
 * 1. Every start of any engine goes through [startEngine]. If another engine is
 *    currently active, it is stopped first, the stop is awaited (with timeout), and
 *    only then the new engine is started. This prevents two simultaneous VpnService
 *    instances fighting for the TUN interface.
 * 2. The actual start/stop of the Xray core is delegated to [LauncherManager] /
 *    [MessageHelper]. The daemon process remains the single authority on whether the
 *    core is really running (see repository agent guides). This controller only
 *    arbitrates and keeps bookkeeping based on daemon broadcasts.
 * 3. Stop is always idempotent: [stopActive] may be called any number of times.
 *
 * NOTE: engine availability is checked via [ExternalEngineManager.isBundled]. When an
 * engine is NOT bundled in this build (its native library / BUNDLE_MARKER asset is
 * absent), [startEngine] fails fast with an honest error and nothing is started.
 */
object VpnServiceController {

    /** All VPN engines known to the app. */
    enum class EngineType {
        NONE,
        XRAY,
        SLIPNET,
        TOR,
        PSIPHON;

        /** Stable id used in preferences and logs. */
        val id: String get() = name.lowercase()

        companion object {
            fun fromId(id: String): EngineType? = entries.firstOrNull { it.id == id }
        }
    }

    data class ControllerState(
        /** Engine acknowledged as running by daemon broadcasts; NONE when stopped. */
        val activeEngine: EngineType = EngineType.NONE,
        /** True while a stop/start switch is being coordinated. */
        val busy: Boolean = false,
        /** Monotonic timestamp (ms) when the active engine was confirmed running. */
        val startedAt: Long = 0L
    )

    private val _state = MutableStateFlow(ControllerState())
    val state: StateFlow<ControllerState> = _state.asStateFlow()

    private val mutex = Mutex()
    private var registered = false

    /**
     * Last engine whose start was requested through this controller. Used to map
     * daemon "running" broadcasts back to the engine that produced them.
     */
    @Volatile
    private var lastRequested: EngineType? = null

    /**
     * Pure arbitration rule. Kept internal and side-effect free so it can be unit
     * tested without Android.
     */
    internal fun decideStart(activeEngineRunning: Boolean, requested: EngineType): StartDecision {
        if (!activeEngineRunning) return StartDecision.START
        return if (requested == _state.value.activeEngine) StartDecision.ALREADY_RUNNING
        else StartDecision.STOP_THEN_START
    }

    /** Registers daemon state broadcasts. Safe to call multiple times (idempotent). */
    fun initialize(context: Context) {
        if (registered) return
        val appContext = context.applicationContext
        ContextCompat_registerReceiver(
            appContext,
            daemonStateReceiver,
            IntentFilter(AppConfig.BROADCAST_ACTION_ACTIVITY)
        )
        registered = true
        LogUtil.i(AppConfig.TAG, "VpnServiceController: initialized")
    }

    private val daemonStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.getIntExtra("key", 0)) {
                AppConfig.MSG_STATE_RUNNING, AppConfig.MSG_STATE_START_SUCCESS -> {
                    val engine = lastRequested ?: EngineType.XRAY
                    _state.value = ControllerState(
                        activeEngine = engine,
                        busy = false,
                        startedAt = if (_state.value.activeEngine == engine && _state.value.startedAt != 0L)
                            _state.value.startedAt else System.currentTimeMillis()
                    )
                    LogUtil.i(AppConfig.TAG, "VpnServiceController: running engine=$engine")
                }

                AppConfig.MSG_STATE_NOT_RUNNING,
                AppConfig.MSG_STATE_STOP_SUCCESS,
                AppConfig.MSG_STATE_START_FAILURE -> {
                    if (_state.value.activeEngine != EngineType.NONE) {
                        LogUtil.i(
                            AppConfig.TAG,
                            "VpnServiceController: daemon reported stopped (key=${intent.getIntExtra("key", 0)})"
                        )
                    }
                    _state.value = ControllerState()
                    lastRequested = null
                }
            }
        }
    }

    /**
     * Starts [engine] ensuring single-active-VPN invariant.
     *
     * @param startBlock the actual start routine (e.g. LauncherManager.startService).
     * @return null on success, or a human-readable honest failure reason.
     */
    suspend fun startEngine(
        context: Context,
        engine: EngineType,
        startBlock: (Context) -> Unit
    ): String? {
        initialize(context)
        return mutex.withLock {
            if (!ExternalEngineManager.isBundled(context, engine)) {
                return@withLock ExternalEngineManager.missingReason(context, engine)
            }
            val decision = decideStart(_state.value.activeEngine != EngineType.NONE, engine)
            LogUtil.i(AppConfig.TAG, "VpnServiceController: start engine=$engine decision=$decision")
            when (decision) {
                StartDecision.ALREADY_RUNNING -> null

                StartDecision.START -> {
                    lastRequested = engine
                    runCatching { startBlock(context) }
                        .onFailure {
                            LogUtil.e(AppConfig.TAG, "VpnServiceController: start failed", it)
                            lastRequested = null
                        }
                        .exceptionOrNull()?.let { return@withLock it.message ?: it.javaClass.simpleName }
                    null
                }

                StartDecision.STOP_THEN_START -> {
                    _state.value = _state.value.copy(busy = true)
                    val stopped = stopActiveInternal(context)
                    if (!stopped) {
                        _state.value = _state.value.copy(busy = false)
                        return@withLock "previous_engine_stop_timeout"
                    }
                    lastRequested = engine
                    runCatching { startBlock(context) }
                        .onFailure {
                            LogUtil.e(AppConfig.TAG, "VpnServiceController: start after switch failed", it)
                            lastRequested = null
                        }
                        .exceptionOrNull()?.let {
                            _state.value = _state.value.copy(busy = false)
                            return@withLock it.message ?: it.javaClass.simpleName
                        }
                    _state.value = _state.value.copy(busy = false)
                    null
                }
            }
        }
    }

    /**
     * Convenience for the Xray core: routes through the standard LauncherManager
     * start path (VPN / proxy-only / root mode is resolved by LauncherManager).
     */
    suspend fun startXray(context: Context): String? =
        startEngine(context, EngineType.XRAY) { ctx ->
            if (!LauncherManager.startServiceFromToggle(ctx)) {
                error("start_failed")
            }
        }

    /**
     * Stops the currently active engine (idempotent). Does not wait for the daemon
     * acknowledgement; callers that need to switch engines synchronously use
     * [stopActiveInternal] through [startEngine].
     */
    fun stopActive(context: Context) {
        initialize(context)
        lastRequested = null
        MessageHelper.sendMsg2Service(context.applicationContext, AppConfig.MSG_STATE_STOP, "")
        LogUtil.i(AppConfig.TAG, "VpnServiceController: stop requested")
    }

    /** Stops and waits for the daemon stop broadcast (bounded). @return true if stopped */
    private suspend fun stopActiveInternal(context: Context): Boolean {
        if (_state.value.activeEngine == EngineType.NONE) return true
        // The daemon broadcast resets _state; wait for it with an explicit bounded
        // timeout so engine switching can never hang the caller forever.
        val done = withTimeoutOrNull(STOP_TIMEOUT_MS) {
            while (_state.value.activeEngine != EngineType.NONE) {
                kotlinx.coroutines.delay(100)
            }
            true
        } ?: false
        if (done) {
            LogUtil.i(AppConfig.TAG, "VpnServiceController: previous engine stopped cleanly")
        } else {
            LogUtil.w(AppConfig.TAG, "VpnServiceController: previous engine stop timed out")
        }
        return done
    }

    private const val STOP_TIMEOUT_MS = 5_000L

    /** Test-only helper: forces the acknowledged engine state. Never call in production code. */
    internal fun resetForTest(engine: EngineType) {
        _state.value = if (engine == EngineType.NONE) ControllerState()
        else ControllerState(activeEngine = engine, startedAt = 1L)
        lastRequested = null
    }
}

/** Small indirection so the receiver registration helper stays mockable in tests. */
private fun ContextCompat_registerReceiver(context: Context, receiver: BroadcastReceiver, filter: IntentFilter) {
    androidx.core.content.ContextCompat.registerReceiver(
        context, receiver, filter, Utils.receiverFlags()
    )
}

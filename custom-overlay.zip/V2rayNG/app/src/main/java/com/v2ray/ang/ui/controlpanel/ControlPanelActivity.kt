package com.v2ray.ang.ui.controlpanel

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.v2ray.ang.AppConfig
import com.v2ray.ang.R
import com.v2ray.ang.core.VpnServiceController
import com.v2ray.ang.dto.entities.ProfileItem
import com.v2ray.ang.extension.toast
import com.v2ray.ang.handler.MmkvManager
import com.v2ray.ang.ui.base.BaseComponentActivity
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.ItemDivider
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import com.v2ray.ang.util.NetDiagnostics
import com.v2ray.ang.util.Utils
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Control Panel page: live dashboard of the central VPN Service Controller.
 * Runs state follows the daemon broadcasts (the daemon is the only authority on
 * whether the core is running). Traffic shown is device-wide TrafficStats delta
 * while this screen is open, clearly labelled as device traffic.
 */
class ControlPanelActivity : BaseComponentActivity() {

    private var isRunning by mutableStateOf(false)
    private var runningSince by mutableLongStateOf(0L)
    private var selectedProfile by mutableStateOf<ProfileItem?>(null)

    private var baseRx = 0L
    private var baseTx = 0L
    private var sessionRx by mutableLongStateOf(0L)
    private var sessionTx by mutableLongStateOf(0L)
    private var tickerRunning = false

    private val serviceReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.getIntExtra("key", 0)) {
                AppConfig.MSG_STATE_RUNNING, AppConfig.MSG_STATE_START_SUCCESS -> {
                    if (!isRunning) runningSince = System.currentTimeMillis()
                    isRunning = true
                }

                AppConfig.MSG_STATE_NOT_RUNNING,
                AppConfig.MSG_STATE_STOP_SUCCESS,
                AppConfig.MSG_STATE_START_FAILURE -> {
                    isRunning = false
                    runningSince = 0L
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        VpnServiceController.initialize(this)
        androidx.core.content.ContextCompat.registerReceiver(
            this, serviceReceiver,
            IntentFilter(AppConfig.BROADCAST_ACTION_ACTIVITY), Utils.receiverFlags()
        )
        // Ask the daemon for its current state; the reply updates the receiver above.
        com.v2ray.ang.helper.MessageHelper.sendMsg2Service(this, AppConfig.MSG_REGISTER_CLIENT, "")
        selectedProfile = MmkvManager.getSelectServer()?.let { MmkvManager.decodeServerConfig(it) }
    }

    @Composable
    override fun ScreenContent() {
        val controllerState by VpnServiceController.state.collectAsStateWithLifecycle()
        val context = LocalContext.current

        DisposableEffect(Unit) {
            baseRx = android.net.TrafficStats.getTotalRxBytes()
            baseTx = android.net.TrafficStats.getTotalTxBytes()
            tickerRunning = true
            val job = lifecycleScope.launch {
                while (isActive && tickerRunning) {
                    delay(1000)
                    sessionRx = (android.net.TrafficStats.getTotalRxBytes() - baseRx).coerceAtLeast(0)
                    sessionTx = (android.net.TrafficStats.getTotalTxBytes() - baseTx).coerceAtLeast(0)
                }
            }
            onDispose { tickerRunning = false; job.cancel() }
        }

        Scaffold(
            topBar = {
                AppTopBar(title = stringResource(R.string.title_control_panel), onBackClick = { finish() })
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = stringResource(R.string.cp_summary),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )

                CpRow(stringResource(R.string.cp_active_engine),
                    controllerState.activeEngine.name.lowercase().replaceFirstChar { it.uppercase() })
                CpRow(stringResource(R.string.cp_selected_profile),
                    selectedProfile?.remarks ?: stringResource(R.string.cp_not_connected))
                CpRow(
                    stringResource(R.string.cp_state_running),
                    stringResource(if (isRunning) R.string.cp_state_running else R.string.cp_state_stopped)
                )
                if (isRunning && runningSince > 0L) {
                    CpRow(stringResource(R.string.cp_uptime), formatUptime(System.currentTimeMillis() - runningSince))
                }
                CpRow(
                    stringResource(R.string.cp_session_traffic),
                    "${NetDiagnostics.formatBytes(sessionRx)} ↓ / ${NetDiagnostics.formatBytes(sessionTx)} ↑"
                )

                androidx.compose.foundation.layout.Box(modifier = Modifier.padding(vertical = 8.dp)) {
                    ItemDivider()
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = {
                            VpnServiceController.stopActive(context)
                            toast(R.string.toast_services_stop)
                        },
                        enabled = isRunning
                    ) {
                        Text(stringResource(R.string.cp_action_disconnect))
                    }
                }
                NavigationBarsSpacer()
            }
        }
    }

    @Composable
    private fun CpRow(label: String, value: String) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
            Text(
                value,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.secondary
            )
        }
    }

    private fun formatUptime(ms: Long): String {
        val totalSeconds = ms / 1000
        val h = totalSeconds / 3600
        val m = (totalSeconds % 3600) / 60
        val s = totalSeconds % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
    }

    override fun onDestroy() {
        tickerRunning = false
        runCatching { unregisterReceiver(serviceReceiver) }
        super.onDestroy()
    }
}

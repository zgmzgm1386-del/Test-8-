package com.v2ray.ang.ui.safety

import android.app.KeyguardManager
import android.content.Context
import android.os.Bundle
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.v2ray.ang.R
import com.v2ray.ang.ui.base.BaseComponentActivity
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.ItemDivider
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import com.v2ray.ang.util.NetDiagnostics
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * Safety Shield page. REAL device/network indicators only:
 * - Public IP + country via ip-api.com (documented external endpoint)
 * - DNS resolver identity via edns.ip-api.com (documented external endpoint)
 * - VPN tunnel interface presence (local, no network)
 * - Screen lock / debugger / storage encryption (local device state)
 */
class SafetyShieldActivity : BaseComponentActivity() {

    data class CheckItem(val label: String, val value: String, val ok: Boolean?)

    private val runningState = mutableStateOf(false)
    private val itemsState = mutableStateOf<List<CheckItem>>(emptyList())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    @Composable
    override fun ScreenContent() {
        val running by runningState
        val items by itemsState

        Scaffold(
            topBar = {
                AppTopBar(title = stringResource(R.string.title_safety_shield), onBackClick = { finish() })
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                Text(
                    text = stringResource(R.string.safety_summary),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
                Text(
                    text = stringResource(R.string.safety_external_note),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                Button(
                    onClick = { runChecks() },
                    enabled = !running,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text(stringResource(if (running) R.string.diag_running else R.string.safety_run))
                }
                LazyColumn(modifier = Modifier.weight(1f)) {
                    items(items) { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.label, style = MaterialTheme.typography.bodyLarge)
                                Text(
                                    item.value,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = when (item.ok) {
                                        null -> MaterialTheme.colorScheme.onSurfaceVariant
                                        true -> MaterialTheme.colorScheme.tertiary
                                        false -> MaterialTheme.colorScheme.error
                                    }
                                )
                            }
                        }
                        ItemDivider()
                    }
                    item { NavigationBarsSpacer() }
                }
            }
        }
    }

    private fun runChecks() {
        runningState.value = true
        itemsState.value = emptyList()

        lifecycleScope.launch {
            val local = buildList {
                add(
                    CheckItem(
                        getString(R.string.safety_vpn_tun),
                        if (NetDiagnostics.isTunInterfaceUp()) getString(R.string.safety_yes)
                        else getString(R.string.safety_no),
                        NetDiagnostics.isTunInterfaceUp()
                    )
                )
                val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
                val secure = km.isDeviceSecure
                add(
                    CheckItem(
                        getString(R.string.safety_screen_lock),
                        if (secure) getString(R.string.safety_yes) else getString(R.string.safety_no),
                        secure
                    )
                )
                val debugger = android.os.Debug.isDebuggerConnected()
                add(
                    CheckItem(
                        getString(R.string.safety_debugger),
                        if (debugger) getString(R.string.safety_yes) else getString(R.string.safety_no),
                        !debugger
                    )
                )
                val encryptionStatus = try {
                    val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager
                    when (dpm.storageEncryptionStatus) {
                        android.app.admin.DevicePolicyManager.ENCRYPTION_STATUS_ACTIVE,
                        android.app.admin.DevicePolicyManager.ENCRYPTION_STATUS_ACTIVE_PER_USER ->
                            getString(R.string.safety_yes)

                        else -> getString(R.string.safety_no)
                    }
                } catch (e: Exception) {
                    getString(R.string.safety_unknown)
                }
                add(CheckItem(getString(R.string.safety_encryption), encryptionStatus, null))
            }

            val network = withContext(Dispatchers.IO) {
                val ipBody = NetDiagnostics.fetchRawText("http://ip-api.com/json/?fields=query,country,countryCode,isp")
                var ipValue = getString(R.string.safety_unknown)
                var ipOk: Boolean? = null
                try {
                    if (ipBody != null) {
                        val obj = JSONObject(ipBody)
                        val ip = obj.optString("query")
                        val country = obj.optString("country")
                        val isp = obj.optString("isp")
                        if (ip.isNotEmpty()) {
                            ipValue = "$ip · $country · ${isp.take(30)}"
                            ipOk = true
                        }
                    }
                } catch (e: Exception) {
                    ipOk = null
                }

                val dnsBody = NetDiagnostics.fetchRawText("http://edns.ip-api.com/json")
                var dnsValue = getString(R.string.safety_unknown)
                var dnsOk: Boolean? = null
                try {
                    if (dnsBody != null) {
                        val obj = JSONObject(dnsBody)
                        val dns = obj.optString("dns")
                        val geo = obj.optString("geo")
                        if (dns.isNotEmpty()) {
                            dnsValue = "$dns ${geo.take(20)}"
                            dnsOk = true
                        }
                    }
                } catch (e: Exception) {
                    dnsOk = null
                }
                listOf(
                    CheckItem(getString(R.string.safety_public_ip), ipValue, ipOk),
                    CheckItem(getString(R.string.safety_dns_resolver), dnsValue, dnsOk)
                )
            }

            itemsState.value = network + local
            runningState.value = false
        }
    }
}

package com.v2ray.ang.util

import com.v2ray.ang.BuildConfig
import com.v2ray.ang.util.JsonUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.InetAddress
import java.util.concurrent.TimeUnit

/**
 * Real network diagnostics used by the Disruption Diagnostic / IP Scan / Tools /
 * Safety Shield pages. Pure parsing/formatting helpers live in this file so they can
 * be covered by JVM unit tests; all network calls run on Dispatchers.IO.
 */
object NetDiagnostics {

    // ---------------------------------------------------------------------
    // Pure helpers (unit-tested)
    // ---------------------------------------------------------------------

    data class ProbeResult(
        val ok: Boolean,
        val latencyMs: Long,
        val detail: String? = null
    )

    /** Formats milliseconds into a compact human string. */
    fun formatLatency(ms: Long): String = when {
        ms < 0 -> "—"
        ms < 1000 -> "$ms ms"
        else -> String.format(java.util.Locale.US, "%.2f s", ms / 1000.0)
    }

    /** Formats a byte count into KB/MB/GB. */
    fun formatBytes(bytes: Long): String {
        if (bytes < 0) return "—"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        return when {
            gb >= 1 -> String.format(java.util.Locale.US, "%.2f GB", gb)
            mb >= 1 -> String.format(java.util.Locale.US, "%.2f MB", mb)
            kb >= 1 -> String.format(java.util.Locale.US, "%.2f KB", kb)
            else -> "$bytes B"
        }
    }

    /** Formats bytes/second into Mbps. */
    fun formatMbps(bytesPerSecond: Double): String =
        String.format(java.util.Locale.US, "%.2f Mbps", bytesPerSecond * 8 / 1_000_000.0)

    /**
     * Parses a CIDR into a bounded list of IPv4 addresses.
     * Returns null when the input is malformed or would expand beyond [maxAddresses]
     * entries (protects against accidental /0 scans).
     */
    fun expandCidr(cidr: String, maxAddresses: Int = 1024): List<String>? {
        val parts = cidr.trim().split("/")
        if (parts.size != 2) return null
        val ip = parts[0].trim()
        val prefix = parts[1].trim().toIntOrNull() ?: return null
        if (prefix !in 16..32) return null
        val ipParts = ip.split(".")
        if (ipParts.size != 4) return null
        var addr = 0L
        for (p in ipParts) {
            val v = p.toIntOrNull() ?: return null
            if (v !in 0..255) return null
            addr = (addr shl 8) or v.toLong()
        }
        val hostBits = 32 - prefix
        val size = 1L shl hostBits
        if (size > maxAddresses) return null
        val network = addr and (0xFFFFFFFFL shl hostBits)
        return (0 until size).map { offset ->
            val a = network + offset
            "${(a shr 24) and 0xFF}.${(a shr 16) and 0xFF}.${(a shr 8) and 0xFF}.${a and 0xFF}"
        }
    }

    /** True for a plausible IPv4 literal. */
    fun isValidIpv4(value: String): Boolean {
        val parts = value.trim().split(".")
        if (parts.size != 4) return false
        return parts.all {
            val v = it.toIntOrNull() ?: return@all false
            v in 0..255 && it.length <= 3 && (it.length == 1 || !it.startsWith("0"))
        }
    }

    /**
     * Extracts A-record IPv4 answers from a DoH JSON response (RFC 8484 JSON format
     * as served by dns.google/resolve and compatible resolvers).
     */
    fun parseDohAnswerIps(json: String?): List<String> {
        if (json.isNullOrBlank()) return emptyList()
        val root = runCatching { JsonUtil.parseString(json) }.getOrNull() ?: return emptyList()
        val answers = root.getAsJsonArray("Answer") ?: return emptyList()
        return answers.mapNotNull { element ->
            val obj = element.asJsonObject
            val type = obj.get("type")?.takeIf { it.isJsonPrimitive }?.asInt
            val data = obj.get("data")?.takeIf { it.isJsonPrimitive }?.asString
            if (type == 1 && data != null && isValidIpv4(data.trim().removeSuffix("."))) {
                data.trim().removeSuffix(".")
            } else null
        }
    }

    // ---------------------------------------------------------------------
    // Real network operations
    // ---------------------------------------------------------------------

    private val plainClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(8, TimeUnit.SECONDS)
            .writeTimeout(8, TimeUnit.SECONDS)
            .build()
    }

    /** System DNS resolution via the OS resolver. */
    suspend fun dnsLookupSystem(host: String): List<String> = withContext(Dispatchers.IO) {
        runCatching { InetAddress.getAllByName(host).map { it.hostAddress ?: "" }.filter { it.isNotEmpty() } }
            .getOrDefault(emptyList())
    }

    /** DNS-over-HTTPS JSON query (RFC 8484 JSON). Default endpoint: Google dns.google. */
    suspend fun dnsLookupDoh(host: String, dohUrl: String = "https://dns.google/resolve?name=$host&type=A"): List<String> =
        withContext(Dispatchers.IO) {
            val body = runCatching {
                val request = Request.Builder().url(dohUrl).get().build()
                plainClient.newCall(request).execute().use { resp ->
                    if (!resp.isSuccessful) return@withContext emptyList()
                    resp.body?.string()
                }
            }.getOrNull()
            parseDohAnswerIps(body)
        }

    /**
     * HTTP(S) reachability probe. Measures total time until response headers arrive.
     * Any HTTP response (even 4xx/5xx) proves the endpoint is reachable.
     */
    suspend fun httpProbe(url: String, timeoutMs: Int = 8000): ProbeResult = withContext(Dispatchers.IO) {
        val client = plainClient.newBuilder()
            .connectTimeout(timeoutMs.toLong(), TimeUnit.MILLISECONDS)
            .readTimeout(timeoutMs.toLong(), TimeUnit.MILLISECONDS)
            .build()
        val start = System.currentTimeMillis()
        try {
            val request = Request.Builder().url(url).head().build()
            client.newCall(request).execute().use { resp ->
                ProbeResult(ok = true, latencyMs = System.currentTimeMillis() - start, detail = "HTTP ${resp.code}")
            }
        } catch (e: IOException) {
            ProbeResult(ok = false, latencyMs = -1, detail = e.message?.take(120))
        } catch (e: Exception) {
            ProbeResult(ok = false, latencyMs = -1, detail = e.message?.take(120))
        }
    }

    /** TCP connect timing (used by IP Scan and Tools → TCPing). */
    suspend fun tcpConnect(host: String, port: Int, timeoutMs: Int = 1200): Long = withContext(Dispatchers.IO) {
        val start = System.currentTimeMillis()
        val socket = java.net.Socket()
        try {
            socket.connect(java.net.InetSocketAddress(host, port), timeoutMs)
            System.currentTimeMillis() - start
        } catch (e: Exception) {
            -1
        } finally {
            runCatching { socket.close() }
        }
    }

    /**
     * Downloads [url] and reports measured throughput. Uses a bounded byte budget so
     * the tool never consumes unbounded traffic.
     */
    suspend fun downloadSpeedTest(url: String, maxBytes: Long = 8L * 1024 * 1024, timeoutMs: Int = 20000): Pair<Long, Long>? =
        withContext(Dispatchers.IO) {
            val client = plainClient.newBuilder()
                .connectTimeout(8, TimeUnit.SECONDS)
                .readTimeout(timeoutMs.toLong(), TimeUnit.MILLISECONDS)
                .build()
            try {
                val request = Request.Builder().url(url).build()
                client.newCall(request).execute().use { resp ->
                    if (!resp.isSuccessful) return@withContext null
                    val source = resp.body?.byteStream() ?: return@withContext null
                    val start = System.currentTimeMillis()
                    val buffer = ByteArray(64 * 1024)
                    var total = 0L
                    while (total < maxBytes) {
                        val read = source.read(buffer, 0, buffer.size)
                        if (read < 0) break
                        total += read
                    }
                    val elapsed = System.currentTimeMillis() - start
                    if (elapsed <= 0) return@withContext null
                    total to elapsed
                }
            } catch (e: Exception) {
                null
            }
        }

    /**
     * Queries a plain-HTTP IP echo endpoint and returns the raw body (JSON payload
     * of ip-api.com / edns.ip-api.com style endpoints).
     */
    suspend fun fetchRawText(url: String, timeoutMs: Int = 8000): String? = withContext(Dispatchers.IO) {
        try {
            val client = plainClient.newBuilder()
                .connectTimeout(timeoutMs.toLong(), TimeUnit.MILLISECONDS)
                .readTimeout(timeoutMs.toLong(), TimeUnit.MILLISECONDS)
                .build()
            val request = Request.Builder().url(url).get().build()
            client.newCall(request).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext null
                resp.body?.string()?.take(64 * 1024)
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Whether a TUN interface is currently up on the device (VPN active, any app). */
    fun isTunInterfaceUp(): Boolean {
        return runCatching {
            java.net.NetworkInterface.getNetworkInterfaces()?.asSequence()
                ?.any { it.isUp && (it.name.startsWith("tun") || it.name.startsWith("ppp")) }
        }.getOrDefault(false) == true
    }

    const val TEST_SPEED_URL = "https://proof.ovh.net/files/10Mb.dat"

    /** Marker for logging consistency in release builds. */
    private const val BUILD_TAG = BuildConfig.APPLICATION_ID
}

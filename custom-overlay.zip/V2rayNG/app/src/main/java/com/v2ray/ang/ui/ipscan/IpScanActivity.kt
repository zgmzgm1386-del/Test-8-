package com.v2ray.ang.ui.ipscan

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.v2ray.ang.R
import com.v2ray.ang.ui.base.BaseComponentActivity
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.FormTextField
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import com.v2ray.ang.ui.engines.EngineSectionDivider
import com.v2ray.ang.extension.toast
import com.v2ray.ang.util.NetDiagnostics
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.util.Collections
import kotlin.coroutines.coroutineContext

/**
 * IP Scan page. REAL implementation: performs concurrent TCP connect scans over a
 * user-selected CIDR range (bounded to 1024 addresses) and lists responsive IPs by
 * measured latency. Results can be copied to the clipboard.
 */
class IpScanActivity : BaseComponentActivity() {

    private data class ScanResult(val ip: String, val latencyMs: Long)

    private val cidrState = mutableStateOf(PRESET_CIDRS.first())
    private val portState = mutableStateOf("443")
    private val timeoutState = mutableStateOf("1000")
    private val scanningState = mutableStateOf(false)
    private val progressState = mutableStateOf(0 to 0)
    private val resultsState = mutableStateOf<List<ScanResult>>(emptyList())
    private val errorState = mutableStateOf<String?>(null)

    private var scanJob: Job? = null
    private val syncResults = Collections.synchronizedList(mutableListOf<ScanResult>())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    @Composable
    override fun ScreenContent() {
        var cidr by cidrState
        var port by portState
        var timeout by timeoutState
        val scanning by scanningState
        val progress by progressState
        val results by resultsState
        val error by errorState

        Scaffold(
            topBar = {
                AppTopBar(title = stringResource(R.string.title_ip_scan), onBackClick = { finish() })
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = stringResource(R.string.ip_scan_summary),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        PRESET_CIDRS.forEach { preset ->
                            TextButton(onClick = {
                                cidr = preset
                                cidrState.value = preset
                            }) {
                                Text(preset, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                    FormTextField(
                        label = stringResource(R.string.ip_scan_cidr),
                        value = cidr,
                        onValueChange = { cidr = it },
                        maxLines = 1
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            FormTextField(
                                label = stringResource(R.string.ip_scan_port),
                                value = port,
                                onValueChange = { port = it.filter(Char::isDigit).take(5) },
                                maxLines = 1
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            FormTextField(
                                label = stringResource(R.string.ip_scan_timeout_ms),
                                value = timeout,
                                onValueChange = { timeout = it.filter(Char::isDigit).take(4) },
                                maxLines = 1
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { startScan() },
                            enabled = !scanning
                        ) {
                            Text(stringResource(R.string.ip_scan_start))
                        }
                        OutlinedButton(
                            onClick = { scanJob?.cancel() },
                            enabled = scanning
                        ) {
                            Text(stringResource(R.string.ip_scan_stop))
                        }
                    }
                    if (scanning) {
                        Text(
                            text = stringResource(
                                R.string.ip_scan_scanning,
                                progress.first, progress.second, results.size
                            ),
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                    error?.let {
                        Text(
                            text = it,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                    EngineSectionDivider()
                }

                if (results.isNotEmpty()) {
                    Text(
                        text = stringResource(R.string.ip_scan_result_header),
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                    LazyColumn(modifier = Modifier.weight(1f)) {
                        items(results, key = { it.ip }) { item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.ip, style = MaterialTheme.typography.bodyLarge)
                                    Text(
                                        NetDiagnostics.formatLatency(item.latencyMs),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.tertiary
                                    )
                                }
                                TextButton(onClick = { copyToClipboard(item.ip) }) {
                                    Text(stringResource(R.string.ip_scan_copy))
                                }
                            }
                            com.v2ray.ang.ui.compose.ItemDivider()
                        }
                    }
                } else {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState())
                    ) {
                        if (!scanning && error == null) {
                            Text(
                                text = if (progress.second > 0) stringResource(R.string.ip_scan_no_results)
                                else "",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 16.dp)
                            )
                        }
                    }
                }
                NavigationBarsSpacer()
            }
        }
    }

    private fun startScan() {
        val port = portState.value.toIntOrNull() ?: 443
        val timeout = timeoutState.value.toIntOrNull() ?: 1000
        val addresses = NetDiagnostics.expandCidr(cidrState.value, maxAddresses = 1024)
        if (addresses.isNullOrEmpty()) {
            errorState.value = getString(R.string.ip_scan_invalid_range)
            return
        }
        errorState.value = null
        resultsState.value = emptyList()
        syncResults.clear()
        progressState.value = 0 to addresses.size
        scanningState.value = true

        scanJob = lifecycleScope.launch {
            val semaphore = Semaphore(64)
            withContext(kotlinx.coroutines.Dispatchers.IO) {
                val jobs = addresses.map { ip ->
                    launch {
                        semaphore.withPermit {
                            val latency = NetDiagnostics.tcpConnect(ip, port, timeout)
                            if (latency >= 0) syncResults.add(ScanResult(ip, latency))
                            progressState.value = progressState.value.let { (done, total) -> (done + 1) to total }
                        }
                        currentCoroutineContext().ensureActive()
                    }
                }
                jobs.joinAll()
            }
            resultsState.value = syncResults.toList().sortedBy { it.latencyMs }
            scanningState.value = false
        }
    }

    private fun copyToClipboard(ip: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("IP", ip))
        toast(R.string.toast_success)
    }

    private suspend fun List<Job>.joinAll() {
        forEach { it.join() }
    }

    companion object {
        private val PRESET_CIDRS = listOf(
            "104.16.0.0/24",
            "104.17.0.0/24",
            "172.67.0.0/24",
            "188.114.96.0/24"
        )
    }
}

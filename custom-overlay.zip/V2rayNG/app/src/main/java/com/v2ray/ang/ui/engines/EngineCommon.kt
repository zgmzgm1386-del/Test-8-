package com.v2ray.ang.ui.engines

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.v2ray.ang.R
import com.v2ray.ang.core.ExternalEngineManager
import com.v2ray.ang.core.VpnServiceController
import com.v2ray.ang.ui.compose.ItemDivider

/**
 * Status card shared by the SlipNet / Tor / Psiphon pages. Shows the honest bundle
 * status of the engine and the live single-active-VPN state from the controller.
 */
@Composable
fun EngineStatusCard(
    engine: VpnServiceController.EngineType,
    actions: @Composable () -> Unit = {}
) {
    val controllerState by VpnServiceController.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    Surface(
        tonalElevation = 1.dp,
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = stringResource(R.string.engine_section_status),
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
            val bundled = ExternalEngineManager.isBundled(context, engine)
            Text(
                text = ExternalEngineManager.engineStatusLine(context, engine),
                style = MaterialTheme.typography.bodyMedium,
                color = if (bundled) MaterialTheme.colorScheme.tertiary
                else MaterialTheme.colorScheme.error
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = stringResource(R.string.engine_state_active) + ": " +
                        if (controllerState.activeEngine == engine)
                            stringResource(R.string.cp_state_running)
                        else
                            stringResource(R.string.engine_state_inactive),
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = stringResource(R.string.engine_note_single_vpn),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                actions()
            }
        }
    }
}

/** Standard Start / Stop button pair for engine pages. */
@Composable
fun EngineStartStopButtons(
    engine: VpnServiceController.EngineType,
    onStart: () -> Unit,
    onStop: () -> Unit
) {
    val controllerState by VpnServiceController.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val bundled = ExternalEngineManager.isBundled(context, engine)
    val isMine = controllerState.activeEngine == engine

    Button(
        onClick = onStart,
        enabled = bundled && controllerState.activeEngine != engine
    ) {
        Text(stringResource(R.string.engine_action_start))
    }
    OutlinedButton(
        onClick = onStop,
        enabled = isMine
    ) {
        Text(stringResource(R.string.engine_action_stop))
    }
}

@Composable
fun EngineSectionDivider() {
    com.v2ray.ang.ui.compose.AppDivider(modifier = Modifier.padding(vertical = 8.dp))
}

/** Small labeled switch row used by engine settings. */
@Composable
fun EngineSwitchRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.weight(1f)
        )
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedTrackColor = MaterialTheme.colorScheme.secondary)
        )
    }
}

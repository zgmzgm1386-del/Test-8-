package com.v2ray.ang.ui.usage

import android.app.AppOpsManager
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.os.Bundle
import android.os.RemoteException
import android.provider.Settings
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import com.v2ray.ang.extension.toast
import com.v2ray.ang.ui.base.BaseComponentActivity
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.ItemDivider
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import com.v2ray.ang.ui.engines.EngineSectionDivider
import com.v2ray.ang.util.NetDiagnostics
import java.util.Calendar

/**
 * Usage page. REAL implementation backed by Android system counters:
 * - TrafficStats: bytes since device boot (no permission required)
 * - NetworkStatsManager: per-period device totals for mobile / Wi-Fi
 *   (requires the user to grant "Usage access", handled honestly in-page).
 */
class UsageActivity : BaseComponentActivity() {

    private data class UsageTotals(val rx: Long, val tx: Long, val available: Boolean)

    private val permissionState = mutableStateOf(false)
    private val bootRxState = mutableStateOf(0L)
    private val bootTxState = mutableStateOf(0L)
    private val todayMobileState = mutableStateOf(UsageTotals(0, 0, false))
    private val todayWifiState = mutableStateOf(UsageTotals(0, 0, false))
    private val monthMobileState = mutableStateOf(UsageTotals(0, 0, false))
    private val monthWifiState = mutableStateOf(UsageTotals(0, 0, false))
    private val refreshTick = mutableStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        refresh()
    }

    @Composable
    override fun ScreenContent() {
        val hasPermission by permissionState
        val tick by refreshTick // keep composable in sync with refresh()

        Scaffold(
            topBar = {
                AppTopBar(
                    title = stringResource(R.string.title_usage),
                    onBackClick = { finish() },
                    actions = {
                        OutlinedButton(
                            onClick = { refresh() },
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text(stringResource(R.string.usage_refresh))
                        }
                    }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = stringResource(R.string.usage_summary),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )

                Text(
                    text = stringResource(R.string.usage_boot_summary),
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                UsageRow(
                    stringResource(R.string.usage_rx_label),
                    NetDiagnostics.formatBytes(bootRxState.value)
                )
                UsageRow(
                    stringResource(R.string.usage_tx_label),
                    NetDiagnostics.formatBytes(bootTxState.value)
                )

                EngineSectionDivider()

                if (!hasPermission) {
                    Text(
                        text = stringResource(R.string.usage_permission_required),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                    Button(
                        onClick = { requestUsageAccess() },
                        modifier = Modifier.padding(horizontal = 16.dp)
                    ) {
                        Text(stringResource(R.string.usage_grant_permission))
                    }
                } else {
                    UsageSection(
                        title = stringResource(R.string.usage_period_today),
                        mobile = todayMobileState.value,
                        wifi = todayWifiState.value
                    )
                    ItemDivider()
                    UsageSection(
                        title = stringResource(R.string.usage_period_month),
                        mobile = monthMobileState.value,
                        wifi = monthWifiState.value
                    )
                }
                NavigationBarsSpacer()
            }
        }
    }

    @Composable
    private fun UsageRow(label: String, value: String) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
            Text(value, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.secondary)
        }
    }

    @Composable
    private fun UsageSection(title: String, mobile: UsageTotals, wifi: UsageTotals) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        UsageRow(
            stringResource(R.string.usage_mobile),
            if (mobile.available) "${NetDiagnostics.formatBytes(mobile.rx)} / ${NetDiagnostics.formatBytes(mobile.tx)}"
            else stringResource(R.string.safety_unknown)
        )
        UsageRow(
            stringResource(R.string.usage_wifi),
            if (wifi.available) "${NetDiagnostics.formatBytes(wifi.rx)} / ${NetDiagnostics.formatBytes(wifi.tx)}"
            else stringResource(R.string.safety_unknown)
        )
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        permissionState.value = hasUsageAccess()
        bootRxState.value = android.net.TrafficStats.getTotalRxBytes()
        bootTxState.value = android.net.TrafficStats.getTotalTxBytes()
        if (permissionState.value) {
            val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }
            todayMobileState.value = queryTotals(ConnectivityManager.TYPE_MOBILE, cal.timeInMillis)
            todayWifiState.value = queryTotals(ConnectivityManager.TYPE_WIFI, cal.timeInMillis)

            val month = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }
            monthMobileState.value = queryTotals(ConnectivityManager.TYPE_MOBILE, month.timeInMillis)
            monthWifiState.value = queryTotals(ConnectivityManager.TYPE_WIFI, month.timeInMillis)
        }
        refreshTick.value++
    }

    private fun hasUsageAccess(): Boolean {
        return try {
            val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(),
                packageName
            )
            mode == AppOpsManager.MODE_ALLOWED
        } catch (e: Exception) {
            false
        }
    }

    private fun requestUsageAccess() {
        try {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        } catch (e: Exception) {
            toast(R.string.toast_failure)
        }
    }

    /** Queries real device totals; returns available=false on any API failure (honest). */
    private fun queryTotals(networkType: Int, startMs: Long): UsageTotals {
        return try {
            val nsm = getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
            val end = System.currentTimeMillis()
            val bucket = nsm.querySummaryForDevice(networkType, null, startMs, end)
            UsageTotals(rx = bucket.rxBytes, tx = bucket.txBytes, available = true)
        } catch (e: RemoteException) {
            UsageTotals(0, 0, false)
        } catch (e: SecurityException) {
            UsageTotals(0, 0, false)
        } catch (e: Exception) {
            UsageTotals(0, 0, false)
        }
    }
}

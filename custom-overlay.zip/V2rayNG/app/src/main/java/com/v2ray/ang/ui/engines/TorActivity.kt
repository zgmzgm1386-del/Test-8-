package com.v2ray.ang.ui.engines

import android.content.Intent
import android.os.Bundle
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.v2ray.ang.AppConfig
import com.v2ray.ang.R
import com.v2ray.ang.core.ExternalEngineManager
import com.v2ray.ang.core.VpnServiceController
import com.v2ray.ang.extension.toastError
import com.v2ray.ang.extension.toastSuccess
import com.v2ray.ang.handler.MmkvManager
import com.v2ray.ang.ui.base.BaseComponentActivity
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.FormTextField
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import com.v2ray.ang.util.LogUtil
import kotlinx.coroutines.launch

/**
 * Tor engine page. Bridge/SOCKS settings are persisted with MMKV and handed to the
 * engine once its library is bundled. Start/stop goes through the central controller.
 */
class TorActivity : BaseComponentActivity() {

    private val socksPortState = mutableStateOf("")
    private val bridgesEnabledState = mutableStateOf(false)
    private val bridgeLinesState = mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        VpnServiceController.initialize(this)
        socksPortState.value = MmkvManager.decodeSettingsInt(PREF_TOR_SOCKS_PORT, 9050).toString()
        bridgesEnabledState.value = MmkvManager.decodeSettingsBool(PREF_TOR_BRIDGES_ENABLED, false)
        bridgeLinesState.value = MmkvManager.decodeSettingsString(PREF_TOR_BRIDGE_LINES, "").orEmpty()
    }

    @Composable
    override fun ScreenContent() {
        var socksPort by socksPortState
        var bridgesEnabled by bridgesEnabledState
        var bridgeLines by bridgeLinesState

        Scaffold(
            topBar = {
                AppTopBar(title = stringResource(R.string.title_tor), onBackClick = { finish() })
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = stringResource(R.string.tor_summary),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
                EngineStatusCard(engine = VpnServiceController.EngineType.TOR) {
                    EngineStartStopButtons(
                        engine = VpnServiceController.EngineType.TOR,
                        onStart = { startEngine() },
                        onStop = { stopEngine() }
                    )
                }
                EngineSectionDivider()
                Text(
                    text = stringResource(R.string.engine_section_settings),
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                FormTextField(
                    label = stringResource(R.string.tor_socks_port),
                    value = socksPort,
                    onValueChange = { value ->
                        socksPort = value.filter { it.isDigit() }.take(5)
                    },
                    maxLines = 1
                )
                EngineSwitchRow(
                    title = stringResource(R.string.tor_bridges_enabled),
                    checked = bridgesEnabled,
                    onCheckedChange = { checked -> bridgesEnabled = checked }
                )
                FormTextField(
                    label = stringResource(R.string.tor_bridge_lines),
                    value = bridgeLines,
                    onValueChange = { bridgeLines = it },
                    maxLines = 6
                )
                NavigationBarsSpacer()
            }
        }
    }

    private fun startEngine() {
        val port = socksPortState.value.toIntOrNull() ?: 9050
        MmkvManager.encodeSettings(PREF_TOR_SOCKS_PORT, port)
        MmkvManager.encodeSettings(PREF_TOR_BRIDGES_ENABLED, bridgesEnabledState.value)
        MmkvManager.encodeSettings(PREF_TOR_BRIDGE_LINES, bridgeLinesState.value)
        lifecycleScope.launch {
            val error = VpnServiceController.startEngine(
                this@TorActivity,
                VpnServiceController.EngineType.TOR
            ) { ctx ->
                val serviceClass = ExternalEngineManager.descriptorOf(
                    VpnServiceController.EngineType.TOR
                )?.serviceClassName ?: error("engine service not configured")
                val intent = Intent().setClassName(ctx.packageName, serviceClass)
                androidx.core.content.ContextCompat.startForegroundService(ctx, intent)
            }
            if (error != null) {
                LogUtil.w(AppConfig.TAG, "Tor start rejected: $error")
                toastError(getString(R.string.msg_engine_not_bundled, getString(R.string.title_tor)))
            } else {
                toastSuccess(R.string.toast_success)
            }
        }
    }

    private fun stopEngine() {
        VpnServiceController.stopActive(this)
    }

    companion object {
        private const val PREF_TOR_SOCKS_PORT = "pref_custom_tor_socks_port"
        private const val PREF_TOR_BRIDGES_ENABLED = "pref_custom_tor_bridges_enabled"
        private const val PREF_TOR_BRIDGE_LINES = "pref_custom_tor_bridge_lines"
    }
}

package com.v2ray.ang.ui.diagnostic

import android.os.Bundle
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.v2ray.ang.R
import com.v2ray.ang.ui.base.BaseComponentActivity
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.ItemDivider
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import com.v2ray.ang.util.NetDiagnostics
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Disruption Diagnostic page. REAL implementation: runs system DNS, DoH and HTTP
 * probes from the device and reports raw PASS/FAIL results with latency. Nothing
 * is simulated.
 */
class DiagnosticActivity : BaseComponentActivity() {

    data class DiagItem(val label: String, val passed: Boolean, val detail: String)

    private val runningState = mutableStateOf(false)
    private val resultsState = mutableStateOf<List<DiagItem>>(emptyList())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    @Composable
    override fun ScreenContent() {
        val running by runningState
        val results by resultsState

        Scaffold(
            topBar = {
                AppTopBar(title = stringResource(R.string.title_diagnostic), onBackClick = { finish() })
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                Text(
                    text = stringResource(R.string.diag_summary),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
                Button(
                    onClick = { runDiagnostics() },
                    enabled = !running,
                    modifier = Modifier.padding(horizontal = 16.dp)
                ) {
                    Text(stringResource(if (running) R.string.diag_running else R.string.diag_run))
                }
                if (results.isEmpty()) {
                    Text(
                        text = stringResource(R.string.diag_no_results),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(16.dp)
                    )
                }
                LazyColumn(modifier = Modifier.weight(1f)) {
                    items(results) { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.label, style = MaterialTheme.typography.bodyLarge)
                                if (item.detail.isNotEmpty()) {
                                    Text(
                                        item.detail,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Text(
                                text = stringResource(
                                    if (item.passed) R.string.diag_result_pass else R.string.diag_result_fail
                                ),
                                style = MaterialTheme.typography.titleMedium,
                                color = if (item.passed) MaterialTheme.colorScheme.tertiary
                                else MaterialTheme.colorScheme.error
                            )
                        }
                        ItemDivider()
                    }
                    item { NavigationBarsSpacer() }
                }
            }
        }
    }

    private fun runDiagnostics() {
        runningState.value = true
        resultsState.value = emptyList()

        lifecycleScope.launch {
            val items: List<DiagItem> = withContext(Dispatchers.IO) {
                val jobs = listOf(
                    async {
                        val ips = NetDiagnostics.dnsLookupSystem("www.google.com")
                        DiagItem(
                            getString(R.string.diag_system_dns),
                            ips.isNotEmpty(),
                            ips.take(2).joinToString(", ")
                        )
                    },
                    async {
                        val ips = NetDiagnostics.dnsLookupDoh("www.google.com")
                        DiagItem(
                            getString(R.string.diag_doh_dns),
                            ips.isNotEmpty(),
                            ips.take(2).joinToString(", ")
                        )
                    },
                    async {
                        val r = NetDiagnostics.httpProbe("https://www.google.com/generate_204")
                        DiagItem(
                            getString(R.string.diag_http_google),
                            r.ok,
                            r.detail ?: NetDiagnostics.formatLatency(r.latencyMs)
                        )
                    },
                    async {
                        val r = NetDiagnostics.httpProbe("http://connectivitycheck.gstatic.com/generate_204")
                        DiagItem(
                            getString(R.string.diag_http_gstatic),
                            r.ok,
                            r.detail ?: NetDiagnostics.formatLatency(r.latencyMs)
                        )
                    }
                )
                jobs.awaitAll()
            }
            resultsState.value = items
            runningState.value = false
        }
    }
}

package com.v2ray.ang.ui.gasmhr

import android.os.Bundle
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.v2ray.ang.R
import com.v2ray.ang.handler.AngConfigManager
import com.v2ray.ang.handler.MmkvManager
import com.v2ray.ang.ui.base.BaseComponentActivity
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.FormTextField
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import com.v2ray.ang.ui.engines.EngineSectionDivider
import com.v2ray.ang.ui.engines.EngineSwitchRow
import com.v2ray.ang.util.NetDiagnostics
import com.v2ray.ang.extension.toast
import com.v2ray.ang.extension.toastError
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Google Apps Script / MHR endpoint page. REAL implementation: performs an HTTPS
 * GET against the user-configured endpoint and feeds the raw response into
 * AngConfigManager.importBatchConfig, which parses vless://, vmess://, ss:// etc.
 * No fake import counts are ever shown.
 */
class GasMhrActivity : BaseComponentActivity() {

    private val urlState = mutableStateOf("")
    private val appendState = mutableStateOf(true)
    private val busyState = mutableStateOf(false)
    private val resultState = mutableStateOf<String?>(null)
    private val isErrorState = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        urlState.value = MmkvManager.decodeSettingsString(PREF_GAS_MHR_URL, "").orEmpty()
        appendState.value = MmkvManager.decodeSettingsBool(PREF_GAS_MHR_APPEND, true)
    }

    @Composable
    override fun ScreenContent() {
        var url by urlState
        var append by appendState
        val busy by busyState
        val result by resultState

        Scaffold(
            topBar = {
                AppTopBar(title = stringResource(R.string.title_gas_mhr), onBackClick = { finish() })
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = stringResource(R.string.gas_mhr_summary),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
                FormTextField(
                    label = stringResource(R.string.gas_mhr_url),
                    value = url,
                    onValueChange = { url = it },
                    maxLines = 2,
                    isError = url.isNotEmpty() && !url.trim().startsWith("https://"),
                    supportingText = if (url.isNotEmpty() && !url.trim().startsWith("https://"))
                        stringResource(R.string.gas_mhr_invalid_url) else null
                )
                EngineSwitchRow(
                    title = stringResource(R.string.gas_mhr_append_mode),
                    checked = append,
                    onCheckedChange = { checked -> append = checked }
                )
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = { fetchAndImport() },
                        enabled = !busy && url.trim().startsWith("https://")
                    ) {
                        Text(stringResource(if (busy) R.string.diag_running else R.string.gas_mhr_fetch))
                    }
                }
                result?.let {
                    Text(
                        text = it,
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (isErrorState.value) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }
                EngineSectionDivider()
                NavigationBarsSpacer()
            }
        }
    }

    private fun fetchAndImport() {
        val endpoint = urlState.value.trim()
        if (!endpoint.startsWith("https://")) {
            toast(R.string.gas_mhr_invalid_url)
            return
        }
        MmkvManager.encodeSettings(PREF_GAS_MHR_URL, endpoint)
        MmkvManager.encodeSettings(PREF_GAS_MHR_APPEND, appendState.value)
        busyState.value = true
        resultState.value = null

        lifecycleScope.launch {
            var ok = false
            val result: String = withContext(Dispatchers.IO) {
                val body = NetDiagnostics.fetchRawText(endpoint, timeoutMs = 15000)
                if (body == null) {
                    getString(R.string.gas_mhr_network_error, "no response / timeout")
                } else {
                    val append = appendState.value
                    val (profiles, subs) = AngConfigManager.importBatchConfig(body, "", append)
                    if (profiles == 0 && subs == 0) {
                        getString(R.string.gas_mhr_result_empty)
                    } else {
                        ok = true
                        getString(R.string.gas_mhr_result_ok, profiles, subs)
                    }
                }
            }
            busyState.value = false
            resultState.value = result
            isErrorState.value = !ok
            if (!ok) toastError(result)
        }
    }

    companion object {
        private const val PREF_GAS_MHR_URL = "pref_custom_gas_mhr_url"
        private const val PREF_GAS_MHR_APPEND = "pref_custom_gas_mhr_append"
    }
}

package com.v2ray.ang.ui.engines

import android.content.Intent
import android.os.Bundle
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.v2ray.ang.AppConfig
import com.v2ray.ang.R
import com.v2ray.ang.core.ExternalEngineManager
import com.v2ray.ang.core.VpnServiceController
import com.v2ray.ang.extension.toastError
import com.v2ray.ang.extension.toastSuccess
import com.v2ray.ang.handler.MmkvManager
import com.v2ray.ang.ui.base.BaseComponentActivity
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.FormTextField
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import com.v2ray.ang.util.LogUtil
import kotlinx.coroutines.launch

/**
 * Psiphon (Shir-o-Khorshid) engine page. Region and timeout settings are persisted
 * and handed to the engine once its library is bundled in a build.
 */
class PsiphonActivity : BaseComponentActivity() {

    private val regionState = mutableStateOf("")
    private val disableTimeoutState = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        VpnServiceController.initialize(this)
        regionState.value = MmkvManager.decodeSettingsString(PREF_PSIPHON_REGION, "").orEmpty()
        disableTimeoutState.value = MmkvManager.decodeSettingsBool(PREF_PSIPHON_NO_TIMEOUT, false)
    }

    @Composable
    override fun ScreenContent() {
        var region by regionState
        var disableTimeout by disableTimeoutState

        Scaffold(
            topBar = {
                AppTopBar(title = stringResource(R.string.title_psiphon), onBackClick = { finish() })
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = stringResource(R.string.psiphon_summary),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
                EngineStatusCard(engine = VpnServiceController.EngineType.PSIPHON) {
                    EngineStartStopButtons(
                        engine = VpnServiceController.EngineType.PSIPHON,
                        onStart = { startEngine() },
                        onStop = { stopEngine() }
                    )
                }
                EngineSectionDivider()
                Text(
                    text = stringResource(R.string.engine_section_settings),
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                FormTextField(
                    label = stringResource(R.string.psiphon_region),
                    value = region,
                    onValueChange = { region = it },
                    maxLines = 1
                )
                EngineSwitchRow(
                    title = stringResource(R.string.psiphon_disable_timeout),
                    checked = disableTimeout,
                    onCheckedChange = { checked -> disableTimeout = checked }
                )
                NavigationBarsSpacer()
            }
        }
    }

    private fun startEngine() {
        MmkvManager.encodeSettings(PREF_PSIPHON_REGION, regionState.value)
        MmkvManager.encodeSettings(PREF_PSIPHON_NO_TIMEOUT, disableTimeoutState.value)
        lifecycleScope.launch {
            val error = VpnServiceController.startEngine(
                this@PsiphonActivity,
                VpnServiceController.EngineType.PSIPHON
            ) { ctx ->
                val serviceClass = ExternalEngineManager.descriptorOf(
                    VpnServiceController.EngineType.PSIPHON
                )?.serviceClassName ?: error("engine service not configured")
                val intent = Intent().setClassName(ctx.packageName, serviceClass)
                androidx.core.content.ContextCompat.startForegroundService(ctx, intent)
            }
            if (error != null) {
                LogUtil.w(AppConfig.TAG, "Psiphon start rejected: $error")
                toastError(getString(R.string.msg_engine_not_bundled, getString(R.string.title_psiphon)))
            } else {
                toastSuccess(R.string.toast_success)
            }
        }
    }

    private fun stopEngine() {
        VpnServiceController.stopActive(this)
    }

    companion object {
        private const val PREF_PSIPHON_REGION = "pref_custom_psiphon_region"
        private const val PREF_PSIPHON_NO_TIMEOUT = "pref_custom_psiphon_no_timeout"
    }
}

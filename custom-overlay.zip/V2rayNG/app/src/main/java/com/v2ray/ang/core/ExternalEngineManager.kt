package com.v2ray.ang.core

import android.content.Context
import com.v2ray.ang.AppConfig
import com.v2ray.ang.R
import com.v2ray.ang.util.LogUtil
import java.util.Locale

/**
 * Registry and availability checker for the external VPN engines that can be shipped
 * with the fork (SlipNet / Tor / Psiphon).
 *
 * An engine counts as BUNDLED only when a signed build includes, under
 * `assets/engines/<id>/`, a `BUNDLE_MARKER` file whose first line is the engine
 * version. This keeps the check honest: menu pages for engines whose native library
 * is NOT present in the APK clearly report that the engine is not bundled instead of
 * pretending to start a service that cannot work.
 *
 * To enable an engine in a future build:
 *  1. Add its native/AAR library to `app/libs` (or code) and its assets marker.
 *  2. Declare its foreground VpnService in the manifest.
 *  3. Set [ExternalEngineDescriptor.serviceClassName] below.
 *  4. Route its start through [VpnServiceController.startEngine].
 */
object ExternalEngineManager {

    data class ExternalEngineDescriptor(
        val id: String,
        val serviceClassName: String?,
        /** Optional asset file expected inside the marker directory. */
        val requiredAssetFile: String? = null
    )

    val SLIPNET = ExternalEngineDescriptor("slipnet", serviceClassName = null)
    val TOR = ExternalEngineDescriptor("tor", serviceClassName = null)
    val PSIPHON = ExternalEngineDescriptor("psiphon", serviceClassName = null)

    val ALL = listOf(SLIPNET, TOR, PSIPHON)

    fun descriptorOf(engine: VpnServiceController.EngineType): ExternalEngineDescriptor? = when (engine) {
        VpnServiceController.EngineType.SLIPNET -> SLIPNET
        VpnServiceController.EngineType.TOR -> TOR
        VpnServiceController.EngineType.PSIPHON -> PSIPHON
        else -> null
    }

    /** @return engine version when bundled, null otherwise. */
    fun bundledVersion(context: Context, engine: VpnServiceController.EngineType): String? {
        val descriptor = descriptorOf(engine) ?: return null
        return runCatching {
            context.assets.open("engines/${descriptor.id}/BUNDLE_MARKER")
                .bufferedReader().useLines { lines -> lines.firstOrNull()?.trim() }
        }.onFailure {
            LogUtil.d(AppConfig.TAG, "Engine ${descriptor.id} not bundled: ${it.message}")
        }.getOrNull()?.takeIf { it.isNotEmpty() }
    }

    /** Honest availability: true only when the engine library really ships in this build. */
    fun isBundled(context: Context, engine: VpnServiceController.EngineType): Boolean {
        if (engine == VpnServiceController.EngineType.XRAY) return true
        if (engine == VpnServiceController.EngineType.NONE) return false
        val descriptor = descriptorOf(engine) ?: return false
        val hasMarker = bundledVersion(context, engine) != null
        val hasAsset = descriptor.requiredAssetFile?.let { file ->
            runCatching {
                context.assets.open("engines/${descriptor.id}/$file").close()
                true
            }.getOrDefault(false)
        } ?: true
        return hasMarker && hasAsset
    }

    /** Human-readable reason shown in UI/logs when an engine is not bundled. */
    fun missingReason(context: Context, engine: VpnServiceController.EngineType): String {
        if (engine == VpnServiceController.EngineType.XRAY) return ""
        return context.getString(R.string.msg_engine_not_bundled, engineDisplayName(context, engine))
    }

    fun engineDisplayName(context: Context, engine: VpnServiceController.EngineType): String {
        val res = when (engine) {
            VpnServiceController.EngineType.SLIPNET -> R.string.title_slipnet
            VpnServiceController.EngineType.TOR -> R.string.title_tor
            VpnServiceController.EngineType.PSIPHON -> R.string.title_psiphon
            VpnServiceController.EngineType.XRAY -> return "Xray"
            VpnServiceController.EngineType.NONE -> return "—"
        }
        return context.getString(res)
    }

    fun engineStatusLine(context: Context, engine: VpnServiceController.EngineType): String {
        val version = bundledVersion(context, engine)
        return if (version != null) {
            String.format(Locale.US, "%s v%s", context.getString(R.string.engine_state_bundled), version)
        } else {
            context.getString(R.string.engine_state_not_bundled)
        }
    }
}

package com.v2ray.ang.ui.tools

import android.os.Bundle
import android.util.Base64
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.v2ray.ang.R
import com.v2ray.ang.ui.base.BaseComponentActivity
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.FormTextField
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import com.v2ray.ang.ui.engines.EngineSectionDivider
import com.v2ray.ang.extension.toast
import com.v2ray.ang.util.NetDiagnostics
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Tools page. All actions are REAL:
 * - TCPing: measured TCP handshake latency
 * - DNS lookup: actual resolver answer list
 * - Speed test: downloads ~10 MB from the documented endpoint and measures throughput
 * - Base64: local encode/decode
 */
class ToolsActivity : BaseComponentActivity() {

    // TCPing
    private val pingHostState = mutableStateOf("www.google.com")
    private val pingPortState = mutableStateOf("443")
    private val pingResultState = mutableStateOf<String?>(null)

    // DNS
    private val dnsHostState = mutableStateOf("www.google.com")
    private val dnsResultState = mutableStateOf<String?>(null)

    // Speed
    private val speedResultState = mutableStateOf<String?>(null)
    private val busyState = mutableStateOf(false)

    // Base64
    private val b64InputState = mutableStateOf("")
    private val b64OutputState = mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    @Composable
    override fun ScreenContent() {
        Scaffold(
            topBar = {
                AppTopBar(title = stringResource(R.string.title_tools), onBackClick = { finish() })
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
            ) {
                // ---- TCPing ----
                SectionTitle(stringResource(R.string.tools_tcping))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
                    Column(modifier = Modifier.weight(2f)) {
                        FormTextField(
                            label = stringResource(R.string.tools_tcping_host),
                            value = pingHostState.value,
                            onValueChange = { pingHostState.value = it },
                            maxLines = 1
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        FormTextField(
                            label = stringResource(R.string.tools_tcping_port),
                            value = pingPortState.value,
                            onValueChange = { pingPortState.value = it.filter(Char::isDigit).take(5) },
                            maxLines = 1
                        )
                    }
                }
                ActionButton(stringResource(R.string.tools_run)) { runTcping() }
                pingResultState.value?.let { ResultText(it) }

                EngineSectionDivider()

                // ---- DNS lookup ----
                SectionTitle(stringResource(R.string.tools_dns_lookup))
                FormTextField(
                    label = stringResource(R.string.tools_dns_host),
                    value = dnsHostState.value,
                    onValueChange = { dnsHostState.value = it },
                    maxLines = 1
                )
                ActionButton(stringResource(R.string.tools_run)) { runDnsLookup() }
                dnsResultState.value?.let { ResultText(it) }

                EngineSectionDivider()

                // ---- Speed test ----
                SectionTitle(stringResource(R.string.tools_speed_test))
                ActionButton(
                    stringResource(if (busyState.value) R.string.diag_running else R.string.tools_run),
                    enabled = !busyState.value
                ) { runSpeedTest() }
                speedResultState.value?.let { ResultText(it) }

                EngineSectionDivider()

                // ---- Base64 ----
                SectionTitle(stringResource(R.string.tools_base64_encode) + " / " + stringResource(R.string.tools_base64_decode))
                FormTextField(
                    label = stringResource(R.string.tools_base64_input),
                    value = b64InputState.value,
                    onValueChange = { b64InputState.value = it },
                    maxLines = 4
                )
                Row(modifier = Modifier.padding(horizontal = 16.dp), horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = { encodeBase64() }) {
                        Text(stringResource(R.string.tools_base64_encode))
                    }
                    OutlinedButton(onClick = { decodeBase64() }) {
                        Text(stringResource(R.string.tools_base64_decode))
                    }
                }
                FormTextField(
                    label = stringResource(R.string.tools_base64_output),
                    value = b64OutputState.value,
                    onValueChange = { },
                    maxLines = 4,
                    enabled = false
                )
                NavigationBarsSpacer()
            }
        }
    }

    @Composable
    private fun SectionTitle(text: String) {
        Text(
            text = text,
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        )
    }

    @Composable
    private fun ActionButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
        Button(
            onClick = onClick,
            enabled = enabled,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        ) {
            Text(text)
        }
    }

    @Composable
    private fun ResultText(text: String) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.tertiary,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )
    }

    private fun runTcping() {
        val host = pingHostState.value.trim()
        val port = pingPortState.value.toIntOrNull()
        if (host.isEmpty() || port == null || port !in 1..65535) {
            toast(R.string.tools_invalid_input)
            return
        }
        busyState.value = true
        lifecycleScope.launch {
            val latency = withContext(Dispatchers.IO) { NetDiagnostics.tcpConnect(host, port, timeoutMs = 2000) }
            pingResultState.value = getString(
                R.string.tools_result_latency,
                if (latency >= 0) NetDiagnostics.formatLatency(latency) else getString(R.string.tools_error)
            )
            busyState.value = false
        }
    }

    private fun runDnsLookup() {
        val host = dnsHostState.value.trim()
        if (host.isEmpty()) {
            toast(R.string.tools_invalid_input)
            return
        }
        busyState.value = true
        lifecycleScope.launch {
            val ips = withContext(Dispatchers.IO) { NetDiagnostics.dnsLookupSystem(host) }
            dnsResultState.value = getString(
                R.string.tools_result_ips,
                if (ips.isNotEmpty()) ips.joinToString(", ") else getString(R.string.tools_error)
            )
            busyState.value = false
        }
    }

    private fun runSpeedTest() {
        busyState.value = true
        speedResultState.value = null
        lifecycleScope.launch {
            val pair = withContext(Dispatchers.IO) {
                NetDiagnostics.downloadSpeedTest(NetDiagnostics.TEST_SPEED_URL)
            }
            speedResultState.value = if (pair == null) {
                getString(R.string.tools_error)
            } else {
                val (bytes, ms) = pair
                val seconds = ms / 1000.0
                getString(
                    R.string.tools_speed_result,
                    NetDiagnostics.formatBytes(bytes),
                    NetDiagnostics.formatLatency(ms),
                    NetDiagnostics.formatMbps(bytes / seconds)
                )
            }
            busyState.value = false
        }
    }

    private fun encodeBase64() {
        try {
            b64OutputState.value = Base64.encodeToString(
                b64InputState.value.toByteArray(Charsets.UTF_8), Base64.NO_WRAP
            )
        } catch (e: Exception) {
            toast(R.string.tools_error)
        }
    }

    private fun decodeBase64() {
        try {
            b64OutputState.value = String(
                Base64.decode(b64InputState.value.trim(), Base64.DEFAULT), Charsets.UTF_8
            )
        } catch (e: Exception) {
            toast(R.string.tools_invalid_input)
        }
    }
}

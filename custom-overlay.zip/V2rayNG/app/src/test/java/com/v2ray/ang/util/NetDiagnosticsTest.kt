package com.v2ray.ang.util

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test

/** JVM tests for the pure parsing/formatting helpers used by the fork tools. */
class NetDiagnosticsTest {

    @Test
    fun `expandCidr returns bounded range for slash 24`() {
        val result = NetDiagnostics.expandCidr("104.16.0.0/24")
        requireNotNull(result)
        assertEquals(256, result.size)
        assertEquals("104.16.0.0", result.first())
        assertEquals("104.16.0.255", result.last())
    }

    @Test
    fun `expandCidr respects network boundary for slash 23`() {
        val result = NetDiagnostics.expandCidr("104.16.3.7/23", maxAddresses = 1024)
        requireNotNull(result)
        assertEquals(512, result.size)
        assertEquals("104.16.2.0", result.first())
        assertEquals("104.16.3.255", result.last())
    }

    @Test
    fun `expandCidr rejects malformed input`() {
        assertNull(NetDiagnostics.expandCidr("not-a-cidr"))
        assertNull(NetDiagnostics.expandCidr("104.16.0.0"))
        assertNull(NetDiagnostics.expandCidr("104.16.0.0/33"))
        assertNull(NetDiagnostics.expandCidr("999.16.0.0/24"))
        assertNull(NetDiagnostics.expandCidr("104.16.0.0/15")) // 32768 > default cap
    }

    @Test
    fun `isValidIpv4 accepts only plausible addresses`() {
        assertTrue(NetDiagnostics.isValidIpv4("104.16.0.1"))
        assertTrue(NetDiagnostics.isValidIpv4("0.0.0.0"))
        assertFalse(NetDiagnostics.isValidIpv4("104.16.0"))
        assertFalse(NetDiagnostics.isValidIpv4("104.16.0.256"))
        assertFalse(NetDiagnostics.isValidIpv4("104.16.00.1"))
        assertFalse(NetDiagnostics.isValidIpv4("example.com"))
    }

    @Test
    fun `parseDohAnswerIps extracts only A records`() {
        val json = """
            {"Status":0,"Answer":[
                {"name":"www.google.com.","type":1,"TTL":300,"data":"142.250.4.104"},
                {"name":"www.google.com.","type":28,"TTL":300,"data":"2607:f8b0:4004:c07::71"},
                {"name":"www.google.com.","type":5,"TTL":300,"data":"www.google.com."}
            ]}
        """.trimIndent()
        val ips = NetDiagnostics.parseDohAnswerIps(json)
        assertEquals(listOf("142.250.4.104"), ips)
    }

    @Test
    fun `parseDohAnswerIps handles null and invalid payloads`() {
        assertEquals(emptyList<String>(), NetDiagnostics.parseDohAnswerIps(null))
        assertEquals(emptyList<String>(), NetDiagnostics.parseDohAnswerIps(""))
        assertEquals(emptyList<String>(), NetDiagnostics.parseDohAnswerIps("not json"))
        assertEquals(emptyList<String>(), NetDiagnostics.parseDohAnswerIps("{\"Status\":0}"))
    }

    @Test
    fun `formatBytes produces human units`() {
        assertEquals("0 B", NetDiagnostics.formatBytes(0))
        assertEquals("512 B", NetDiagnostics.formatBytes(512))
        assertEquals("1.00 KB", NetDiagnostics.formatBytes(1024))
        assertEquals("1.50 MB", NetDiagnostics.formatBytes((1.5 * 1024 * 1024).toLong()))
        assertEquals("2.00 GB", NetDiagnostics.formatBytes(2L * 1024 * 1024 * 1024))
        assertEquals("—", NetDiagnostics.formatBytes(-1))
    }

    @Test
    fun `formatLatency switches unit at one second`() {
        assertEquals("250 ms", NetDiagnostics.formatLatency(250))
        assertEquals("1.50 s", NetDiagnostics.formatLatency(1500))
        assertEquals("—", NetDiagnostics.formatLatency(-1))
    }

    @Test
    fun `formatMbps converts bytes per second`() {
        // 1_000_000 bytes/s = 8 Mbps
        assertEquals("8.00 Mbps", NetDiagnostics.formatMbps(1_000_000.0))
    }
}

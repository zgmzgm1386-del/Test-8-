package com.v2ray.ang.core

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test

/**
 * JVM tests for the central VPN Service Controller arbitration rule that keeps at
 * most one VPN engine active at a time.
 */
class VpnServiceControllerTest {

    @Test
    fun `starts directly when nothing is running`() {
        val decision = VpnServiceController.decideStart(
            activeEngineRunning = false,
            requested = VpnServiceController.EngineType.XRAY
        )
        assertEquals(StartDecision.START, decision)
    }

    @Test
    fun `same running engine is idempotent`() {
        // Simulate Xray being the acknowledged active engine.
        VpnServiceController.resetForTest(VpnServiceController.EngineType.XRAY)
        val decision = VpnServiceController.decideStart(
            activeEngineRunning = true,
            requested = VpnServiceController.EngineType.XRAY
        )
        assertEquals(StartDecision.ALREADY_RUNNING, decision)
        VpnServiceController.resetForTest(VpnServiceController.EngineType.NONE)
    }

    @Test
    fun `different running engine requires stop then start`() {
        VpnServiceController.resetForTest(VpnServiceController.EngineType.XRAY)
        val decision = VpnServiceController.decideStart(
            activeEngineRunning = true,
            requested = VpnServiceController.EngineType.TOR
        )
        assertEquals(StartDecision.STOP_THEN_START, decision)
        VpnServiceController.resetForTest(VpnServiceController.EngineType.NONE)
    }

    @Test
    fun `engine ids are stable lowercase`() {
        assertEquals("xray", VpnServiceController.EngineType.XRAY.id)
        assertEquals("slipnet", VpnServiceController.EngineType.SLIPNET.id)
        assertEquals("tor", VpnServiceController.EngineType.TOR.id)
        assertEquals("psiphon", VpnServiceController.EngineType.PSIPHON.id)
        assertEquals(
            VpnServiceController.EngineType.TOR,
            VpnServiceController.EngineType.fromId("tor")
        )
    }
}

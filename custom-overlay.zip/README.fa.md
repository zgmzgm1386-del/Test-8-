# v2rayNG نسخه سفارشی (Fork)

این پروژه یک نسخه سفارشی از [v2rayNG](https://github.com/2dust/v2rayNG) است که بر اساس توافق‌نامه انجام‌شده توسعه یافته است. **تمام قابلیت‌ها و رابط کاربری اصلی v2rayNG بدون هیچ تغییری حفظ شده‌اند** و تنها منوی همبرگری مطابق توافق اصلاح و ۱۰ صفحه جدید به‌صورت کاملاً بومی (Kotlin + Jetpack Compose) اضافه شده است.

---

## ۱. معرفی

- پایه: سورس رسمی v2rayNG نسخه **2.3.15** (شاخه master)
- موتور: **Xray Core** (از طریق `libv2ray.aar` رسمی پروژه 2dust — تگ `v26.10.31`)
- حداقل اندروید: 7.0 (API 24) — هدف: API 37
- زبان‌ها: تمام زبان‌های اصلی به‌همراه **فارسی کامل** برای همه صفحه‌های جدید

## ۲. قابلیت‌های جدید (۱۰ مورد)

| # | صفحه | وضعیت پیاده‌سازی واقعی |
|---|------|------------------------|
| 1 | **SlipNet** | صفحه بومی + اتصال به کنترلر مرکزی VPN. موتور SlipNet در ZIP ارائه‌نشده بود؛ بنابراین تا وقتی کتابخانه موتور + فایل `BUNDLE_MARKER` به بیلد اضافه شود، صفحه صادقانه وضعیت «در این بیلد موجود نیست» را نشان می‌دهد و هیچ تونل ساختگی‌ای شروع نمی‌شود. |
| 2 | **Tor** | صفحه بومی با تنظیمات SOCKS Port و Bridges (ذخیره در MMKV) + کنترلر مرکزی. موتور Tor (کتابخانه بومی) همراه بیلد نیست — وضعیت صادقانه نمایش داده می‌شود. |
| 3 | **Psiphon (شیر و خورشید)** | صفحه بومی با تنظیمات Region/Timeout + کنترلر مرکزی. موتور Psiphon همراه بیلد نیست — وضعیت صادقانه نمایش داده می‌شود. |
| 4 | **Google Script / MHR** | ✅ **کاملاً واقعی**: واکشی HTTPS از نقطه‌پایانی دلخواه شما و واردسازی خودکار کانفیگ‌ها (vless/vmess/ss/...) از طریق موتور واردسازی خود v2rayNG. |
| 5 | **IP Scan** | ✅ **کاملاً واقعی**: اسکن همزمان TCP (۶۴ اتصال موازی) روی بازه CIDR دلخواه (تا ۱۰۲۴ آدرس)، نمایش IPهای پاسخ‌دهنده بر اساس تأخیر واقعی، کپی به کلیپ‌بورد. |
| 6 | **Usage** | ✅ **کاملاً واقعی**: مصرف دانلود/آپلود امروز و این ماه (موبایل/وای‌فای) از شمارنده‌های خود اندروید (NetworkStatsManager) + مجموع از زمان روشن شدن دستگاه (TrafficStats). برای آمار دوره‌ای، دسترسی «Usage access» از کاربر گرفته می‌شود. |
| 7 | **Disruption Diagnostic** | ✅ **کاملاً واقعی**: رد DNS سیستم، رد DoH، پروب HTTP به نقاط بررسی اتصال (generate_204) با تأخیر واقعی و نتیجه موفق/ناموفق. |
| 8 | **Safety Shield** | ✅ **کاملاً واقعی**: IP عمومی و کشور (ip-api.com)، ریسالور DNS (edns.ip-api.com)، تشخیص رابط tun/ppp، قفل صفحه ایمن، دیباگر متصل، وضعیت رمزنگاری حافظه. نقاط پایانی خارجی در خود صفحه ذکر شده‌اند. |
| 9 | **Control Panel** | ✅ **کاملاً واقعی**: داشبورد زنده کنترلر مرکزی — موتور فعال، پروفایل انتخاب‌شده، وضعیت اجرا (از برادکست خود سرویس)، مدت فعالیت و ترافیک زنده دستگاه. |
| 10 | **Tools** | ✅ **کاملاً واقعی**: TCPing واقعی، جست‌وجوی DNS، تست سرعت دانلود (~۱۰MB از proof.ovh.net)، کدگذاری/کدگشایی Base64. |

> **صداقت فنی:** فایل `panels-manager-fixed.zip` تحویل و به‌طور کامل بررسی شد (Flutter/Dart، اسکریپت Code.gs، worker جاوااسکریپت و سورس Rust موتورها شامل `mhrv-rs` با crate-type `cdylib` برای اندروید، `torbin` و `psi_config.json` با اسکلت `native/kotlin`). نتیجه بررسی: ZIP فقط **سورس** موتورها را دارد و هیچ باینری آماده اندروید (`.so`/`.aar`) در آن نیست؛ تبدیل این سورس به کتابخانه اندروید نیازمند cross-compile با زنجیره Rust + NDK است که در محیط ساخت این پروژه (سندباکس ۲ هسته/فضای محدود) انجام‌پذیر نبود. به همین دلیل سه موتور SlipNet/Tor/Psiphon در **این بیلد** همراه نشده‌اند. صفحه‌ها، تنظیمات و اتصال به کنترلر مرکزی به‌طور کامل آماده است؛ منطق GAS/MHR از روی ZIP واقعاً پیاده‌سازی شده (صفحه شماره ۴). برای فعال‌سازی هر موتور در بیلد آینده، کتابخانه آن را بسازید و فایل `assets/engines/<id>/BUNDLE_MARKER` را اضافه کنید — همان صفحه بدون هیچ تغییر کدی فعال می‌شود (راهنما در کد `ExternalEngineManager`).

## ۳. ساختار منوی همبرگری

**بالای جداکننده (بدون تغییر — همه حفظ شده‌اند):**
1. Subscription Group Settings
2. Per-App Settings
3. Routing Settings
4. Geo Resources
5. Settings

**زیر جداکننده — حذف‌شده‌ها (فقط از منو؛ کلاس‌ها و قابلیت‌های زیرین سالم‌اند):**
- Promotion (تبلیغات)، Logcat (گزارش‌ها)، Check Update، Backup/Restore، About

**زیر جداکننده — اضافه‌شده‌ها (هر کدام یک آیتم مستقل):**
SlipNet · Tor · Psiphon (شیر و خورشید) · Google Script/MHR · IP Scan · Usage · Disruption Diagnostic · Safety Shield · Control Panel · Tools

**صفحه اصلی v2rayNG (لیست کانفیگ‌ها، اتصال/قطع، گروه‌ها، تست تأخیر و ...) هیچ تغییری نکرده است.**

## ۴. معماری: Central VPN Service Controller

```
                        ┌─────────────────────────────┐
                        │   UI (MainActivity drawer)  │
                        └──────────────┬──────────────┘
                                       │ startEngine(engine)
                        ┌──────────────▼──────────────┐
                        │   VpnServiceController      │  ← تک‌سرویس فعال (Invariant)
                        │  (core/VpnServiceController)│
                        │                             │
                        │  StartDecision (تست‌پذیر):  │
                        │   • ALREADY_RUNNING         │
                        │   • START                   │
                        │   • STOP_THEN_START         │
                        └───┬──────────┬──────────┬───┘
                            │          │          │
              stop+await(5s)│   Explicit ComponentName│
                            ▼          ▼          ▼
                   ┌────────────┐ ┌──────────┐ ┌──────────┐
                   │ Xray (Core)│ │ SlipNet  │ │Tor/Psiphon│
                   │ Launcher-  │ │ (وقتی   │ │(وقتی    │
                   │ Manager    │ │  bundled)│ │ bundled) │
                   └────────────┘ └──────────┘ └──────────┘
```

- هر شروع سرویس از طریق `VpnServiceController.startEngine()` انجام می‌شود؛ اگر موتور دیگری فعال باشد، ابتدا توقف آن از سرویس فعلی درخواست، **تأیید توقف از برادکست خود دیمون منتظر می‌شود (تا ۵ ثانیه)** و بعد موتور جدید شروع می‌شود. در نتیجه هرگز دو VpnService هم‌زمان برای TUN نمی‌جنگند.
- مرجع نهایی وضعیت «در حال اجرا»، پروسه دیمون است (`MSG_STATE_RUNNING`/`MSG_STATE_NOT_RUNNING`) — کنترلر فقط وضعیت را دنبال می‌کند و تصمیمات را بر اساس برادکست‌های واقعی دیمون می‌گیرد.
- فرآیند توقف/تعویض شامل آزادسازی TUN و منابع توسط همان مکانیزم رسمی `CoreVpnService` است (`stopAllService`، بستن Interface در `onDestroy`).
- منطق تصمیم‌گیری (`decideStart`) خالص و تحت پوشش تست واحد JVM است.

## ۵. روش Build (محلی)

پیش‌نیازها: JDK 21، Android SDK (platform 37 + build-tools 37 + platform-tools)، NDK 30.0.16248370

```bash
git clone <این مخزن> && cd v2rayNG
git submodule update --init --recursive          # AndroidLibXrayLite + hev-socks5-tunnel
cd hev-socks5-tunnel && git submodule update --init --recursive && cd ..
export ANDROID_HOME=/path/to/sdk
export NDK_HOME=$ANDROID_HOME/ndk/30.0.16248370
export JAVA_HOME=/path/to/jdk-21

bash compile-hevtun.sh                           # ساخت کتابخانه بومی hev (خروجی: ./libs)
cp -r libs V2rayNG/app/                          # قرار دادن .so ها کنار libv2ray.aar

mkdir -p V2rayNG/app/libs
curl -L -o V2rayNG/app/libs/libv2ray.aar \
  "https://github.com/2dust/AndroidLibXrayLite/releases/download/v26.10.31/libv2ray.aar"

cd V2rayNG
echo "sdk.dir=$ANDROID_HOME" > local.properties
./gradlew :app:assemblePlaystoreDebug            # خروجی: app/build/outputs/apk/playstore/debug/
```

نکته: `V2rayNG/app/libs/libv2ray.aar` و پوشه `libs/` (فایل‌های .so) از قبل داخل مخزن تحویل داده شده‌اند تا Build آفلاین هم کار کند؛ اسکریپت‌های بالا برای به‌روزرسانی بعدی‌اند.

## ۶. GitHub Actions

دو Workflow در `.github/workflows/` اضافه شده است:

1. **android-fork-debug.yml** — روی هر push/PR یا دستی: سورس را با هر ۴ ABI به‌صورت Debug می‌سازد و APKها را به‌عنوان Artifact منتشر می‌کند (بدون نیاز به هیچ Secret).
2. **android-fork-release.yml** — فقط دستی (workflow_dispatch) با ورودی `release_tag`:
   - اگر Secret های `APP_KEYSTORE_BASE64` / `APP_KEYSTORE_PASSWORD` / `APP_KEYSTORE_ALIAS` / `APP_KEY_PASSWORD` تنظیم شده باشند، APK امضاشده Release ساخته و به GitHub Releases منتشر می‌شود.
   - اگر Secret تنظیم نشده باشد، Job با پیام خطای صریح متوقف می‌شود — **هرگز APK بدون امضا را «امضاشده» جا نمی‌زند.**
   - Keystore هرگز داخل سورس قرار نمی‌گیرد.

(Workflow رسمی upstream یعنی build.yml هم برای انتشار Release حفظ شده است.)

## ۷. دریافت و نصب APK

- APKهای Debug همین نسخه ضمیمه این تحویل هستند: نسخه **Universal** (هر ۴ معماری، ~۸۴MB) و **arm64-v8a** (~۴۱MB).
- APKهای Debug با کلید دیباگ اندروید امضا شده‌اند (debug-signed) — برای تست/استفاده شخصی قابل نصب‌اند؛ برای انتشار نهایی از Workflow Release با Secret های خودتان استفاده کنید.
- نصب: انتقال فایل به گوشی → اجرا → تأیید «نصب از منابع ناشناس» (نخستین بار).
- اگر v2rayNG اصلی نصب است، نسخه playstore این فورک روی آن نصب/به‌روزرسانی می‌شود (همان `com.v2ray.ang`)؛ نسخه fdroid (`com.v2ray.ang.fdroid`) به‌صورت جداگانه کنارش نصب می‌شود.

## ۸. راهنمای استفاده از قابلیت‌های جدید

- **Google Script/MHR:** آدرس https نقطه‌پایانی را وارد و «واکشی و افزودن» را بزنید؛ کانفیگ‌ها به لیست پروفایل‌های صفحه اصلی اضافه می‌شوند (مثل واردسازی دستی خود v2rayNG).
- **IP Scan:** بازه CIDR (مثلاً `104.16.0.0/24`)، پورت و Timeout را تنظیم و «شروع اسکن» کنید؛ نتیجه‌ها بر اساس کمترین تأخیر مرتب می‌شوند.
- **Usage:** نخستین بار «اعطای دسترسی مصرف» را بزنید و در تنظیمات اندروید به این اپ اجازه Usage access بدهید؛ بعد آمار امروز/ماه نمایش داده می‌شود.
- **Diagnostic / Safety Shield:** فقط دکمه اجرا را بزنید؛ همه نتایج واقعی‌اند.
- **Control Panel:** وضعیت لحظه‌ای اتصال و امکان قطع از داخل داشبورد.
- **SlipNet/Tor/Psiphon:** تا همراه‌شدن موتور، صفحه وضعیت «در این بیلد موجود نیست» را نشان می‌دهد و دکمه شروع غیرفعال است — این رفتار عمدی و صادقانه است، نه نقص.

## ۹. وابستگی‌ها و نقاط پایانی خارجی

- **Xray Core:** `libv2ray.aar` از Releases رسمی 2dust/AndroidLibXrayLite (تگ v26.10.31)
- **hev-socks5-tunnel:** ساب‌مدیول رسمی heiher — کامپایل با NDK 30 (۴ ABI)
- سایر وابستگی‌ها: همان‌های پروژه upstream (Compose BOM 2026.09، MMKV، OkHttp، Gson، ZXing، CameraX، WorkManager...)
- نقاط پایانی شبکه در صفحات جدید (همگی مستند در خود کد/صفحه):
  - `dns.google/resolve` (DoH تشخیصی)
  - `ip-api.com` و `edns.ip-api.com` (Safety Shield — http و بدون کلید)
  - `proof.ovh.net` (فایل تست سرعت)
  - نقطه‌پایانی GAS/MHR که **خود کاربر** وارد می‌کند
- هیچ API Key، Secret یا پس‌وردی در کد هاردکد نشده است. هیچ درِ پشتی یا کنترل مخفی وجود ندارد.

## ۱۰. محدودیت‌های فنی و صداقت آزمون

- سه موتور SlipNet/Tor/Psiphon در این بیلد همراه نیستند (ZIP ارائه نشد) — صفحه‌ها صادقانه این را نشان می‌دهند.
- تست روی گوشی/شبیه‌ساز واقعی در محیط ساخت انجام نشده است؛ سناریوهای سرویس (شروع/توقف/تعویض موتور) باید روی دستگاه واقعی آزموده شوند — در گزارش آزمون با برچسب NOT TESTED ثبت شده‌اند.
- آنچه واقعاً اجرا و تأیید شده: کامپایل کامل، ۱۳۷ تست واحد JVM (0 شکست)، ساخت ۵ APK در هر دو طعم، و تأیید محتویات APK (مانیفست، کتابخانه‌های بومی، اکتیویتی‌ها). جزئیات در `TEST-REPORT.fa.md`.

## ۱۱. لایسنس

- کد پایه: لایسنس رسمی v2rayNG (LICENSE در ریشه مخزن — حفظ شده است).
- تغییرات سفارشی این فورک در `CUSTOMIZATIONS.md` فهرست شده‌اند تا مرز کد upstream و تغییرات شفاف بماند.
- هیچ بخشی با لایسنس ناسازگار از هیچ منبعی وارد این پروژه نشده است.

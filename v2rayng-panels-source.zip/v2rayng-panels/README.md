# v2rayNG — Panels Edition

A V2Ray/Xray client for Android based on the official **[v2rayNG](https://github.com/2dust/v2rayNG)** (F-Droid flavor), with a set of **native (Kotlin/Compose) anti-censorship panel modules** integrated into the app itself. No WebView, no HTML/CSS shell — every screen is native Compose in the same design language as v2rayNG.

> **GitHub Actions:** push this folder to a GitHub repository → the included
> `.github/workflows/build.yml` builds signed APKs automatically
> (`Actions → Build APK → Run workflow`, or on every push to `master`).
> APK artifacts appear under the run's *Artifacts* section.

---

## What is inside

Everything from official v2rayNG is preserved (config list, subscriptions,
connection, speed/traffic, settings, VPN service, notifications, DNS/routing,
dark/light themes). The **only** main-UI change, per the approved design:

- The navigation drawer keeps its top 5 entries + divider; the 5 items below
  the divider are replaced by **11 panel modules**:

| Module | Engine (real, inside the APK) | What it actually does |
|---|---|---|
| **SlipNet** | Go CLI from [anonvector/SlipNet](https://github.com/anonvector/SlipNet) (AGPL) as `libslipnet.so` | DNS/SSH/VLESS tunneling: imports a `slipnet://` profile, optional DNS override, real SOCKS+TUN tunnel with true connectivity verification |
| **Tor** | Rust [Arti](https://gitlab.torproject.org/tpo/core/arti) client as `libtorbin.so` (built from `engines/torbin`) | Real Tor network connection; optional obfs4 bridge lines are passed to the engine |
| **Psiphon (شیر و خورشید)** | `psiphon-tunnel-core` ConsoleClient as `libshkcore.so` | Zero-config Psiphon network with embedded config (`res/raw/psi_config.json`), optional egress region |
| **Google Script** | Rust kernel [mhrv-rs](https://github.com/therealaleph/MasterHttpRelayVPN-RUST) as `libmhrv_rs.so` | Deploys your own Apps Script relay (Code.gs included): stores endpoint+key, tests the relay with a real POST, generates the real mhrv config, starts the engine |
| **MHR** | same mhrv-rs kernel | Full config editor (apps_script / direct / full modes, ports, raw JSON), live engine stats via JNI (`statsJson`), live engine logs (`drainLogs`), MITM CA management |
| **IP Scan (اسکن IP)** | — (pure Kotlin) | Resolves the target, builds the /24 neighborhood, runs real TCP and TLS-SNI probes with concurrency control and progress |
| **Usage (مصرف)** | mhrv-rs counters | Real relay/bytes/cache counters from the engine + real today-quota countdown (Pacific rollover), accumulated per day on device |
| **Interference (اختلال)** | — (pure Kotlin) | Layered real probes: DNS (UDP/53 queries to real resolvers) → TCP:443 → TLS handshake with SNI → HTTP; tells you which layer is disrupted |
| **Safety Shield (سپر ایمنی)** | — (pure Kotlin) | Real MITM-CA export/install/fingerprint/install-check, real audit of user-added CAs in `AndroidCAStore`, real DNS resolver reachability + public IP/location |
| **Control Panel (کنترل پنل)** | mhrv-rs relay | Manages your Apps Script panel endpoint, real connection test, live relay statistics from the running engine, Code.gs copy/save |
| **Tools (ابزارها)** | — (pure Kotlin) | Real TCP ping, real DNS A-record lookup with answer parsing, public IP/location, real HTTP header fetch, and the original v2rayNG logcat |

### Single-VPN arbitration

`VpnArbiter` (Kotlin, `com.therealaleph.mhrv`) guarantees that **at most one VPN
engine is active at any moment** — v2rayNG core, mhrv-rs, SlipNet, Tor or
Psiphon. Before any engine starts it stops the active one (core via
`LauncherManager`, internal services via their stop actions), waits for the
real teardown, then starts the requested engine. Every screen shows only real
engine state; if an engine binary is not bundled for the current ABI, the tab
says exactly that instead of pretending.

---

## Building

### GitHub Actions (recommended)

Just push. The workflow:

1. builds `libhev-socks5-tunnel` (official v2rayNG submodule, NDK),
2. cross-compiles the Rust engines with **cargo-ndk** for
   `arm64-v8a` + `armeabi-v7a` (`engines/mhrv-rs` → `libmhrv_rs.so` +
   `libtun2proxy.so`, `engines/torbin` → `libtorbin.so`),
3. cross-compiles the Go engines (`SlipNet` → `libslipnet.so`;
   Psiphon `libshkcore.so` best-effort — upstream repo availability may vary),
4. downloads `libv2ray.aar` (Xray core) from the official release,
5. runs `./gradlew assembleRelease` and uploads APK artifacts.

**Signing:** set repo secrets `APP_KEYSTORE_BASE64` / `APP_KEYSTORE_PASSWORD` /
`APP_KEYSTORE_ALIAS` / `APP_KEY_PASSWORD` to sign with your own key. If the
secrets are not set, the workflow generates a throwaway CI keystore so the
build always produces an installable APK (fine for personal use).

### Android Studio

Open the `V2rayNG/` folder. To also build the panel engines locally:
`bash compile-hevtun.sh` plus `cargo ndk` / `go build` steps from the workflow.

---

## Notes & licenses

- Base app: **v2rayNG** — GPL-3.0 (2dust). This project keeps the same license
  (see `LICENSE`).
- `engines/mhrv-rs` — MIT (therealaleph). `engines/torbin` — MIT wrapper over
  Arti (Arti: MPL-2.0 / MIT / Apache-2.0). SlipNet — AGPL-3.0 (built from
  upstream at CI time). psiphon-tunnel-core — GPL-3.0 (Psiphon-Inc).
  See `THIRD_PARTY_NOTICES.md`.
- x86/x86_64 APKs ship without the panel engines (arm-only builds); those
  tabs show the honest "engine not bundled" message. `universal` APK contains
  the arm engines.
- Nothing in this repository proxies through third-party servers: the Apps
  Script relay runs on **your own** Google account, and Code.gs is included
  for review before deployment.

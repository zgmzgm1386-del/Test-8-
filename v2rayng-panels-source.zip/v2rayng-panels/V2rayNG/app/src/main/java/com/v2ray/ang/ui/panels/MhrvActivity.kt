package com.v2ray.ang.ui.panels

import android.content.Intent
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import com.v2ray.ang.R
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.FormDropdownField
import com.v2ray.ang.ui.compose.FormTextField
import com.therealaleph.mhrv.CaInstall
import com.therealaleph.mhrv.MhrvVpnService
import com.therealaleph.mhrv.Native
import com.therealaleph.mhrv.VpnArbiter
import com.therealaleph.mhrv.VpnState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * تب MHR — کنترل کامل موتور mhrv-rs:
 *   • کانفیگ JSON واقعی (با پریستِ حالت و پورت‌ها)
 *   • استارت/قطع از طریق داور واحد
 *   • آمار زندهٔ واقعی از Native.statsJson و لاگ واقعی از Native.drainLogs
 *   • مدیریت گواهی MITM با CaInstall (خروجی/نصب/اثر انگشت)
 */
class MhrvActivity : BasePanelActivity() {

    private val installCaLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    override fun ScreenContent() {
        val ctx = this
        val scope = androidx.compose.runtime.rememberCoroutineScope()
        val scroll = rememberScrollState()

        var configJson by rememberSaveable { mutableStateOf(loadConfig()) }
        var mode by rememberSaveable { mutableStateOf(guessMode(configJson)) }
        var listenPort by rememberSaveable { mutableStateOf(guessPort(configJson, "listen_port", "8080")) }
        var socksPort by rememberSaveable { mutableStateOf(guessPort(configJson, "socks5_port", "1081")) }
        var running by remember { mutableStateOf(VpnState.isRunning) }
        var statsLine by remember { mutableStateOf("") }
        var engineLogs by remember { mutableStateOf("") }
        var caFp by remember { mutableStateOf<String?>(null) }
        var caInstalled by remember { mutableStateOf(false) }

        LaunchedEffect(Unit) {
            while (isActive) {
                delay(1000)
                running = VpnState.isRunning
                if (running) {
                    val h = VpnState.proxyHandle
                    if (h != 0L) {
                        val s = runCatching { JSONObject(Native.statsJson(h)) }.getOrNull()
                        if (s != null) {
                            statsLine = listOf(
                                "relay_calls=${s.optLong("relay_calls", 0)}",
                                "bytes=${NetTools.humanBytes(s.optLong("bytes_relayed", 0))}",
                                "cache_hits=${s.optLong("cache_hits", 0)}",
                                "today=${s.optLong("today_calls", 0)}",
                            ).joinToString("  ")
                        }
                        val logs = runCatching { Native.drainLogs() }.getOrDefault("")
                        if (logs.isNotBlank()) {
                            engineLogs = ((engineLogs + "\n" + logs).split("\n").takeLast(300)).joinToString("\n")
                        }
                    }
                }
            }
        }

        Scaffold(
            topBar = {
                AppTopBar(
                    title = stringResource(R.string.p_title_mhrv),
                    onBackClick = { finish() },
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(scroll)
            ) {
                EngineStatusCard(
                    running = running,
                    verified = running,
                    stage = if (running) stringResource(R.string.p_running) else stringResource(R.string.p_stopped),
                    rows = if (statsLine.isNotEmpty()) listOf("stats" to statsLine) else emptyList(),
                )

                StartStopButtons(
                    running = running,
                    onStart = {
                        if (configJson.isBlank()) {
                            applyPresetToConfig(configJson, mode, listenPort, socksPort)?.let { configJson = it }
                        }
                        startEngineArbitrated(VpnArbiter.ENGINE_MHRV) {
                            runCatching {
                                Intent(this@MhrvActivity, MhrvVpnService::class.java)
                                    .also { androidx.core.content.ContextCompat.startForegroundService(ctx, it) }
                            }
                        }
                    },
                    onStop = {
                        runCatching {
                            Intent(this@MhrvActivity, MhrvVpnService::class.java)
                                .setAction(MhrvVpnService.ACTION_STOP)
                                .also { androidx.core.content.ContextCompat.startForegroundService(ctx, it) }
                        }
                    },
                )

                FormDropdownField(
                    label = stringResource(R.string.p_mhrv_mode),
                    value = mode,
                    options = listOf("apps_script", "direct", "full"),
                    onValueChange = { mode = it },
                )
                FormTextField(
                    label = stringResource(R.string.p_mhrv_listen_port),
                    value = listenPort,
                    onValueChange = { listenPort = it.filter { c -> c.isDigit() }.take(5) },
                    keyboardType = KeyboardType.Number,
                    maxLines = 1,
                )
                FormTextField(
                    label = stringResource(R.string.p_mhrv_socks_port),
                    value = socksPort,
                    onValueChange = { socksPort = it.filter { c -> c.isDigit() }.take(5) },
                    keyboardType = KeyboardType.Number,
                    maxLines = 1,
                )

                SaveButton {
                    val merged = buildConfigJson(configJson, mode, listenPort, socksPort) ?: run {
                        Toast.makeText(ctx, getString(R.string.p_mhrv_invalid_json), Toast.LENGTH_SHORT).show()
                        return@SaveButton
                    }
                    configJson = merged.toString(2)
                    getSharedPreferences(MhrvVpnService.PREFS, MODE_PRIVATE).edit()
                        .putString(MhrvVpnService.KEY_CONFIG, configJson)
                        .apply()
                    Toast.makeText(ctx, getString(R.string.p_mhrv_config_saved), Toast.LENGTH_SHORT).show()
                }

                SectionHeader(stringResource(R.string.p_mhrv_advanced_json))
                FormTextField(
                    label = "config.json",
                    value = configJson,
                    onValueChange = { configJson = it },
                    maxLines = 14,
                )

                SectionHeader(stringResource(R.string.p_mhrv_ca_section))
                ActionButton(title = stringResource(R.string.p_mhrv_ca_export)) {
                    scope.launch(Dispatchers.IO) {
                        val ok = runCatching { CaInstall.export(ctx) }.getOrDefault(false)
                        val fp = runCatching {
                            CaInstall.fingerprint(ctx)?.let { CaInstall.fingerprintHex(it) }
                        }.getOrNull()
                        val inst = runCatching {
                            fp == null || CaInstall.isInstalled(CaInstall.fingerprint(ctx)!!)
                        }.getOrDefault(false)
                        withContext(Dispatchers.Main) {
                            if (ok && fp != null) {
                                caFp = fp
                                caInstalled = inst
                            } else {
                                Toast.makeText(ctx, getString(R.string.p_mhrv_ca_export_fail), Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
                ActionButton(
                    title = stringResource(R.string.p_mhrv_ca_install),
                    enabled = caFp != null,
                ) {
                    val intent = runCatching { CaInstall.buildInstallIntent(ctx) }.getOrNull()
                    if (intent != null) runCatching { installCaLauncher.launch(intent) }
                }
                if (caFp != null) {
                    StatusRow(stringResource(R.string.p_mhrv_ca_fp), caFp ?: "", mono = true)
                    StatusRow(
                        "install",
                        stringResource(if (caInstalled) R.string.p_mhrv_ca_installed else R.string.p_mhrv_ca_not_installed),
                    )
                }

                SectionHeader(stringResource(R.string.p_logs))
                EngineLogBox(engineLogs)
                NavigationBarsSpacer()
            }
        }
    }

    /** از فیلدهای UI، کانفیگ واقعی می‌سازد؛ اگر JSON دست‌کاری‌شده باشد همان را حفظ می‌کند. */
    private fun buildConfigJson(currentJson: String, mode: String, listenPort: String, socksPort: String): JSONObject? {
        val base = try {
            if (currentJson.isBlank()) JSONObject() else JSONObject(currentJson)
        } catch (_: Throwable) {
            return null
        }
        return try {
            base.put("mode", mode)
            base.put("listen_port", listenPort.toIntOrNull()?.coerceIn(1024, 65535) ?: 8080)
            base.put("socks5_port", socksPort.toIntOrNull()?.coerceIn(1024, 65535) ?: 1081)
            base
        } catch (_: Throwable) {
            null
        }
    }

    /** اگر کانفیگ خالی است یک پریست واقعی می‌سازد (endpoint پنل اگر ذخیره شده). */
    private fun applyPresetToConfig(currentJson: String, mode: String, listenPort: String, socksPort: String): String? {
        val cfg = buildConfigJson(currentJson, mode, listenPort, socksPort) ?: return null
        val panelUrl = PanelPrefs.getScriptUrl(this)
        val panelKey = PanelPrefs.getAuthKey(this)
        if (mode == "apps_script" && panelUrl.isNotEmpty()) {
            cfg.put("script_id", org.json.JSONArray().put(panelUrl))
            if (panelKey.isNotEmpty()) cfg.put("auth_key", panelKey)
        }
        return cfg.toString(2)
    }

    private fun loadConfig(): String =
        getSharedPreferences(MhrvVpnService.PREFS, MODE_PRIVATE)
            .getString(MhrvVpnService.KEY_CONFIG, "") ?: ""

    private fun guessMode(json: String): String =
        runCatching { JSONObject(json).optString("mode", "apps_script") }.getOrDefault("apps_script")
            .ifBlank { "apps_script" }

    private fun guessPort(json: String, key: String, def: String): String =
        runCatching {
            val o = JSONObject(json)
            val v = if (o.has(key)) o.getInt(key) else def.toInt()
            v.toString()
        }.getOrDefault(def)
}

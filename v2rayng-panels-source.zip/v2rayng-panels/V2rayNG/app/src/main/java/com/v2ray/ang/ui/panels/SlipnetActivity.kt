package com.v2ray.ang.ui.panels

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.FormTextField
import com.therealaleph.mhrv.SlipVpnService
import com.therealaleph.mhrv.VpnArbiter
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import org.json.JSONObject
import java.io.File

/**
 * تب SlipNet — تونل DNS/SSH/VLESS با موتور Go داخلی (libslipnet.so):
 * پروفایل (slipnet://) + رزولور دستی ذخیره می‌شود و سرویس SlipVpnService
 * همان را واقعاً اجرا می‌کند. وضعیت/لاگ از snapshot() خود سرویس می‌آید.
 */
class SlipnetActivity : BasePanelActivity() {

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    override fun ScreenContent() {
        val ctx = this
        val scroll = rememberScrollState()

        var uri by rememberSaveable { mutableStateOf(loadUri()) }
        var dns by rememberSaveable { mutableStateOf(loadDns()) }
        var snap by remember { mutableStateOf(snapshot()) }
        var enginePresent by remember { mutableStateOf(engineAvailable()) }

        LaunchedEffect(Unit) {
            while (isActive) {
                delay(600)
                snap = snapshot()
                enginePresent = engineAvailable()
            }
        }

        Scaffold(
            topBar = {
                AppTopBar(
                    title = stringResource(R.string.p_title_slipnet),
                    onBackClick = { finish() },
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(scroll)
            ) {
                EngineStatusCard(
                    running = snap.optBoolean("running", false),
                    verified = snap.optBoolean("verified", false),
                    stage = snap.optString("stage", ""),
                    rows = listOfNotNull(
                        if (snap.optString("ip", "").isNotEmpty())
                            stringResource(R.string.p_exit_ip) to snap.optString("ip") else null,
                        if (snap.optString("loc", "").isNotEmpty())
                            stringResource(R.string.p_location) to snap.optString("loc") else null,
                    ),
                )

                if (!enginePresent) {
                    NoticeLine(stringResource(R.string.p_engine_not_installed, "SlipNet"))
                }

                StartStopButtons(
                    running = snap.optBoolean("running", false),
                    onStart = {
                        if (uri.isBlank()) {
                            Toast.makeText(ctx, getString(R.string.p_slipnet_need_uri), Toast.LENGTH_SHORT).show()
                            return@StartStopButtons
                        }
                        // ذخیرهٔ پروفایل قبل از استارت — سرویس همین را می‌خواند
                        getSharedPreferences(SlipVpnService.PREFS, MODE_PRIVATE).edit()
                            .putString(SlipVpnService.KEY_URI, uri.trim())
                            .putString(SlipVpnService.KEY_DNS, dns.trim())
                            .apply()
                        startEngineArbitrated(VpnArbiter.ENGINE_SLIPNET) {
                            runCatching {
                                Intent(this@SlipnetActivity, SlipVpnService::class.java)
                                    .also { androidx.core.content.ContextCompat.startForegroundService(ctx, it) }
                            }
                        }
                    },
                    onStop = {
                        runCatching {
                            Intent(this@SlipnetActivity, SlipVpnService::class.java)
                                .setAction(SlipVpnService.ACTION_STOP)
                                .also { androidx.core.content.ContextCompat.startForegroundService(ctx, it) }
                        }
                    },
                )

                FormTextField(
                    label = stringResource(R.string.p_slipnet_uri),
                    value = uri,
                    onValueChange = { uri = it },
                    placeholder = stringResource(R.string.p_slipnet_uri_hint),
                    maxLines = 6,
                )
                ClipboardPasteButton { pasted ->
                    if (pasted.isNotBlank()) uri = pasted.trim()
                }
                FormTextField(
                    label = stringResource(R.string.p_slipnet_dns),
                    value = dns,
                    onValueChange = { dns = it },
                    placeholder = stringResource(R.string.p_slipnet_dns_hint),
                    keyboardType = KeyboardType.Number,
                    maxLines = 1,
                )
                SaveButton {
                    getSharedPreferences(SlipVpnService.PREFS, MODE_PRIVATE).edit()
                        .putString(SlipVpnService.KEY_URI, uri.trim())
                        .putString(SlipVpnService.KEY_DNS, dns.trim())
                        .apply()
                    Toast.makeText(ctx, getString(R.string.p_slipnet_profile_saved), Toast.LENGTH_SHORT).show()
                }

                EngineLogBox(snap.optString("logs", ""))
                NavigationBarsSpacer()
            }
        }
    }

    private fun loadUri(): String =
        getSharedPreferences(SlipVpnService.PREFS, MODE_PRIVATE).getString(SlipVpnService.KEY_URI, "") ?: ""

    private fun loadDns(): String =
        getSharedPreferences(SlipVpnService.PREFS, MODE_PRIVATE).getString(SlipVpnService.KEY_DNS, "") ?: ""

    private fun snapshot(): JSONObject = try {
        JSONObject(SlipVpnService.snapshot())
    } catch (_: Throwable) {
        JSONObject()
    }

    private fun engineAvailable(): Boolean = try {
        SlipVpnService.engineAvailable(this)
    } catch (_: Throwable) {
        File(applicationInfo.nativeLibraryDir, SlipVpnService.LIB).exists()
    }
}

/** خط اطلاع‌رسانی صادقانه (موتور غایب و …) — با استایل خود UI. */
@Composable
internal fun NoticeLine(text: String) {
    androidx.compose.material3.Text(
        text = text,
        style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
        color = androidx.compose.material3.MaterialTheme.colorScheme.error,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
    )
}

/** دکمهٔ چسباندن از کلیپ‌بورد (برای URI پروفایل). */
@Composable
internal fun ClipboardPasteButton(onPasted: (String) -> Unit) {
    val ctx = LocalContext.current
    androidx.compose.material3.TextButton(onClick = {
        val cm = ctx.getSystemService(android.content.ClipboardManager::class.java)
        val text = runCatching { cm?.primaryClip?.getItemAt(0)?.text?.toString() }.getOrNull().orEmpty()
        onPasted(text)
    }) {
        androidx.compose.material3.Text(stringResource(R.string.p_slipnet_paste))
    }
}

/** دکمهٔ ذخیرهٔ عمومی. */
@Composable
internal fun SaveButton(onSave: () -> Unit) {
    androidx.compose.material3.TextButton(onClick = onSave) {
        androidx.compose.material3.Text(stringResource(R.string.p_save))
    }
}

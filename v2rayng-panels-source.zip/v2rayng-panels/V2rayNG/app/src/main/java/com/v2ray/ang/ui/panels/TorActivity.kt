package com.v2ray.ang.ui.panels

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import com.v2ray.ang.R
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.FormTextField
import com.therealaleph.mhrv.TorVpnService
import com.therealaleph.mhrv.VpnArbiter
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import org.json.JSONObject
import java.io.File

/**
 * تب تور — موتور Arti (Rust) داخلی: خط‌های پل obfs4 اختیاری ذخیره می‌شوند و
 * TorVpnService واقعاً همان‌ها را به موتور می‌دهد. وضعیت/لاگ واقعی از
 * snapshot() خود سرویس می‌آید.
 */
class TorActivity : BasePanelActivity() {

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    override fun ScreenContent() {
        val ctx = this
        val scroll = rememberScrollState()

        var bridges by rememberSaveable { mutableStateOf(loadBridges()) }
        var snap by remember { mutableStateOf(snapshot()) }
        var enginePresent by remember { mutableStateOf(engineAvailable()) }

        LaunchedEffect(Unit) {
            while (isActive) {
                delay(600)
                snap = snapshot()
                enginePresent = engineAvailable()
            }
        }

        Scaffold(
            topBar = {
                AppTopBar(
                    title = stringResource(R.string.p_title_tor),
                    onBackClick = { finish() },
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(scroll)
            ) {
                EngineStatusCard(
                    running = snap.optBoolean("running", false),
                    verified = snap.optBoolean("verified", false),
                    stage = snap.optString("stage", ""),
                    rows = listOfNotNull(
                        if (snap.optString("ip", "").isNotEmpty())
                            stringResource(R.string.p_exit_ip) to snap.optString("ip") else null,
                        if (snap.optString("loc", "").isNotEmpty())
                            stringResource(R.string.p_location) to snap.optString("loc") else null,
                    ),
                )

                if (!enginePresent) {
                    NoticeLine(stringResource(R.string.p_engine_not_installed, "Tor (Arti)"))
                }
                NoticeLine(stringResource(R.string.p_tor_bridges_note))

                StartStopButtons(
                    running = snap.optBoolean("running", false),
                    onStart = {
                        startEngineArbitrated(VpnArbiter.ENGINE_TOR) {
                            getSharedPreferences(TorVpnService.PREFS, MODE_PRIVATE).edit()
                                .putString(TorVpnService.KEY_BRIDGES, bridges.trim())
                                .apply()
                            runCatching {
                                Intent(this@TorActivity, TorVpnService::class.java)
                                    .also { androidx.core.content.ContextCompat.startForegroundService(ctx, it) }
                            }
                        }
                    },
                    onStop = {
                        runCatching {
                            Intent(this@TorActivity, TorVpnService::class.java)
                                .setAction(TorVpnService.ACTION_STOP)
                                .also { androidx.core.content.ContextCompat.startForegroundService(ctx, it) }
                        }
                    },
                )

                FormTextField(
                    label = stringResource(R.string.p_tor_bridges),
                    value = bridges,
                    onValueChange = { bridges = it },
                    placeholder = stringResource(R.string.p_tor_bridges_hint),
                    maxLines = 8,
                )
                SaveButton {
                    getSharedPreferences(TorVpnService.PREFS, MODE_PRIVATE).edit()
                        .putString(TorVpnService.KEY_BRIDGES, bridges.trim())
                        .apply()
                    Toast.makeText(ctx, getString(R.string.p_tor_bridges_saved), Toast.LENGTH_SHORT).show()
                }

                EngineLogBox(snap.optString("logs", ""))
                NavigationBarsSpacer()
            }
        }
    }

    private fun loadBridges(): String =
        getSharedPreferences(TorVpnService.PREFS, MODE_PRIVATE).getString(TorVpnService.KEY_BRIDGES, "") ?: ""

    private fun snapshot(): JSONObject = try {
        JSONObject(TorVpnService.snapshot())
    } catch (_: Throwable) {
        JSONObject()
    }

    private fun engineAvailable(): Boolean =
        File(applicationInfo.nativeLibraryDir, TorVpnService.LIB).exists()
}

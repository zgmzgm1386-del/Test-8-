package com.v2ray.ang.ui.panels

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import com.v2ray.ang.ui.compose.ItemDivider

/**
 * اجزای مشترک صفحات موتور — همان زبان طراحی v2rayNG (کارتهای سطح، تایپوگرافی
 * متریال ۳ و دکمه‌های استاندارد). هیچ دیتای نمایشی اینجا تولید نمی‌شود؛
 * همهٔ مقادیر از snapshot واقعی سرویس‌ها می‌آیند.
 */

/** ردیف «برچسب / مقدار» برای نمایش وضعیت واقعی موتور. */
@Composable
fun StatusRow(label: String, value: String, mono: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(0.42f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontFamily = if (mono) FontFamily.Monospace else null,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(0.58f),
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/** کارت وضعیت: خط اول = مرحلهٔ موتور، بقیه ردیف‌های واقعی (IP/لوکیشن/…). */
@Composable
fun EngineStatusCard(
    running: Boolean,
    verified: Boolean,
    stage: String,
    rows: List<Pair<String, String>> = emptyList(),
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Column(modifier = Modifier.padding(vertical = 8.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = stage.ifBlank { stringResource(if (running) R.string.p_running else R.string.p_stopped) },
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = when {
                        running && verified -> stringResource(R.string.p_verified)
                        running -> stringResource(R.string.p_running)
                        else -> stringResource(R.string.p_stopped)
                    },
                    style = MaterialTheme.typography.labelMedium,
                    color = if (running)
                        MaterialTheme.colorScheme.primary
                    else
                        MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            rows.forEach { (k, v) -> StatusRow(k, v) }
        }
    }
}

/** جعبهٔ لاگ — متن واقعی موتور، قابل انتخاب برای کپی. */
@Composable
fun EngineLogBox(logs: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .background(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(12.dp),
            )
    ) {
        Text(
            text = stringResource(R.string.p_logs),
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 16.dp, top = 10.dp, bottom = 4.dp),
        )
        Text(
            text = logs.ifBlank { stringResource(R.string.p_empty_logs) },
            style = MaterialTheme.typography.bodySmall,
            fontFamily = FontFamily.Monospace,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 12.dp),
        )
    }
}

/** جفت دکمهٔ وصل/قطع. */
@Composable
fun StartStopButtons(
    running: Boolean,
    onStart: () -> Unit,
    onStop: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Button(
            onClick = onStart,
            enabled = !running,
            modifier = Modifier.weight(1f),
        ) { Text(stringResource(R.string.p_start)) }
        OutlinedButton(
            onClick = onStop,
            enabled = running,
            modifier = Modifier.weight(1f),
        ) { Text(stringResource(R.string.p_stop)) }
    }
}

/** هدر بخش (مثل گروه‌های تنظیمات v2rayNG). */
@Composable
fun SectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 4.dp),
    )
}

/** جداکنندهٔ سبک بین ردیف‌ها. */
@Composable
fun PanelDivider() = ItemDivider()

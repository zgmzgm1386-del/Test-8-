package com.v2ray.ang.ui.panels

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.FormTextField
import com.therealaleph.mhrv.MhrvVpnService
import com.therealaleph.mhrv.Native
import com.therealaleph.mhrv.VpnArbiter
import com.therealaleph.mhrv.VpnState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * تب Google Script — کلاینت mhrv-rs با رلهٔ Apps Script:
 *   ۱) URL و کلید Web App کاربر ذخیره می‌شود (همان منبع «کنترل پنل»)
 *   ۲) «تست رله» یک POST واقعی با فرمت Code.gs می‌فرستد و جواب واقعی نشان می‌دهد
 *   ۳) «ذخیرهٔ کانفیگ MHR» کانفیگ JSON واقعی (mode=apps_script) برای موتور می‌سازد
 *   ۴) استارت/قطع موتور MHR + آمار زندهٔ statsJson
 */
class GscriptActivity : BasePanelActivity() {

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    override fun ScreenContent() {
        val ctx = this
        val scope = androidx.compose.runtime.rememberCoroutineScope()
        val scroll = rememberScrollState()

        var url by rememberSaveable { mutableStateOf(PanelPrefs.getScriptUrl(ctx)) }
        var key by rememberSaveable { mutableStateOf(PanelPrefs.getAuthKey(ctx)) }
        var testResult by remember { mutableStateOf("") }
        var testing by remember { mutableStateOf(false) }
        var snap by remember { mutableStateOf(snapshot()) }

        LaunchedEffect(Unit) {
            while (isActive) {
                delay(700)
                snap = snapshot()
            }
        }

        Scaffold(
            topBar = {
                AppTopBar(
                    title = stringResource(R.string.p_title_gscript),
                    onBackClick = { finish() },
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(scroll)
            ) {
                EngineStatusCard(
                    running = snap.optBoolean("running", false),
                    verified = true,
                    stage = if (snap.optBoolean("running", false))
                        stringResource(R.string.p_running) else stringResource(R.string.p_stopped),
                )

                FormTextField(
                    label = stringResource(R.string.p_gscript_url),
                    value = url,
                    onValueChange = { url = it },
                    placeholder = stringResource(R.string.p_gscript_url_hint),
                    maxLines = 3,
                )
                FormTextField(
                    label = stringResource(R.string.p_gscript_key),
                    value = key,
                    onValueChange = { key = it },
                    maxLines = 1,
                )

                // تست واقعی رله — POST با فرمت دقیق Code.gs
                ActionButton(
                    title = stringResource(R.string.p_gscript_test),
                    enabled = !testing && url.isNotBlank(),
                ) {
                    if (url.isBlank()) {
                        Toast.makeText(ctx, getString(R.string.p_gscript_need_url), Toast.LENGTH_SHORT).show()
                        return@ActionButton
                    }
                    testing = true
                    testResult = ""
                    scope.launch {
                        val res = withContext(Dispatchers.IO) {
                            NetTools.httpPostJson(
                                url.trim(),
                                JSONObject()
                                    .put("k", key.trim())
                                    .put("u", "https://www.gstatic.com/generate_204")
                                    .put("m", "GET")
                                    .toString(),
                            )
                        }
                        testing = false
                        testResult = if (res != null && res.status in 200..299)
                            getString(R.string.p_gscript_test_ok, res.status, res.latencyMs)
                        else
                            getString(R.string.p_gscript_test_fail)
                    }
                }
                if (testResult.isNotEmpty()) {
                    Text(
                        text = testResult,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp),
                    )
                }

                // ذخیرهٔ endpoint + ساخت کانفیگ واقعی mhrv (apps_script)
                ActionButton(title = stringResource(R.string.p_gscript_gen_config), enabled = url.isNotBlank()) {
                    PanelPrefs.save(ctx, url, key)
                    val cfg = JSONObject()
                        .put("mode", "apps_script")
                        .put("script_id", org.json.JSONArray().put(url.trim()))
                        .put("auth_key", key.trim())
                        .put("listen_port", 8080)
                        .put("socks5_port", 1081)
                        .put("log_level", "info")
                    getSharedPreferences(MhrvVpnService.PREFS, MODE_PRIVATE).edit()
                        .putString(MhrvVpnService.KEY_CONFIG, cfg.toString())
                        .apply()
                    Toast.makeText(ctx, getString(R.string.p_gscript_config_saved), Toast.LENGTH_SHORT).show()
                }

                // استارت/قطع موتور MHR با همان کانفیگ
                StartStopButtons(
                    running = snap.optBoolean("running", false),
                    onStart = {
                        if (url.isBlank()) {
                            Toast.makeText(ctx, getString(R.string.p_gscript_need_url), Toast.LENGTH_SHORT).show()
                            return@StartStopButtons
                        }
                        startEngineArbitrated(VpnArbiter.ENGINE_MHRV) {
                            runCatching {
                                Intent(this@GscriptActivity, MhrvVpnService::class.java)
                                    .also { androidx.core.content.ContextCompat.startForegroundService(ctx, it) }
                            }
                        }
                    },
                    onStop = {
                        runCatching {
                            Intent(this@GscriptActivity, MhrvVpnService::class.java)
                                .setAction(MhrvVpnService.ACTION_STOP)
                                .also { androidx.core.content.ContextCompat.startForegroundService(ctx, it) }
                        }
                    },
                )

                SectionHeader(stringResource(R.string.p_gscript_view_code))
                Text(
                    text = stringResource(R.string.p_gscript_code_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp),
                )
                ActionButton(title = stringResource(R.string.p_panel_code_copy)) {
                    val code = runCatching { assets.open("Code.gs").bufferedReader().use { it.readText() } }
                        .getOrDefault("")
                    val cm = getSystemService(android.content.ClipboardManager::class.java)
                    cm?.setPrimaryClip(android.content.ClipData.newPlainText("Code.gs", code))
                    Toast.makeText(ctx, getString(R.string.p_copied), Toast.LENGTH_SHORT).show()
                }
                ActionButton(title = stringResource(R.string.p_panel_code_save)) {
                    scope.launch(Dispatchers.IO) {
                        val ok = runCatching {
                            val code = assets.open("Code.gs").bufferedReader().use { it.readText() }
                            val values = android.content.ContentValues().apply {
                                put(android.provider.MediaStore.Downloads.DISPLAY_NAME, "Code.gs")
                                put(android.provider.MediaStore.Downloads.MIME_TYPE, "text/plain")
                            }
                            val uri = contentResolver.insert(
                                android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values
                            ) ?: return@runCatching false
                            contentResolver.openOutputStream(uri)?.use { it.write(code.toByteArray()) }
                            true
                        }.getOrDefault(false)
                        withContext(Dispatchers.Main) {
                            if (ok) Toast.makeText(ctx, getString(R.string.p_panel_code_saved), Toast.LENGTH_SHORT).show()
                            else Toast.makeText(ctx, getString(R.string.p_err_generic), Toast.LENGTH_SHORT).show()
                        }
                    }
                }
                NavigationBarsSpacer()
            }
        }
    }

    private fun snapshot(): JSONObject {
        val o = JSONObject()
        o.put("running", VpnState.isRunning)
        return o
    }
}

/** دکمهٔ اکشن متنی تمام‌عرض سبک v2rayNG. */
@Composable
internal fun ActionButton(title: String, enabled: Boolean = true, onClick: () -> Unit) {
    androidx.compose.material3.TextButton(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 2.dp),
    ) {
        Text(title, fontFamily = FontFamily.SansSerif)
    }
}

package com.therealaleph.mhrv

import android.content.Context
import android.content.Intent
import android.util.Log
import com.v2ray.ang.core.CoreServiceManager
import com.v2ray.ang.core.LauncherManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * داورِ واحد VPN — تضمین می‌کند که در هر لحظه **حداکثر یک** موتور VPN فعال باشد:
 *
 *   هستهٔ v2rayNG  |  mhrv-rs  |  SlipNet  |  Tor  |  سایفون (shkcore)
 *
 * قبل از استارت هر موتور، ترتیب خاموشی درست رعایت می‌شود:
 *   ۱) اگر هستهٔ v2rayNG روشن است → LauncherManager.stopService و صبر تا توقف کامل
 *   ۲) اگر هرکدام از سرویس‌های داخلی (mhrv/Slip/Tor/Shk) فعال‌اند → ACTION_STOP
 *      همان سرویس و صبر تا آزاد شدن TUN/پورت‌ها
 *   ۳) فقط بعد از آن، فراخوانِ VpnService.prepare() و استارت موتور جدید انجام می‌شود
 *
 * نکتهٔ فنی: سرویس‌های داخلی در پروسهٔ اصلی اجرا می‌شوند و وضعیت‌شان از طریق
 * فلگ‌های companion (running / VpnState.isRunning) خواندنی است؛ هستهٔ v2rayNG
 * در پروسهٔ :daemon است و توقفش از طریق LauncherManager انجام می‌شود.
 */
object VpnArbiter {

    private const val TAG = "VpnArbiter"

    /** شناسهٔ موتورهای قابل مدیریت توسط داور. */
    const val ENGINE_NONE = "none"
    const val ENGINE_V2RAY = "v2ray"
    const val ENGINE_MHRV = "mhrv"
    const val ENGINE_SLIPNET = "slipnet"
    const val ENGINE_TOR = "tor"
    const val ENGINE_PSIPHON = "psiphon"

    /** شناسهٔ موتور فعال فعلی از دید سرویس‌های داخلی (none یعنی هیچ‌کدام). */
    fun activeEngine(): String = when {
        VpnState.isRunning -> ENGINE_MHRV
        SlipVpnService.running -> ENGINE_SLIPNET
        TorVpnService.running -> ENGINE_TOR
        ShkVpnService.running -> ENGINE_PSIPHON
        else -> ENGINE_NONE
    }

    /** تعریف داخلی برای هر سرویس قابل‌توقف: فلگ «در حال اجرا» + نحوهٔ ارسال توقف. */
    private data class Ext(
        val engine: String,
        val running: () -> Boolean,
        val stop: (Context) -> Unit,
    )

    /**
     * هر موتور فعال دیگری (به‌جزExcept) را متوقف می‌کند و تا آزاد شدن واقعی
     * منابع صبر می‌کند. هستهٔ v2rayNG هم اگر روشن باشد خاموش می‌شود.
     *
     * باید از Dispatchers.Main صدا زده شود؛ انتظارها با delay غیرمسدودکننده است.
     */
    suspend fun ensureExclusive(context: Context, except: String? = null): Boolean =
        withContext(Dispatchers.Main) {
            var stoppedSomething = false

            // ۱) هستهٔ v2rayNG (پروسهٔ :daemon)
            if (except != ENGINE_V2RAY && CoreServiceManager.isRunning()) {
                Log.i(TAG, "stopping v2rayNG core before starting another engine")
                runCatching { LauncherManager.stopService(context) }
                stoppedSomething = true
                // انتظار برای توقف واقعی — حداکثر ۵ ثانیه
                var waited = 0L
                while (CoreServiceManager.isRunning() && waited < 5_000L) {
                    kotlinx.coroutines.delay(200L)
                    waited += 200L
                }
            }

            // ۲) سرویس‌های داخلی (پروسهٔ اصلی — فلگ‌ها همین‌جا خوانده می‌شوند)
            val externals = listOf(
                Ext(ENGINE_MHRV, { VpnState.isRunning }) { ctx ->
                    ctx.startService(
                        Intent(ctx, MhrvVpnService::class.java).setAction(MhrvVpnService.ACTION_STOP)
                    )
                },
                Ext(ENGINE_SLIPNET, { SlipVpnService.running }) { ctx ->
                    ctx.startService(
                        Intent(ctx, SlipVpnService::class.java).setAction(SlipVpnService.ACTION_STOP)
                    )
                },
                Ext(ENGINE_TOR, { TorVpnService.running }) { ctx ->
                    ctx.startService(
                        Intent(ctx, TorVpnService::class.java).setAction(TorVpnService.ACTION_STOP)
                    )
                },
                Ext(ENGINE_PSIPHON, { ShkVpnService.running }) { ctx ->
                    ctx.startService(
                        Intent(ctx, ShkVpnService::class.java).setAction(ShkVpnService.ACTION_STOP)
                    )
                },
            )

            for (ext in externals) {
                if (ext.engine == except) continue
                if (ext.running()) {
                    Log.i(TAG, "stopping external engine ${ext.engine}")
                    runCatching { ext.stop(context) }
                    stoppedSomething = true
                    var waited = 0L
                    while (ext.running() && waited < 6_000L) {
                        kotlinx.coroutines.delay(250L)
                        waited += 250L
                    }
                }
            }

            stoppedSomething
        }

    /**
     * آیا موتور درخواستی اصلاً می‌تواند استارت شود؟ (بدون دست‌زدن به بقیه)
     * برای پیام‌های دقیق UI استفاده می‌شود.
     */
    fun isEngineBusyElsewhere(except: String): Boolean = activeEngine() != ENGINE_NONE && activeEngine() != except
}

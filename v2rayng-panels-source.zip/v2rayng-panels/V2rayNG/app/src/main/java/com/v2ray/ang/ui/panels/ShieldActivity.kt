package com.v2ray.ang.ui.panels

import android.security.KeyChain
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import com.v2ray.ang.ui.compose.AppTopBar
import com.therealaleph.mhrv.CaInstall
import com.therealaleph.mhrv.DnsProbe
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.security.KeyStore

/**
 * تب سپر ایمنی — سه بررسی واقعی، بدون هیچ ترفند نمایشی:
 *   ۱) گواهی MITM موتور: خروجی/نصب/اثرانگشت/وضعیت نصب واقعی (CaInstall)
 *   ۲) ممیزی گواهی‌های دستی نصب‌شدهٔ کاربر در استور سیستم (AndroidCAStore واقعی)
 *   ۳) دسترس‌پذیری واقعی رزولورهای DNS + IP/کشور فعلی (trace واقعی کلودفلر)
 */
class ShieldActivity : BasePanelActivity() {

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    override fun ScreenContent() {
        val ctx = this
        val scope = rememberCoroutineScope()

        var caFp by rememberSaveable { mutableStateOf<String?>(null) }
        var caInstalled by rememberSaveable { mutableStateOf(false) }
        var userCas by remember { mutableStateOf<List<String>>(emptyList()) }
        var resolverRows by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
        var checkingResolvers by rememberSaveable { mutableStateOf(false) }
        var publicIp by rememberSaveable { mutableStateOf("") }
        var publicLoc by rememberSaveable { mutableStateOf("") }

        fun readUserCas(): List<String> = runCatching {
            val ks = KeyStore.getInstance("AndroidCAStore")
            ks.load(null)
            ks.aliases().toList().filter { it.startsWith("user:") }.sorted()
        }.getOrDefault(emptyList())

        fun refreshCa() {
            val fp = runCatching { CaInstall.fingerprint(ctx) }.getOrNull()
            caFp = fp?.let { CaInstall.fingerprintHex(it) }
            caInstalled = fp != null && runCatching { CaInstall.isInstalled(fp) }.getOrDefault(false)
            userCas = readUserCas()
        }

        val installCaLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { refreshCa() }

        Scaffold(
            topBar = {
                AppTopBar(
                    title = stringResource(R.string.p_title_shield),
                    onBackClick = { finish() },
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
            ) {
                SectionHeader(stringResource(R.string.p_shield_ca_section))
                if (caFp == null) {
                    Text(
                        text = stringResource(R.string.p_shield_ca_export_first),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp),
                    )
                } else {
                    StatusRow(stringResource(R.string.p_mhrv_ca_fp), caFp ?: "", mono = true)
                    StatusRow(
                        "install",
                        stringResource(if (caInstalled) R.string.p_mhrv_ca_installed else R.string.p_mhrv_ca_not_installed),
                    )
                }
                ActionButton(title = stringResource(R.string.p_mhrv_ca_export)) {
                    scope.launch(Dispatchers.IO) {
                        val ok = runCatching { CaInstall.export(ctx) }.getOrDefault(false)
                        withContext(Dispatchers.Main) {
                            if (!ok) Toast.makeText(ctx, R.string.p_mhrv_ca_export_fail, Toast.LENGTH_SHORT).show()
                            refreshCa()
                        }
                    }
                }
                ActionButton(
                    title = stringResource(R.string.p_shield_ca_install_now),
                    enabled = caFp != null,
                ) {
                    val intent = runCatching { CaInstall.buildInstallIntent(ctx) }.getOrNull()
                    if (intent != null) runCatching { installCaLauncher.launch(intent) }
                }

                SectionHeader(stringResource(R.string.p_shield_ca_installed_list))
                if (userCas.isEmpty()) {
                    Text(
                        text = stringResource(R.string.p_shield_no_user_ca),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp),
                    )
                } else {
                    userCas.forEach { alias ->
                        StatusRow("user CA", alias)
                    }
                }

                SectionHeader(stringResource(R.string.p_shield_resolver_check))
                ActionButton(
                    title = stringResource(R.string.p_shield_check),
                    enabled = !checkingResolvers,
                ) {
                    checkingResolvers = true
                    scope.launch(Dispatchers.IO) {
                        val list = listOf("1.1.1.1", "8.8.8.8", "9.9.9.9", "178.22.122.100", "10.202.10.10")
                        val result = list.associateWith { DnsProbe.probe(it, 1, 2000) }
                        val trace = NetTools.cloudflareTrace()
                        withContext(Dispatchers.Main) {
                            resolverRows = result
                            publicIp = trace?.get("ip") ?: ""
                            publicLoc = trace?.get("loc") ?: ""
                            checkingResolvers = false
                        }
                    }
                }
                resolverRows.forEach { (ip, ms) ->
                    StatusRow(ip, if (ms >= 0) "${ms}ms" else getString(R.string.p_int_fail))
                }
                if (publicIp.isNotEmpty()) {
                    StatusRow(stringResource(R.string.p_shield_ip_exit), publicIp, mono = true)
                    StatusRow(stringResource(R.string.p_shield_loc), publicLoc)
                }
                NavigationBarsSpacer()
            }
        }
    }
}

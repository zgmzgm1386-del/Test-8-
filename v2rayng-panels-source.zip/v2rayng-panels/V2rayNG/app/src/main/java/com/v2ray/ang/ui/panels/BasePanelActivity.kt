package com.v2ray.ang.ui.panels

import android.content.Intent
import android.net.VpnService
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import com.v2ray.ang.ui.base.BaseComponentActivity
import com.therealaleph.mhrv.VpnArbiter
import kotlinx.coroutines.launch

/**
 * بیس مشترک اکتیویتی‌هایی که موتور VPN استارت می‌کنند.
 *
 * ترتیب استارت همیشه یکسان است (شرط «هرگز دو VPN همزمان»):
 *   ۱) VpnArbiter.ensureExclusive() → توقف هستهٔ v2rayNG یا موتور فعال دیگر
 *   ۲) VpnService.prepare() → اگر مجوز لازم بود، دیالوگ سیستم
 *   ۳) استارت موتور انتخابی (ForegroundService)
 */
abstract class BasePanelActivity : BaseComponentActivity() {

    private var pendingStart: (() -> Unit)? = null

    private val vpnPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val granted = result.resultCode == RESULT_OK
            val start = pendingStart
            pendingStart = null
            if (granted) start?.invoke()
        }

    /**
     * توقف بقیهٔ موتورها → گرفتن مجوز VPN (در صورت نیاز) → اجرای استارت واقعی.
     * [engine] شناسهٔ VpnArbiter.ENGINE_* است.
     */
    protected fun startEngineArbitrated(engine: String, start: () -> Unit) {
        lifecycleScope.launch {
            VpnArbiter.ensureExclusive(this@BasePanelActivity, engine)
            val intent: Intent? = try {
                VpnService.prepare(this@BasePanelActivity)
            } catch (_: Throwable) {
                null
            }
            if (intent == null) {
                start()
            } else {
                pendingStart = start
                runCatching { vpnPermissionLauncher.launch(intent) }
            }
        }
    }
}

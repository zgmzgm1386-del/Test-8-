package com.therealaleph.mhrv

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.util.Log
import com.v2ray.ang.R
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStream
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import javax.net.ssl.SSLSocketFactory

/**
 * موتور «سایفون» داخل اپ — کلاینت Psiphon (psiphon-tunnel-core، GPL-3.0):
 *
 *   باینری shkcore (Go، arm64 — از ConsoleClient همان مخزن رسمی ساخته می‌شود)
 *   با پیکربندی تعبیه‌شدهٔ شبکهٔ Psiphon (همان چیزی که اپ رسمی shirokhorshid
 *   داخل خودش دارد) بالا می‌آید و یک SOCKS5 روی 127.0.0.1:20873 گوش می‌دهد
 *   → کلید VPN سیستم (TUN) → tun2proxy.
 *
 * v1.25.16 — فیکس ریشه‌ایِ «سایفون هرگز وصل نمی‌شد» (تأییدشده از سورس رسمی):
 *   (۱) ConsoleClientِ tunnel-core، لیستِ تعبیه‌شدهٔ سرورانترها را «فقط» از فایلِ
 *       فلگ ‎-serverList می‌خواند (TunnelWorker.Init پارامتر config را "" رد می‌کند؛
 *       ImportEmbeddedServerEntries در dataStore.go) → فراخوانیِ قدیمیِ ما
 *       «shkcore --config» یعنی صفر کاندیداد و اتصال هرگز انجام نمی‌شد.
 *   (۲) فرمت هر خطِ آن فایل باید «legacy encoded server entry» باشد:
 *           hex("ip port secret cert {json}")
 *       و وقتی مدخل webServerCertificate ندارد (دقیقاً حالت مدخل‌های ما،
 *       طبق encodeServerEntry رسمی) پیشوند «0 0 0 0» می‌گیرد.
 *   پس prepareEntryFile() از psi_config تعبیه‌شده همین فایل را می‌سازد و
 *   shkcore با «--config … ‎-serverList …» اجرا می‌شود.
 *
 * صفر کانفیگ: کاربر فقط «وصل» می‌زند؛ شبکه و سرورها داخل پیکربندی است.
 * «وصل» فقط با تست واقعی HTTPS از داخل تونل تأیید می‌شود (استاندارد تب‌های دیگر).
 */
class ShkVpnService : VpnService() {

    private var tun: ParcelFileDescriptor? = null
    private var tun2proxyThread: Thread? = null
    private val tun2proxyRunning = AtomicBoolean(false)
    private val tornDown = AtomicBoolean(false)
    private var proc: Process? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.i(TAG, "onStartCommand action=${intent?.action ?: "<null>"}")
        return when (intent?.action) {
            ACTION_STOP -> {
                try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Throwable) {}
                Thread({ teardown(); stopSelf() }, "shk-stop").start()
                START_NOT_STICKY
            }
            else -> {
                tornDown.set(false)
                startForeground(NOTIF_ID, buildNotif())
                Thread({ startEngine() }, "shk-start").start()
                START_NOT_STICKY
            }
        }
    }

    override fun onRevoke() {
        Thread({ teardown(); stopSelf() }, "shk-revoke").start()
    }

    override fun onDestroy() {
        try { teardown() } catch (t: Throwable) { Log.e(TAG, "onDestroy: ${t.message}") }
        super.onDestroy()
    }

    /** پیکربندی تعبیه‌شده را از res/raw به filesDir می‌برد و پورت SOCKS را داخلش ست می‌کند.
     *  v1.25.16: برمی‌گرداند (فایل پیکربندی، فایل سرورانترها ‎-serverList، تعداد مدخل‌ها). */
    private fun prepareConfig(): Triple<File, File?, Int>? {
        val out = File(filesDir, "shk-config.json")
        try {
            val raw = resources.openRawResource(R.raw.psi_config)
            val bytes = raw.readBytes()
            raw.close()
            val txt = String(bytes, Charsets.UTF_8).trim()
            if (txt.isEmpty() || txt == "{}") { fail("پیکربندی شبکهٔ سایفون در این APK تعبیه نشده — نسخهٔ جدید برنامه را نصب کن"); return null }
            // پورت SOCKS را مستقیم داخل پیکربندی می‌گذاریم (بدون اتکا به فلگ‌های console_client)
            // v1.24.7 — فیکس ریشهٔ «وصل شد ولی اینترنت نمی‌آمد»: اسم فیلدها باید دقیقاً
            // مطابق ClientConfig رسمی psiphon-tunnel-core باشد؛ نام‌های قدیمیِ اشتباه
            // (listener با کلید غلط) باعث می‌شد موتور روی پورت دلخواهِ ۰ گوش بدهد و
            // tun2proxy به 20873 وصل شود اما هیچ‌کس آن‌جا گوش نمی‌داد.
            val obj = JSONObject(txt)
            obj.put("LocalSocksProxyPort", PORT)
            obj.put("DisableLocalHTTPProxy", true)
            if (region.length == 2) obj.put("EgressRegion", region.uppercase()) // v1.30: انتخاب کشور
            obj.put("EmitDiagnosticNotices", false)
            // v1.25.5 — فیکس ریشه‌ای خطای «failed to create datastore directory …
            // read-only file system»: وقتی DataRootDirectory خالی باشد، tunnel-core
            // دایرکتوری داده را نسبت به CWD می‌سازد و CWD پروسهٔ اندروید «/»
            // (فقط‌خواندنی) است. یک زیرپوشهٔ اختصاصیِ نوشتنی داخل filesDir می‌دهیم —
            // tunnel-core کلّ محتوای این مسیر را مدیریت می‌کند (مستندات Config).
            val dsRoot = File(filesDir, "shk-root")
            try { dsRoot.mkdirs() } catch (_: Throwable) {}
            obj.put("DataRootDirectory", dsRoot.absolutePath)
            out.writeText(obj.toString())
            val (entryFile, entryCount) = prepareEntryFile(obj)
            return Triple(out, entryFile, entryCount)
        } catch (t: Throwable) {
            Log.e(TAG, "prepareConfig: ${t.message}")
            fail("خواندن پیکربندی سایفون شکست خورد")
            return null
        }
    }

    /** فیلد اختیاری رشته‌ای از مدخل JSON (با گارد JSONObject.NULL و انواع مختلف). */
    private fun entryStr(f: JSONObject, k: String): String {
        val v = f.opt(k) ?: return ""
        if (v === JSONObject.NULL) return ""
        return v.toString().trim()
    }

    /**
     * v1.25.16 — فایل ‎-serverList برای ConsoleClient می‌سازد.
     * هر خط: hex("ip port secret cert {json}")؛ بدون گواهیِ وب‌سرور → "0 0 0 0"
     * (طبق encodeServerEntry رسمی tunnel-core؛ دیکودر رسمی: hex→SplitN(" ",5)→JSON).
     * JSONِ هر مدخل عیناً از پیکربندی تعبیه‌شده حفظ می‌شود (هیچ فیلدی دور ریخته نمی‌شود).
     * اگر هیچ مدخلی قابل تبدیل نبود null برمی‌گرداند (تکیه بر datastore پیشین/ریموت).
     */
    private fun prepareEntryFile(cfg: JSONObject): Pair<File?, Int> {
        val arr = cfg.optJSONArray("EmbeddedServerEntryList")
        if (arr == null || arr.length() == 0) return Pair(null, 0)
        val out = File(filesDir, "shk-entries.txt")
        val hexDigits = "0123456789abcdef"
        val sb = StringBuilder(arr.length() * 3200)
        var n = 0
        for (i in 0 until arr.length()) {
            val raw = try { arr.getString(i) } catch (_: Throwable) { continue }
            val j = raw.indexOf("{")
            if (j < 0) continue
            // newline واقعی در JSON فقط whitespace بین توکن‌هاست — با فاصله جابه‌جا می‌شود
            // (داخل رشته‌ها newline به شکل \n Escape است؛ دیکودر خط‌محور نمی‌شکند)
            val json = raw.substring(j).trim().replace('\n', ' ').replace('\r', ' ')
            if (json.isEmpty()) continue
            val f = try { JSONObject(json) } catch (_: Throwable) { continue }
            val ip = entryStr(f, "ipAddress")
            if (ip.isEmpty() || ip.contains(' ')) continue
            val port = entryStr(f, "webServerPort").ifBlank { "0" }
            val secret = entryStr(f, "webServerSecret").ifBlank { "0" }
            val cert = entryStr(f, "webServerCertificate")
            val line = if (cert.isEmpty() || cert == "0") "0 0 0 0 $json" else "$ip $port $secret $cert $json"
            for (b in line.toByteArray(Charsets.UTF_8)) {
                sb.append(hexDigits[(b.toInt() ushr 4) and 0xF]).append(hexDigits[b.toInt() and 0xF])
            }
            sb.append('\n')
            n++
        }
        if (n == 0) return Pair(null, 0)
        out.writeText(sb.toString())
        return Pair(out, n)
    }

    private fun startEngine() {
        stopping = false
        running = true
        verified = false
        err = ""
        stage("راه‌اندازی شبکهٔ سایفون…")
        val bin = File(applicationInfo.nativeLibraryDir, LIB)
        if (!bin.exists()) {
            fail("موتور سایفون در این APK نصب نشده (بیلد اختیاری است) — نسخهٔ جدید برنامه را نصب کن")
            finishFailed(); return
        }
        val prep = prepareConfig() ?: run { finishFailed(); return }
        val cfg = prep.first
        val entryFile = prep.second
        val entryCount = prep.third
        if (!establishTun()) { finishFailed(); return }

        // v1.25.16: لیست تعبیه‌شده فقط از فایل ‎-serverList خوانده می‌شود — بدون این فلگ
        // ConsoleClient صفر کاندیداد دارد و «وصل» هیچ‌وقت ممکن نیست (ریشهٔ باگ).
        val flags = mutableListOf<String>("--config", cfg.absolutePath)
        if (entryFile != null) {
            flags.addAll(listOf("-serverList", entryFile.absolutePath))
            log("cmd: shkcore --config ${cfg.absolutePath} (${cfg.length()} bytes) -serverList ${entryFile.name} ($entryCount entries)")
        } else {
            log("cmd: shkcore --config ${cfg.absolutePath} (${cfg.length()} bytes) — بدون سرورانتر تعبیه‌شده")
        }
        val p = try {
            ProcessBuilder(listOf(bin.absolutePath) + flags).redirectErrorStream(true).start()
        } catch (t: Throwable) {
            log("exec مستقیم نشد (" + (t.message ?: "?") + ") → از لینکر سیستم")
            try {
                ProcessBuilder(listOf("/system/bin/linker64", bin.absolutePath) + flags)
                    .redirectErrorStream(true).start()
            } catch (t2: Throwable) {
                fail("اجرای موتور سایفون شکست: " + (t2.message ?: t2.toString()))
                finishFailed(); return
            }
        }
        proc = p
        Thread({
            try {
                BufferedReader(InputStreamReader(p.inputStream, Charsets.UTF_8)).use { r ->
                    while (true) { val line = r.readLine() ?: break; log(line.take(300)) }
                }
            } catch (_: Throwable) {}
        }, "shk-log").apply { isDaemon = true }.start()

        if (awaitVerified(120_000L)) return
        if (stopping) return
        fail(if (err.isBlank()) "شبکهٔ سایفون وصل نشد — دوباره تلاش کن" else err)
        finishFailed()
    }

    private fun finishFailed() {
        running = false
        try { teardown() } catch (_: Throwable) {}
        try { stopSelf() } catch (_: Throwable) {}
    }

    private fun establishTun(): Boolean {
        val builder = Builder()
            .setSession("shk")
            .setMtu(MTU)
            .addAddress("10.117.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("1.1.1.1")
            .setBlocking(false)
        try { builder.addDisallowedApplication(packageName) } catch (_: Throwable) {}
        val fd = try { builder.establish() } catch (t: Throwable) {
            Log.e(TAG, "establish: " + t.message); null
        }
        if (fd == null) { fail("مجوز VPN داده نشد یا یک VPN دیگر فعاله"); return false }
        tun = fd
        val det = fd.detachFd()
        tun2proxyRunning.set(true)
        val proxyUrl = "socks5://127.0.0.1:$PORT"
        val th = Thread({
            try {
                val rc = Native.runTun2proxy(proxyUrl, det, MTU, "")
                Log.i(TAG, "tun2proxy exited rc=$rc")
            } catch (t: Throwable) {
                Log.e(TAG, "tun2proxy: " + t.message)
            } finally {
                tun2proxyRunning.set(false)
            }
        }, "shk-tun2proxy")
        th.start()
        tun2proxyThread = th
        return true
    }

    private fun awaitVerified(budgetMs: Long): Boolean {
        val start = SystemClock.elapsedRealtime()
        var next = 0L
        while (SystemClock.elapsedRealtime() - start < budgetMs) {
            if (stopping) return false
            if (proc != null && proc?.isAlive != true) { log("موتور خودش بسته شد"); return false }
            if (SystemClock.elapsedRealtime() >= next) {
                val body = traceThroughSocks()
                if (body != null && body.contains("\r\n\r\n")) {
                    verified = true
                    exitIp = Regex("(?m)^ip=(.*)$").find(body)?.groupValues?.getOrNull(1)?.trim() ?: ""
                    loc = Regex("(?m)^loc=(.*)$").find(body)?.groupValues?.getOrNull(1)?.trim() ?: ""
                    stage("وصل شد ✓ · شبکهٔ سایفون: " + (loc.ifBlank { exitIp.ifBlank { "—" } }))
                    log("✅ تست واقعی از داخل تونل جواب داد · ip=$exitIp · loc=$loc")
                    return true
                }
                next = SystemClock.elapsedRealtime() + 5000
            }
            try { Thread.sleep(500) } catch (_: InterruptedException) { return false }
        }
        return false
    }

    private fun traceThroughSocks(): String? {
        return try {
        val s = Socket()
        s.soTimeout = 12000
        s.connect(InetSocketAddress("127.0.0.1", PORT), 5000)
        val out = s.getOutputStream()
        val inp = s.getInputStream()
        out.write(byteArrayOf(0x05, 0x01, 0x00)); out.flush()
        val greet = ByteArray(2)
        if (readFully(inp, greet) != 2 || greet[0] != 0x05.toByte() || greet[1] == 0xff.toByte()) {
            try { s.close() } catch (_: Throwable) {}
            return null
        }
        val host = "www.cloudflare.com".toByteArray(Charsets.US_ASCII)
        val req = ByteArray(7 + host.size)
        req[0] = 0x05; req[1] = 0x01; req[2] = 0x00; req[3] = 0x03
        req[4] = host.size.toByte()
        host.copyInto(req, 5)
        req[5 + host.size] = ((443 ushr 8) and 0xFF).toByte()
        req[6 + host.size] = (443 and 0xFF).toByte()
        out.write(req); out.flush()
        val rep = ByteArray(10)
        if (readFully(inp, rep) != 10 || rep[1] != 0x00.toByte()) {
            try { s.close() } catch (_: Throwable) {}
            return null
        }
        val ssl = (SSLSocketFactory.getDefault() as SSLSocketFactory)
            .createSocket(s, "www.cloudflare.com", 443, true)
        ssl.soTimeout = 12000
        val ro = ssl.getOutputStream()
        ro.write(("GET /cdn-cgi/trace HTTP/1.1\r\nHost: www.cloudflare.com\r\nUser-Agent: panels-manager\r\nConnection: close\r\n\r\n").toByteArray(Charsets.US_ASCII))
        ro.flush()
        val body = ssl.getInputStream().readBytes().toString(Charsets.UTF_8)
        try { ssl.close() } catch (_: Throwable) {}
        body
        } catch (t: Throwable) { null }
    }

    private fun readFully(inp: InputStream, b: ByteArray): Int {
        var n = 0
        while (n < b.size) {
            val k = inp.read(b, n, b.size - n)
            if (k < 0) break
            n += k
        }
        return n
    }

    private fun teardown() {
        if (!tornDown.compareAndSet(false, true)) return
        stopping = true
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Throwable) {}
        killEngine()
        if (tun2proxyRunning.get()) {
            val stopper = Thread({
                try { Native.stopTun2proxy() } catch (_: Throwable) {}
            }, "shk-t2p-stop").apply { start() }
            try { stopper.join(2_000) } catch (_: InterruptedException) {}
        }
        try { tun?.close() } catch (_: Throwable) {}
        tun = null
        try { tun2proxyThread?.join(4_000) } catch (_: InterruptedException) {}
        tun2proxyThread = null
        running = false
        stageText = "قطع شد"
    }

    private fun killEngine() {
        val p = proc ?: return
        proc = null
        try { p.destroy() } catch (_: Throwable) {}
        val gone = try { p.waitFor(3, TimeUnit.SECONDS) } catch (_: Throwable) { false }
        if (!gone) { try { p.destroyForcibly() } catch (_: Throwable) {} }
    }

    private fun buildNotif(): Notification {
        val mgr = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Shir o Khorshid", NotificationManager.IMPORTANCE_LOW)
                .apply { description = "وضعیت تونل سایفون"; setShowBadge(false) }
            mgr.createNotificationChannel(ch)
        }
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        val openIntent = PendingIntent.getActivity(
            this, 0, launch ?: Intent(),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stopIntent = PendingIntent.getService(
            this, 3,
            Intent(this, ShkVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        @Suppress("DEPRECATION")
        val b = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return b
            .setContentTitle("سایفون فعال — شبکهٔ Psiphon")
            .setContentText("SOCKS 127.0.0.1:$PORT · موتور داخل اپ")
            .setSmallIcon(android.R.drawable.presence_online)
            .setContentIntent(openIntent)
            .addAction(
                Notification.Action.Builder(
                    android.graphics.drawable.Icon.createWithResource(
                        this, android.R.drawable.ic_menu_close_clear_cancel
                    ),
                    "قطع", stopIntent
                ).build()
            )
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val TAG = "ShkVpnService"
        private const val CHANNEL_ID = "shk.vpn.status"
        private const val NOTIF_ID = 0x1007
        private const val MTU = 1500
        const val PORT = 20873
        const val LIB = "libshkcore.so"
        const val ACTION_STOP = "com.therealaleph.mhrv.SHK_STOP"

        @Volatile @JvmField var region: String = ""
        @Volatile @JvmField var running = false
        @Volatile @JvmField var verified = false
        @Volatile var stageText = "آماده"; private set
        @Volatile var err = ""; private set
        @Volatile var exitIp = ""; private set
        @Volatile var loc = ""; private set
        @Volatile private var stopping = false
        private val ring = ArrayDeque<String>()

        fun log(line: String) {
            synchronized(ring) {
                ring.addLast(line)
                while (ring.size > 300) ring.removeFirst()
            }
            Log.i(TAG, line)
        }

        private fun stage(s: String) { stageText = s; log(s) }

        private fun fail(s: String) {
            err = s; stageText = s; running = false
            log("خطا: " + s)
        }

        fun snapshot(): String {
            val o = JSONObject()
            o.put("running", running)
            o.put("verified", verified)
            o.put("stage", stageText)
            o.put("err", err)
            o.put("ip", exitIp)
            o.put("loc", loc)
            val tail = synchronized(ring) { ring.toList().takeLast(14) }
            o.put("logs", tail.joinToString("\n"))
            return o.toString()
        }
    }
}

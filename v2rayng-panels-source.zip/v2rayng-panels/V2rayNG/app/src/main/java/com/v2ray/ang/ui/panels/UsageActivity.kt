package com.v2ray.ang.ui.panels

import android.widget.Toast
import androidx.compose.foundation.layout.Column
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import com.v2ray.ang.ui.compose.AppTopBar
import com.therealaleph.mhrv.Native
import com.therealaleph.mhrv.VpnState
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * تب مصرف — فقط خروجی واقعی Native.statsJson موتور mhrv-rs:
 *   • شمارنده‌های رله/کش/بایت این نشست
 *   • سهمیهٔ امروز (today_* با ریست واقعی نیمه‌شب Pacific — همان که Apps Script دارد)
 *   • انباشت روزانهٔ محلی (بین اجراها در PanelPrefs — از خود اعداد موتور پر می‌شود)
 * موتور خاموش = اعداد آخرین وضعیت واقعی؛ هیچ عدد ساختگی نمایش داده نمی‌شود.
 */
class UsageActivity : BasePanelActivity() {

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    override fun ScreenContent() {
        val ctx = this
        var stats by remember { mutableStateOf<JSONObject?>(null) }
        var running by remember { mutableStateOf(VpnState.isRunning) }
        var accum by remember { mutableStateOf(PanelPrefs.loadUsage(ctx)) }

        LaunchedEffect(Unit) {
            while (isActive) {
                delay(1000)
                running = VpnState.isRunning
                val h = VpnState.proxyHandle
                if (running && h != 0L) {
                    val s = runCatching { JSONObject(Native.statsJson(h)) }.getOrNull()
                    if (s != null) {
                        stats = s
                        // انباشت واقعی روزانه: همان کلید روزِ موتور (Pacific) به‌عنوان مرز
                        val day = s.optString("today_key", todayKey())
                        val prev = PanelPrefs.loadUsage(ctx)
                        val next = if (prev.day != day) {
                            PanelPrefs.UsageSnapshot(day, s.optLong("today_calls", 0), s.optLong("today_bytes", 0), s.optLong("relay_calls", 0))
                        } else {
                            PanelPrefs.UsageSnapshot(
                                day,
                                maxOf(prev.calls, s.optLong("today_calls", 0)),
                                maxOf(prev.bytes, s.optLong("today_bytes", 0)),
                                maxOf(prev.relayCalls, s.optLong("relay_calls", 0)),
                            )
                        }
                        PanelPrefs.saveUsage(ctx, next)
                        accum = next
                    }
                }
            }
        }

        Scaffold(
            topBar = {
                AppTopBar(
                    title = stringResource(R.string.p_title_usage),
                    onBackClick = { finish() },
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
            ) {
                if (!running) {
                    Text(
                        text = stringResource(R.string.p_usage_note_off),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    )
                }

                val s = stats
                EngineStatusCard(
                    running = running,
                    verified = running,
                    stage = if (running) stringResource(R.string.p_running) else stringResource(R.string.p_stopped),
                    rows = if (s == null) emptyList() else listOf(
                        stringResource(R.string.p_usage_relay_calls) to s.optLong("relay_calls", 0).toString(),
                        stringResource(R.string.p_usage_relay_failures) to s.optLong("relay_failures", 0).toString(),
                        stringResource(R.string.p_usage_bytes) to NetTools.humanBytes(s.optLong("bytes_relayed", 0)),
                        stringResource(R.string.p_usage_cache_hits) to s.optLong("cache_hits", 0).toString(),
                        stringResource(R.string.p_usage_cache_misses) to s.optLong("cache_misses", 0).toString(),
                    ),
                )

                SectionHeader(stringResource(R.string.p_usage_local_totals, accum.day.ifBlank { "—" }))
                EngineStatusCard(
                    running = running,
                    verified = running,
                    stage = "",
                    rows = listOf(
                        stringResource(R.string.p_usage_today_calls) to accum.calls.toString(),
                        stringResource(R.string.p_usage_today_bytes) to NetTools.humanBytes(accum.bytes),
                        stringResource(R.string.p_usage_relay_calls) to accum.relayCalls.toString(),
                    ),
                )

                // شمارش معکوس واقعی ریست سهمیه (today_reset_secs از خود موتور)
                val resetSecs = s?.optLong("today_reset_secs", -1L) ?: -1L
                if (resetSecs > 0) {
                    StatusRow(
                        stringResource(R.string.p_usage_reset_in, formatHms(resetSecs)),
                        "",
                    )
                }

                ActionButton(title = stringResource(R.string.p_usage_reset)) {
                    PanelPrefs.resetUsage(ctx)
                    accum = PanelPrefs.loadUsage(ctx)
                    Toast.makeText(ctx, R.string.p_saved_ok, Toast.LENGTH_SHORT).show()
                }
                NavigationBarsSpacer()
            }
        }
    }

    private fun todayKey(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun formatHms(totalSecs: Long): String {
        val h = totalSecs / 3600
        val m = (totalSecs % 3600) / 60
        val sec = totalSecs % 60
        return String.format(Locale.US, "%02d:%02d:%02d", h, m, sec)
    }
}

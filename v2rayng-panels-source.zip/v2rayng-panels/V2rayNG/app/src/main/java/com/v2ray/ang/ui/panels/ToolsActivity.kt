package com.v2ray.ang.ui.panels

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import com.v2ray.ang.ui.compose.FormTextField
import com.v2ray.ang.ui.logcat.LogcatActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * تب ابزارها — هر ابزار یک کار واقعی شبکه/سیستم:
 *   • TCP ping واقعی (میزبان/پورت)
 *   • جست‌وجوی DNS واقعی (A) به رزولور دلخواه با پارس واقعی پاسخ
 *   • IP/لوکیشن فعلی (trace واقعی کلودفلر)
 *   • دریافت هدرهای واقعی یک URL
 *   • باز کردن logcat (قابلیت اصلی v2rayNG از منو حذف شده بود؛ اینجا در دسترس می‌ماند)
 */
class ToolsActivity : BasePanelActivity() {

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    override fun ScreenContent() {
        val ctx = this
        val scope = rememberCoroutineScope()

        var host by rememberSaveable { mutableStateOf("www.google.com") }
        var port by rememberSaveable { mutableStateOf("443") }
        var domain by rememberSaveable { mutableStateOf("www.google.com") }
        var resolver by rememberSaveable { mutableStateOf("1.1.1.1") }
        var headersUrl by rememberSaveable { mutableStateOf("https://www.cloudflare.com/cdn-cgi/trace") }
        var result by remember { mutableStateOf("") }

        fun run(block: suspend () -> String) {
            result = "…"
            scope.launch(Dispatchers.IO) {
                val text = runCatching { block() }.getOrDefault(getString(R.string.p_err_generic))
                withContext(Dispatchers.Main) { result = text }
            }
        }

        Scaffold(
            topBar = {
                AppTopBar(
                    title = stringResource(R.string.p_title_tools),
                    onBackClick = { finish() },
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
            ) {
                // TCP ping
                SectionHeader(stringResource(R.string.p_tools_tcping))
                FormTextField(
                    label = stringResource(R.string.p_tools_host),
                    value = host,
                    onValueChange = { host = it },
                    maxLines = 1,
                )
                FormTextField(
                    label = stringResource(R.string.p_tools_port),
                    value = port,
                    onValueChange = { port = it.filter { c -> c.isDigit() }.take(5) },
                    keyboardType = KeyboardType.Number,
                    maxLines = 1,
                )
                ActionButton(title = stringResource(R.string.p_tools_run)) {
                    val p = port.toIntOrNull()?.coerceIn(1, 65535) ?: 443
                    run {
                        val ms = NetTools.tcping(host.trim(), p, 4000)
                        if (ms >= 0) "${host.trim()}:$p → ${ms}ms"
                        else getString(R.string.p_tools_fail)
                    }
                }

                // DNS lookup
                SectionHeader(stringResource(R.string.p_tools_dns))
                FormTextField(
                    label = stringResource(R.string.p_tools_domain),
                    value = domain,
                    onValueChange = { domain = it },
                    maxLines = 1,
                )
                FormTextField(
                    label = stringResource(R.string.p_tools_resolver),
                    value = resolver,
                    onValueChange = { resolver = it },
                    maxLines = 1,
                )
                ActionButton(title = stringResource(R.string.p_tools_run)) {
                    val answers = NetTools.dnsQueryA(domain.trim(), resolver.trim())
                    if (answers == null) getString(R.string.p_tools_fail)
                    else if (answers.isEmpty()) "${domain.trim()} → NXDOMAIN/no A"
                    else "${domain.trim()} @${resolver.trim()}\n" + answers.joinToString("\n")
                }

                // IP / location
                SectionHeader(stringResource(R.string.p_tools_ip_info))
                ActionButton(title = stringResource(R.string.p_tools_run)) {
                    val trace = NetTools.cloudflareTrace()
                    if (trace == null) getString(R.string.p_tools_fail)
                    else "ip=${trace["ip"] ?: "—"}\nloc=${trace["loc"] ?: "—"}\ncolo=${trace["colo"] ?: "—"}"
                }

                // HTTP headers
                SectionHeader(stringResource(R.string.p_tools_headers))
                FormTextField(
                    label = stringResource(R.string.p_tools_url),
                    value = headersUrl,
                    onValueChange = { headersUrl = it },
                    maxLines = 2,
                )
                ActionButton(title = stringResource(R.string.p_tools_run)) {
                    val r = NetTools.httpGet(headersUrl.trim(), 10000)
                    if (r == null) getString(R.string.p_tools_fail)
                    else "HTTP ${r.status} · ${r.latencyMs}ms\n" +
                        r.headers.entries.joinToString("\n") { "${it.key}: ${it.value}" } +
                        "\n\n" + r.body.take(500)
                }

                // logcat — دسترس‌پذیری قابلیت اصلی
                ActionButton(title = stringResource(R.string.p_tools_open_logcat)) {
                    runCatching { startActivity(Intent(this@ToolsActivity, LogcatActivity::class.java)) }
                }

                if (result.isNotEmpty()) {
                    SectionHeader(stringResource(R.string.p_tools_result))
                    Text(
                        text = result,
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                    )
                }
                NavigationBarsSpacer()
            }
        }
    }
}

package com.v2ray.ang.ui.panels

import android.content.Context
import android.content.SharedPreferences

/**
 * حافظهٔ تنظیمات ماژول‌های پنل — یک منبع حقیقت واحد برای endpoint/key پنل
 * (Google Apps Script) که هم «کنترل پنل» و هم «Google Script» از آن می‌خوانند.
 * صرفاً SharedPreferences محلی؛ هیچ دادهٔ نمونه/پیش‌فرضی اینجا ذخیره نمی‌شود.
 */
object PanelPrefs {

    private const val PREFS = "panels_store"

    const val KEY_SCRIPT_URL = "script_url"
    const val KEY_AUTH_KEY = "auth_key"

    fun prefs(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getScriptUrl(ctx: Context): String =
        prefs(ctx).getString(KEY_SCRIPT_URL, "")?.trim() ?: ""

    fun getAuthKey(ctx: Context): String =
        prefs(ctx).getString(KEY_AUTH_KEY, "")?.trim() ?: ""

    fun save(ctx: Context, url: String, key: String) {
        prefs(ctx).edit()
            .putString(KEY_SCRIPT_URL, url.trim())
            .putString(KEY_AUTH_KEY, key.trim())
            .apply()
    }

    /** آمار مصرف تجمعی محلی — فقط از خروجی واقعی statsJson موتور پر می‌شود. */
    private const val KEY_USAGE_DAY = "usage_day"
    private const val KEY_USAGE_CALLS = "usage_calls"
    private const val KEY_USAGE_BYTES = "usage_bytes"
    private const val KEY_USAGE_RELAY = "usage_relay"

    fun loadUsage(ctx: Context): UsageSnapshot {
        val p = prefs(ctx)
        return UsageSnapshot(
            day = p.getString(KEY_USAGE_DAY, "") ?: "",
            calls = p.getLong(KEY_USAGE_CALLS, 0L),
            bytes = p.getLong(KEY_USAGE_BYTES, 0L),
            relayCalls = p.getLong(KEY_USAGE_RELAY, 0L),
        )
    }

    fun saveUsage(ctx: Context, s: UsageSnapshot) {
        prefs(ctx).edit()
            .putString(KEY_USAGE_DAY, s.day)
            .putLong(KEY_USAGE_CALLS, s.calls)
            .putLong(KEY_USAGE_BYTES, s.bytes)
            .putLong(KEY_USAGE_RELAY, s.relayCalls)
            .apply()
    }

    fun resetUsage(ctx: Context) {
        prefs(ctx).edit()
            .putString(KEY_USAGE_DAY, "")
            .putLong(KEY_USAGE_CALLS, 0L)
            .putLong(KEY_USAGE_BYTES, 0L)
            .putLong(KEY_USAGE_RELAY, 0L)
            .apply()
    }

    data class UsageSnapshot(val day: String, val calls: Long, val bytes: Long, val relayCalls: Long)
}

package com.v2ray.ang.ui.panels

import android.content.ClipData
import android.content.ClipboardManager
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.FormTextField
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetAddress

/**
 * تب اسکن IP — اسکنر واقعی: دامنه/IP هدف را رزولو می‌کند، همسایگی /24 را
 * می‌سازد و اتصال واقعی TCP (و در صورت انتخاب، دست‌دادن TLS با SNI) می‌زند.
 * هر عدد خروجی، نتیجهٔ یک اتصال واقعی است؛ چیزی شبیه‌سازی نمی‌شود.
 */
class IpScanActivity : BasePanelActivity() {

    private data class Row(val ip: String, val tcpMs: Int, val tlsMs: Int?)

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    override fun ScreenContent() {
        val ctx = this
        val scope = rememberCoroutineScope()

        var target by rememberSaveable { mutableStateOf("") }
        var port by rememberSaveable { mutableStateOf("443") }
        var maxIps by rememberSaveable { mutableStateOf("64") }
        var tlsTest by rememberSaveable { mutableStateOf(true) }
        var scanning by remember { mutableStateOf(false) }
        var done by remember { mutableIntStateOf(0) }
        var total by remember { mutableIntStateOf(0) }
        var error by remember { mutableStateOf("") }
        val rows = remember { mutableStateListOf<Row>() }
        val scanJob = remember { mutableStateOf<Job?>(null) }

        Scaffold(
            topBar = {
                AppTopBar(
                    title = stringResource(R.string.p_title_ipscan),
                    onBackClick = { finish() },
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    FormTextField(
                        label = stringResource(R.string.p_ipscan_target),
                        value = target,
                        onValueChange = { target = it },
                        maxLines = 1,
                    )
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f)) {
                            FormTextField(
                                label = stringResource(R.string.p_ipscan_port),
                                value = port,
                                onValueChange = { port = it.filter { c -> c.isDigit() }.take(5) },
                                keyboardType = KeyboardType.Number,
                                maxLines = 1,
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            FormTextField(
                                label = stringResource(R.string.p_ipscan_max),
                                value = maxIps,
                                onValueChange = { maxIps = it.filter { c -> c.isDigit() }.take(4) },
                                keyboardType = KeyboardType.Number,
                                maxLines = 1,
                            )
                        }
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(checked = tlsTest, onCheckedChange = { tlsTest = it })
                        Text(
                            text = stringResource(R.string.p_ipscan_tls_test),
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                    Text(
                        text = stringResource(R.string.p_ipscan_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                    )

                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    ) {
                        TextButton(
                            enabled = !scanning,
                            onClick = {
                                val t = target.trim()
                                val p = port.toIntOrNull()?.coerceIn(1, 65535) ?: 443
                                val max = maxIps.toIntOrNull()?.coerceIn(1, 254) ?: 64
                                if (t.isEmpty()) {
                                    Toast.makeText(ctx, R.string.p_ipscan_need_target, Toast.LENGTH_SHORT).show()
                                    return@TextButton
                                }
                                rows.clear()
                                done = 0
                                total = 0
                                error = ""
                                scanning = true
                                scanJob.value = scope.launch(Dispatchers.IO) {
                                    try {
                                        // رزولوی واقعی دامنه
                                        val isIp = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(t)
                                        val baseIps: List<String> = if (isIp) listOf(t) else {
                                            runCatching {
                                                InetAddress.getAllByName(t).map { it.hostAddress ?: "" }
                                                    .filter { it.contains('.') }
                                            }.getOrDefault(emptyList())
                                        }
                                        if (baseIps.isEmpty()) {
                                            withContext(Dispatchers.Main) {
                                                error = getString(R.string.p_ipscan_resolve_fail)
                                                scanning = false
                                            }
                                            return@launch
                                        }
                                        // ساخت همسایگی /24 (بدون تکرار شبکه)
                                        val networks = LinkedHashSet<String>()
                                        for (ip in baseIps) {
                                            val parts = ip.split(".")
                                            if (parts.size == 4) networks.add("${parts[0]}.${parts[1]}.${parts[2]}")
                                            if (networks.size >= 4) break
                                        }
                                        val candidates = ArrayList<String>()
                                        outer@ for (net in networks) {
                                            for (h in 1..254) {
                                                candidates.add("$net.$h")
                                                if (candidates.size >= max) break@outer
                                            }
                                        }
                                        withContext(Dispatchers.Main) { total = candidates.size }
                                        val sni = if (isIp) "www.google.com" else t
                                        for (chunk in candidates.chunked(12)) {
                                            if (!scope.isActive) break
                                            val chunkRows: List<Row> = coroutineScope {
                                                chunk.map { ip ->
                                                    async {
                                                        val tcp = NetTools.tcping(ip, p, 1500)
                                                        if (tcp >= 0 && tlsTest) {
                                                            val tls = NetTools.tlsSniProbe(ip, sni, p, 3000)
                                                            Row(ip, tcp, tls)
                                                        } else {
                                                            Row(ip, tcp, null)
                                                        }
                                                    }
                                                }.awaitAll()
                                            }
                                            withContext(Dispatchers.Main) {
                                                rows.addAll(chunkRows.filter { it.tcpMs >= 0 })
                                                done += chunk.size
                                            }
                                        }
                                    } finally {
                                        withContext(Dispatchers.Main) { scanning = false }
                                    }
                                }
                            },
                        ) { Text(stringResource(R.string.p_ipscan_run)) }
                        TextButton(
                            enabled = scanning,
                            onClick = { scanJob.value?.cancel(); scanning = false },
                        ) { Text(stringResource(R.string.p_ipscan_stop)) }
                        if (total > 0) {
                            TextButton(
                                enabled = rows.isNotEmpty(),
                                onClick = {
                                    val text = rows.joinToString("\n") { r ->
                                        "${r.ip}\ttcp=${r.tcpMs}ms" +
                                            (r.tlsMs?.let { "\ttls=${it}ms" } ?: "")
                                    }
                                    val cm = ctx.getSystemService(ClipboardManager::class.java)
                                    cm?.setPrimaryClip(ClipData.newPlainText("ipscan", text))
                                    Toast.makeText(ctx, R.string.p_copied, Toast.LENGTH_SHORT).show()
                                },
                            ) { Text(stringResource(R.string.p_ipscan_copy_results)) }
                        }
                    }

                    if (total > 0) {
                        Text(
                            text = stringResource(R.string.p_ipscan_progress, done, total),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 16.dp),
                        )
                    }
                    if (error.isNotEmpty()) {
                        NoticeLine(error)
                    }
                }

                Text(
                    text = stringResource(R.string.p_ipscan_no_results)
                        .takeIf { rows.isEmpty() } ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp),
                )

                LazyColumn(modifier = Modifier.weight(1f)) {
                    items(rows) { r ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = r.ip,
                                style = MaterialTheme.typography.bodyMedium,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.weight(0.5f),
                            )
                            Text(
                                text = if (r.tcpMs >= 0)
                                    "${stringResource(R.string.p_ipscan_result_open)} · ${r.tcpMs}ms"
                                else stringResource(R.string.p_ipscan_result_closed),
                                style = MaterialTheme.typography.bodySmall,
                                color = if (r.tcpMs >= 0) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.weight(0.25f),
                            )
                            Text(
                                text = r.tlsMs?.let { m ->
                                    if (m >= 0) "TLS ${m}ms" else stringResource(R.string.p_int_fail)
                                } ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.weight(0.25f),
                            )
                        }
                    }
                }
                NavigationBarsSpacer()
            }
        }
    }
}

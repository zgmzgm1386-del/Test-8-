package com.v2ray.ang.ui.panels

import android.os.SystemClock
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.Socket
import java.net.URL
import java.nio.charset.StandardCharsets
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLParameters
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/**
 * ابزارهای واقعی شبکه — همهٔ ماژول‌ها (اسکن IP، اختلال، ابزارها، کنترل پنل،
 * Google Script) فقط از همین توابع استفاده می‌کنند؛ هیچ دادهٔ ساختگی وجود
 * ندارد: هر عددی که در UI دیده می‌شود از یک اتصال/کوئری واقعی همین توابع
 * به‌دست آمده است.
 */
object NetTools {

    // ── TCP ping ────────────────────────────────────────────────────────────

    /** دست‌دادن TCP واقعی؛ تأخیر برحسب ms یا -1 در صورت شکست. */
    fun tcping(host: String, port: Int, timeoutMs: Int = 3000): Int {
        return try {
            val s = Socket()
            val t0 = SystemClock.elapsedRealtime()
            s.connect(InetSocketAddress(host, port), timeoutMs)
            val dt = (SystemClock.elapsedRealtime() - t0).toInt()
            runCatching { s.close() }
            dt
        } catch (_: Throwable) {
            -1
        }
    }

    // ── DNS ─────────────────────────────────────────────────────────────────

    /**
     * کوئری واقعی A روی UDP/53 به یک رزولور مشخص. لیست IPv4های جواب یا null
     * (خطا/تایم‌اوت/بلاک). برخلاف DnsProbe فقط تأخیر برنمی‌گرداند بلکه
     * رکوردها را هم می‌خواند (برای «ابزارها»).
     */
    fun dnsQueryA(name: String, resolver: String, timeoutMs: Int = 2500): List<String>? {
        if (!Regex("^[A-Za-z0-9.\\-]+$").matches(name.trim())) return null
        val q = buildDnsQuery(name.trim())
        val sock = DatagramSocket()
        return try {
            sock.soTimeout = timeoutMs
            sock.send(DatagramPacket(q, q.size, InetAddress.getByName(resolver.trim()), 53))
            val rb = ByteArray(2048)
            val p = DatagramPacket(rb, rb.size)
            sock.receive(p)
            parseDnsAnswers(rb, p.length)
        } catch (_: Throwable) {
            null
        } finally {
            runCatching { sock.close() }
        }
    }

    private fun buildDnsQuery(name: String): ByteArray {
        val labels = name.trim('.').split('.')
        var size = 17
        for (l in labels) size += l.length + 1
        val q = ByteArray(size)
        val rnd = (Math.random() * 65536).toInt()
        q[0] = ((rnd ushr 8) and 0xFF).toByte(); q[1] = (rnd and 0xFF).toByte()
        q[2] = 0x01; q[3] = 0x00 // recursion desired
        q[4] = 0x00; q[5] = 0x01 // qdcount
        var i = 12
        for (l in labels) {
            q[i++] = l.length.toByte()
            for (b in l.toByteArray(StandardCharsets.US_ASCII)) q[i++] = b
        }
        q[i++] = 0
        q[i++] = 0; q[i++] = 1 // type A
        q[i++] = 0; q[i++] = 1 // class IN
        return q.copyOf(i)
    }

    /** از یک پاسخ DNS استاندارد، فقط رکوردهای A استخراج می‌شود (نام/کلاس فشرده هم پشتیبانی می‌شود). */
    private fun parseDnsAnswers(buf: ByteArray, len: Int): List<String>? {
        if (len < 12) return null
        var i = 12
        // skip question section
        fun skipName(): Boolean {
            while (i < len) {
                val l = buf[i].toInt() and 0xFF
                if (l == 0) { i++; return true }
                if (l and 0xC0 != 0) { i += 2; return true } // compressed
                i += l + 1
            }
            return false
        }
        if (!skipName()) return null
        i += 4 // qtype + qclass
        val answers = mutableListOf<String>()
        val anCount = ((buf[6].toInt() and 0xFF) shl 8) or (buf[7].toInt() and 0xFF)
        for (a in 0 until anCount) {
            if (!skipName()) break
            if (i + 10 > len) break
            val type = ((buf[i].toInt() and 0xFF) shl 8) or (buf[i + 1].toInt() and 0xFF)
            val rdLen = ((buf[i + 8].toInt() and 0xFF) shl 8) or (buf[i + 9].toInt() and 0xFF)
            i += 10
            if (type == 1 && rdLen == 4 && i + 4 <= len) {
                answers.add("${buf[i].toInt() and 0xFF}.${buf[i + 1].toInt() and 0xFF}.${buf[i + 2].toInt() and 0xFF}.${buf[i + 3].toInt() and 0xFF}")
            }
            i += rdLen
        }
        return answers
    }

    // ── TLS/SNI probe ───────────────────────────────────────────────────────

    /**
     * دست‌دادن واقعی TLS به یک IP مشخص با SNI دلخواه (تشخیص اختلال SNI).
     * خروجی: تأخیر ms یا -1 (شکست) — همان منطق اسکنر تب اسکن.
     */
    fun tlsSniProbe(ip: String, sni: String, port: Int = 443, timeoutMs: Int = 4000): Int {
        return try {
            val sslFactory = SSLSocketFactory.getDefault() as SSLSocketFactory
            val s = Socket()
            s.connect(InetSocketAddress(ip, port), timeoutMs)
            val ssl = sslFactory.createSocket(s, sni, port, true) as SSLSocket
            ssl.soTimeout = timeoutMs
            val t0 = SystemClock.elapsedRealtime()
            runCatching {
                val params = ssl.sslParameters
                params.serverNames = listOf(SNIHostName(sni))
                ssl.sslParameters = params
            }
            ssl.startHandshake()
            val dt = (SystemClock.elapsedRealtime() - t0).toInt()
            runCatching { ssl.close() }
            dt
        } catch (_: Throwable) {
            -1
        }
    }

    // ── HTTP(S) ─────────────────────────────────────────────────────────────

    data class HttpResult(val status: Int, val headers: Map<String, String>, val body: String, val latencyMs: Int)

    /**
     * GET واقعی. اگر socksHost/socksPort داده شود، کل درخواست از داخل همان
     * SOCKS5 (موتور فعال) می‌گذرد — برای «تست واقعی از داخل تونل».
     */
    fun httpGet(
        url: String,
        timeoutMs: Int = 10000,
        headers: Map<String, String> = emptyMap(),
        socksHost: String? = null,
        socksPort: Int = 0,
    ): HttpResult? {
        return try {
            val conn = if (socksHost != null && socksPort > 0) {
                URL(url).openConnection(Proxy(Proxy.Type.SOCKS, InetSocketAddress(socksHost, socksPort)))
            } else {
                URL(url).openConnection()
            } as java.net.HttpURLConnection
            conn.connectTimeout = timeoutMs
            conn.readTimeout = timeoutMs
            conn.instanceFollowRedirects = false
            for ((k, v) in headers) conn.setRequestProperty(k, v)
            val t0 = SystemClock.elapsedRealtime()
            conn.connect()
            val status = conn.responseCode
            val hdrs = mutableMapOf<String, String>()
            for ((k, v) in conn.headerFields) {
                if (k != null && v != null && v.isNotEmpty()) hdrs[k] = v.first()
            }
            val stream: InputStream? = if (status in 200..399) conn.inputStream else conn.errorStream
            val body = stream?.let {
                BufferedReader(InputStreamReader(it, StandardCharsets.UTF_8)).use { r ->
                    val sb = StringBuilder()
                    var line: String? = r.readLine()
                    var n = 0
                    while (line != null && n < 400) { sb.append(line).append('\n'); n++; line = r.readLine() }
                    sb.toString()
                }
            } ?: ""
            val dt = (SystemClock.elapsedRealtime() - t0).toInt()
            runCatching { conn.disconnect() }
            HttpResult(status, hdrs, body, dt)
        } catch (_: Throwable) {
            null
        }
    }

    /**
     * POST واقعی JSON — برای تست رلهٔ Apps Script (کنترل پنل / Google Script).
     * خروجی status یا -1؛ latency برمی‌گردد.
     */
    fun httpPostJson(
        url: String,
        jsonBody: String,
        timeoutMs: Int = 15000,
    ): HttpResult? {
        return try {
            val conn = URL(url).openConnection() as java.net.HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = timeoutMs
            conn.readTimeout = timeoutMs
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            val t0 = SystemClock.elapsedRealtime()
            conn.outputStream.use { it.write(jsonBody.toByteArray(StandardCharsets.UTF_8)) }
            val status = conn.responseCode
            val stream: InputStream? = if (status in 200..399) conn.inputStream else conn.errorStream
            val body = stream?.let {
                BufferedReader(InputStreamReader(it, StandardCharsets.UTF_8)).use { r -> r.readText() }
            } ?: ""
            val dt = (SystemClock.elapsedRealtime() - t0).toInt()
            runCatching { conn.disconnect() }
            HttpResult(status, emptyMap(), body, dt)
        } catch (_: Throwable) {
            null
        }
    }

    // ── Cloudflare trace ────────────────────────────────────────────────────

    /**
     * trace واقعی کلودفلر — «IP خروجی» و «لوکیشن» از جواب واقعی سرور.
     * viaSocks=true یعنی تست از داخل موتور فعال (پورت SOCKS آن).
     */
    fun cloudflareTrace(socksHost: String? = null, socksPort: Int = 0): Map<String, String>? {
        val r = httpGet(
            "https://www.cloudflare.com/cdn-cgi/trace",
            timeoutMs = 12000,
            headers = mapOf("User-Agent" to "v2rayNG-panels", "Connection" to "close"),
            socksHost = socksHost,
            socksPort = socksPort,
        ) ?: return null
        if (r.status !in 200..299) return null
        return r.body.lineSequence()
            .mapNotNull { line ->
                val idx = line.indexOf('=')
                if (idx <= 0) null else line.substring(0, idx) to line.substring(idx + 1).trim()
            }
            .toMap()
    }

    // ── helpers ─────────────────────────────────────────────────────────────

    /** بایت خوانا: 1.2 MB / 345 KB … */
    fun humanBytes(b: Long): String {
        if (b < 1024) return "$b B"
        val units = arrayOf("KB", "MB", "GB", "TB")
        var v = b.toDouble()
        var u = 0
        while (v >= 1024.0 && u < units.size - 1) { v /= 1024.0; u++ }
        return String.format(java.util.Locale.US, "%.1f %s", v, units[u])
    }
}

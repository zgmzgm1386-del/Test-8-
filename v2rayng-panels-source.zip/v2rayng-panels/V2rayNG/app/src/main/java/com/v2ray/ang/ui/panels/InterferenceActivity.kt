package com.v2ray.ang.ui.panels

import androidx.compose.foundation.layout.Column
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import com.v2ray.ang.ui.compose.AppTopBar
import com.therealaleph.mhrv.DnsProbe
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * تب اختلال — پروب‌های لایه‌ای واقعی روی شبکهٔ واقعی (بدون VPN):
 *   DNS (کوئری واقعی UDP/53) → TCP (دست‌دادن واقعی 443) → TLS (دست‌دادن با SNI)
 *   → HTTP (درخواست واقعی). نتیجهٔ هر خط از همان پروب می‌آید؛ شکست‌ها نشان
 *   می‌دهند کدام لایه روی اپراتور کاربر اختلال دارد.
 */
class InterferenceActivity : BasePanelActivity() {

    private data class Check(val name: String, val ok: Boolean, val ms: Int)

    private val resolvers = listOf(
        "1.1.1.1" to "Cloudflare",
        "8.8.8.8" to "Google",
        "9.9.9.9" to "Quad9",
        "178.22.122.100" to "Shecan",
        "10.202.10.10" to "403.online",
        "94.103.125.157" to "Begzar",
    )

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    override fun ScreenContent() {
        val scope = rememberCoroutineScope()
        var running by remember { mutableStateOf(false) }
        var verdict by remember { mutableStateOf("") }
        val checks = remember { mutableStateListOf<Check>() }

        Scaffold(
            topBar = {
                AppTopBar(
                    title = stringResource(R.string.p_title_interference),
                    onBackClick = { finish() },
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        text = stringResource(R.string.p_int_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                    )
                    TextButton(
                        enabled = !running,
                        onClick = {
                            running = true
                            checks.clear()
                            verdict = ""
                            scope.launch(Dispatchers.IO) {
                                suspend fun add(name: String, block: () -> Int) {
                                    val ms = runCatching(block).getOrDefault(-1)
                                    withContext(Dispatchers.Main) {
                                        checks.add(Check(name, ms >= 0, ms))
                                    }
                                }

                                // ۱) DNS واقعی روی رزولورها
                                for ((ip, label) in resolvers) {
                                    add("DNS · $label ($ip)") { DnsProbe.probe(ip, 1, 2500) }
                                }
                                // ۲) TCP واقعی روی 443
                                for ((host, label) in listOf(
                                    "1.1.1.1" to "Cloudflare",
                                    "8.8.8.8" to "Google",
                                    "www.google.com" to "google.com",
                                )) {
                                    add("TCP:443 · $label") { NetTools.tcping(host, 443, 4000) }
                                }
                                // ۳) دست‌دادن واقعی TLS با SNI
                                add("TLS · www.google.com (SNI)") {
                                    val ip = runCatching {
                                        java.net.InetAddress.getByName("www.google.com").hostAddress
                                            ?: ""
                                    }.getOrDefault("")
                                    if (ip.isEmpty()) -1 else NetTools.tlsSniProbe(ip, "www.google.com", 443, 5000)
                                }
                                add("TLS · www.cloudflare.com (SNI)") {
                                    NetTools.tlsSniProbe("104.16.132.229", "www.cloudflare.com", 443, 5000)
                                }
                                // ۴) درخواست واقعی HTTP(S)
                                add("HTTPS · gstatic generate_204") {
                                    val r = NetTools.httpGet("https://www.gstatic.com/generate_204", 8000)
                                    if (r != null && r.status in 200..299) r.latencyMs else -1
                                }
                                add("HTTP · connectivitycheck") {
                                    val r = NetTools.httpGet(
                                        "http://connectivitycheck.gstatic.com/generate_204", 8000
                                    )
                                    if (r != null && r.status in 200..399) r.latencyMs else -1
                                }

                                withContext(Dispatchers.Main) {
                                    val failed = checks.count { !it.ok }
                                    verdict = if (failed == 0)
                                        getString(R.string.p_int_all_ok)
                                    else
                                        getString(R.string.p_int_some_fail, failed, checks.size)
                                    running = false
                                }
                            }
                        },
                    ) {
                        Text(
                            if (running) stringResource(R.string.p_int_running)
                            else stringResource(R.string.p_int_run)
                        )
                    }
                    if (verdict.isNotEmpty()) {
                        SectionHeader(stringResource(R.string.p_int_verdict))
                        Text(
                            text = verdict,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(horizontal = 16.dp),
                        )
                    }
                }

                LazyColumn(modifier = Modifier.weight(1f)) {
                    items(checks) { c ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 6.dp),
                        ) {
                            Text(
                                text = c.name,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.weight(1f),
                            )
                            Text(
                                text = if (c.ok) stringResource(R.string.p_int_ok, c.ms)
                                else stringResource(R.string.p_int_fail),
                                style = MaterialTheme.typography.bodySmall,
                                color = if (c.ok) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.error,
                            )
                        }
                    }
                }
                NavigationBarsSpacer()
            }
        }
    }
}

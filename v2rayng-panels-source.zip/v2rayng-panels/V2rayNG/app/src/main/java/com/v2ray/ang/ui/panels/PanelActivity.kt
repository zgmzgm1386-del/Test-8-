package com.v2ray.ang.ui.panels

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.FormTextField
import com.therealaleph.mhrv.Native
import com.therealaleph.mhrv.VpnState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * تب کنترل پنل — مدیریت اتصال به «پنل» کاربر (Web App گوگل‌اسکریپت خودش):
 *   • ذخیرهٔ endpoint + کلید احراز (منبع واحد با تب Google Script)
 *   • تست اتصال واقعی (POST با فرمت Code.gs → جواب واقعی)
 *   • آمار زندهٔ واقعی رله از Native.statsJson وقتی موتور MHR روشن است
 *   • کپی/ذخیرهٔ Code.gs برای دیپلوی + پرش به تب Google Script برای استارت
 */
class PanelActivity : BasePanelActivity() {

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    override fun ScreenContent() {
        val ctx = this
        val scope = androidx.compose.runtime.rememberCoroutineScope()

        var url by rememberSaveable { mutableStateOf(PanelPrefs.getScriptUrl(ctx)) }
        var key by rememberSaveable { mutableStateOf(PanelPrefs.getAuthKey(ctx)) }
        var testLine by remember { mutableStateOf("") }
        var testing by rememberSaveable { mutableStateOf(false) }
        var stats by remember { mutableStateOf<JSONObject?>(null) }
        var running by remember { mutableStateOf(VpnState.isRunning) }

        LaunchedEffect(Unit) {
            while (isActive) {
                delay(1200)
                running = VpnState.isRunning
                val h = VpnState.proxyHandle
                if (running && h != 0L) {
                    stats = runCatching { JSONObject(Native.statsJson(h)) }.getOrNull()
                }
            }
        }

        Scaffold(
            topBar = {
                AppTopBar(
                    title = stringResource(R.string.p_title_panel),
                    onBackClick = { finish() },
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
            ) {
                FormTextField(
                    label = stringResource(R.string.p_panel_url),
                    value = url,
                    onValueChange = { url = it },
                    placeholder = stringResource(R.string.p_gscript_url_hint),
                    maxLines = 3,
                )
                FormTextField(
                    label = stringResource(R.string.p_panel_key),
                    value = key,
                    onValueChange = { key = it },
                    maxLines = 1,
                )
                ActionButton(title = stringResource(R.string.p_save)) {
                    PanelPrefs.save(ctx, url, key)
                    Toast.makeText(ctx, R.string.p_panel_saved, Toast.LENGTH_SHORT).show()
                }

                ActionButton(
                    title = stringResource(R.string.p_panel_test),
                    enabled = !testing && url.isNotBlank(),
                ) {
                    testing = true
                    testLine = ""
                    scope.launch(Dispatchers.IO) {
                        val res = NetTools.httpPostJson(
                            url.trim(),
                            JSONObject()
                                .put("k", key.trim())
                                .put("u", "https://www.gstatic.com/generate_204")
                                .put("m", "GET")
                                .toString(),
                        )
                        withContext(Dispatchers.Main) {
                            testing = false
                            testLine = if (res != null && res.status in 200..299)
                                getString(R.string.p_gscript_test_ok, res.status, res.latencyMs)
                            else
                                getString(R.string.p_gscript_test_fail)
                        }
                    }
                }
                if (testLine.isNotEmpty()) {
                    Text(
                        text = testLine,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp),
                    )
                }

                SectionHeader(stringResource(R.string.p_panel_stats))
                if (running && stats != null) {
                    val s = stats!!
                    EngineStatusCard(
                        running = true,
                        verified = true,
                        stage = stringResource(R.string.p_running),
                        rows = listOf(
                            stringResource(R.string.p_usage_relay_calls) to s.optLong("relay_calls", 0).toString(),
                            stringResource(R.string.p_usage_relay_failures) to s.optLong("relay_failures", 0).toString(),
                            stringResource(R.string.p_usage_bytes) to NetTools.humanBytes(s.optLong("bytes_relayed", 0)),
                            stringResource(R.string.p_usage_cache_hits) to s.optLong("cache_hits", 0).toString(),
                            stringResource(R.string.p_usage_today_calls) to s.optLong("today_calls", 0).toString(),
                            stringResource(R.string.p_usage_today_bytes) to NetTools.humanBytes(s.optLong("today_bytes", 0)),
                        ),
                    )
                } else {
                    Text(
                        text = stringResource(R.string.p_panel_stats_off),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp),
                    )
                }

                SectionHeader(stringResource(R.string.p_panel_guide))
                Text(
                    text = stringResource(R.string.p_gscript_code_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp),
                )
                ActionButton(title = stringResource(R.string.p_panel_code_copy)) {
                    val code = runCatching { assets.open("Code.gs").bufferedReader().use { it.readText() } }
                        .getOrDefault("")
                    val cm = getSystemService(android.content.ClipboardManager::class.java)
                    cm?.setPrimaryClip(android.content.ClipData.newPlainText("Code.gs", code))
                    Toast.makeText(ctx, R.string.p_copied, Toast.LENGTH_SHORT).show()
                }
                ActionButton(title = stringResource(R.string.p_panel_code_save)) {
                    scope.launch(Dispatchers.IO) {
                        val ok = runCatching {
                            val code = assets.open("Code.gs").bufferedReader().use { it.readText() }
                            val values = android.content.ContentValues().apply {
                                put(android.provider.MediaStore.Downloads.DISPLAY_NAME, "Code.gs")
                                put(android.provider.MediaStore.Downloads.MIME_TYPE, "text/plain")
                            }
                            val uri = contentResolver.insert(
                                android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values
                            ) ?: return@runCatching false
                            contentResolver.openOutputStream(uri)?.use { it.write(code.toByteArray()) }
                            true
                        }.getOrDefault(false)
                        withContext(Dispatchers.Main) {
                            Toast.makeText(
                                ctx,
                                if (ok) R.string.p_panel_code_saved else R.string.p_err_generic,
                                Toast.LENGTH_SHORT,
                            ).show()
                        }
                    }
                }
                ActionButton(title = stringResource(R.string.p_panel_open_gscript)) {
                    runCatching {
                        startActivity(Intent(this@PanelActivity, GscriptActivity::class.java))
                    }
                }
                NavigationBarsSpacer()
            }
        }
    }
}

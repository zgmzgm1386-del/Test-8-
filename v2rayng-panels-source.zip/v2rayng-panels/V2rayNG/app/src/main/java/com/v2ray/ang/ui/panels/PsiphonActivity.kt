package com.v2ray.ang.ui.panels

import android.content.Intent
import androidx.compose.foundation.layout.Column
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import com.v2ray.ang.R
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.FormDropdownField
import com.therealaleph.mhrv.ShkVpnService
import com.therealaleph.mhrv.VpnArbiter
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import org.json.JSONObject
import java.io.File

/**
 * تب سایفون (شیر و خورشید) — موتور shkcore (psiphon-tunnel-core) با پیکربندی
 * تعبیه‌شدهٔ شبکه (res/raw/psi_config.json). کاربر فقط کشور خروجی (اختیاری)
 * انتخاب می‌کند؛ استارت واقعی با ShkVpnService انجام می‌شود.
 */
class PsiphonActivity : BasePanelActivity() {

    private val regions = listOf("", "US", "GB", "DE", "NL", "CA", "SG", "JP", "TR", "SE", "CH")

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    override fun ScreenContent() {
        val ctx = this
        val scroll = rememberScrollState()

        var region by rememberSaveable { mutableStateOf(ShkVpnService.region) }
        var snap by remember { mutableStateOf(snapshot()) }
        var enginePresent by remember { mutableStateOf(engineAvailable()) }

        LaunchedEffect(Unit) {
            while (isActive) {
                delay(600)
                snap = snapshot()
                enginePresent = engineAvailable()
            }
        }

        Scaffold(
            topBar = {
                AppTopBar(
                    title = stringResource(R.string.p_title_psiphon),
                    onBackClick = { finish() },
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(scroll)
            ) {
                EngineStatusCard(
                    running = snap.optBoolean("running", false),
                    verified = snap.optBoolean("verified", false),
                    stage = snap.optString("stage", ""),
                    rows = listOfNotNull(
                        if (snap.optString("ip", "").isNotEmpty())
                            stringResource(R.string.p_exit_ip) to snap.optString("ip") else null,
                        if (snap.optString("loc", "").isNotEmpty())
                            stringResource(R.string.p_location) to snap.optString("loc") else null,
                    ),
                )

                if (!enginePresent) {
                    NoticeLine(stringResource(R.string.p_engine_not_installed, "Psiphon (shkcore)"))
                }
                NoticeLine(stringResource(R.string.p_psiphon_note))

                StartStopButtons(
                    running = snap.optBoolean("running", false),
                    onStart = {
                        ShkVpnService.region = region
                        startEngineArbitrated(VpnArbiter.ENGINE_PSIPHON) {
                            runCatching {
                                Intent(this@PsiphonActivity, ShkVpnService::class.java)
                                    .also { androidx.core.content.ContextCompat.startForegroundService(ctx, it) }
                            }
                        }
                    },
                    onStop = {
                        runCatching {
                            Intent(this@PsiphonActivity, ShkVpnService::class.java)
                                .setAction(ShkVpnService.ACTION_STOP)
                                .also { androidx.core.content.ContextCompat.startForegroundService(ctx, it) }
                        }
                    },
                )

                FormDropdownField(
                    label = stringResource(R.string.p_psiphon_region),
                    value = region,
                    options = regions,
                    onValueChange = { region = it },
                    modifier = Modifier.fillMaxWidth(),
                )

                EngineLogBox(snap.optString("logs", ""))
                NavigationBarsSpacer()
            }
        }
    }

    private fun snapshot(): JSONObject = try {
        JSONObject(ShkVpnService.snapshot())
    } catch (_: Throwable) {
        JSONObject()
    }

    private fun engineAvailable(): Boolean =
        File(applicationInfo.nativeLibraryDir, ShkVpnService.LIB).exists()
}

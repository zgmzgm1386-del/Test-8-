# Third-party notices

This repository combines several open-source components. Each keeps its own
license; the combined work is distributed under **GPL-3.0** (see `LICENSE`).

| Component | Origin | License | Where it lives |
|---|---|---|---|
| v2rayNG (base app) | https://github.com/2dust/v2rayNG | GPL-3.0 | `V2rayNG/` |
| Xray core | https://github.com/XTLS/Xray-core (via AndroidLibXrayLite `libv2ray.aar`) | MPL-2.0 etc. | downloaded at build time |
| hev-socks5-tunnel | https://github.com/heiher/hev-socks5-tunnel | MIT | git submodule, built by `compile-hevtun.sh` |
| mhrv-rs (Rust kernel) | https://github.com/therealaleph/MasterHttpRelayVPN-RUST | MIT | `engines/mhrv-rs` |
| tun2proxy | https://github.com/blechschmidt/tun2proxy (crates.io `tun2proxy`) | MIT | built from `engines/mhrv-rs` dependency tree |
| torbin (Arti wrapper) | https://gitlab.torproject.org/tpo/core/arti | MPL-2.0 / MIT / Apache-2.0 | `engines/torbin` |
| SlipNet CLI | https://github.com/anonvector/SlipNet | AGPL-3.0 | cloned at CI build time → `libslipnet.so` |
| psiphon-tunnel-core (ConsoleClient) | https://github.com/Psiphon-Inc/psiphon-tunnel-core | GPL-3.0 | cloned at CI build time → `libshkcore.so` (best-effort) |
| leaf | https://github.com/eycorsican/leaf | Apache-2.0 | Rust dependency of mhrv-rs |
| Kotlin / AndroidX / Material 3 / coil / okhttp / mmkv / gson | Google & community | Apache-2.0 | Gradle dependencies |

Engine licenses are also shipped verbatim: `engines/mhrv-rs/LICENSE` (MIT),
`engines/torbin` (same crate family), plus the original notices
`V2rayNG/app/src/main/java/com/therealaleph/mhrv/*` file headers.
